// Service worker das notificações. O push chega SEM conteúdo; aqui buscamos o texto pela API
// com o login do usuário. Se o login expirou, mostra um aviso genérico (sem dados pessoais).
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
async function config() {
  try { const c = await caches.open('mobi-config'); const r = await c.match('/__mobi_config'); return r ? await r.json() : null; } catch (e) { return null; }
}
self.addEventListener('push', (ev) => {
  ev.waitUntil((async () => {
    const cfg = await config();
    let itens = [];
    if (cfg && cfg.token) {
      try {
        const r = await fetch(cfg.url.replace(/\/+$/, '') + '/rest/v1/rpc/minhas_notificacoes', {
          method: 'POST', headers: { apikey: cfg.anon, Authorization: 'Bearer ' + cfg.token, 'Content-Type': 'application/json' },
          body: JSON.stringify({ p_limite: 3, p_so_nao_lidas: true }) });
        if (r.ok) itens = await r.json();
      } catch (e) {}
    }
    if (!itens.length) return self.registration.showNotification('Nova atualização', { body: 'Abra o app para ver.', tag: 'mobi', data: { app: cfg && cfg.app } });
    const n = itens[0];
    return self.registration.showNotification(n.titulo, { body: n.mensagem, tag: n.evento, renotify: true, data: { app: cfg.app } });
  })());
});
self.addEventListener('notificationclick', (ev) => {
  ev.notification.close();
  ev.waitUntil(self.clients.matchAll({ type: 'window' }).then((ws) => ws.length ? ws[0].focus() : self.clients.openWindow((ev.notification.data && ev.notification.data.app) || '/')));
});
