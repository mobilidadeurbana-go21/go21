// ===================== NÚCLEO COMUM DOS APPS (gerado a partir de apps/src/core.js) =====================
// Regras: o app NUNCA grava tabela direto. Tudo passa pelas funções do banco (RPC), que validam
// permissão, saldo, limites e auditoria. O app só mostra e chama.
// ordem: CONFIG da página ← configuração gerada no build (window.MOBI_CONFIG) ← tela de configuração (só preenche o que faltar)
const CFG = (() => {
  let salvo = {};
  try { salvo = JSON.parse(localStorage.getItem('mobi_config') || '{}'); } catch (e) {}
  const base = Object.assign({}, CONFIG, Object.fromEntries(Object.entries(window.MOBI_CONFIG || {}).filter(([, v]) => v !== '' && v !== null)));
  return Object.assign(base, Object.fromEntries(Object.entries(salvo).filter(([k, v]) => v && !base[k])));
})();
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
// escapa TUDO que vem do banco ou do usuário antes de ir para o HTML (contra XSS)
const esc = (v) => String(v ?? '').replace(/[&<>"'`]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' }[c]));
const reais = (v) => v === null || v === undefined || v === '' ? '—' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const num = (v, c = 0) => v === null || v === undefined ? '—' : Number(v).toLocaleString('pt-BR', { minimumFractionDigits: c, maximumFractionDigits: c });
const dataHora = (v) => v ? new Date(v).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';
const dataCurta = (v) => v ? new Date(v).toLocaleDateString('pt-BR') : '—';
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : 'x' + Date.now() + Math.random().toString(16).slice(2));
const dorme = (ms) => new Promise((r) => setTimeout(r, ms));
const hojeISO = () => new Date().toISOString().slice(0, 10);

const ERROS = {
  CPF_INVALIDO: 'CPF inválido.', DADOS_JA_CADASTRADOS: 'Esses dados já estão em uso em outra conta.', LIMITE_EXCEDIDO: 'Muitas tentativas. Aguarde alguns minutos.',
  JA_EXISTE_CORRIDA_ATIVA: 'Você já tem uma corrida em andamento.', PAGAMENTO_EM_ABERTO: 'Há um pagamento pendente. Pague antes de pedir outra corrida.',
  FORA_DA_AREA_DE_ATENDIMENTO: 'Esse endereço está fora da área atendida.', CIDADE_NAO_ATENDIDA: 'Cidade ainda não atendida.',
  CATEGORIA_INDISPONIVEL: 'Categoria indisponível nesta cidade.', DESTINO_MUITO_PROXIMO: 'Destino muito próximo da origem.',
  SALDO_INSUFICIENTE: 'Saldo insuficiente.', SEM_PERMISSAO: 'Você não tem permissão para isso.', CONFLITO_DE_INTERESSE: 'Você não pode agir sobre o seu próprio cadastro.',
  CORRIDA_NAO_ENCONTRADA: 'Corrida não encontrada.', STATUS_INVALIDO: 'Essa ação não vale no estado atual da corrida.',
  CATEGORIA_SO_DE_OU_PARA_AEROPORTO: 'Essa categoria só vale de ou para o aeroporto.', CATEGORIA_SO_DE_OU_PARA_TERMINAL: 'Essa categoria só vale de ou para o terminal.',
  CATEGORIA_SO_SAINDO_DE_EVENTO: 'Essa categoria só vale saindo de um evento cadastrado.', DESTINO_DENTRO_DO_MUNICIPIO: 'Para destino na mesma cidade, escolha outra categoria.',
  ANTECEDENCIA_MINIMA: 'Agende com mais antecedência.', ANTECEDENCIA_MAXIMA: 'Data muito distante.', LIMITE_DE_AGENDAMENTOS: 'Você atingiu o limite de agendamentos ativos.',
  CUPOM_INVALIDO: 'Cupom inválido.', CUPOM_EXPIRADO: 'Cupom expirado.', CUPOM_ESGOTADO: 'Cupom esgotado.', CUPOM_JA_USADO: 'Você já usou esse cupom.',
  CUPOM_SO_PRIMEIRA_CORRIDA: 'Cupom válido só na primeira corrida.', CUPOM_NAO_VALE_NESTA_CATEGORIA: 'Cupom não vale para essa categoria.', CUPOM_NAO_VALE_NESTA_CIDADE: 'Cupom não vale nesta cidade.',
  PENDENCIAS_DE_COMPLIANCE: 'Há pendências no seu cadastro.', OFERTA_EXPIRADA: 'A oferta expirou.', OFERTA_INDISPONIVEL: 'Oferta indisponível.',
  LONGE_DO_EMBARQUE: 'Você ainda está longe do ponto de embarque.', GPS_DESATUALIZADO: 'Seu GPS está sem atualização. Verifique a localização.',
  VALOR_ABAIXO_DO_MINIMO: 'Valor abaixo do mínimo para saque.', JA_ASSINANTE: 'Você já é assinante.', CNPJ_INVALIDO: 'CNPJ inválido.',
  SEM_PERMISSAO_NA_EMPRESA: 'Sem permissão nesta empresa.', CATEGORIA_FORA_DA_POLITICA: 'Categoria fora da política da empresa.',
  JUSTIFICATIVA_OBRIGATORIA: 'Informe a justificativa.', LIMITE_MENSAL_ATINGIDO: 'Limite mensal atingido.', LIMITE_DE_CREDITO_DA_EMPRESA: 'Limite de crédito da empresa atingido.',
  EMPRESA_COM_FATURA_VENCIDA: 'A empresa tem fatura vencida.', CONTEXTO_INSUFICIENTE: 'Para bloquear, confirme um sinal ou detalhe a evidência.',
  ASSUMA_O_INCIDENTE_ANTES: 'Assuma o incidente antes de agir.', NOTIFICACAO_ESSENCIAL: 'Esse aviso é essencial e não pode ser desligado.',
  CORRIDA_EM_ANDAMENTO: 'Termine a corrida em andamento antes.', SAQUE_SEU_SALDO_ANTES: 'Saque seu saldo antes de excluir a conta.',
  CADASTRO_INCOMPLETO: 'Complete seu cadastro.', 'JWT expired': 'Sua sessão expirou. Entre de novo.',
};
function mensagemErro(e) {
  const cod = (e && (e.message || e.code)) || String(e);
  if (ERROS[cod]) return ERROS[cod] + (e.details && !/^[A-Z_]+$/.test(e.details) ? ' (' + e.details + ')' : '');
  if (/^[A-Z0-9_]+$/.test(cod)) { const t = cod.toLowerCase().replace(/_/g, ' '); return t.charAt(0).toUpperCase() + t.slice(1) + '.'; }
  if (/Failed to fetch|NetworkError/i.test(cod)) return 'Sem conexão. Verifique a internet.';
  return cod;
}

let sb = null;
function iniciarSupabase() {
  if (!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return false;
  sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, storageKey: 'mobi-auth' } });
  sb.auth.onAuthStateChange((evento) => {
    if (evento === 'PASSWORD_RECOVERY') telaNovaSenha();          // veio do link "esqueci a senha"
    if (evento === 'TOKEN_REFRESHED' || evento === 'SIGNED_IN') atualizarTokenSW();
  });
  return true;
}
// aviso fixo de conexão (some sozinho quando a rede volta)
function avisoRede(on, texto = 'Sem conexão. Tentando de novo…') {
  let b = document.getElementById('aviso-rede');
  if (!on) { if (b) b.remove(); return; }
  if (!b) { b = document.createElement('div'); b.id = 'aviso-rede'; b.setAttribute('role', 'alert');
    b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:200;background:var(--perigo);color:#fff;text-align:center;padding:6px;font-size:.85rem';
    document.body.appendChild(b); }
  b.textContent = texto;
}
window.addEventListener('online', () => avisoRede(false));
window.addEventListener('offline', () => avisoRede(true));
let sessaoExpirada = false;
async function api(fn, args = {}) {
  let res;
  try { res = await sb.rpc(fn, args); }
  catch (e) { avisoRede(true); throw new Error('Failed to fetch'); }
  const { data, error, status } = res;
  if (error) {
    if (/Failed to fetch|NetworkError|fetch failed/i.test(error.message || '')) avisoRede(true); else avisoRede(false);
    // sessão vencida/inválida: volta para o login em vez de mostrar telas vazias
    if ((status === 401 || /JWT expired|invalid JWT|PGRST30/i.test(error.message + ' ' + (error.code || ''))) && !sessaoExpirada) {
      sessaoExpirada = true; toast('Sua sessão expirou. Entre de novo.', true);
      setTimeout(async () => { await sb.auth.signOut({ scope: 'local' }).catch(() => {}); location.reload(); }, 1500);
    }
    const e = new Error(error.message); e.details = error.details; e.code = error.code; throw e;
  }
  avisoRede(false);
  return data;
}
// erros inesperados das telas vão para a equipe (sem dados pessoais: só mensagem e tela)
let errosEnviados = 0;
window.addEventListener('error', (ev) => reportarErro(ev.message, { arquivo: ev.filename, linha: ev.lineno }));
window.addEventListener('unhandledrejection', (ev) => reportarErro(String(ev.reason && ev.reason.message || ev.reason), {}));
function reportarErro(msg, ctx) {
  if (!sb || errosEnviados++ > 5 || !msg) return;
  sb.rpc('registrar_erro_app', { p_app: location.pathname.split('/').pop() || 'index', p_mensagem: String(msg).slice(0, 400), p_contexto: { ...ctx, tela: location.hash } }).then(() => {}, () => {});
}
async function tabela(nome, monta) {
  let qb = sb.from(nome).select(monta.select || '*');
  if (monta.where) qb = monta.where(qb);
  const { data, error } = await qb;
  if (error) throw new Error(error.message);
  return data;
}

let toastTimer;
function toast(msg, erro = false) {
  let t = $('#toast'); if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  t.textContent = msg; t.className = 'on' + (erro ? ' erro' : '');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.className = ''), erro ? 5200 : 3000);
}
// executa ação de botão com trava (evita clique duplo) e mensagem de erro amigável
async function acao(botao, fn) {
  if (botao && botao.disabled) return;
  const txt = botao ? botao.innerHTML : '';
  if (botao) { botao.disabled = true; botao.innerHTML = '<span class="carregando"></span>'; }
  try { return await fn(); }
  catch (e) { console.error(e); toast(mensagemErro(e), true); }
  finally { if (botao) { botao.disabled = false; botao.innerHTML = txt; } }
}
function modal(html, aoAbrir) {
  const f = document.createElement('div'); f.className = 'modal-fundo';
  f.innerHTML = `<div class="modal" role="dialog" aria-modal="true" tabindex="-1">${html}</div>`;
  f.addEventListener('click', (ev) => { if (ev.target === f) fechar(); });
  const anterior = document.activeElement;
  const esc_ = (ev) => { if (ev.key === 'Escape') fechar(); };
  const fechar = () => { f.remove(); document.removeEventListener('keydown', esc_); if (anterior && anterior.focus) anterior.focus(); };
  document.addEventListener('keydown', esc_);
  document.body.appendChild(f);
  setTimeout(() => { const alvo = f.querySelector('input,select,textarea,button') || f.querySelector('.modal'); alvo && alvo.focus(); }, 0);
  $$('[data-fechar]', f).forEach((b) => b.addEventListener('click', fechar));
  if (aoAbrir) aoAbrir(f, fechar);
  return fechar;
}
function confirmar(texto, okTxt = 'Confirmar', perigo = false) {
  return new Promise((res) => {
    modal(`<p>${esc(texto)}</p><div class="linha"><button class="sec cresce" data-fechar>Voltar</button><button class="cresce ${perigo ? 'perigo' : ''}" id="ok-conf">${esc(okTxt)}</button></div>`,
      (f, fechar) => { $('#ok-conf', f).onclick = () => { fechar(); res(true); }; $$('[data-fechar]', f).forEach((b) => b.addEventListener('click', () => res(false))); });
  });
}
function baixar(nome, conteudo, tipo = 'application/json') {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([conteudo], { type: tipo })); a.download = nome; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
function posicaoAtual(timeout = 8000) {
  return new Promise((res) => {
    if (!navigator.geolocation) return res(null);
    navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude, precisao: p.coords.accuracy }), () => res(null),
      { enableHighAccuracy: true, timeout, maximumAge: 10000 });
  });
}
// gráfico de barras/linhas em SVG (sem biblioteca)
function grafico(series, { altura = 160, tipo = 'barra', rotulos = [], formato = (v) => num(v) } = {}) {
  const vals = series.flatMap((s) => s.valores.map(Number).filter((v) => Number.isFinite(v)));
  const max = Math.max(1, ...vals), min = Math.min(0, ...vals), L = 600, A = altura, m = 22, n = Math.max(1, series[0]?.valores.length || 1);
  const y = (v) => A - m - ((v - min) / (max - min || 1)) * (A - 2 * m);
  const larg = (L - 2 * m) / n;
  let s = `<svg class="grafico" viewBox="0 0 ${L} ${A}" role="img"><line x1="${m}" x2="${L - m}" y1="${y(0)}" y2="${y(0)}" stroke="currentColor" opacity=".2"/>`;
  series.forEach((ser, k) => {
    if (tipo === 'barra') ser.valores.forEach((v, i) => {
      const bw = larg / series.length * .8, x = m + i * larg + k * bw + larg * .1, yv = y(Math.max(0, v)), h = Math.abs(y(v) - y(0));
      s += `<rect x="${x}" y="${v >= 0 ? yv : y(0)}" width="${bw}" height="${Math.max(h, .5)}" rx="2" fill="${ser.cor || 'var(--pri)'}"><title>${esc((rotulos[i] || '') + ': ' + formato(v))}</title></rect>`;
    });
    else s += `<polyline fill="none" stroke="${ser.cor || 'var(--pri)'}" stroke-width="2.5" points="${ser.valores.map((v, i) => `${m + i * larg + larg / 2},${y(v)}`).join(' ')}"/>`;
  });
  const passo = Math.ceil(n / 8);
  rotulos.forEach((r, i) => { if (i % passo === 0) s += `<text x="${m + i * larg + larg / 2}" y="${A - 6}" text-anchor="middle">${esc(r)}</text>`; });
  s += `<text x="${m}" y="12">${esc(formato(max))}</text></svg>`;
  return s;
}
// tela de configuração (primeiro uso): URL e chave pública do Supabase
function telaConfiguracao(alvo) {
  alvo.innerHTML = `<div class="app"><h1>Configurar o app</h1>
    <p class="sub">Informe os dados do projeto Supabase (Configurações → API). A chave <b>anon</b> é pública por natureza; a segurança está nas regras do banco.</p>
    <label>URL do projeto</label><input id="cfg-url" placeholder="https://xxxx.supabase.co">
    <label>Chave anon (public)</label><input id="cfg-chave" placeholder="eyJ...">
    <p></p><button class="cheio" id="cfg-ok">Salvar</button>
    <p class="sub peq">Para publicar, preencha o bloco CONFIG no topo do arquivo HTML em vez de usar esta tela.</p></div>`;
  $('#cfg-ok').onclick = () => {
    localStorage.setItem('mobi_config', JSON.stringify({ SUPABASE_URL: $('#cfg-url').value.trim(), SUPABASE_ANON_KEY: $('#cfg-chave').value.trim() }));
    location.reload();
  };
}
// ---------- login / cadastro (Supabase Auth) ----------
function telaLogin(alvo, { titulo, aoEntrar, permitirCadastro = true }) {
  alvo.innerHTML = `<div class="app"><h1>${esc(titulo)}</h1>
    <div class="card"><label for="lg-email">E-mail</label><input id="lg-email" type="email" autocomplete="email">
    <label for="lg-senha">Senha</label><input id="lg-senha" type="password" autocomplete="current-password" minlength="8">
    <p></p><button class="cheio" id="lg-entrar">Entrar</button>
    ${permitirCadastro ? '<p></p><button class="cheio sec" id="lg-criar">Criar conta</button>' : ''}
    <p class="cent"><a href="#" id="lg-esqueci">Esqueci a senha</a></p></div></div>`;
  const email = () => $('#lg-email').value.trim(), senha = () => $('#lg-senha').value;
  $('#lg-entrar').onclick = (ev) => acao(ev.currentTarget, async () => {
    const { error } = await sb.auth.signInWithPassword({ email: email(), password: senha() });
    if (error) throw new Error(/Invalid login/i.test(error.message) ? 'E-mail ou senha incorretos.' : error.message);
    aoEntrar();
  });
  if (permitirCadastro) $('#lg-criar').onclick = (ev) => acao(ev.currentTarget, async () => {
    if (senha().length < 8) throw new Error('A senha precisa ter pelo menos 8 caracteres.');
    const { data, error } = await sb.auth.signUp({ email: email(), password: senha() });
    if (error) throw new Error(error.message);
    if (!data.session) { toast('Enviamos um link de confirmação para o seu e-mail.'); return; }
    aoEntrar();
  });
  $('#lg-esqueci').onclick = async (ev) => {
    ev.preventDefault();
    if (!email()) return toast('Digite seu e-mail primeiro.', true);
    await sb.auth.resetPasswordForEmail(email(), { redirectTo: location.href.split('#')[0] });
    toast('Se o e-mail existir, enviamos o link para criar nova senha.');
  };
}
async function sair() {
  await sb.auth.signOut().catch(() => {}); localStorage.removeItem('mobi-auth');
  try { if ('caches' in window) await caches.delete('mobi-config'); } catch (e) {}   // o aparelho não guarda mais o acesso
  location.hash = ''; location.reload();
}
// link do e-mail "esqueci a senha": o usuário define a nova senha aqui
function telaNovaSenha() {
  modal(`<h2>Criar nova senha</h2><label for="ns-1">Nova senha (mín. 8)</label><input id="ns-1" type="password" autocomplete="new-password" minlength="8">
    <label for="ns-2">Repita a senha</label><input id="ns-2" type="password" autocomplete="new-password"><p></p><button class="cheio" id="ns-ok">Salvar senha</button>`, (f, fechar) => {
    $('#ns-ok', f).onclick = (ev) => acao(ev.currentTarget, async () => {
      const a = $('#ns-1', f).value; if (a.length < 8) throw new Error('A senha precisa ter pelo menos 8 caracteres.'); if (a !== $('#ns-2', f).value) throw new Error('As senhas não conferem.');
      const { error } = await sb.auth.updateUser({ password: a }); if (error) throw new Error(error.message);
      fechar(); toast('Senha alterada.'); });
  });
}
async function usuarioAtual() { const { data } = await sb.auth.getSession(); return data.session ? data.session.user : null; }

// formulário de "completar cadastro" (perfil da plataforma)
async function telaCompletarCadastro(alvo, { motorista = false, aoConcluir }) {
  const cidades = await tabela('cidades', { select: 'id,nome,uf,centro_lat,centro_lng', where: (q) => q.eq('ativa', true).order('nome') });
  const codigoUrl = new URLSearchParams(location.search).get('codigo') || localStorage.getItem('mobi_codigo') || '';
  const u = await usuarioAtual();
  alvo.innerHTML = `<div class="app"><h1>Complete seu cadastro</h1><div class="card">
    <label for="cc-nome">Nome completo</label><input id="cc-nome" autocomplete="name">
    <label for="cc-tel">Celular (com DDD)</label><input id="cc-tel" inputmode="tel" autocomplete="tel" placeholder="21 99999-9999">
    <label for="cc-cpf">CPF</label><input id="cc-cpf" inputmode="numeric" placeholder="000.000.000-00">
    <label for="cc-cidade">Cidade</label><select id="cc-cidade">${cidades.map((c) => `<option value="${c.id}">${esc(c.nome)} – ${esc(c.uf)}</option>`).join('')}</select>
    <label for="cc-cod">Código de indicação (opcional)</label><input id="cc-cod" value="${esc(codigoUrl)}">
    <label class="chk"><input type="checkbox" id="cc-termos"> Li e aceito os <a href="${esc(CFG.URL_TERMOS || '#')}" target="_blank" rel="noopener">Termos de Uso</a></label>
    <label class="chk"><input type="checkbox" id="cc-priv"> Li e aceito a <a href="${esc(CFG.URL_PRIVACIDADE || '#')}" target="_blank" rel="noopener">Política de Privacidade</a> (inclui uso da localização durante as corridas)</label>
    <label class="chk"><input type="checkbox" id="cc-mkt"> Quero receber promoções (opcional, pode desligar quando quiser)</label>
    <p></p><button class="cheio" id="cc-ok">Continuar</button></div></div>`;
  $('#cc-ok').onclick = (ev) => acao(ev.currentTarget, async () => {
    if (!$('#cc-termos').checked || !$('#cc-priv').checked) throw new Error('É preciso aceitar os Termos e a Política de Privacidade.');
    const r = await api('completar_cadastro', {
      p_nome: $('#cc-nome').value.trim(), p_telefone: $('#cc-tel').value, p_cpf: $('#cc-cpf').value, p_email: u.email,
      p_cidade: $('#cc-cidade').value, p_quer_ser_motorista: motorista, p_codigo_indicacao: $('#cc-cod').value.trim() || null,
      p_dispositivo: dispositivoId(), p_versao_termos: CFG.VERSAO_TERMOS || 'v1',
    });
    if (r && r.ok === false) throw new Error(r.erro);
    await api('registrar_consentimento', { p_tipo: 'TERMOS', p_versao: CFG.VERSAO_TERMOS || 'v1', p_aceito: true });
    await api('registrar_consentimento', { p_tipo: 'PRIVACIDADE', p_versao: CFG.VERSAO_TERMOS || 'v1', p_aceito: true });
    await api('registrar_consentimento', { p_tipo: 'MARKETING', p_versao: CFG.VERSAO_TERMOS || 'v1', p_aceito: $('#cc-mkt').checked });
    if (r && r.aviso_indicacao) toast(r.aviso_indicacao);
    aoConcluir();
  });
}
function dispositivoId() {
  let d = localStorage.getItem('mobi_dispositivo');
  if (!d) { d = uuid(); localStorage.setItem('mobi_dispositivo', d); }
  return d;
}
// notificações push (PWA): o toque chega sem texto, o service worker busca pela API
async function ativarPush() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !CFG.VAPID_PUBLICA) throw new Error('Este navegador não suporta notificações ou o push não foi configurado.');
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') throw new Error('Permissão de notificação negada.');
  const reg = await navigator.serviceWorker.register('/sw.js');
  const chave = Uint8Array.from(atob(CFG.VAPID_PUBLICA.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((CFG.VAPID_PUBLICA.length + 3) % 4)), (c) => c.charCodeAt(0));
  const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: chave });
  const j = sub.toJSON();
  await api('registrar_push', { p_endpoint: j.endpoint, p_p256dh: j.keys.p256dh, p_auth: j.keys.auth, p_navegador: navigator.userAgent.slice(0, 80) });
  await atualizarTokenSW();
  toast('Notificações ativadas.');
}
// o service worker busca o texto das notificações com o login do usuário (guardado só neste aparelho)
async function atualizarTokenSW() {
  try {
    if (!('caches' in window)) return;
    const s = (await sb.auth.getSession()).data.session;
    const c = await caches.open('mobi-config');
    await c.put('/__mobi_config', new Response(JSON.stringify({ url: CFG.SUPABASE_URL, anon: CFG.SUPABASE_ANON_KEY, token: s ? s.access_token : null, app: location.pathname })));
  } catch (e) {}
}
async function registrarAcesso() { try { await api('registrar_acesso', { p_dispositivo: dispositivoId(), p_plataforma: 'WEB' }); } catch (e) {} }
// mapa (Leaflet + OpenStreetMap). Em produção, troque o provedor de mapa em CONFIG.MAPA_TILES.
function criarMapa(el, centro, zoom = 14) {
  const m = L.map(el, { zoomControl: true, attributionControl: true }).setView([centro.lat, centro.lng], zoom);
  L.tileLayer(CFG.MAPA_TILES || 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: CFG.MAPA_ATRIBUICAO || '&copy; OpenStreetMap' }).addTo(m);
  return m;
}
const corNivel = { ALTA: '#c62828', MODERADA: '#e07b00', NORMAL: '#1f7a3a', BAIXA: '#7a8594' };
// busca de endereço (geocodificação). Padrão: Nominatim (OSM) com limite de 1 req/s — em produção use um provedor contratado.
let geoTimer;
function buscarEndereco(texto, perto) {
  return new Promise((res) => {
    clearTimeout(geoTimer);
    geoTimer = setTimeout(async () => {
      if (!texto || texto.length < 4) return res([]);
      try {
        const url = (CFG.GEOCODER_URL || 'https://nominatim.openstreetmap.org/search') + '?format=json&addressdetails=0&limit=6&countrycodes=br&q=' + encodeURIComponent(texto)
          + (perto ? `&viewbox=${perto.lng - .3},${perto.lat + .3},${perto.lng + .3},${perto.lat - .3}` : '');
        const r = await fetch(url, { headers: { 'Accept-Language': 'pt-BR' } });
        res((await r.json()).map((x) => ({ nome: x.display_name, lat: +x.lat, lng: +x.lon })));
      } catch (e) { res([]); }
    }, 700);
  });
}
// ---------- cobrança online (PIX copia-e-cola / link de cartão) ----------
async function obterCobranca(pagamentoId) {
  let c = await api('minha_cobranca', { p_pagamento: pagamentoId });
  if (c.status === 'PENDENTE' && !c.cobranca && CFG.COBRANCA_URL) {
    const s = (await sb.auth.getSession()).data.session;
    const r = await fetch(CFG.COBRANCA_URL, { method: 'POST', headers: { Authorization: 'Bearer ' + s.access_token, apikey: CFG.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ pagamento_id: pagamentoId }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.erro || 'Não foi possível gerar a cobrança agora.'); }
    c = await api('minha_cobranca', { p_pagamento: pagamentoId });
  }
  return c;
}
function htmlCobranca(c) {
  if (!c || c.status !== 'PENDENTE') return '';
  const cb = c.cobranca || {};
  if (cb.pix_copia_cola) return `<div class="cent"><div id="qr-pix" style="display:inline-block;background:#fff;padding:8px;border-radius:10px"></div></div>
      <label for="pix-cc">PIX copia e cola</label><div class="linha"><input id="pix-cc" class="cresce" readonly value="${esc(cb.pix_copia_cola)}"><button class="mini" id="pix-copiar">Copiar</button></div>
      ${cb.expira_em ? `<div class="sub peq">Válido até ${dataHora(cb.expira_em)}</div>` : ''}`;
  if (cb.link) return `<a class="btn cheio" href="${esc(cb.link)}" target="_blank" rel="noopener">Pagar com cartão</a>`;
  return CFG.COBRANCA_URL ? '<div class="sub">Gerando cobrança…</div>' : '<div class="sub">Pagamento online ainda não configurado nesta instalação.</div>';
}
function ligarCobranca(el) {
  const inp = $('#pix-cc', el); if (!inp) return;
  try { if (window.qrcode) { const q = qrcode(0, 'M'); q.addData(inp.value); q.make(); $('#qr-pix', el).innerHTML = q.createSvgTag({ cellSize: 4, margin: 2 }); } } catch (e) {}
  $('#pix-copiar', el).onclick = async () => { await navigator.clipboard.writeText(inp.value).catch(() => { inp.select(); document.execCommand('copy'); }); toast('Código PIX copiado.'); };
}
// ===================== fim do núcleo =====================
