// Gera os apps HTML de arquivo único em site/ a partir de apps/src/.
//   node apps/build.js
// - injeta o núcleo comum (core.css + core.js) em cada página
// - troca <!--LIB:...--> pela tag do CDN com SRI (hash de integridade calculado do pacote npm de mesma versão)
// - copia service worker, manifest e ícone; gera vercel.json com rotas e cabeçalhos de segurança
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const RAIZ = path.join(__dirname, '..');
const SRC = path.join(__dirname, 'src');
const OUT = path.join(RAIZ, 'site');
const nm = (p) => path.join(RAIZ, 'node_modules', p);
const versao = (pkg) => JSON.parse(fs.readFileSync(nm(pkg + '/package.json'), 'utf8')).version;

const LIBS = {
  'leaflet.css': { pkg: 'leaflet', arq: 'dist/leaflet.css', tipo: 'css' },
  'leaflet.js': { pkg: 'leaflet', arq: 'dist/leaflet.js', tipo: 'js' },
  'supabase.js': { pkg: '@supabase/supabase-js', arq: 'dist/umd/supabase.js', tipo: 'js' },
  'qrcode.js': { pkg: 'qrcode-generator', arq: 'qrcode.js', tipo: 'js' },
};
function tagLib(nome) {
  const l = LIBS[nome];
  if (!l) throw new Error('lib desconhecida: ' + nome);
  const conteudo = fs.readFileSync(nm(`${l.pkg}/${l.arq}`));
  const sri = 'sha384-' + crypto.createHash('sha384').update(conteudo).digest('base64');
  const url = `https://cdn.jsdelivr.net/npm/${l.pkg}@${versao(l.pkg)}/${l.arq}`;
  return l.tipo === 'css'
    ? `<link rel="stylesheet" href="${url}" integrity="${sri}" crossorigin="anonymous">`
    : `<script src="${url}" integrity="${sri}" crossorigin="anonymous"></script>`;
}

// configuração de produção: apps/config.json (não vai para o git) ou variáveis MOBI_*.
// Ex.: { "SUPABASE_URL": "https://xxxx.supabase.co", "SUPABASE_ANON_KEY": "...", "VAPID_PUBLICA": "...", "COBRANCA_URL": "...", ... }
const arqCfg = path.join(__dirname, 'config.json');
const cfg = fs.existsSync(arqCfg) ? JSON.parse(fs.readFileSync(arqCfg, 'utf8')) : {};
for (const [k, v] of Object.entries(process.env)) if (k.startsWith('MOBI_') && v) cfg[k.slice(5)] = v;
if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
  if (process.argv.includes('--exigir-config')) { console.error('ERRO: faltam SUPABASE_URL e SUPABASE_ANON_KEY em apps/config.json (ou MOBI_SUPABASE_URL / MOBI_SUPABASE_ANON_KEY).'); process.exit(1); }
  console.warn('  AVISO: sem apps/config.json — as páginas vão pedir URL e chave na primeira abertura (bom só para testes).');
}
const cfgPublica = Object.fromEntries(Object.entries(cfg).filter(([k]) => !/SERVICE|SECRET|SEGREDO|PRIVAD/i.test(k)));   // nunca publicar segredo
const tagCfg = `<script>window.MOBI_CONFIG = ${JSON.stringify(cfgPublica).replace(/</g, '\\u003c')};</script>`;
const host = (u) => { try { return new URL(u).origin; } catch (e) { return null; } };
const hostTiles = (u) => { try { return new URL(u.replace('{s}', 'a').replace(/\{[xyz]\}/g, '0')).origin.replace('://a.', '://*.'); } catch (e) { return null; } };

fs.mkdirSync(OUT, { recursive: true });
const css = fs.readFileSync(path.join(SRC, 'core.css'), 'utf8');
const js = fs.readFileSync(path.join(SRC, 'core.js'), 'utf8');
const paginas = fs.readdirSync(SRC).filter((f) => f.endsWith('.html'));
for (const p of paginas) {
  let h = fs.readFileSync(path.join(SRC, p), 'utf8');
  h = h.replace('/*CORE_CSS*/', () => css).replace('/*CORE_JS*/', () => js).replace(/<!--LIB:([a-z.]+)-->/g, (_, n) => tagLib(n));
  if (h.includes('<script>\nconst CONFIG')) h = h.replace('<script>\nconst CONFIG', () => tagCfg + '\n<script>\nconst CONFIG');
  else if (h.includes('<script>\n// ======== CONFIGURAÇÃO')) h = h.replace('<script>\n// ======== CONFIGURAÇÃO', () => tagCfg + '\n<script>\n// ======== CONFIGURAÇÃO');
  if (/\/\*CORE_|<!--LIB:/.test(h)) throw new Error('marcador não substituído em ' + p);
  fs.writeFileSync(path.join(OUT, p), h);
  console.log('  site/' + p.padEnd(18) + (h.length / 1024).toFixed(0).padStart(4) + ' KB');
}
for (const f of ['sw.js', 'manifest.webmanifest', 'icone.svg']) fs.copyFileSync(path.join(SRC, f), path.join(OUT, f));

// cabeçalhos de segurança (Vercel). connect-src libera o Supabase, o geocodificador e os mapas.
// a CSP acompanha a configuração (Supabase com domínio próprio, provedor de mapa e de busca de endereço)
const sbHost = host(cfg.SUPABASE_URL) || 'https://*.supabase.co';
const extrasConnect = [sbHost, sbHost.replace('https://', 'wss://'), 'https://*.supabase.co', 'wss://*.supabase.co',
  host(cfg.GEOCODER_URL) || 'https://nominatim.openstreetmap.org', host(cfg.COBRANCA_URL), host(cfg.ASSISTENTE_URL)].filter(Boolean);
const extrasImg = [cfg.MAPA_TILES ? hostTiles(cfg.MAPA_TILES) : 'https://*.tile.openstreetmap.org', sbHost, 'https://*.supabase.co'].filter(Boolean);
const csp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
  "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
  `img-src 'self' data: blob: https://cdn.jsdelivr.net ${[...new Set(extrasImg)].join(' ')}`,
  `connect-src 'self' ${[...new Set(extrasConnect)].join(' ')}`,
  "worker-src 'self'", "manifest-src 'self'", "frame-ancestors 'none'", "base-uri 'self'", "form-action 'self'", "object-src 'none'",
].join('; ');
const vercel = {
  cleanUrls: false,
  rewrites: [
    { source: '/c/:codigo', destination: '/motorista.html?codigo=:codigo' },
    { source: '/v/:token', destination: '/acompanhar.html?t=:token' },
  ],
  headers: [
    { source: '/(.*)', headers: [
      { key: 'Content-Security-Policy', value: csp },
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'Permissions-Policy', value: 'geolocation=(self), camera=(self), microphone=()' },
      { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' },
      { key: 'X-Frame-Options', value: 'DENY' },
    ] },
    { source: '/admin.html', headers: [{ key: 'X-Robots-Tag', value: 'noindex, nofollow' }, { key: 'Cache-Control', value: 'no-store' }] },
    { source: '/acompanhar.html', headers: [{ key: 'X-Robots-Tag', value: 'noindex, nofollow' }, { key: 'Referrer-Policy', value: 'no-referrer' }] },
    { source: '/sw.js', headers: [{ key: 'Cache-Control', value: 'no-cache' }] },
  ],
};
fs.writeFileSync(path.join(OUT, 'vercel.json'), JSON.stringify(vercel, null, 2));
console.log('  site/vercel.json, sw.js, manifest.webmanifest, icone.svg');
