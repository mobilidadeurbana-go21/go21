# Auditoria da Etapa 2

Duas rodadas: (1) o que os testes automatizados pegaram durante a construção; (2) auditoria **independente** em três frentes (segurança/LGPD/antifraude · financeiro/QA/operação · UX/arquitetura/DevOps), feita por revisores que não escreveram o código, com reprodução real em banco próprio. Tudo que foi corrigido tem teste que falharia se o problema voltasse (Etapa 2 › "CORREÇÕES DA AUDITORIA DA ETAPA 2", testes de funções e E2E).

## 1. Encontrados pelos testes durante a construção

| # | Problema | Correção |
|---|---|---|
| 1 | Exportação de dados (LGPD) dava erro sempre (variável com nome ambíguo) | Corrigida em 0006 + teste |
| 2 | Gestor de uma empresa podia sobrescrever política/departamento de outra (upsert por id) | Id informado precisa ser da própria empresa (0010) + teste |
| 3 | Cancelar o Mobi+ cortava benefícios já pagos; reassinar cobrava de novo | Benefício vale até o fim do período; reativação sem cobrança (0010) + teste |
| 4 | Painel do motorista mostrava R$/hora absurdo com poucos minutos online | Só calcula com 15 min+ (0014) |
| 5 | Teste de carga: clique duplo em "pedir corrida" às vezes dava erro em vez de devolver a mesma corrida | Pedidos do mesmo passageiro serializados (0012) |
| 6 | Teste de carga: radar recalculava a cidade inteira por motorista (p50 700 ms) | Cache de 30 s com proteção contra "efeito manada" (p50 ~100 ms) (0012) |
| 7 | Inteligência/assistentes: SQL inválido no histórico, agregação no GROUP BY, códigos de zona como nome, formatação BR | Corrigidos em 0007/0008 |

## 2. Auditoria independente — segurança, LGPD e antifraude

| Sev. | Achado | Correção | Onde |
|---|---|---|---|
| CRÍTICO | Qualquer pessoa assumia uma empresa digitando no perfil o e-mail de um convite pendente (e-mail não verificado) | Convite só casa com contato **confirmado no Auth**, aceite explícito (`meus_convites_empresa`, `responder_convite_empresa`) | 0010 |
| ALTO | ADMIN apagava toda a auditoria configurando retenção 0 | Retenção só SUPER_ADMIN, com piso legal no job e na configuração | 0006 |
| ALTO | XSS armazenado no mapa do admin (tooltip do Leaflet) permitiria a um papel menor agir como SUPER_ADMIN | Escape nas telas + banco recusa `<` `>` em nomes exibidos | admin.html, 0015 |
| MÉDIO/ALTO | Limite de crédito da empresa estourava com pedidos simultâneos | Trava da empresa no pedido corporativo | 0010 |
| MÉDIO | "Adicionar funcionário" revelava nome de quem tem conta a partir do telefone | Sempre vira convite; empresa só convida depois de aprovada | 0010 |
| MÉDIO | Exclusão/exportação LGPD ignoravam tabelas novas (favoritos, agendadas, push…) | Ampliadas; pedido de exclusão cancela agendamentos | 0015 |
| BAIXO/MÉDIO | SUPORTE/RISCO viam receita pelo assistente | Perguntas financeiras só ADMIN/FINANCEIRO | 0008 |
| BAIXO | Conta de equipe bloqueada mantinha os poderes | Papel de equipe exige conta ATIVA (funções e RLS) | 0015 |

## 3. Auditoria independente — financeiro, QA e operação

| Sev. | Achado | Correção | Onde |
|---|---|---|---|
| CRÍTICO | "Pagar de novo" uma recarga com créditos criava dinheiro (carteira 100 → 400 sem pagar) | Créditos não pagam recarga nem fatura; método validado; confirmação recusa | 0015, 0010 |
| CRÍTICO | Mobi+ grátis trocando PIX por CARTEIRA (reaproveitava a cobrança PIX) | Cobrança pendente de outro método é cancelada; confirmação interna só se o pagamento é de fato CARTEIRA | 0010 |
| ALTO | Nova tentativa de pagamento de assinatura/fatura perdia o vínculo (cobrava e não ativava) | Nova tentativa herda `assinatura_id`/`fatura_id` | 0015 |
| ALTO | Estorno de corrida corporativa depois do fechamento continuava na fatura | Abate da fatura aberta ou crédito na próxima (`empresa_creditos`) | 0010 |
| ALTO | Reembolso em créditos ignorava estorno e desconto; repetição creditava em dobro | Teto = valor efetivamente pago; corrida estornada não recebe; chave do pedido torna idempotente | 0010 |
| MÉDIO | Limite de crédito da empresa sob concorrência | (mesma correção da seção 2) | 0010 |
| MÉDIO | Renovação do Mobi+ não era gerada quando o período caía no mesmo mês | Chave por período (data), não por mês | 0010 |
| MÉDIO | Confirmação atrasada de cobrança substituída quebrava o webhook (reenvio infinito) | Registrada para devolução com sinal; webhook responde e para | 0010 |
| MÉDIO | Painel do dono errava depois de estorno (conferência falhava, lucro errado) | Corridas estornadas saem de GMV/motoristas/descontos; estornos mostrados à parte | 0011 |

## 4. Auditoria independente — UX, arquitetura e DevOps

| Sev. | Achado | Correção |
|---|---|---|
| ALTO | Não havia criação de cobrança no gateway (PIX ficaria "aguardando" para sempre) | Edge Function `criar-cobranca` + `minha_cobranca` + tela com QR e copia-e-cola (adaptador real do gateway continua dependência) |
| ALTO | Atualização a cada 3 s apagava PIN, avaliação e gorjeta enquanto a pessoa digitava | Redesenha só quando o estado muda (teste E2E confere) |
| ALTO | Banco nascia em "desenvolvimento" (simulador de pagamento aberto) | Padrão agora é **produção** |
| ALTO | README só instalava 0001–0005; configuração das telas manual | README completo; build injeta `apps/config.json` e calcula a CSP |
| ALTO | Link `/c/CODIGO` perdia o código e quebrava o service worker | Código lido do caminho; `sw.js`/manifest com caminho absoluto (teste E2E) |
| MÉDIO | "Esqueci a senha" não permitia criar a senha nova | Tela de nova senha no evento de recuperação |
| MÉDIO | Push ficava genérico depois de 1 h; logout não limpava | Token atualizado a cada renovação; logout limpa o cache |
| MÉDIO | Aceite de oferta que falhava não avisava; mensagem de PIN bloqueado | Retorno conferido e mensagem clara |
| MÉDIO | Sem rede/sessão vencida as telas "mentiam" | Aviso de conexão; sessão vencida volta ao login |
| MÉDIO | Contagem da oferta pelo relógio do celular, a cada 3 s | Tempo do servidor, contagem a cada 1 s |
| MÉDIO | Motorista não tinha "passageiro não apareceu" | Botão com a regra de espera mínima do banco |
| MÉDIO | Corrida finalizada sumia ao reabrir o app | Retoma corrida finalizada sem pagamento/avaliação |
| MÉDIO | GPS a cada 4 s mesmo parado; wake lock não voltava | Envio por distância (25 m) ou 20 s parado; wake lock reativado |
| MÉDIO | Contraste no modo escuro; labels; modal sem Esc/foco | Corrigidos |
| MÉDIO | Menu do admin mostrava seções que o papel não usa | Menu alinhado às permissões do banco |
| MÉDIO | CSP fixa bloquearia outro provedor de mapa/busca ou domínio próprio do Supabase; servidores públicos do OSM não servem para produção | CSP calculada a partir de `apps/config.json`; provedor contratado listado como dependência |
| MÉDIO | Erros das telas não chegavam à equipe; ninguém era avisado de problemas | `registrar_erro_app` + vigia de hora em hora |
| BAIXO | Passageiro lia ids de motoristas que recusaram | Coluna fora do acesso dos apps |
| BAIXO | Custos do carro não editáveis depois de configurados | Link "Editar custos" sempre visível |
| BAIXO | Emergência repetida abria vários incidentes | Deduplicação de 3 min |
| BAIXO | Testes não simulavam as permissões padrão do Supabase | Shim agora simula; migration 0015 fecha qualquer tabela que escape |

## 5. Verificado e sem problema
Webhook (HMAC, janela anti-replay, idempotência, registro), funções só de servidor, cupom sob concorrência, políticas de estrutura da empresa, demais pontos de `innerHTML` (todos com escape), assinaturas das chamadas das telas × funções do banco (comparação automática), RLS em todas as tabelas, SRI das bibliotecas.
