# Integrações externas (dependências para produção)

| Integração | Situação no projeto | O que falta |
|---|---|---|
| **Gateway de pagamento** (PIX e cartão) | Webhook assinado e idempotente pronto; Edge Function `criar-cobranca` com adaptador `simulado` (recusado em produção) e modelo de adaptador real | Contratar gateway; escrever o adaptador (~40 linhas) em `supabase/functions/_shared/cobranca.ts`; mapear o formato do webhook dele em `_shared/webhook.ts` (`adaptadores`) usando o **mecanismo de assinatura do próprio gateway**; tokenização de cartão no front do gateway (o projeto nunca recebe número de cartão: só token em `meios_pagamento`, gravado pelo servidor via `registrar_meio_pagamento`) |
| **Repasse PIX ao motorista** | Fila `repasses` e `fin_concluir_repasse` (servidor) prontos | Worker que envia o PIX pelo gateway e chama `fin_concluir_repasse` |
| **SMS / WhatsApp / e-mail** | Fila `notificacoes` por canal (SMS para contatos de confiança na emergência; e-mail/WhatsApp previstos) | Provedor (Twilio, Zenvia…) e um enviador igual ao de push; SMS também no Supabase Auth para login por telefone |
| **Push (Web Push)** | Pronto (VAPID, sem conteúdo, remoção de aparelho inválido) | Gerar chaves VAPID e agendar a função a cada minuto. Em iPhone, push web exige o app "instalado" na tela inicial (iOS 16.4+) |
| **Mapas e busca de endereço** | Leaflet + OpenStreetMap e Nominatim (padrão) | **Não usar o servidor público em produção** (política de uso): contratar provedor de tiles e geocodificação (MapTiler, Mapbox, Google, Here…) e preencher `MAPA_TILES` / `GEOCODER_URL` em `apps/config.json` (a CSP se ajusta no build) |
| **Rotas e trânsito** | Distância/tempo estimados no banco (linha reta × fator) e trilha GPS real na cobrança final | Provedor de rotas (OSRM próprio, Google Directions…) para ETA mais preciso; enviar `p_rota_km/p_rota_min` (já aceitos pelas funções, com saneamento) |
| **Clima** | `registrar_clima` (servidor) pronto | Job que consulta uma API de clima e grava |
| **Modelo de linguagem** | Opcional, com trava de números | Chave e modelo (`ASSISTENTE_LLM_CHAVE`, `ASSISTENTE_MODELO`) |
| **Verificação de documentos/antecedentes** | Envio, análise humana e validade prontos | Provedor de checagem de antecedentes e biometria facial, se desejado |
| **Monitoramento externo** | `saude_sistema`, vigia, `erros_app`, métricas | Ferramenta de alerta (e-mail/telefone de plantão) e exportação de logs do Supabase |
