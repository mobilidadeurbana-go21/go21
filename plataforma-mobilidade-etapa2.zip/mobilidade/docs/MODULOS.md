# Módulos da Etapa 1 — ficha técnica

Para cada módulo: **o que** foi criado · **onde** · **dependências** · **banco** · **APIs** (funções `rpc`) · **segurança** · **testes** · **como validar**.
Todas as APIs são chamadas pelo app com `supabase.rpc('<nome>', { ...parâmetros })`. Testes em `supabase/tests/testes.js` (156 verificações).

---

### 1. Usuários, autenticação e papéis
- **O que:** perfil da plataforma ligado ao login do Supabase Auth; papéis; aparelhos; contatos de confiança.
- **Onde:** `0001_base.sql` (papéis, auditoria, limites), `0002_cadastros.sql` (perfis, dispositivos).
- **Dependências:** Supabase Auth (login por SMS/e-mail, sessão, recuperação, logout).
- **Banco:** `perfis`, `usuario_papeis`, `dispositivos`, `contatos_confianca`, `limites_uso`.
- **APIs:** `completar_cadastro`, `registrar_acesso`, `meu_perfil`, `salvar_contato_confianca`, `tem_papel`.
- **Segurança:** CPF validado e único, nunca devolvido inteiro; mensagem genérica para dado já cadastrado; limite de 5 cadastros/h; login auditado; aparelho compartilhado gera sinal de risco.
- **Testes:** CPF inválido/duplicado, varredura barrada, perfil sem CPF, login auditado, visitante sem acesso.
- **Validar:** criar conta no app → `meu_perfil` mostra papel PASSAGEIRO.

### 2. Cidades e categorias
- **O que:** multi-cidade com regras, requisitos legais, tarifas e categorias por cidade.
- **Onde:** `0002_cadastros.sql`, `seed.sql`.
- **Banco:** `cidades` (regras, requisitos, tributos, horários, regulamentação), `categorias` (15 já catalogadas; 3 ligadas), `cidade_categorias` (tarifas e taxa de cancelamento por cidade).
- **APIs:** leitura direta (`from('cidades')`) e `estimar_corrida`.
- **Segurança:** visitante só vê cidades ativas e categorias ligadas.
- **Validar:** ligar `SETE_LUGARES` em `categorias.disponivel_no_sistema` + habilitar em `cidade_categorias` → aparece na estimativa.

### 3. Motorista, veículo, documentos e compliance
- **O que:** cadastro completo, análise humana, estados PENDENTE → EM_ANALISE → APROVADO → ATIVO / SUSPENSO / BLOQUEADO / INATIVO, pendências calculadas.
- **Onde:** `0002_cadastros.sql`.
- **Dependências:** Storage (bucket privado `documentos`, pasta `<id_do_usuario>/`).
- **Banco:** `motoristas`, `veiculos`, `documentos`.
- **APIs:** `motorista_salvar_dados`, `motorista_cadastrar_veiculo`, `motorista_enviar_documento`, `ops_analisar_documento`, `ops_analisar_veiculo`, `ops_alterar_status_motorista`, `ops_atualizar_cnh`.
- **Compliance:** CNH válida, EAR quando a cidade exige, selfie verificada, documentos obrigatórios da cidade aprovados e no prazo, veículo aprovado, no mesmo município, dentro da idade máxima da categoria. Sem isso não fica online nem aceita corrida. Job diário vence documentos e avisa 15 dias antes.
- **Segurança:** só OPERAÇÕES aprova; BLOQUEIO só RISCO; motivo obrigatório; ninguém aprova a si mesmo; motorista ativo não altera a própria CNH; placa duplicada gera sinal.
- **Testes:** 12 verificações (pendências, caminho do arquivo, permissões, placa, autoaprovação).

### 4. Corrida (ciclo completo)
- **O que:** solicitação → busca → oferta → aceite → deslocamento → chegada → embarque com PIN → corrida → finalização → pagamento → avaliação → repasse.
- **Onde:** `0003_corridas.sql`.
- **Banco:** `corridas`, `corrida_segredos` (PIN), `corrida_eventos` (imutável), `ofertas`, `avaliacoes`, `corrida_trilha`, `motorista_presenca`, `sessoes_online`.
- **APIs passageiro:** `estimar_corrida`, `solicitar_corrida`, `acompanhar_corrida`, `cancelar_corrida`, `avaliar_corrida`, `dar_gorjeta`.
- **APIs motorista:** `ficar_online`, `ficar_offline`, `atualizar_localizacao`, `minha_oferta`, `aceitar_oferta`, `recusar_oferta`, `cheguei`, `iniciar_corrida`, `finalizar_corrida`, `cancelar_corrida`.
- **Segurança:** pedido idempotente; 1 corrida ativa por pessoa (trava no banco); "cheguei" só a até 300 m com GPS recente; PIN com limite de tentativas e invisível ao motorista; km só da trilha do servidor com teto; dívida em aberto bloqueia nova corrida.
- **Testes:** ciclo completo, eventos em ordem, idempotência, concorrência real, cancelamentos com e sem taxa, não comparecimento, corridas travadas.

### 5. Matching e rematching
- **O que:** escolha por score multi-critério, raio crescente, oferta com prazo, rematching automático.
- **Onde:** `interno.candidatos`, `interno.buscar_motorista`, `interno.job_matching` (`0003`).
- **Banco:** pesos em `cidades.regras.matching` (ex.: `{"peso_direcao":4,"peso_ocioso":0.1,"peso_qualidade":2,"peso_cancelamento":10,"peso_aceite":2,"peso_risco":5,"fator_transito":1.2}`).
- **Testes:** motorista mais perto com nota baixa perde para um um pouco mais longe com nota 5; recusa/expiração passam ao próximo; cancelamento volta para busca sem repetir o motorista; raio amplia sozinho.

### 6. Pagamentos
- **O que:** PIX, cartão, carteira, dinheiro (por cidade), gorjeta, taxa de cancelamento, recarga, estorno; cupons com estrutura pronta.
- **Onde:** `0004_financeiro.sql`.
- **Banco:** `pagamentos` (UUID único por pagamento, chave de idempotência), `webhooks_recebidos`, `cupons`, `cupom_usos`.
- **APIs:** `pagar_novamente`, `dar_gorjeta`, `processar_webhook` (só servidor), `dev_simular_pagamento` (só fora de produção), `fin_estornar_corrida`.
- **Segurança:** nenhum dado de cartão armazenado; webhook repetido ignorado; valor divergente não confirma e abre sinal; confirmação com trava de linha.
- **Testes:** 4 webhooks simultâneos = 1 liquidação; valor divergente; dinheiro; falha → pagar de novo.

### 7. Comissões (configuráveis)
- **Banco:** `regras_comissao` — por cidade, categoria, motorista, dia da semana, horário (inclusive virando a meia-noite), campanha, vigência e prioridade. A mais específica vence.
- **APIs:** `admin_salvar_regra_comissao` (ADMIN/FINANCEIRO, auditada).
- **Testes:** padrão 20%; PREMIUM 15% na cidade; janela 22h–2h; arredondamento nunca deixa a plataforma negativa.

### 8. Indicação (3 níveis)
- **Banco:** `indicacoes` (1 indicador por pessoa, trava anticiclo no banco), `ganhos_indicacao` (PENDENTE, DISPONÍVEL, PAGO, BLOQUEADO, ESTORNADO).
- **APIs:** código no cadastro (`completar_cadastro`), `minha_rede` (código, link `/c/<codigo>`, árvore por nível, ganhos, histórico). O QR Code é gerado no app a partir do link.
- **Regras:** só paga sobre corrida válida (km e minutos mínimos) depois de o indicado ter N corridas; carência D+7; autoindicação, ciclo, conta relacionada (aparelho/IP/PIX), passageiro da própria rede e corridas artificiais → valor **retido** até decisão humana.
- **Testes:** divisão exata de R$100; árvore; autoindicação; ciclo; conta relacionada; retenção; liberação/negação humana; estorno com bônus já decidido.

### 9. Carteira e repasses
- **Banco:** ledger (`contas_ledger`, `transacoes_ledger`, `lancamentos_ledger`, `saldos`), `recebiveis`, `repasses`.
- **APIs:** `minha_carteira` (pendente, disponível, indicação, créditos, extrato, saques), `solicitar_repasse`, `fin_concluir_repasse`.
- **Segurança:** imutável; partidas dobradas conferidas no commit; carteira do passageiro não fica negativa; saque com trava de saldo e idempotente; suspeita grave segura o saque (não a conta).
- **Testes:** soma do ledger = 0; saldos batem; 3 saques simultâneos; falha devolve o valor.

### 10. Motorista "gerente financeiro" e motor de rentabilidade
- **Banco:** `custos_motorista` (combustível, consumo, manutenção, pneus, depreciação, seguro, financiamento, outros), `custos_lancados`.
- **APIs:** `salvar_custos`, `lancar_custo`, `painel_motorista(inicio, fim)` (faturamento, combustível, outros custos, resultado, tempo online/em corrida/ocioso, resultado por hora). Antes de aceitar, `minha_oferta.rentabilidade` mostra valor, distância, tempo, combustível, custos, resultado e resultado/hora. **A decisão é do motorista.**

### 11. Segurança da viagem
- **Banco:** `corrida_compartilhamentos`, `incidentes`, `verificacoes_seguranca`, `corrida_trilha`.
- **APIs:** `compartilhar_corrida` / `ver_corrida_compartilhada` (link sem login), `acionar_emergencia` (incidente crítico + SMS aos contatos + suporte), `registrar_denuncia`, `responder_verificacao` (só o passageiro), `suporte_finalizar_corrida`.
- **Detecção:** desvio, parada inesperada e duração anormal geram a pergunta "Está tudo bem?". Sem resposta em 3 min, vira atendimento humano.

### 12. Antifraude
- **Banco:** `sinais_fraude` (entidade, tipo, severidade, ocorrências, status, decisão).
- **Detectores:** aparelho compartilhado, conta relacionada, mesmo par repetido, corridas curtas em série, corrida na própria rede, autoindicação, ciclo, placa duplicada, PIX compartilhado, GPS impossível, km acima do teto, PIN errado repetido, valor divergente, cancelamento excessivo.
- **API:** `risco_decidir_sinal` (confirmar/descartar + ação: nenhuma, negar bônus, suspender, bloquear; motivo obrigatório; auditado).

### 13. Admin, auditoria e notificações
- **APIs:** `admin_indicadores(inicio, fim, cidade, categoria)` (passageiros ativos, motoristas online, corridas, concluídas, canceladas, espera e chegada médias, ticket médio, GMV, receita, repasses, margem, incidentes, fraudes, novos usuários, retenção, por cidade e categoria).
- **Auditoria:** `auditoria` imutável (login, cadastros, status, comissões, pagamentos, estornos, repasses, indicações, decisões de risco, suporte).
- **Notificações:** fila `notificacoes` (IN_APP, PUSH, SMS, EMAIL, WHATSAPP) com eventos de corrida, motorista chegando, cancelamento, pagamento, segurança, documentos, indicação e bônus. `notificacoes_para_enviar` / `notificacao_resultado` (só servidor) para o envio real (Etapa 2).

---

# Módulos da Etapa 2 — ficha técnica

Cada módulo: o que faz · funções principais · garantias · testes.

### 14. Mobility Intelligence
- Zonas de ~1,1 km com nome automático ("Região Central", "Zona Norte (3 km do centro)"); demanda, oferta, tendência, cancelamentos, clima e eventos.
- `interno.prever_demanda` devolve **faixa** (mín–máx) e **confiança**; sempre com `estimativa: true` e aviso.
- `inteligencia_painel`, `ops_tratar_alerta`, `ops_decidir_incentivo` (sugestão nunca vira bônus sem decisão humana), `ops_salvar_regiao`, `ops_salvar_evento`, `registrar_clima` (só servidor).
- Testes: Etapa 2 › RADAR E INTELIGÊNCIA.

### 15. Radar do motorista
- `radar(lat,lng)`: zonas com nível ALTA/MODERADA/NORMAL/BAIXA, título ("Demanda crescente"), explicação (região, +x% em 15 min, motoristas disponíveis, espera estimada em faixa), distância e tempo até a zona, chance estimada.
- Cache de 30 s por cidade (0012) — o cálculo pesado roda 1 vez, não 1 por motorista.

### 16. Assistentes (motorista e admin)
- Motorista: faturamento, gastos, líquido, melhor horário/região, corrida mais rentável, custo por km, meta de amanhã. Admin: corridas, receita, pago a motoristas, crescimento, cancelamentos, pico, falta de motorista, fraude.
- Respostas montadas **só com dados do banco**; sem dados, diz que faltam. Receita/pagamentos só para ADMIN/FINANCEIRO. Camada opcional de linguagem natural com trava de números (`docs/IA.md`).

### 17. Rentabilidade avançada
- `rentabilidade_historico(dias)`: receita, combustível, manutenção, pneus, depreciação, seguro, financiamento, outros, resultado, R$/km e R$/h (só com 15 min+ online). Comparação apenas com o próprio histórico; nenhum ranking pessoal.

### 18. Central de segurança
- Etapas detecção → análise → contato → intervenção → encerramento → registro; ações imutáveis (`incidente_acoes`); grave só encerra com contato registrado; verificação automática pergunta ao passageiro antes de escalar; emergência repetida não duplica.

### 19. Motor de risco
- Relaciona contas por CPF, telefone, aparelho, IP, cartão, PIX, veículo e indicação; pontuação BAIXO/MÉDIO/ALTO com fatores explicados; fila do analista; bloqueio exige sinal confirmado ou justificativa detalhada; CPF completo só com justificativa (auditado).

### 20. Indicação evoluída
- Mantém 20% = motorista 80 / indicação 3-2-1 / plataforma 14 (configurável). Árvore com nomes mascarados, métricas, bônus por status, estornos e auditoria. Antifraude: rede artificial, volume atípico, auto-benefício.

### 21. Mobi Empresas
- Cadastro com CNPJ validado → aprovação de crédito pelo financeiro (sem conflito de interesse). Departamentos, centros de custo, políticas (categorias, limites, dias, horários, justificativa, centro obrigatório).
- Convite por contato **verificado** e aceite explícito. Corrida corporativa liquida contra `EMPRESA_A_RECEBER`; fatura no dia de fechamento; vencida bloqueia novas corridas; estorno depois do fechamento abate a fatura ou vira crédito na próxima.

### 22. Mobi Wallet, cupons e Mobi+
- Recarga (gateway), reembolso em créditos (teto = valor pago, idempotente), cupom (validade, cidade, categoria, usos com trava, teto, mínimo de R$ 1 cobrado; desconto pago pela verba de promoções — motorista recebe 80% do preço cheio).
- Mobi+: desconto, cancelamentos grátis, benefícios até o fim do período pago após cancelar; reativação sem cobrar de novo; renovação por período.

### 23. Driver+ e parceiros
- Níveis BRONZE/PRATA/OURO por atividade e qualidade (aviso explícito: não é promessa de renda). Parceiros por proximidade ("Oficina parceira a 1,8 km"), ofertas por nível/público, código de resgate de uso único validado pela operação.

### 24. Categorias especiais e agendamento
- Requisitos por categoria (padrão nacional + ajuste por cidade): veículo acessível, itens verificados (cadeirinha, porta-malas grande…), capacidade, treinamentos, nota/histórico. Regras geográficas: aeroporto, terminal, eventos, intermunicipal.
- Agendamento com antecedência mín./máx., lembrete, disparo automático (mesmas regras do pedido normal), falha avisada sem cobrança. Compartilhada fica bloqueada (algoritmo de agrupamento não implementado).

### 25. Painel do dono, mapa nacional e analytics
- `dono_dashboard` com filtros (período, cidade, categoria, motorista, passageiro): GMV, comissões, pago a motoristas, indicação, assinaturas, taxas, descontos, reembolsos, custos lançados, gateway estimado, **lucro operacional estimado**, CAC, **LTV estimado**, conferência com o ledger.
- `mapa_operacional`: BRASIL → UF → cidade → região. `analytics_coortes` (retenção por mês da 1ª corrida) e `analytics_funil` (pedido → aceite → início → fim → pagamento, tempos p50/p90, motivos de cancelamento).

### 26. Notificações inteligentes
- Documento vencendo (30/7/1 dias), bônus liberado, manutenção por km, lembrete de agendamento, campanhas só para quem consentiu; intervalo mínimo e máximo diário por tipo, horário de silêncio, avisos essenciais não desligáveis. Push sem conteúdo (o texto é buscado pelo app com login).

### 27. Pagamento online
- `criar-cobranca` gera PIX copia-e-cola/link no gateway (adaptador); a confirmação só vem do webhook assinado (HMAC + janela anti-replay + idempotência + registro de cada tentativa).
