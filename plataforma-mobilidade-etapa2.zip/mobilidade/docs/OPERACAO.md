# Operação: observabilidade, backup e resposta a incidentes

## O que já está no sistema
- **Saúde** (`admin → Saúde do sistema`): job de matching, jobs com erro, soma do ledger, pagamentos pendentes há +1 h, webhooks com assinatura inválida, saques parados, notificações atrasadas, incidentes críticos, sinais graves, corridas sem motorista, latência.
- **Vigia** (job de hora em hora): itens CRÍTICOS viram aviso para ADMIN/OPERAÇÕES (1 por item por hora).
- **Registros:** `jobs_execucoes` (duração, resultado, erro), `webhook_tentativas` (cada chamada do gateway, IP, assinatura, status), `erros_app` (erros das telas, sem dados pessoais), `metricas`, `auditoria` (imutável, 5 anos mínimo).

## Backup e restauração
1. **Produção no plano Pro** com **PITR** (recuperação a qualquer instante) ligado.
2. Exportação semanal criptografada (`pg_dump -Fc`) para outro provedor (S3/GCS), guardada por 90 dias.
3. **Teste de restauração mensal**: restaurar o dump num projeto separado, rodar `select sum(valor) from lancamentos_ledger` (tem que dar 0,00) e conferir contagens de corridas/pagamentos do mês. Registrar data e resultado.
4. Objetivos: RPO ≤ 5 min (PITR), RTO ≤ 2 h.
5. Arquivos de documentos (bucket `documentos`): replicação/exportação semanal separada.

## Plantão — o que fazer quando…
| Sinal | Ação |
|---|---|
| Soma do ledger ≠ 0 | Parar repasses (desligar o worker), abrir incidente técnico, localizar a transação pela auditoria. Nunca corrigir saldo "na mão": lançamento de correção pelo ledger. |
| Webhooks com assinatura inválida | Verificar segredo do gateway e IPs de origem; se for ataque, bloquear na borda. |
| Pagamentos pendentes há +1 h | Conferir a função `criar-cobranca` e o painel do gateway; webhook pode estar falhando (ver `webhook_tentativas`). |
| Sinal "PAGAMENTO_SUBSTITUIDO_CONFIRMADO" / "ASSINATURA_CANCELADA_PAGA" | Cliente pagou duas vezes: devolver pelo gateway e registrar. |
| Job de matching parado | Conferir `cron.job_run_details`; rodar `select public.executar_jobs('rapido')` manualmente. |
| Incidente crítico sem responsável | Suporte assume na Central de Segurança; em perigo imediato orientar 190/192. |

## Retenção (LGPD)
Trilha GPS 180 dias (mín.), notificações 365 (mín. 90), webhooks 730, auditoria 1.825 (5 anos, mín.). Só SUPER_ADMIN altera, nunca abaixo do mínimo. Exclusão de conta: anonimização após 7 dias de carência, mantendo registros financeiros/fiscais anonimizados.
