# Inteligência e assistentes — como funcionam e quais são os limites

## Regra principal
Números vêm do **banco**, nunca de um modelo de linguagem. Toda previsão é **estimativa** e aparece assim na tela (com faixa e nível de confiança).

## Previsão de demanda (`interno.prever_demanda`)
- Base: pedidos dos últimos 15 min, mesmo horário nas últimas semanas (histórico), tendência, clima e eventos cadastrados.
- Saída: `pedidos_previstos`, `faixa_min`–`faixa_max`, `confianca` (MUITO_BAIXA … ALTA conforme semanas de histórico) e `aviso`.
- Pressão da zona = demanda prevista ÷ (motoristas disponíveis + 1) → nível ALTA / MODERADA / NORMAL / BAIXA (limites em `configuracoes.radar_niveis`).
- Limitações: com pouco histórico a faixa é larga e a confiança baixa (o sistema diz isso). Não usa dados externos de trânsito (ver `docs/INTEGRACOES.md`).

## Assistente do motorista (`assistente_motorista`)
Entende 9 perguntas (faturamento, gastos, líquido, melhor horário, melhor região, corrida mais rentável, custo por km, meta de amanhã, ajuda). Cada resposta traz `dados_suficientes` e os `dados` usados. Sem dados: responde que faltam e o que fazer (ex.: configurar custos, cadastrar meta). Nenhuma promessa de ganho.

## Assistente do admin (`assistente_admin`)
Corridas, receita, pago a motoristas, cidade que mais cresceu, cancelamentos, horário de pico, falta de motoristas, fraude. Perguntas financeiras só para ADMIN/FINANCEIRO.

## Camada opcional de linguagem natural (Edge Function `assistente`)
1. A pergunta vai ao banco **com o login da pessoa** (mesmas permissões).
2. Se `ASSISTENTE_LLM_CHAVE` e `ASSISTENTE_MODELO` estiverem configurados, o modelo só reescreve o texto, com instruções de usar apenas os números fornecidos, não prometer ganhos, não comparar pessoas.
3. **Trava:** qualquer número na resposta do modelo que não exista nos dados → a resposta do modelo é descartada e vale a do banco. Links também são bloqueados. Sem dados suficientes, o modelo não fala.
4. Tempo máximo de 8 s; se falhar, vale a resposta do banco.

## Risco e segurança
A pontuação de risco é soma de fatores explicados (não é "caixa-preta") e **nunca bloqueia sozinha**: bloquear exige sinal confirmado ou justificativa detalhada de um analista. A central de segurança pergunta ao passageiro antes de escalar e nunca presume crime.

## Ética e privacidade
Sem ranking por aparência ou características pessoais; comparação de rentabilidade só com o próprio histórico; dados de terceiros mascarados; perguntas ao assistente entram na exportação LGPD e são apagadas na exclusão.
