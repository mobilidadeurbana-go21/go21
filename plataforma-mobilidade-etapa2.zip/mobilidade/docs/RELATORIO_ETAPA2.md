# Relatório final — Etapa 2

Base: Etapa 1 auditada (156 testes). Nada foi recriado: a Etapa 2 entrou como migrations novas (0006–0015), Edge Functions e telas HTML. Funções antigas só foram reescritas quando um problema exigiu, sempre com o mesmo texto mais as linhas marcadas.

## 1. Funcionalidades implementadas
- **Equipe e permissões:** papéis SUPER ADMIN, ADMIN, FINANCEIRO, OPERAÇÕES, RISCO e SUPORTE com matriz de permissões. Só o SUPER ADMIN concede ADMIN. Ninguém age sobre o próprio cadastro, e uma conta bloqueada perde o acesso de equipe.
- **LGPD:**
  - consentimentos versionados;
  - exportação dos dados do titular;
  - exclusão com 7 dias de carência e anonimização;
  - retenção com piso legal;
  - dados mascarados nos painéis;
  - CPF completo só com justificativa registrada na auditoria.
- **Observabilidade:** execução de jobs, métricas, tentativas de webhook, erros das telas, painel de saúde e um vigia que avisa a equipe.
- **Mobility Intelligence e Radar:**
  - zonas com nome;
  - previsão com faixa e confiança, sempre marcada como estimativa;
  - níveis ALTA, MODERADA, NORMAL e BAIXA, cada um com explicação;
  - distância até a zona;
  - alertas e sugestões de incentivo, que dependem de decisão humana.
- **Assistentes:**
  - do motorista: as 9 perguntas;
  - do admin: as 8 perguntas;
  - ambos usam só dados reais e dizem quando os dados não bastam;
  - camada opcional de linguagem natural, com trava contra números inventados.
- **Rentabilidade avançada:** custos completos, histórico, metas, R$/km e R$/hora. A comparação é só com o próprio histórico, sem nenhum ranking pessoal.
- **Central de Segurança:** detecção → análise → contato → intervenção → encerramento → registro, com ações imutáveis e verificação de contexto. O sistema nunca presume crime.
- **Motor de Risco:**
  - relaciona contas por CPF, telefone, aparelho, IP, cartão, PIX, veículo e indicação;
  - pontuação BAIXO, MÉDIO ou ALTO com os fatores explicados;
  - fila para o analista;
  - a pontuação nunca bloqueia sozinha.
- **Indicação evoluída:** mantém 20% = 80/3/2/1/14, configurável. Tem árvore com nomes mascarados, métricas, bônus por status, estornos, auditoria e antifraude (rede artificial, volume atípico, auto-benefício).
- **Mobi Empresas:**
  - CNPJ validado e aprovação de crédito;
  - departamentos, centros de custo e políticas;
  - convites só por contato verificado;
  - corrida corporativa, fatura, bloqueio quando vencida;
  - relatórios e exportação CSV.
- **Mobi Wallet:** créditos, recarga, reembolso em créditos, cupons e pagamentos pendentes. Todo dinheiro passa pelo ledger.
- **Mobi+:** desconto, cancelamentos grátis, renovação, cancelamento sem perder o período pago e reativação.
- **Driver+ e parceiros:** níveis por atividade (sem promessa de renda), parceiros por proximidade ("Oficina parceira a 1,8 km"), ofertas e resgate com código.
- **Categorias especiais:**
  - requisitos verificados pela operação: veículo acessível, itens, capacidade, treinamentos, nota;
  - regras geográficas: aeroporto, terminal, eventos, intermunicipal;
  - modular por cidade.
- **Experiência do passageiro:**
  - agendamento;
  - favoritos;
  - faixas de preço e de chegada;
  - opções da corrida (recado, voo, bagagens);
  - recibo e histórico.
- **Visão do dono:**
  - painel do dono: GMV, comissões, custos, lucro operacional estimado, CAC e LTV estimado, com filtros e conferência contra o ledger;
  - mapa BRASIL → UF → cidade → região;
  - coortes e funil.
- **Notificações inteligentes:** documento vencendo, bônus, manutenção, lembrete de agendamento e campanhas só com consentimento, tudo com limites contra spam.
- **Edge Functions:**
  - webhook de pagamento com HMAC, janela anti-replay, idempotência, registro e tentativas;
  - criação de cobrança;
  - push web sem conteúdo;
  - assistente;
  - jobs.
- **Telas HTML (arquivo único):** passageiro, motorista, empresa, administração (17 seções) e acompanhamento público, com build que injeta a configuração, SRI e CSP.

## 2. Funcionalidades testadas
Todas as listadas acima têm teste automatizado.
- **Banco:**
  - fluxo completo de corrida;
  - cancelamento, fraude, estorno, reembolso, duplicidade;
  - falha de pagamento e pagamento de novo;
  - webhook duplicado, falho e atrasado;
  - queda (motorista sem sinal);
  - corridas e pedidos simultâneos;
  - empresas, cupons, Mobi+, carteira, LGPD, risco, segurança, radar, assistentes, painel do dono, mapa, coortes, notificações, agendamento.
- **API real:** permissões vistas de fora (anônimo, logado, servidor), webhook, cobrança e push.
- **Navegador:** fluxo passageiro → motorista → pagamento → avaliação, clicando nas telas; admin com todas as seções; empresa; link público.

## 3. Testes realizados
| Suíte | Resultado |
|---|---|
| Banco — Etapa 1 (regressão) | **156 OK** |
| Banco — Etapa 2 | **189 OK** |
| Edge Functions contra a API real (PostgREST, o mesmo motor do Supabase) | **40 OK** |
| E2E no navegador (Chromium, clicando nas telas) | **36 OK** |
| Carga e concorrência (ver abaixo) | **todas as invariantes OK** |

**Teste de carga:**
- **Cenário:** 400 passageiros pedindo ao mesmo tempo (metade com clique duplo), 120 motoristas atendendo em paralelo, jobs rodando a cada 300 ms e cada webhook enviado 3 vezes.
- **Invariantes conferidas:**
  - 0 corridas duplicadas;
  - 0 liquidações duplas;
  - ledger fecha em R$ 0,00;
  - 0 motoristas em 2 corridas;
  - 0 ofertas aceitas duas vezes;
  - 0 carteiras negativas;
  - 0 jobs com erro.
- **Latências:** máquina de teste com 2 vCPU e 80 conexões simultâneas (não é capacidade de produção).
  - pedido de corrida: p50 0,3 s, p95 1,3 s;
  - webhook: p50 0,13 s, p95 0,7 s;
  - radar: p50 60 ms;
  - "minha oferta": p50 4 ms.

Todos os testes usam um banco que **simula as permissões padrão do Supabase**, nas quais tabelas novas nascem abertas. Assim provam que as migrations fecham o acesso sozinhas.

## 4. Problemas encontrados
- **Durante a construção:** 7 problemas, detalhados em `docs/AUDITORIA_ETAPA2.md` §1. Exemplos: exportação LGPD quebrada, sobrescrita entre empresas, clique duplo sob carga, radar pesado.
- **Auditoria independente:** 38 achados, feita por três revisores que não escreveram o código, cada um reproduzindo os problemas num banco próprio.
  - **Críticos (3):** tomada de empresa por convite; criação de crédito na carteira via "pagar de novo"; Mobi+ grátis.
  - **Altos (11):** entre eles, auditoria apagável por ADMIN, XSS no mapa do admin, estorno corporativo que ficava na fatura, reembolso acima do pago, ausência de cobrança no gateway, telas que apagavam o PIN, banco nascendo em desenvolvimento, link de indicação quebrado.
  - **Restante:** médios e baixos.

## 5. Problemas corrigidos
**Todos os 45** (7 + 38), cada um com teste que falharia se voltasse. O detalhamento por item, com a correção e o arquivo, está em `docs/AUDITORIA_ETAPA2.md`.

## 6. Riscos restantes
1. **Pagamento real ainda não conectado.** O adaptador do gateway precisa ser escrito com o contrato escolhido. O simulador é recusado em produção, então sem gateway não há cobrança online.
2. **Celular com tela apagada:** o GPS do navegador para. Para operação intensa de motoristas, o caminho é empacotar o app do motorista como app nativo (WebView com serviço de localização em segundo plano).
3. **iPhone:** push web só funciona com o app "instalado" na tela inicial (iOS 16.4+).
4. **Mapas e busca de endereço** usam serviços públicos do OpenStreetMap, que não podem ser usados em produção. É preciso contratar um provedor.
5. **Contas de saldo da plataforma serializam liquidações** em volume muito alto (acima de ~100 pagamentos/s). A mitigação (fracionar o saldo das contas de sistema) está documentada para quando a escala exigir.
6. **Testes rodaram em PostgreSQL 16;** o Supabase usa 15 ou 17. Não há recurso exclusivo da 16 no código, mas é preciso validar na homologação.
7. **Leitura de telefone e e-mail por qualquer papel de equipe:** a equipe consegue ler essas colunas pela API (os painéis mostram mascarado). Se quiser restringir mais, crie visões por papel.
8. **Categoria Compartilhada** está bloqueada (agrupamento de passageiros não implementado). **Agendamento corporativo** ainda não existe.
9. **Instalação da Etapa 1 já feita antes:** confira `configuracoes.ambiente`. O padrão antigo era "desenvolvimento" e precisa ficar "producao".

## 7. Dependências externas
Gateway de pagamento (PIX e cartão, com tokenização), repasse PIX, provedor de SMS/WhatsApp/e-mail, mapas e geocodificação, rotas/trânsito (opcional), clima (opcional), modelo de linguagem (opcional), checagem de antecedentes/biometria (opcional), ferramenta de alertas e logs. Detalhes em `docs/INTEGRACOES.md`.

## 8. Pontos de revisão jurídica
- **Transporte individual:** Lei 13.640/2018 e regulamentação **de cada município** (cadastro, EAR na CNH, seguro APP, idade do veículo, vistoria). Intermunicipal depende de regras estaduais (DER/ANTT) e pode ser proibido em alguns estados. Embarque em aeroportos/terminais depende das concessionárias.
- **Programa de indicação em 3 níveis:** remunera só corrida real paga, sem bônus por cadastro. Mesmo assim, revisar para afastar caracterização de pirâmide ou marketing multinível, e definir o tratamento tributário do bônus.
- **Tributação:**
  - ISS sobre a intermediação;
  - notas fiscais (plataforma, Mobi+, faturas corporativas);
  - retenções;
  - tratamento de cupom e reembolso.
- **CDC:**
  - preço estimado × preço final;
  - taxa de cancelamento e de "não comparecimento";
  - assinatura recorrente (cancelamento fácil);
  - política de reembolso.
- **LGPD:**
  - encarregado (DPO);
  - relatório de impacto (localização, biometria/selfie, antecedentes);
  - bases legais por finalidade;
  - prazos de retenção;
  - contratos com operadores (Supabase, Vercel, gateway, SMS, modelo de linguagem);
  - transferência internacional;
  - termos e política de privacidade.
- **Relação com motoristas:** níveis Driver+, incentivos e regras de cancelamento não podem configurar subordinação. O contrato de adesão precisa ser revisado.
- **Mobi Empresas:** contrato B2B, concessão de crédito, cobrança e inadimplência.
- **Acessibilidade e categoria Familiar:** LBI (Lei 13.146/2015), obrigação de cadeirinha (CTB) e treinamento.
- **Segurança:** a central não substitui 190/192 (deixar claro nos termos). Regras para gravação/compartilhamento de localização com contatos de confiança.
- **IA:** transparência sobre estimativas e sobre o uso de modelo de linguagem.

## 9. Pontos de configuração de produção
1. **Supabase:** Pro, região São Paulo, **PITR ligado**, `pg_cron` e `pg_net`. Auth com confirmação de e-mail, SMTP próprio, CAPTCHA no cadastro e limites do Auth revisados.
2. **Banco:**
   - `ambiente = producao`;
   - cidade, tarifas e regra de comissão reais;
   - documentos exigidos por cidade;
   - prazos de retenção;
   - primeiro SUPER ADMIN.
3. **Segredos das Edge Functions:**
   - `CRON_SEGREDO`, `APP_ORIGEM`;
   - `AMBIENTE=producao`, `GATEWAY=<real>`, `WEBHOOK_SEGREDO_<GATEWAY>`;
   - `VAPID_*`;
   - opcionais: `ASSISTENTE_LLM_CHAVE`, `ASSISTENTE_MODELO`.
4. **Agendamento:** `enviar-notificacoes` a cada minuto (pg_net). Conferir os jobs em Cron Jobs.
5. **Telas:**
   - `apps/config.json` com URL e chave anon, `COBRANCA_URL`, `VAPID_PUBLICA`, URLs de termos e privacidade, telefone de suporte, provedor de mapas;
   - `MODO_TESTE` desligado;
   - `npm run build:producao`.
6. **Vercel:** domínio com HTTPS, pasta `site/` (o `vercel.json` já traz CSP, HSTS, rotas `/c/` e `/v/`).
7. **Gateway:** URL do webhook `…/functions/v1/webhook-pagamento?gateway=<nome>` e segredo de assinatura.
8. **Monitoramento:** contatos de plantão, exportação de logs, backup semanal externo e teste de restauração mensal (`docs/OPERACAO.md`).

## 10. Próximos passos para lançamento
1. Contratar o gateway, escrever o adaptador (cobrança, webhook, repasse PIX) e homologar com dinheiro de teste.
2. Contratar SMS, mapas e geocodificação e configurar.
3. Revisão jurídica (item 8) e publicação de termos e privacidade versionados.
4. Projeto de **homologação** separado: rodar as quatro suítes contra o Supabase real (PostgreSQL 15/17) e repetir o teste de carga no plano contratado.
5. Piloto fechado em uma cidade: 20–50 motoristas aprovados manualmente, passageiros convidados e equipe de suporte com a Central de Segurança aberta.
6. Acompanhar no painel do dono e na saúde do sistema por 2–4 semanas. Ajustar tarifas, raio, pesos do matching e os limites do radar com dados reais (a previsão melhora com histórico).
7. Decidir sobre o app nativo do motorista (GPS com tela apagada) antes de escalar.
8. Abrir gradualmente: Mobi+, Mobi Empresas e categorias especiais por cidade, à medida que a operação comprovar cada uma.
