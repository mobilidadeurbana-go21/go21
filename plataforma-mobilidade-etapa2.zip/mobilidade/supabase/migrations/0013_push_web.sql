-- ============================================================
-- 0013 — NOTIFICAÇÃO PUSH NOS APPS HTML (Web Push / PWA)
-- O push vai SEM conteúdo: o celular só "acorda" e o próprio app busca as
-- notificações pela API, com o login do usuário. Assim nenhum texto
-- (endereço, valor, nome) passa pelos servidores de push de terceiros.
-- ============================================================
create table if not exists push_inscricoes (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id) on delete cascade,
  endpoint text not null unique check (endpoint ~ '^https://'),
  p256dh text, auth text,
  navegador text,
  falhas int not null default 0,
  criado_em timestamptz not null default now(),
  usado_em timestamptz
);
create index if not exists push_inscricoes_usuario_idx on push_inscricoes (usuario_id);

create or replace function public.registrar_push(p_endpoint text, p_p256dh text, p_auth text, p_navegador text default null) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  perform interno.limitar('registrar_push', 10, 3600);
  if p_endpoint !~ '^https://' or length(p_endpoint) > 1000 then perform interno.erro('ENDPOINT_INVALIDO'); end if;
  -- o mesmo aparelho trocando de conta passa a ser da conta nova
  insert into push_inscricoes (usuario_id, endpoint, p256dh, auth, navegador) values (v_uid, p_endpoint, p_p256dh, p_auth, left(p_navegador, 80))
  on conflict (endpoint) do update set usuario_id = excluded.usuario_id, p256dh = excluded.p256dh, auth = excluded.auth, falhas = 0;
  if (select count(*) from push_inscricoes where usuario_id = v_uid) > 10 then
    delete from push_inscricoes where id in (select id from push_inscricoes where usuario_id = v_uid order by criado_em limit 1);
  end if;
end $$;

create or replace function public.remover_push(p_endpoint text) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  delete from push_inscricoes where endpoint = p_endpoint and usuario_id = interno.exigir_login();
end $$;

-- servidor: para quem mandar o "toque" de push
create or replace function public.push_destinos(p_usuarios uuid[]) returns table (id uuid, usuario_id uuid, endpoint text)
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  return query select p.id, p.usuario_id, p.endpoint from push_inscricoes p where p.usuario_id = any(p_usuarios) and p.falhas < 5;
end $$;

-- servidor: endpoint que respondeu 404/410 (app desinstalado) sai da lista
create or replace function public.push_resultado(p_inscricao uuid, p_ok boolean, p_remover boolean default false) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  if p_remover then delete from push_inscricoes where id = p_inscricao; return; end if;
  update push_inscricoes set falhas = case when p_ok then 0 else falhas + 1 end, usado_em = case when p_ok then now() else usado_em end
  where id = p_inscricao;
end $$;

-- o app (ou o service worker) busca as notificações depois do "toque"
create or replace function public.minhas_notificacoes(p_limite int default 30, p_so_nao_lidas boolean default false) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'evento', evento, 'titulo', titulo, 'mensagem', mensagem, 'dados', dados,
           'criado_em', criado_em, 'lida', lida_em is not null) order by criado_em desc), '[]')
  from (select * from notificacoes where usuario_id = auth.uid() and canal = 'IN_APP'
          and (not p_so_nao_lidas or lida_em is null) order by criado_em desc limit least(greatest(p_limite, 1), 100)) n
$$;

-- recuperação: se o enviador cair no meio, o que ficou "ENVIANDO" volta para a fila
create or replace function public.notificacoes_para_enviar(p_canal text, p_limite int default 100) returns setof notificacoes
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  return query
  update notificacoes set status = 'ENVIANDO', tentativas = tentativas + 1
  where id in (select id from notificacoes where canal = p_canal and tentativas < 5
                 and (status in ('PENDENTE','FALHOU') or (status = 'ENVIANDO' and criado_em < now() - interval '5 minutes'))
               order by criado_em limit p_limite for update skip locked)
  returning *;
end $$;

alter table push_inscricoes enable row level security;
revoke all on push_inscricoes from anon, authenticated;
select interno.criar_politica('push_inscricoes', 'proprio', 'usuario_id = auth.uid()');

insert into funcoes_servidor (assinatura) values
  ('public.push_destinos(uuid[])'), ('public.push_resultado(uuid, boolean, boolean)')
on conflict do nothing;
select interno.aplicar_permissoes_funcoes();
