-- ============================================================
-- 0012 — CORREÇÕES ENCONTRADAS NO TESTE DE CARGA
-- Mesma função da 0003, com UMA linha a mais (marcada [0012]).
-- ============================================================

create or replace function public.solicitar_corrida(
  p_chave_idempotencia text, p_cidade uuid, p_categoria text,
  p_o_lat float8, p_o_lng float8, p_o_endereco text,
  p_d_lat float8, p_d_lng float8, p_d_endereco text,
  p_metodo metodo_pagamento, p_rota_km numeric default null, p_rota_min numeric default null,
  p_passageiros int default 1)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_rota record; v_preco numeric; pf perfis; v_match jsonb;
begin
  if coalesce(length(p_chave_idempotencia), 0) < 8 then perform interno.erro('CHAVE_IDEMPOTENCIA_OBRIGATORIA'); end if;
  -- [0012] pedidos do MESMO passageiro passam um de cada vez: o clique duplo
  -- sempre recebe a mesma corrida (antes, numa janela curta, recebia JA_EXISTE_CORRIDA_ATIVA)
  perform pg_advisory_xact_lock(hashtextextended('solicitar:' || v_uid::text, 0));

  -- mesmo pedido repetido (internet caiu, clique duplo): devolve a mesma corrida
  select * into c from corridas where passageiro_id = v_uid and chave_idempotencia = p_chave_idempotencia;
  if found then return jsonb_build_object('corrida', c.id, 'status', c.status, 'repetido', true); end if;

  perform interno.limitar('solicitar', 6, 60);
  select * into pf from perfis where id = v_uid;
  if not found then perform interno.erro('CADASTRO_INCOMPLETO'); end if;
  if pf.status <> 'ATIVO' then perform interno.erro('CONTA_' || pf.status::text); end if;
  if not exists (select 1 from cidade_categorias cc join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
                 where cc.cidade_id = p_cidade and cc.categoria = p_categoria and cc.habilitada) then
    perform interno.erro('CATEGORIA_INDISPONIVEL');
  end if;
  if exists (select 1 from corridas where passageiro_id = v_uid and status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO')) then
    perform interno.erro('JA_EXISTE_CORRIDA_ATIVA');
  end if;
  -- corrida anterior sem pagar (PIX pendente há muito tempo ou cobrança que falhou): paga antes de pedir outra
  if exists (select 1 from pagamentos pg where pg.pagador_id = v_uid and pg.tipo in ('CORRIDA','TAXA_CANCELAMENTO')
             and ((pg.status = 'PENDENTE' and pg.criado_em < now() - make_interval(mins => interno.cfg_num('divida_bloqueio_minutos', 30)::int))
               or (pg.status = 'FALHOU' and not exists (select 1 from pagamentos p2 where p2.corrida_id = pg.corrida_id and p2.tipo = pg.tipo
                                                         and p2.status in ('PENDENTE','CONFIRMADO','AUTORIZADO'))))) then
    perform interno.erro('PAGAMENTO_EM_ABERTO');
  end if;
  if p_metodo = 'DINHEIRO' and not coalesce((select (regras ->> 'aceita_dinheiro')::boolean from cidades where id = p_cidade), false) then
    perform interno.erro('DINHEIRO_NAO_PERMITIDO_NA_CIDADE');
  end if;
  if p_passageiros not between 1 and 8 then perform interno.erro('PASSAGEIROS_INVALIDO'); end if;

  -- valida área (mesma regra da estimativa)
  perform public.estimar_corrida(p_cidade, p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);

  select * into v_rota from interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  if v_rota.km < 0.3 then perform interno.erro('DESTINO_MUITO_PROXIMO'); end if;
  v_preco := interno.calcular_preco(p_cidade, p_categoria, v_rota.km, v_rota.minutos);

  begin
    insert into corridas (chave_idempotencia, passageiro_id, cidade_id, categoria, passageiros,
      origem_lat, origem_lng, origem_endereco, destino_lat, destino_lng, destino_endereco,
      distancia_estimada_km, duracao_estimada_min, preco_estimado, metodo_pagamento)
    values (p_chave_idempotencia, v_uid, p_cidade, p_categoria, p_passageiros,
      p_o_lat, p_o_lng, left(p_o_endereco, 300), p_d_lat, p_d_lng, left(p_d_endereco, 300),
      v_rota.km, v_rota.minutos, v_preco, p_metodo)
    returning * into c;
    insert into corrida_segredos (corrida_id, pin) values (c.id, lpad((floor(random() * 10000))::int::text, 4, '0'));
  exception when unique_violation then
    -- corrida simultânea do mesmo passageiro: o índice único segura
    select * into c from corridas where passageiro_id = v_uid and chave_idempotencia = p_chave_idempotencia;
    if found then return jsonb_build_object('corrida', c.id, 'status', c.status, 'repetido', true); end if;
    perform interno.erro('JA_EXISTE_CORRIDA_ATIVA');
  end;

  perform interno.evento(c.id, 'SOLICITACAO', null, 'SOLICITADA',
    jsonb_build_object('preco', v_preco, 'km', v_rota.km, 'min', v_rota.minutos, 'categoria', p_categoria, 'metodo', p_metodo));
  v_match := interno.buscar_motorista(c.id);
  return jsonb_build_object('corrida', c.id, 'status', v_match ->> 'status', 'preco_estimado', v_preco,
    'pin', (select pin from corrida_segredos where corrida_id = c.id));
end $$;

-- ------------------------------------------------------------
-- Radar com cache curto: no teste de carga o radar era a chamada mais pesada
-- (cada motorista recalculava todas as zonas da cidade). Agora o cálculo é
-- feito no máximo 1 vez a cada N segundos por cidade; quem chega enquanto
-- outro está calculando usa o último resultado (sem "efeito manada").
-- ------------------------------------------------------------
create table if not exists radar_cache (
  cidade_id uuid primary key references cidades(id) on delete cascade,
  gerado_em timestamptz not null,
  zonas jsonb not null
);
alter table radar_cache enable row level security;
revoke all on radar_cache from anon, authenticated;
insert into configuracoes (chave, valor, descricao) values ('radar_cache_seg', '30', 'validade do cálculo de zonas do radar')
on conflict (chave) do nothing;

create or replace function interno.estado_zonas_cache(p_cidade uuid)
returns table (zona text, regiao text, lat float8, lng float8, demanda_15 int, demanda_ant int, tendencia_pct int, disponiveis int, em_andamento int, sem_motorista_30 int, canceladas_30 int, espera_media_min numeric, previsao jsonb, pressao numeric, nivel text, ticket_medio numeric)
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare rc radar_cache;
begin
  select * into rc from radar_cache where cidade_id = p_cidade;
  if rc.cidade_id is null or rc.gerado_em < now() - make_interval(secs => interno.cfg_num('radar_cache_seg', 30)::int) then
    if pg_try_advisory_xact_lock(hashtextextended('radar:' || p_cidade::text, 0)) then
      insert into radar_cache (cidade_id, gerado_em, zonas)
      values (p_cidade, now(), coalesce((select jsonb_agg(to_jsonb(e)) from interno.estado_zonas(p_cidade) e), '[]'))
      on conflict (cidade_id) do update set gerado_em = excluded.gerado_em, zonas = excluded.zonas
      returning * into rc;
    elsif rc.cidade_id is null then
      return query select * from interno.estado_zonas(p_cidade);   -- primeiro cálculo em andamento: calcula sem gravar
      return;
    end if;
  end if;
  return query select * from jsonb_to_recordset(rc.zonas) as x(zona text, regiao text, lat float8, lng float8, demanda_15 int, demanda_ant int, tendencia_pct int, disponiveis int, em_andamento int, sem_motorista_30 int, canceladas_30 int, espera_media_min numeric, previsao jsonb, pressao numeric, nivel text, ticket_medio numeric);
end $$;

create or replace function public.radar(p_lat float8 default null, p_lng float8 default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_cid uuid; v_lat float8 := p_lat; v_lng float8 := p_lng; v jsonb;
        v_vel numeric := interno.cfg_num('velocidade_media_kmh', 25);
begin
  select m.cidade_id into v_cid from motoristas m where m.id = v_uid;
  if v_lat is null then select lat, lng into v_lat, v_lng from motorista_presenca where motorista_id = v_uid; end if;
  select coalesce(jsonb_agg(z order by (z ->> 'ordem')::numeric desc), '[]') into v from (
    select jsonb_build_object(
      'zona', e.zona, 'regiao', e.regiao, 'lat', e.lat, 'lng', e.lng,
      'nivel', interno.nivel_pressao(e.pressao),
      'titulo', case when e.tendencia_pct >= 15 then 'Demanda crescente'
                     when e.tendencia_pct <= -15 then 'Demanda caindo'
                     else 'Demanda estável' end,
      'explicacao', jsonb_build_array(
         e.regiao,
         case when e.demanda_ant > 0 or e.demanda_15 > 0 then
           (case when e.tendencia_pct >= 0 then '+' else '' end) || e.tendencia_pct || '% de solicitações nos últimos 15 minutos' end,
         e.disponiveis || ' motoristas disponíveis',
         case when e.disponiveis > 0 then
           'Espera estimada: ' || greatest(1, floor(1.3 * 1.5 / v_vel * 60 / sqrt(e.disponiveis)))::int || '–'
             || greatest(2, ceil(1.3 * 3 / v_vel * 60 / sqrt(e.disponiveis) + e.pressao))::int || ' minutos'
         else 'Sem motoristas disponíveis por perto' end),
      'demanda_atual', e.demanda_15, 'tendencia_pct', e.tendencia_pct,
      'motoristas_disponiveis', e.disponiveis, 'corridas_em_andamento', e.em_andamento,
      'previsao', e.previsao,
      'oportunidade_estimada', jsonb_build_object(
          'estimativa', true,
          'chance', case interno.nivel_pressao(e.pressao) when 'ALTA' then 'alta' when 'MODERADA' then 'boa' when 'NORMAL' then 'normal' else 'baixa' end,
          'ticket_medio_7d', e.ticket_medio),
      'distancia_km', case when v_lat is not null then round(interno.distancia_km(v_lat, v_lng, e.lat, e.lng)::numeric, 1) end,
      'tempo_ate_la_min', case when v_lat is not null then round((interno.distancia_km(v_lat, v_lng, e.lat, e.lng) * 1.3 / v_vel * 60)::numeric) end,
      'ordem', e.pressao - case when v_lat is not null then interno.distancia_km(v_lat, v_lng, e.lat, e.lng) / 10 else 0 end) z
    from interno.estado_zonas_cache(v_cid) e   -- [0012] cache curto
    where e.demanda_15 > 0 or e.demanda_ant > 0 or (e.previsao ->> 'pedidos_previstos')::numeric >= 1 or e.disponiveis > 0
    limit 60) x;
  return jsonb_build_object('gerado_em', now(), 'estimativa', true,
    'aviso', 'Radar mostra estimativas com base nos últimos minutos e no histórico. Não é garantia de corrida.',
    'zonas', v);
end $$;

select interno.aplicar_permissoes_funcoes();
