-- Valor novo de enum fica numa migration própria: o Postgres não deixa usar
-- um valor de enum na mesma transação em que ele foi criado.
alter type metodo_pagamento add value if not exists 'EMPRESA';
