-- ============================================================
-- 0007 — MOBILITY INTELLIGENCE + RADAR
-- Toda previsão aqui é ESTIMATIVA (heurística transparente, com
-- faixa e nível de confiança) — nunca apresentada como certeza.
-- ============================================================

-- ---------- ZONAS (grade de ~1,1 km) e REGIÕES com nome ----------
create or replace function interno.zona(lat float8, lng float8) returns text
language sql immutable as $$ select floor(lat * 100)::int || ':' || floor(lng * 100)::int $$;

create or replace function interno.centro_zona(z text, out lat float8, out lng float8)
language sql immutable as $$
  select (split_part(z, ':', 1)::int + 0.5) / 100.0, (split_part(z, ':', 2)::int + 0.5) / 100.0
$$;

alter table corridas add column if not exists origem_zona text
  generated always as (floor(origem_lat * 100)::int || ':' || floor(origem_lng * 100)::int) stored;
create index if not exists corridas_zona_idx on corridas (cidade_id, origem_zona, solicitada_em desc);

-- regiões nomeadas pela operação ("Região Central", "Aeroporto", "Zona Sul"...)
create table if not exists regioes (
  id uuid primary key default gen_random_uuid(),
  cidade_id uuid not null references cidades(id) on delete cascade,
  nome text not null,
  centro_lat float8 not null, centro_lng float8 not null,
  raio_km numeric not null default 1.5,
  tipo text not null default 'BAIRRO' check (tipo in ('BAIRRO','CENTRO','AEROPORTO','TERMINAL','EVENTOS','OUTRO')),
  ativa boolean not null default true,
  criado_em timestamptz not null default now()
);
create index if not exists regioes_cidade_idx on regioes (cidade_id) where ativa;
drop trigger if exists regioes_auditar on regioes;
create trigger regioes_auditar after insert or update or delete on regioes for each row execute function interno.trg_auditar();

create or replace function interno.nome_regiao(p_cidade uuid, p_lat float8, p_lng float8) returns text
language plpgsql stable as $$
declare v text; c cidades; d numeric; r numeric;
begin
  select r2.nome into v from regioes r2 where r2.cidade_id = p_cidade and r2.ativa
     and interno.distancia_km(r2.centro_lat, r2.centro_lng, p_lat, p_lng) <= r2.raio_km
   order by interno.distancia_km(r2.centro_lat, r2.centro_lng, p_lat, p_lng) limit 1;
  if v is not null then return v; end if;
  -- sem região cadastrada: nome automático pela direção a partir do centro da cidade
  select * into c from cidades where id = p_cidade;
  if c.centro_lat is null then return 'Área ' || interno.zona(p_lat, p_lng); end if;
  d := interno.distancia_km(c.centro_lat, c.centro_lng, p_lat, p_lng);
  if d <= 1.5 then return 'Região Central'; end if;
  r := interno.rumo(c.centro_lat, c.centro_lng, p_lat, p_lng);
  return 'Zona ' || (array['Norte','Nordeste','Leste','Sudeste','Sul','Sudoeste','Oeste','Noroeste'])[(floor(((r + 22.5)::numeric % 360) / 45))::int + 1]
         || ' (' || round(d) || ' km do centro)';
end $$;

-- ---------- ENTRADAS EXTERNAS: clima e eventos ----------
create table if not exists clima_cidade (
  cidade_id uuid not null references cidades(id) on delete cascade,
  momento timestamptz not null,
  condicao text not null check (condicao in ('LIMPO','NUBLADO','CHUVA','CHUVA_FORTE','TEMPESTADE')),
  temperatura numeric,
  fonte text,
  primary key (cidade_id, momento)
);

create table if not exists eventos_cidade (
  id uuid primary key default gen_random_uuid(),
  cidade_id uuid not null references cidades(id) on delete cascade,
  nome text not null,
  lat float8 not null, lng float8 not null,
  inicio timestamptz not null, fim timestamptz not null,
  publico_estimado int,
  criado_por uuid,
  criado_em timestamptz not null default now(),
  check (fim > inicio)
);
create index if not exists eventos_cidade_idx on eventos_cidade (cidade_id, fim);

insert into configuracoes (chave, valor, descricao) values
  ('radar_niveis', '{"alta":3,"moderada":1.5,"normal":0.5}', 'pressão = demanda prevista / (motoristas disponíveis + 1)'),
  ('radar_fator_chuva', '1.25', 'multiplicador de demanda com chuva'),
  ('radar_fator_tempestade', '1.4', 'multiplicador de demanda com chuva forte/tempestade'),
  ('radar_evento_raio_km', '2', 'raio de influência de um evento'),
  ('radar_evento_conversao', '0.02', 'fração do público que pede corrida na saída (por 15 min)')
on conflict (chave) do nothing;

-- ---------- RETRATOS (a cada 5 min) ----------
create table if not exists inteligencia_snapshots (
  cidade_id uuid not null references cidades(id) on delete cascade,
  zona text not null,                           -- '*' = cidade inteira
  momento timestamptz not null,                 -- início do bloco de 5 min
  solicitacoes int not null default 0,
  sem_motorista int not null default 0,
  canceladas int not null default 0,
  concluidas int not null default 0,
  motoristas_disponiveis int not null default 0,
  motoristas_ocupados int not null default 0,
  espera_media_seg numeric,
  primary key (cidade_id, zona, momento)
);
create index if not exists snapshots_hist_idx on inteligencia_snapshots (cidade_id, zona, momento desc);

create table if not exists alertas_operacionais (
  id uuid primary key default gen_random_uuid(),
  cidade_id uuid not null references cidades(id) on delete cascade,
  zona text,
  regiao text,
  tipo text not null check (tipo in ('PICO_PREVISTO','BAIXA_OFERTA','ESPERA_ALTA','CANCELAMENTO_ALTO','SEM_MOTORISTA','EVENTO','CLIMA')),
  severidade text not null default 'MEDIA' check (severidade in ('BAIXA','MEDIA','ALTA')),
  mensagem text not null,
  dados jsonb not null default '{}',
  sugestao text,
  status text not null default 'ABERTO' check (status in ('ABERTO','VISTO','RESOLVIDO','DESCARTADO')),
  criado_em timestamptz not null default now(),
  resolvido_por uuid, resolvido_em timestamptz
);
create unique index if not exists alerta_aberto_unico on alertas_operacionais (cidade_id, coalesce(zona, '*'), tipo) where status = 'ABERTO';

-- sugestões de incentivo: SÓ sugestão; a decisão (e o custo) é humana
create table if not exists sugestoes_incentivo (
  id uuid primary key default gen_random_uuid(),
  cidade_id uuid not null references cidades(id) on delete cascade,
  zona text, regiao text,
  janela_inicio timestamptz not null, janela_fim timestamptz not null,
  motivo text not null,
  bonus_sugerido_por_corrida numeric(10,2) not null,
  motoristas_necessarios_estimado int,
  custo_estimado numeric(10,2),
  status text not null default 'SUGERIDA' check (status in ('SUGERIDA','APROVADA','RECUSADA','EXPIRADA')),
  decidido_por uuid, decidido_em timestamptz,
  criado_em timestamptz not null default now()
);

-- ---------- PREFERÊNCIAS E ANTI-SPAM DE NOTIFICAÇÃO ----------
create table if not exists notificacao_preferencias (
  usuario_id uuid not null references perfis(id) on delete cascade,
  evento text not null,                 -- ex.: DEMANDA, PROMOCAO, OPORTUNIDADE, MANUTENCAO
  ativo boolean not null default true,
  primary key (usuario_id, evento)
);

insert into configuracoes (chave, valor, descricao) values
  ('notif_intervalo_min', '{"DEMANDA":30,"OPORTUNIDADE":30,"PROMOCAO":1440,"MANUTENCAO":10080,"BONUS":60,"INDICACAO":60}', 'intervalo mínimo entre notificações do mesmo tipo'),
  ('notif_max_dia', '{"DEMANDA":4,"PROMOCAO":1,"OPORTUNIDADE":4}', 'máximo por dia'),
  ('notif_silencio', '{"inicio":"22:00","fim":"07:00"}', 'sem notificações não urgentes nesse horário (fuso da cidade)')
on conflict (chave) do nothing;

-- decide se dá para mandar uma notificação NÃO crítica (segurança e corrida nunca passam por aqui)
create or replace function interno.pode_notificar(p_usuario uuid, p_evento text) returns boolean
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_int int; v_max int; v_tz text; v_hora time; v_ini time; v_fim time;
begin
  if exists (select 1 from notificacao_preferencias where usuario_id = p_usuario and evento = p_evento and not ativo) then return false; end if;
  if p_evento = 'PROMOCAO' and not interno.consentiu(p_usuario, 'MARKETING') then return false; end if;
  v_int := coalesce((interno.cfg('notif_intervalo_min') ->> p_evento)::int, 30);
  v_max := (interno.cfg('notif_max_dia') ->> p_evento)::int;
  if exists (select 1 from notificacoes where usuario_id = p_usuario and evento = p_evento and canal = 'PUSH'
             and criado_em > now() - make_interval(mins => v_int)) then return false; end if;
  if v_max is not null and (select count(*) from notificacoes where usuario_id = p_usuario and evento = p_evento and canal = 'PUSH'
                            and criado_em > now() - interval '24 hours') >= v_max then return false; end if;
  select coalesce(c.fuso, 'America/Sao_Paulo') into v_tz from perfis p left join cidades c on c.id = p.cidade_id where p.id = p_usuario;
  v_hora := (now() at time zone coalesce(v_tz, 'America/Sao_Paulo'))::time;
  v_ini := (interno.cfg('notif_silencio') ->> 'inicio')::time; v_fim := (interno.cfg('notif_silencio') ->> 'fim')::time;
  if v_ini is not null and (case when v_ini > v_fim then v_hora >= v_ini or v_hora < v_fim else v_hora between v_ini and v_fim end) then
    return false;
  end if;
  return true;
end $$;

create or replace function interno.notificar_se_pode(p_usuario uuid, p_evento text, p_titulo text, p_msg text, p_dados jsonb default '{}')
returns boolean language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if not interno.pode_notificar(p_usuario, p_evento) then return false; end if;
  perform interno.notificar(p_usuario, p_evento, p_titulo, p_msg, p_dados);
  return true;
end $$;

create or replace function public.salvar_preferencia_notificacao(p_evento text, p_ativo boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  if p_evento in ('CORRIDA','SEGURANCA','PAGAMENTO','MOTORISTA_A_CAMINHO','MOTORISTA_CHEGOU','CANCELAMENTO','DOCUMENTO') then
    perform interno.erro('NOTIFICACAO_ESSENCIAL', 'avisos de corrida, segurança, pagamento e documentos não podem ser desligados');
  end if;
  insert into notificacao_preferencias (usuario_id, evento, ativo) values (v_uid, p_evento, p_ativo)
  on conflict (usuario_id, evento) do update set ativo = excluded.ativo;
end $$;

-- ============================================================
-- PREVISÃO DE DEMANDA (estimativa)
-- base = média das últimas 4 semanas no mesmo dia/horário (blocos de 5 min → 15 min)
-- ajustada pela tendência atual, clima e eventos. Sempre com faixa e confiança.
-- ============================================================
create or replace function interno.prever_demanda(p_cidade uuid, p_zona text, p_momento timestamptz default now(), p_janela_min int default 15)
returns jsonb language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare
  v_hist numeric; v_semanas int; v_atual numeric; v_ant numeric; v_tend numeric := 1; v_clima text; v_fclima numeric := 1;
  v_evento numeric := 0; v_est numeric; v_conf text; c_lat float8; c_lng float8; v_fatores jsonb := '[]';
begin
  -- histórico: mesma janela nas 4 semanas anteriores (só conta semana em que o sistema já registrava a cidade)
  select count(*) into v_semanas from generate_series(1, 4) w
  where exists (select 1 from inteligencia_snapshots
                where cidade_id = p_cidade and zona = '*'
                  and momento >= p_momento - make_interval(weeks => w)
                  and momento <  p_momento - make_interval(weeks => w) + make_interval(mins => p_janela_min));
  if v_semanas > 0 then
    select coalesce(sum(s.solicitacoes), 0)::numeric / v_semanas into v_hist
    from generate_series(1, 4) w
    join inteligencia_snapshots s on s.cidade_id = p_cidade and s.zona = p_zona
      and s.momento >= p_momento - make_interval(weeks => w)
      and s.momento <  p_momento - make_interval(weeks => w) + make_interval(mins => p_janela_min);
  end if;

  -- agora: últimos 15 min x 15 min anteriores
  select count(*) filter (where solicitada_em > now() - interval '15 minutes'),
         count(*) filter (where solicitada_em <= now() - interval '15 minutes')
    into v_atual, v_ant
  from corridas where cidade_id = p_cidade and (p_zona = '*' or origem_zona = p_zona) and solicitada_em > now() - interval '30 minutes';

  if v_ant > 0 then v_tend := least(greatest(v_atual / v_ant, 0.5), 2.0); elsif v_atual > 0 then v_tend := 1.3; end if;
  if v_tend <> 1 then v_fatores := v_fatores || jsonb_build_object('fator', 'tendencia', 'multiplicador', round(v_tend, 2)); end if;

  select condicao into v_clima from clima_cidade where cidade_id = p_cidade and momento > now() - interval '2 hours' order by momento desc limit 1;
  if v_clima = 'CHUVA' then v_fclima := interno.cfg_num('radar_fator_chuva', 1.25);
  elsif v_clima in ('CHUVA_FORTE','TEMPESTADE') then v_fclima := interno.cfg_num('radar_fator_tempestade', 1.4); end if;
  if v_fclima <> 1 then v_fatores := v_fatores || jsonb_build_object('fator', 'clima', 'condicao', v_clima, 'multiplicador', v_fclima); end if;

  if p_zona <> '*' then
    select lat, lng into c_lat, c_lng from interno.centro_zona(p_zona);
    select coalesce(sum(coalesce(publico_estimado, 0) * interno.cfg_num('radar_evento_conversao', 0.02)), 0) into v_evento
    from eventos_cidade
    where cidade_id = p_cidade and fim between p_momento - interval '15 minutes' and p_momento + make_interval(mins => p_janela_min + 30)
      and interno.distancia_km(lat, lng, c_lat, c_lng) <= interno.cfg_num('radar_evento_raio_km', 2);
    if v_evento > 0 then v_fatores := v_fatores || jsonb_build_object('fator', 'evento', 'pedidos_extras', round(v_evento, 1)); end if;
  end if;

  v_est := (coalesce(v_hist, v_atual) * 0.5 + v_atual * 0.5) * v_tend * v_fclima + v_evento;
  v_conf := case when v_semanas >= 4 then 'MEDIA' when v_semanas >= 1 then 'BAIXA' else 'MUITO_BAIXA' end;
  return jsonb_build_object('estimativa', true, 'pedidos_previstos', round(v_est, 1),
    'faixa_min', floor(v_est * 0.7), 'faixa_max', ceil(v_est * 1.3) + 1,
    'confianca', v_conf, 'semanas_de_historico', coalesce(v_semanas, 0), 'base_historica', round(v_hist, 1),
    'agora_15min', v_atual, 'anteriores_15min', v_ant, 'fatores', v_fatores,
    'aviso', 'Estimativa baseada em histórico e tendência. Pode não se confirmar.');
end $$;

-- ============================================================
-- ESTADO DAS ZONAS (oferta x demanda) — base do radar e do painel
-- ============================================================
create or replace function interno.estado_zonas(p_cidade uuid)
returns table (zona text, regiao text, lat float8, lng float8, demanda_15 int, demanda_ant int, tendencia_pct int,
               disponiveis int, em_andamento int, sem_motorista_30 int, canceladas_30 int, espera_media_min numeric,
               previsao jsonb, pressao numeric, nivel text, ticket_medio numeric)
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
#variable_conflict use_column
begin
  return query
  with ped as (
    select c.origem_zona z,
      count(*) filter (where c.solicitada_em > now() - interval '15 minutes')::int d15,
      count(*) filter (where c.solicitada_em <= now() - interval '15 minutes')::int dant,
      count(*) filter (where c.status = 'SEM_MOTORISTA')::int semm,
      count(*) filter (where c.status = 'CANCELADA')::int canc,
      avg(extract(epoch from c.aceita_em - c.solicitada_em)) filter (where c.aceita_em is not null) as espera
    from corridas c where c.cidade_id = p_cidade and c.solicitada_em > now() - interval '30 minutes'
    group by c.origem_zona
  ), ofe as (
    select interno.zona(p.lat, p.lng) z,
      count(*) filter (where p.disponivel)::int disp,
      count(*) filter (where not p.disponivel)::int ocup
    from motorista_presenca p
    where p.cidade_id = p_cidade and p.online and p.lat is not null and p.atualizado_em > now() - interval '3 minutes'
    group by 1
  ), tick as (
    select c.origem_zona z, avg(c.preco_final) t from corridas c
    where c.cidade_id = p_cidade and c.status = 'PAGA' and c.solicitada_em > now() - interval '7 days' group by 1
  ), zs as (
    select z from ped union select z from ofe
  )
  select zs.z,
    interno.nome_regiao(p_cidade, cz.lat, cz.lng),
    cz.lat, cz.lng,
    coalesce(ped.d15, 0), coalesce(ped.dant, 0),
    case when coalesce(ped.dant, 0) > 0 then round(100.0 * (ped.d15 - ped.dant) / ped.dant)::int
         when coalesce(ped.d15, 0) > 0 then 100 else 0 end,
    -- motoristas disponíveis "na região": a zona e as 8 vizinhas (~1,5 km)
    (select coalesce(sum(o2.disp), 0)::int from ofe o2
      where abs(split_part(o2.z, ':', 1)::int - split_part(zs.z, ':', 1)::int) <= 1
        and abs(split_part(o2.z, ':', 2)::int - split_part(zs.z, ':', 2)::int) <= 1),
    coalesce(ofe.ocup, 0),
    coalesce(ped.semm, 0), coalesce(ped.canc, 0),
    round((ped.espera / 60)::numeric, 1),
    pv.p,
    round(((pv.p ->> 'pedidos_previstos')::numeric + coalesce(ped.d15, 0)) / 2
          / ((select coalesce(sum(o2.disp), 0) from ofe o2
              where abs(split_part(o2.z, ':', 1)::int - split_part(zs.z, ':', 1)::int) <= 1
                and abs(split_part(o2.z, ':', 2)::int - split_part(zs.z, ':', 2)::int) <= 1) + 1), 2),
    null::text,
    round(tick.t, 2)
  from zs
  cross join lateral interno.centro_zona(zs.z) cz
  cross join lateral (select interno.prever_demanda(p_cidade, zs.z) p) pv
  left join ped on ped.z = zs.z
  left join ofe on ofe.z = zs.z
  left join tick on tick.z = zs.z;
end $$;

create or replace function interno.nivel_pressao(p numeric) returns text
language sql stable as $$
  select case
    when p >= coalesce((interno.cfg('radar_niveis') ->> 'alta')::numeric, 3) then 'ALTA'
    when p >= coalesce((interno.cfg('radar_niveis') ->> 'moderada')::numeric, 1.5) then 'MODERADA'
    when p >= coalesce((interno.cfg('radar_niveis') ->> 'normal')::numeric, 0.5) then 'NORMAL'
    else 'BAIXA' end
$$;

-- ============================================================
-- RADAR DO MOTORISTA — explica, não só pinta
-- ============================================================
create or replace function public.radar(p_lat float8 default null, p_lng float8 default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_cid uuid; v_lat float8 := p_lat; v_lng float8 := p_lng; v jsonb;
        v_vel numeric := interno.cfg_num('velocidade_media_kmh', 25);
begin
  select m.cidade_id into v_cid from motoristas m where m.id = v_uid;
  if v_lat is null then select lat, lng into v_lat, v_lng from motorista_presenca where motorista_id = v_uid; end if;
  select coalesce(jsonb_agg(z order by (z ->> 'ordem')::numeric desc), '[]') into v from (
    select jsonb_build_object(
      'zona', e.zona, 'regiao', e.regiao, 'lat', e.lat, 'lng', e.lng,
      'nivel', interno.nivel_pressao(e.pressao),
      'titulo', case when e.tendencia_pct >= 15 then 'Demanda crescente'
                     when e.tendencia_pct <= -15 then 'Demanda caindo'
                     else 'Demanda estável' end,
      'explicacao', jsonb_build_array(
         e.regiao,
         case when e.demanda_ant > 0 or e.demanda_15 > 0 then
           (case when e.tendencia_pct >= 0 then '+' else '' end) || e.tendencia_pct || '% de solicitações nos últimos 15 minutos' end,
         e.disponiveis || ' motoristas disponíveis',
         case when e.disponiveis > 0 then
           'Espera estimada: ' || greatest(1, floor(1.3 * 1.5 / v_vel * 60 / sqrt(e.disponiveis)))::int || '–'
             || greatest(2, ceil(1.3 * 3 / v_vel * 60 / sqrt(e.disponiveis) + e.pressao))::int || ' minutos'
         else 'Sem motoristas disponíveis por perto' end),
      'demanda_atual', e.demanda_15, 'tendencia_pct', e.tendencia_pct,
      'motoristas_disponiveis', e.disponiveis, 'corridas_em_andamento', e.em_andamento,
      'previsao', e.previsao,
      'oportunidade_estimada', jsonb_build_object(
          'estimativa', true,
          'chance', case interno.nivel_pressao(e.pressao) when 'ALTA' then 'alta' when 'MODERADA' then 'boa' when 'NORMAL' then 'normal' else 'baixa' end,
          'ticket_medio_7d', e.ticket_medio),
      'distancia_km', case when v_lat is not null then round(interno.distancia_km(v_lat, v_lng, e.lat, e.lng)::numeric, 1) end,
      'tempo_ate_la_min', case when v_lat is not null then round((interno.distancia_km(v_lat, v_lng, e.lat, e.lng) * 1.3 / v_vel * 60)::numeric) end,
      'ordem', e.pressao - case when v_lat is not null then interno.distancia_km(v_lat, v_lng, e.lat, e.lng) / 10 else 0 end) z
    from interno.estado_zonas(v_cid) e
    where e.demanda_15 > 0 or e.demanda_ant > 0 or (e.previsao ->> 'pedidos_previstos')::numeric >= 1 or e.disponiveis > 0
    limit 60) x;
  return jsonb_build_object('gerado_em', now(), 'estimativa', true,
    'aviso', 'Radar mostra estimativas com base nos últimos minutos e no histórico. Não é garantia de corrida.',
    'zonas', v);
end $$;

-- ============================================================
-- PAINEL DE INTELIGÊNCIA (operação)
-- ============================================================
create or replace function public.inteligencia_painel(p_cidade uuid) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_z jsonb; v_reloc jsonb;
begin
  select coalesce(jsonb_agg(to_jsonb(e) || jsonb_build_object('nivel', interno.nivel_pressao(e.pressao)) order by e.pressao desc), '[]') into v_z
  from interno.estado_zonas(p_cidade) e;
  -- reposicionamento: zonas com sobra de motoristas → zonas próximas com falta (até 5 km)
  select coalesce(jsonb_agg(x order by (x ->> 'ganho_pressao')::numeric desc), '[]') into v_reloc from (
    select jsonb_build_object('de', b.regiao, 'para', a.regiao,
             'distancia_km', round(interno.distancia_km(a.lat, a.lng, b.lat, b.lng)::numeric, 1),
             'motoristas_sugeridos', least(b.disponiveis - 1, ceil(a.pressao)::int),
             'ganho_pressao', a.pressao - b.pressao, 'estimativa', true) x
    from interno.estado_zonas(p_cidade) a, interno.estado_zonas(p_cidade) b
    where interno.nivel_pressao(a.pressao) in ('ALTA','MODERADA') and interno.nivel_pressao(b.pressao) = 'BAIXA'
      and b.disponiveis >= 2 and interno.distancia_km(a.lat, a.lng, b.lat, b.lng) <= 5
    limit 20) r;
  return jsonb_build_object(
    'gerado_em', now(), 'estimativa', true,
    'cidade', interno.prever_demanda(p_cidade, '*'),
    'zonas', v_z,
    'gargalos', (select coalesce(jsonb_agg(z), '[]') from jsonb_array_elements(v_z) z
                 where z ->> 'nivel' = 'ALTA' or (z ->> 'sem_motorista_30')::int > 0),
    'reposicionamento', v_reloc,
    'alertas', (select coalesce(jsonb_agg(to_jsonb(a) order by criado_em desc), '[]') from alertas_operacionais a
                where cidade_id = p_cidade and status = 'ABERTO'),
    'incentivos_sugeridos', (select coalesce(jsonb_agg(to_jsonb(s) order by criado_em desc), '[]') from sugestoes_incentivo s
                where cidade_id = p_cidade and status = 'SUGERIDA' and janela_fim > now()),
    'picos_previstos', (select coalesce(jsonb_agg(jsonb_build_object('hora', h, 'previsao', interno.prever_demanda(p_cidade, '*', h, 60))), '[]')
                        from generate_series(date_trunc('hour', now()) + interval '1 hour', date_trunc('hour', now()) + interval '6 hours', interval '1 hour') h)
  );
end $$;

create or replace function public.ops_decidir_incentivo(p_sugestao uuid, p_aprovar boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,FINANCEIRO,ADMIN}');
begin
  update sugestoes_incentivo set status = case when p_aprovar then 'APROVADA' else 'RECUSADA' end, decidido_por = v_uid, decidido_em = now()
  where id = p_sugestao and status = 'SUGERIDA';
  if not found then perform interno.erro('SUGESTAO_NAO_DISPONIVEL'); end if;
  perform interno.auditar_evento('DECISAO_INCENTIVO', 'sugestoes_incentivo', p_sugestao::text, jsonb_build_object('aprovar', p_aprovar));
end $$;

create or replace function public.ops_tratar_alerta(p_alerta uuid, p_status text) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}');
begin
  if p_status not in ('VISTO','RESOLVIDO','DESCARTADO') then perform interno.erro('STATUS_INVALIDO'); end if;
  update alertas_operacionais set status = p_status, resolvido_por = v_uid, resolvido_em = now() where id = p_alerta;
end $$;

create or replace function public.ops_salvar_regiao(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  if v_id is null then
    insert into regioes (cidade_id, nome, centro_lat, centro_lng, raio_km, tipo)
    values ((p ->> 'cidade_id')::uuid, p ->> 'nome', (p ->> 'centro_lat')::float8, (p ->> 'centro_lng')::float8,
            coalesce((p ->> 'raio_km')::numeric, 1.5), coalesce(p ->> 'tipo', 'BAIRRO')) returning id into v_id;
  else
    update regioes set nome = coalesce(p ->> 'nome', nome), raio_km = coalesce((p ->> 'raio_km')::numeric, raio_km),
      ativa = coalesce((p ->> 'ativa')::boolean, ativa), tipo = coalesce(p ->> 'tipo', tipo) where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.ops_salvar_evento(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_id uuid;
begin
  insert into eventos_cidade (cidade_id, nome, lat, lng, inicio, fim, publico_estimado, criado_por)
  values ((p ->> 'cidade_id')::uuid, p ->> 'nome', (p ->> 'lat')::float8, (p ->> 'lng')::float8,
          (p ->> 'inicio')::timestamptz, (p ->> 'fim')::timestamptz, (p ->> 'publico_estimado')::int, v_uid)
  returning id into v_id;
  return v_id;
end $$;

-- clima vem de serviço externo (Edge Function com service_role)
create or replace function public.registrar_clima(p_cidade uuid, p_condicao text, p_temperatura numeric, p_fonte text) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  insert into clima_cidade (cidade_id, momento, condicao, temperatura, fonte) values (p_cidade, date_trunc('minute', now()), p_condicao, p_temperatura, p_fonte)
  on conflict do nothing;
end $$;
insert into funcoes_servidor values ('public.registrar_clima(uuid, text, numeric, text)') on conflict do nothing;

-- ============================================================
-- JOB (a cada 5 min): retrato, alertas, incentivos, aviso de demanda
-- ============================================================
create or replace function interno.job_inteligencia() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_bloco timestamptz := to_timestamp(floor(extract(epoch from now()) / 300) * 300) - interval '5 minutes';
        c record; e record; n_alertas int := 0; n_avisos int := 0; d record; v_ok boolean;
begin
  -- 1) retrato do bloco de 5 min que acabou de fechar (por zona e cidade inteira)
  insert into inteligencia_snapshots (cidade_id, zona, momento, solicitacoes, sem_motorista, canceladas, concluidas, espera_media_seg)
  select cidade_id, z, v_bloco, count(*), count(*) filter (where status = 'SEM_MOTORISTA'), count(*) filter (where status = 'CANCELADA'),
         count(*) filter (where status in ('FINALIZADA','PAGA')), avg(extract(epoch from aceita_em - solicitada_em))
  from (select cidade_id, origem_zona z, status, aceita_em, solicitada_em from corridas
        where solicitada_em >= v_bloco and solicitada_em < v_bloco + interval '5 minutes'
        union all
        select cidade_id, '*', status, aceita_em, solicitada_em from corridas
        where solicitada_em >= v_bloco and solicitada_em < v_bloco + interval '5 minutes') x
  group by cidade_id, z
  on conflict (cidade_id, zona, momento) do update set solicitacoes = excluded.solicitacoes, sem_motorista = excluded.sem_motorista,
    canceladas = excluded.canceladas, concluidas = excluded.concluidas, espera_media_seg = excluded.espera_media_seg;

  insert into inteligencia_snapshots (cidade_id, zona, momento, motoristas_disponiveis, motoristas_ocupados)
  select cidade_id, z, v_bloco, count(*) filter (where disponivel), count(*) filter (where not disponivel)
  from (select cidade_id, interno.zona(lat, lng) z, disponivel from motorista_presenca where online and lat is not null and cidade_id is not null
        union all select cidade_id, '*', disponivel from motorista_presenca where online and cidade_id is not null) y
  group by cidade_id, z
  on conflict (cidade_id, zona, momento) do update set motoristas_disponiveis = excluded.motoristas_disponiveis,
    motoristas_ocupados = excluded.motoristas_ocupados;

  -- 2) alertas e sugestões por cidade ativa
  for c in select id from cidades where ativa loop
    for e in select * from interno.estado_zonas(c.id) loop
      if interno.nivel_pressao(e.pressao) = 'ALTA' and e.disponiveis <= 2 then
        begin
          insert into alertas_operacionais (cidade_id, zona, regiao, tipo, severidade, mensagem, dados, sugestao)
          values (c.id, e.zona, e.regiao, 'BAIXA_OFERTA', 'ALTA',
                  e.regiao || ': demanda alta e só ' || e.disponiveis || ' motorista(s) disponível(is) por perto',
                  jsonb_build_object('pressao', e.pressao, 'demanda_15', e.demanda_15, 'previsao', e.previsao),
                  'Avaliar incentivo temporário ou aviso a motoristas próximos');
          n_alertas := n_alertas + 1;
          insert into sugestoes_incentivo (cidade_id, zona, regiao, janela_inicio, janela_fim, motivo, bonus_sugerido_por_corrida,
                                           motoristas_necessarios_estimado, custo_estimado)
          values (c.id, e.zona, e.regiao, now(), now() + interval '1 hour',
                  'Pressão ' || e.pressao || ' (demanda prevista acima da oferta) — estimativa',
                  least(10, greatest(2, round(e.pressao)))::numeric, greatest(1, ceil(e.pressao) - e.disponiveis),
                  least(10, greatest(2, round(e.pressao))) * greatest(1, (e.previsao ->> 'pedidos_previstos')::numeric));
        exception when unique_violation then null;
        end;
      end if;
      if e.sem_motorista_30 >= 3 then
        begin
          insert into alertas_operacionais (cidade_id, zona, regiao, tipo, severidade, mensagem, dados)
          values (c.id, e.zona, e.regiao, 'SEM_MOTORISTA', 'ALTA', e.regiao || ': ' || e.sem_motorista_30 || ' pedidos sem motorista em 30 min',
                  jsonb_build_object('qtd', e.sem_motorista_30));
          n_alertas := n_alertas + 1;
        exception when unique_violation then null;
        end;
      end if;
      if e.demanda_15 >= 5 and e.canceladas_30::numeric / greatest(e.demanda_15 + e.demanda_ant, 1) > 0.3 then
        begin
          insert into alertas_operacionais (cidade_id, zona, regiao, tipo, severidade, mensagem, dados)
          values (c.id, e.zona, e.regiao, 'CANCELAMENTO_ALTO', 'MEDIA', e.regiao || ': muitos cancelamentos na última meia hora',
                  jsonb_build_object('canceladas', e.canceladas_30));
          n_alertas := n_alertas + 1;
        exception when unique_violation then null;
        end;
      end if;
      -- 3) aviso a motoristas online e LIVRES a até 4 km de uma zona ALTA (com anti-spam)
      if interno.nivel_pressao(e.pressao) = 'ALTA' then
        for d in select p.motorista_id, interno.distancia_km(p.lat, p.lng, e.lat, e.lng) dist from motorista_presenca p
                 where p.cidade_id = c.id and p.online and p.disponivel and p.lat is not null
                   and interno.zona(p.lat, p.lng) <> e.zona
                   and interno.distancia_km(p.lat, p.lng, e.lat, e.lng) <= 4 loop
          v_ok := interno.notificar_se_pode(d.motorista_id, 'DEMANDA', 'Demanda aumentando perto de você',
                    e.regiao || ' a ' || round(d.dist::numeric, 1) || ' km. Estimativa — não é garantia de corrida.',
                    jsonb_build_object('zona', e.zona, 'lat', e.lat, 'lng', e.lng));
          if v_ok then n_avisos := n_avisos + 1; end if;
        end loop;
      end if;
    end loop;
    -- picos previstos para a próxima hora (cidade inteira)
    if (interno.prever_demanda(c.id, '*', now() + interval '30 minutes', 60) ->> 'pedidos_previstos')::numeric
       > 1.5 * greatest((select count(*) from corridas where cidade_id = c.id and solicitada_em > now() - interval '1 hour'), 1) then
      begin
        insert into alertas_operacionais (cidade_id, tipo, severidade, mensagem, dados)
        values (c.id, 'PICO_PREVISTO', 'MEDIA', 'Pico de demanda estimado para a próxima hora',
                interno.prever_demanda(c.id, '*', now() + interval '30 minutes', 60));
        n_alertas := n_alertas + 1;
      exception when unique_violation then null;
      end;
    end if;
  end loop;

  -- sugestões vencidas
  update sugestoes_incentivo set status = 'EXPIRADA' where status = 'SUGERIDA' and janela_fim < now();
  return jsonb_build_object('bloco', v_bloco, 'alertas', n_alertas, 'avisos_motoristas', n_avisos);
end $$;

-- inclui o job da inteligência no agendador
create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'inteligencia' then
    return jsonb_build_object('inteligencia', interno.rodar_job('inteligencia', 'interno.job_inteligencia()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object('liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule(jobid) from cron.job where jobname = 'mob_inteligencia';
    perform cron.schedule('mob_inteligencia', '*/5 * * * *', $c$select public.executar_jobs('inteligencia')$c$);
  end if;
exception when others then raise notice 'pg_cron: %', sqlerrm;
end $$;

-- RLS
do $$
declare t text;
begin
  foreach t in array array['regioes','clima_cidade','eventos_cidade','inteligencia_snapshots','alertas_operacionais','sugestoes_incentivo','notificacao_preferencias'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('regioes', 'todos', 'ativa or interno.eh_staff()');
select interno.criar_politica('clima_cidade', 'staff', 'interno.eh_staff()');
select interno.criar_politica('eventos_cidade', 'staff', 'interno.eh_staff()');
select interno.criar_politica('inteligencia_snapshots', 'staff', $p$interno.eh_papel('{OPERACOES,ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('alertas_operacionais', 'staff', $p$interno.eh_papel('{OPERACOES,ADMIN}')$p$);
select interno.criar_politica('sugestoes_incentivo', 'staff', $p$interno.eh_papel('{OPERACOES,ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('notificacao_preferencias', 'proprio', 'usuario_id = auth.uid()');

select interno.aplicar_permissoes_funcoes();
