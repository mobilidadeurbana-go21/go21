-- ============================================================
-- 0014 — AJUSTES ENCONTRADOS AO LIGAR AS TELAS
-- painel_motorista (0005) mostrava R$/hora absurdo com poucos minutos online
-- (ex.: R$ 532/h com 5 min). Mesma regra já usada na rentabilidade (0008).
-- acompanhar_corrida passa a devolver as opções da corrida (observação, voo, bagagens).
-- ============================================================

create or replace function public.painel_motorista(p_inicio date default null, p_fim date default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_tz text; v_ini timestamptz; v_fim timestamptz; k custos_motorista;
  v_fat numeric; v_gorj numeric; v_km numeric; v_corridas int; v_online numeric; v_corrida_h numeric; v_comb_lanc numeric;
  v_comb numeric; v_outros_lanc numeric; v_outros numeric; v_res numeric; v_conf boolean;
begin
  select coalesce(c.fuso, 'America/Sao_Paulo') into v_tz from motoristas m join cidades c on c.id = m.cidade_id where m.id = v_uid;
  v_ini := (coalesce(p_inicio, (now() at time zone v_tz)::date))::timestamp at time zone v_tz;
  v_fim := ((coalesce(p_fim, p_inicio, (now() at time zone v_tz)::date)) + 1)::timestamp at time zone v_tz;
  select * into k from custos_motorista where motorista_id = v_uid;
  v_conf := found;
  if not v_conf then k := row(v_uid, 6.00, 10, 0.10, 0.03, 0.15, 0, 0, 0, 0, 200, now())::custos_motorista; end if;

  select coalesce(sum((e.dados ->> 'motorista')::numeric), 0), count(*) into v_fat, v_corridas
  from corrida_eventos e join corridas c on c.id = e.corrida_id
  where c.motorista_id = v_uid and e.tipo = 'PAGAMENTO' and e.criado_em >= v_ini and e.criado_em < v_fim;
  select coalesce(sum(valor), 0) into v_gorj from recebiveis
  where motorista_id = v_uid and tipo in ('GORJETA','TAXA_CANCELAMENTO') and criado_em >= v_ini and criado_em < v_fim;

  select coalesce(sum(c.distancia_real_km), 0) + coalesce(sum(o.distancia_embarque_km), 0),
         coalesce(sum(extract(epoch from c.finalizada_em - c.aceita_em)) / 3600, 0)
    into v_km, v_corrida_h
  from corridas c left join ofertas o on o.corrida_id = c.id and o.motorista_id = v_uid and o.status = 'ACEITA'
  where c.motorista_id = v_uid and c.finalizada_em >= v_ini and c.finalizada_em < v_fim;

  select coalesce(sum(extract(epoch from least(coalesce(fim, now()), v_fim) - greatest(inicio, v_ini))) / 3600, 0) into v_online
  from sessoes_online where motorista_id = v_uid and inicio < v_fim and coalesce(fim, now()) > v_ini;

  select coalesce(sum(valor) filter (where tipo = 'COMBUSTIVEL'), 0), coalesce(sum(valor) filter (where tipo <> 'COMBUSTIVEL'), 0)
    into v_comb_lanc, v_outros_lanc
  from custos_lancados where motorista_id = v_uid and data >= v_ini::date and data < v_fim::date;

  v_comb := case when v_comb_lanc > 0 then v_comb_lanc else round(v_km / k.consumo_km_l * k.preco_combustivel, 2) end;
  v_outros := round(v_outros_lanc + v_km * (k.manutencao_km + k.pneus_km + k.depreciacao_km + k.outros_km)
                    + (k.seguro_mes + k.financiamento_mes + k.outros_mes) / k.horas_mes * v_online, 2);
  v_res := v_fat + v_gorj - v_comb - v_outros;
  return jsonb_build_object(
    'periodo', jsonb_build_object('inicio', v_ini, 'fim', v_fim),
    'faturamento', round(v_fat + v_gorj, 2), 'corridas', v_corridas, 'km', round(v_km, 1),
    'combustivel', v_comb, 'combustivel_estimado', v_comb_lanc = 0,
    'outros_custos', v_outros,
    'resultado_operacional', round(v_res, 2),
    'tempo_online_h', round(v_online, 2), 'tempo_em_corrida_h', round(v_corrida_h, 2),
    'tempo_ocioso_h', round(greatest(v_online - v_corrida_h, 0), 2),
    'resultado_hora', case when v_online >= 0.25 then round(v_res / v_online, 2) end,   -- [0014] mesma regra da rentabilidade: só com 15 min+ online
    'custos_configurados', v_conf);
end $$;

-- acompanhar_corrida (0003) + opções da corrida (0011), desconto e se é corporativa
create or replace function public.acompanhar_corrida(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_mot jsonb; pr motorista_presenca;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (c.passageiro_id <> v_uid and c.motorista_id is distinct from v_uid and not interno.eh_staff()) then
    perform interno.erro('CORRIDA_NAO_ENCONTRADA');
  end if;
  if c.status in ('SOLICITADA','BUSCANDO') then
    perform interno.buscar_motorista(p_corrida);
    select * into c from corridas where id = p_corrida;
  end if;
  if c.motorista_id is not null then
    select * into pr from motorista_presenca where motorista_id = c.motorista_id;
    select jsonb_build_object('nome', split_part(p.nome, ' ', 1), 'foto', p.foto_path, 'nota', m.avaliacao_media,
             'veiculo', jsonb_build_object('modelo', v.marca || ' ' || v.modelo, 'cor', v.cor, 'placa', v.placa),
             'lat', case when c.status in ('A_CAMINHO','CHEGOU','EM_CURSO') then pr.lat end,
             'lng', case when c.status in ('A_CAMINHO','CHEGOU','EM_CURSO') then pr.lng end,
             'rumo', pr.rumo,
             'eta_min', case when c.status = 'A_CAMINHO' and pr.lat is not null then
                round((interno.distancia_km(pr.lat, pr.lng, c.origem_lat, c.origem_lng) * interno.cfg_num('fator_rota', 1.3)
                      / interno.cfg_num('velocidade_media_kmh', 25) * 60)::numeric, 0) end)
      into v_mot
    from perfis p join motoristas m on m.id = p.id left join veiculos v on v.id = c.veiculo_id
    where p.id = c.motorista_id;
  end if;
  return jsonb_build_object(
    'id', c.id, 'status', c.status, 'categoria', c.categoria,
    'origem', jsonb_build_object('lat', c.origem_lat, 'lng', c.origem_lng, 'endereco', c.origem_endereco),
    'destino', jsonb_build_object('lat', c.destino_lat, 'lng', c.destino_lng, 'endereco', c.destino_endereco),
    'preco_estimado', c.preco_estimado, 'preco_final', c.preco_final, 'metodo', c.metodo_pagamento,
    'pin', case when v_uid = c.passageiro_id then (select pin from corrida_segredos where corrida_id = c.id) end,
    'opcoes', c.opcoes, 'desconto', c.desconto, 'empresa', c.empresa_id is not null,   -- [0014] o app do motorista mostra observação/voo
    'motorista', v_mot,
    'passageiro', case when v_uid = c.motorista_id then
        (select jsonb_build_object('nome', split_part(nome, ' ', 1)) from perfis where id = c.passageiro_id) end,
    'cancelado_por', c.cancelado_por, 'taxa_cancelamento', c.taxa_cancelamento,
    'verificacao', (select jsonb_build_object('id', id, 'mensagem', mensagem) from verificacoes_seguranca
                    where corrida_id = c.id and status = 'AGUARDANDO' order by criada_em desc limit 1),
    'pagamento', (select jsonb_build_object('id', id, 'status', status, 'valor', valor) from pagamentos
                  where corrida_id = c.id and tipo = 'CORRIDA' order by criado_em desc limit 1),
    'avaliou', exists (select 1 from avaliacoes where corrida_id = c.id and avaliador_id = v_uid)
  );
end $$;

select interno.aplicar_permissoes_funcoes();
