-- ============================================================
-- 0008 — RENTABILIDADE AVANÇADA + DRIVER AI + IA DO ADMIN
-- Os assistentes NÃO inventam números: cada resposta sai de uma
-- consulta aos dados reais. Sem dados suficientes, eles dizem isso.
-- (Uma camada de linguagem — LLM — pode reescrever o texto na Edge
--  Function, mas recebe só estes fatos; ver docs/IA.md.)
-- ============================================================

create table if not exists metas_motorista (
  motorista_id uuid primary key references motoristas(id) on delete cascade,
  meta_liquida_mensal numeric(10,2),
  dias_trabalho_mes int not null default 22 check (dias_trabalho_mes between 1 and 31),
  horas_dia numeric(4,1) not null default 8,
  atualizado_em timestamptz not null default now()
);

create or replace function public.salvar_meta(p_meta_liquida_mensal numeric, p_dias_trabalho_mes int default 22, p_horas_dia numeric default 8)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}');
begin
  insert into metas_motorista (motorista_id, meta_liquida_mensal, dias_trabalho_mes, horas_dia)
  values (v_uid, p_meta_liquida_mensal, p_dias_trabalho_mes, p_horas_dia)
  on conflict (motorista_id) do update set meta_liquida_mensal = excluded.meta_liquida_mensal,
    dias_trabalho_mes = excluded.dias_trabalho_mes, horas_dia = excluded.horas_dia, atualizado_em = now();
end $$;

create or replace function interno.custos_do_motorista(p_uid uuid) returns custos_motorista
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare k custos_motorista;
begin
  select * into k from custos_motorista where motorista_id = p_uid;
  if not found then k := row(p_uid, 6.00, 10, 0.10, 0.03, 0.15, 0, 0, 0, 0, 200, null)::custos_motorista; end if;
  return k;
end $$;

-- resultado detalhado de um período (base de todos os números do motorista)
create or replace function interno.resultado_motorista(p_uid uuid, p_ini timestamptz, p_fim timestamptz) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare k custos_motorista; v_fat numeric; v_extra numeric; v_corr int; v_km numeric; v_online numeric; v_em_corrida numeric;
        v_comb_l numeric; v_outros_l numeric; v_comb numeric; v_manut numeric; v_pneus numeric; v_deprec numeric; v_outros_km numeric;
        v_seguro numeric; v_financ numeric; v_outros_mes numeric; v_custos numeric; v_res numeric; v_conf boolean;
begin
  k := interno.custos_do_motorista(p_uid);
  v_conf := k.atualizado_em is not null;
  select coalesce(sum((e.dados ->> 'motorista')::numeric), 0), count(*) into v_fat, v_corr
  from corrida_eventos e join corridas c on c.id = e.corrida_id
  where c.motorista_id = p_uid and e.tipo = 'PAGAMENTO' and e.criado_em >= p_ini and e.criado_em < p_fim;
  select coalesce(sum(valor), 0) into v_extra from recebiveis
  where motorista_id = p_uid and tipo in ('GORJETA','TAXA_CANCELAMENTO') and criado_em >= p_ini and criado_em < p_fim and status <> 'ESTORNADO';
  select coalesce(sum(c.distancia_real_km), 0) + coalesce(sum(o.distancia_embarque_km), 0),
         coalesce(sum(extract(epoch from c.finalizada_em - c.aceita_em)) / 3600, 0)
    into v_km, v_em_corrida
  from corridas c left join ofertas o on o.corrida_id = c.id and o.motorista_id = p_uid and o.status = 'ACEITA'
  where c.motorista_id = p_uid and c.finalizada_em >= p_ini and c.finalizada_em < p_fim;
  select coalesce(sum(extract(epoch from least(coalesce(fim, now()), p_fim) - greatest(inicio, p_ini))) / 3600, 0) into v_online
  from sessoes_online where motorista_id = p_uid and inicio < p_fim and coalesce(fim, now()) > p_ini;
  select coalesce(sum(valor) filter (where tipo = 'COMBUSTIVEL'), 0), coalesce(sum(valor) filter (where tipo <> 'COMBUSTIVEL'), 0)
    into v_comb_l, v_outros_l
  from custos_lancados where motorista_id = p_uid and data >= p_ini::date and data < p_fim::date;

  v_comb := case when v_comb_l > 0 then v_comb_l else round(v_km / k.consumo_km_l * k.preco_combustivel, 2) end;
  v_manut := round(v_km * k.manutencao_km, 2); v_pneus := round(v_km * k.pneus_km, 2);
  v_deprec := round(v_km * k.depreciacao_km, 2); v_outros_km := round(v_km * k.outros_km, 2);
  v_seguro := round(k.seguro_mes / k.horas_mes * v_online, 2);
  v_financ := round(k.financiamento_mes / k.horas_mes * v_online, 2);
  v_outros_mes := round(k.outros_mes / k.horas_mes * v_online, 2);
  v_custos := v_comb + v_manut + v_pneus + v_deprec + v_outros_km + v_seguro + v_financ + v_outros_mes + v_outros_l;
  v_res := v_fat + v_extra - v_custos;
  return jsonb_build_object(
    'inicio', p_ini, 'fim', p_fim,
    'receita', round(v_fat + v_extra, 2), 'receita_corridas', round(v_fat, 2), 'gorjetas_e_taxas', round(v_extra, 2),
    'corridas', v_corr, 'km', round(v_km, 1),
    'combustivel', v_comb, 'combustivel_estimado', v_comb_l = 0,
    'manutencao', v_manut, 'pneus', v_pneus, 'depreciacao', v_deprec, 'seguro', v_seguro, 'financiamento', v_financ,
    'outros', round(v_outros_km + v_outros_mes + v_outros_l, 2),
    'custos_operacionais', round(v_custos, 2),
    'resultado', round(v_res, 2),
    'horas_online', round(v_online, 2), 'horas_em_corrida', round(v_em_corrida, 2), 'horas_ociosas', round(greatest(v_online - v_em_corrida, 0), 2),
    'resultado_hora', case when v_online >= 0.25 then round(v_res / v_online, 2) end,   -- menos de 15 min online: não calcula (distorce)
    'resultado_km', case when v_km > 0 then round(v_res / v_km, 2) end,
    'custos_configurados', v_conf);
end $$;

create or replace function interno.fuso_motorista(p_uid uuid) returns text language sql stable as $$
  select coalesce((select c.fuso from motoristas m join cidades c on c.id = m.cidade_id where m.id = p_uid), 'America/Sao_Paulo')
$$;

-- série histórica por dia + comparação com o PRÓPRIO histórico (nunca com outros motoristas)
create or replace function public.rentabilidade_historico(p_dias int default 30) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_tz text := interno.fuso_motorista(v_uid); v_serie jsonb; v_hoje date;
        v_atual jsonb; v_ant jsonb;
begin
  p_dias := least(greatest(p_dias, 7), 180);
  v_hoje := (now() at time zone v_tz)::date;
  select coalesce(jsonb_agg(interno.resultado_motorista(v_uid, d::timestamp at time zone v_tz, (d + 1)::timestamp at time zone v_tz)
                            || jsonb_build_object('data', d) order by d), '[]')
    into v_serie
  from generate_series(v_hoje - p_dias + 1, v_hoje, interval '1 day') g(dd), lateral (select dd::date d) x;
  v_atual := interno.resultado_motorista(v_uid, (v_hoje - p_dias + 1)::timestamp at time zone v_tz, (v_hoje + 1)::timestamp at time zone v_tz);
  v_ant := interno.resultado_motorista(v_uid, (v_hoje - 2 * p_dias + 1)::timestamp at time zone v_tz, (v_hoje - p_dias + 1)::timestamp at time zone v_tz);
  return jsonb_build_object('dias', p_dias, 'serie', v_serie, 'periodo_atual', v_atual, 'periodo_anterior', v_ant,
    'variacao_resultado_pct', case when (v_ant ->> 'resultado')::numeric > 0
        then round(100 * ((v_atual ->> 'resultado')::numeric - (v_ant ->> 'resultado')::numeric) / (v_ant ->> 'resultado')::numeric, 1) end,
    'variacao_resultado_hora_pct', case when (v_ant ->> 'resultado_hora')::numeric > 0
        then round(100 * ((v_atual ->> 'resultado_hora')::numeric - (v_ant ->> 'resultado_hora')::numeric) / (v_ant ->> 'resultado_hora')::numeric, 1) end);
end $$;

-- melhores horários (resultado por hora online, por hora do dia)
create or replace function interno.melhores_horarios(p_uid uuid, p_dias int default 30) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  with tz as (select interno.fuso_motorista(p_uid) z),
  ganhos as (
    select extract(hour from c.finalizada_em at time zone (select z from tz))::int h, sum((e.dados ->> 'motorista')::numeric) g, count(*) n
    from corrida_eventos e join corridas c on c.id = e.corrida_id
    where c.motorista_id = p_uid and e.tipo = 'PAGAMENTO' and e.criado_em > now() - make_interval(days => p_dias)
    group by 1),
  online as (
    select extract(hour from hh at time zone (select z from tz))::int h,
           sum(extract(epoch from least(coalesce(s.fim, now()), hh + interval '1 hour') - greatest(s.inicio, hh)) / 3600) horas
    from sessoes_online s, generate_series(date_trunc('hour', s.inicio), coalesce(s.fim, now()), interval '1 hour') hh
    where s.motorista_id = p_uid and s.inicio > now() - make_interval(days => p_dias)
    group by 1)
  select coalesce(jsonb_agg(jsonb_build_object('hora', o.h, 'ganho', round(coalesce(g.g, 0), 2), 'corridas', coalesce(g.n, 0),
           'horas_online', round(o.horas, 1), 'ganho_por_hora', round(coalesce(g.g, 0) / nullif(o.horas, 0), 2))
           order by coalesce(g.g, 0) / nullif(o.horas, 0) desc nulls last), '[]')
  from online o left join ganhos g on g.h = o.h where o.horas >= 0.5
$$;

create or replace function interno.melhores_regioes(p_uid uuid, p_dias int default 30) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(x order by (x ->> 'ganho_medio')::numeric desc), '[]') from (
    select jsonb_build_object('regiao', interno.nome_regiao(c.cidade_id, c.origem_lat, c.origem_lng),
             'corridas', count(*), 'ganho_total', round(sum((e.dados ->> 'motorista')::numeric), 2),
             'ganho_medio', round(avg((e.dados ->> 'motorista')::numeric), 2)) x
    from corrida_eventos e join corridas c on c.id = e.corrida_id
    where c.motorista_id = p_uid and e.tipo = 'PAGAMENTO' and e.criado_em > now() - make_interval(days => p_dias)
    group by interno.nome_regiao(c.cidade_id, c.origem_lat, c.origem_lng)) y
$$;

create or replace function interno.corridas_mais_rentaveis(p_uid uuid, p_dias int default 30, p_limite int default 3) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare k custos_motorista := interno.custos_do_motorista(p_uid); v_custo_km numeric;
begin
  v_custo_km := k.preco_combustivel / k.consumo_km_l + k.manutencao_km + k.pneus_km + k.depreciacao_km + k.outros_km;
  return coalesce((select jsonb_agg(x) from (
    select jsonb_build_object('corrida', c.id, 'data', c.finalizada_em,
             'origem', c.origem_endereco, 'destino', c.destino_endereco,
             'valor', c.preco_final, 'seu_ganho', (e.dados ->> 'motorista')::numeric,
             'km_total', round(coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0), 1),
             'minutos', round(extract(epoch from c.finalizada_em - c.aceita_em) / 60),
             'resultado_estimado', round((e.dados ->> 'motorista')::numeric - (coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0)) * v_custo_km, 2),
             'resultado_hora_estimado', round(((e.dados ->> 'motorista')::numeric - (coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0)) * v_custo_km)
                                        / greatest(extract(epoch from c.finalizada_em - c.aceita_em) / 3600, 5.0/60), 2)) x
    from corrida_eventos e join corridas c on c.id = e.corrida_id
    left join ofertas o on o.corrida_id = c.id and o.motorista_id = p_uid and o.status = 'ACEITA'
    where c.motorista_id = p_uid and e.tipo = 'PAGAMENTO' and e.criado_em > now() - make_interval(days => p_dias)
    order by ((e.dados ->> 'motorista')::numeric - (coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0)) * v_custo_km) desc
    limit p_limite) y), '[]');
end $$;

create or replace function interno.custo_por_km(p_uid uuid) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare k custos_motorista := interno.custos_do_motorista(p_uid); v_km_mes numeric; v_var numeric; v_fixo numeric;
begin
  select coalesce(sum(coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0)), 0) into v_km_mes
  from corridas c left join ofertas o on o.corrida_id = c.id and o.motorista_id = p_uid and o.status = 'ACEITA'
  where c.motorista_id = p_uid and c.finalizada_em > now() - interval '30 days';
  v_var := k.preco_combustivel / k.consumo_km_l + k.manutencao_km + k.pneus_km + k.depreciacao_km + k.outros_km;
  v_fixo := case when v_km_mes > 0 then (k.seguro_mes + k.financiamento_mes + k.outros_mes) / v_km_mes end;
  return jsonb_build_object(
    'combustivel_km', round(k.preco_combustivel / k.consumo_km_l, 3), 'manutencao_km', k.manutencao_km, 'pneus_km', k.pneus_km,
    'depreciacao_km', k.depreciacao_km, 'outros_km', k.outros_km, 'variavel_km', round(v_var, 3),
    'fixos_mes', k.seguro_mes + k.financiamento_mes + k.outros_mes, 'km_ultimos_30d', round(v_km_mes, 1),
    'fixo_por_km', round(v_fixo, 3), 'total_km', round(v_var + coalesce(v_fixo, 0), 3),
    'custos_configurados', k.atualizado_em is not null);
end $$;

-- ============================================================
-- DRIVER AI
-- ============================================================
create table if not exists assistente_conversas (
  id bigint generated always as identity primary key,
  usuario_id uuid not null,
  assistente text not null check (assistente in ('MOTORISTA','ADMIN')),
  pergunta text not null,
  intencao text,
  resposta text,
  suficiente boolean,
  criado_em timestamptz not null default now()
);
create index if not exists assistente_conversas_idx on assistente_conversas (usuario_id, criado_em desc);

create or replace function interno.normalizar(t text) returns text language sql immutable as $$
  select lower(translate(coalesce(t, ''), 'áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ', 'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC'))
$$;
create or replace function interno.num(v numeric, casas int default 1) returns text language sql immutable as $$
  select replace(round(coalesce(v, 0), casas)::text, '.', ',')
$$;
create or replace function interno.horas_txt(h numeric) returns text language sql immutable as $$
  select case when coalesce(h, 0) < 1/60.0 then '0 min'
              when h < 1 then round(h * 60) || ' min'
              else floor(h) || 'h' || case when round((h - floor(h)) * 60) > 0 then ' ' || round((h - floor(h)) * 60) || 'min' else '' end end
$$;
create or replace function interno.reais(v numeric) returns text language sql immutable as $$
  select 'R$ ' || replace(replace(replace(to_char(coalesce(v, 0), 'FM999G999G990D00'), ',', '#'), '.', ','), '#', '.')
$$;

-- período pedido na pergunta → (início, fim, rótulo)
create or replace function interno.periodo_da_pergunta(p text, p_tz text, p_padrao text default 'hoje',
  out ini timestamptz, out fim timestamptz, out rotulo text)
language plpgsql stable as $$
declare h date := (now() at time zone p_tz)::date; q text := interno.normalizar(p); k text;
begin
  k := case when q ~ 'ontem' then 'ontem' when q ~ 'semana' then 'semana' when q ~ '\m(mes|mensal)\M' then 'mes'
            when q ~ '30 dias|ultimo mes' then '30d' when q ~ 'hoje|meu dia|o dia' then 'hoje' else p_padrao end;
  if k = 'ontem' then ini := (h - 1)::timestamp at time zone p_tz; fim := h::timestamp at time zone p_tz; rotulo := 'ontem';
  elsif k = 'semana' then ini := (h - 6)::timestamp at time zone p_tz; fim := (h + 1)::timestamp at time zone p_tz; rotulo := 'nos últimos 7 dias';
  elsif k = 'mes' then ini := date_trunc('month', h)::timestamp at time zone p_tz; fim := (h + 1)::timestamp at time zone p_tz; rotulo := 'neste mês';
  elsif k = '30d' then ini := (h - 29)::timestamp at time zone p_tz; fim := (h + 1)::timestamp at time zone p_tz; rotulo := 'nos últimos 30 dias';
  else ini := h::timestamp at time zone p_tz; fim := (h + 1)::timestamp at time zone p_tz; rotulo := 'hoje';
  end if;
end $$;

create or replace function public.assistente_motorista(p_pergunta text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); q text := interno.normalizar(p_pergunta); v_tz text := interno.fuso_motorista(v_uid);
        v_int text; v_resp text; v_dados jsonb; v_ok boolean := true; per record; r jsonb; m metas_motorista; x jsonb; v_dia numeric;
        v_mes jsonb; v_restante numeric; v_dias_rest int; v_custo_dia numeric; v_km_dia numeric;
begin
  perform interno.limitar('assistente', 30, 60);
  if length(trim(coalesce(p_pergunta, ''))) = 0 then perform interno.erro('PERGUNTA_VAZIA'); end if;

  v_int := case
    when q ~ 'amanha|preciso faturar|meta' then 'META_AMANHA'
    when q ~ 'por km|custando|custo do carro|quanto o carro' then 'CUSTO_KM'
    when q ~ 'mais rentavel|melhor corrida|corrida mais' then 'CORRIDA_MAIS_RENTAVEL'
    when q ~ 'melhor hor|que horas|qual horario' then 'MELHOR_HORARIO'
    when q ~ 'melhor regi|onde rend|qual regiao|melhor lugar' then 'MELHOR_REGIAO'
    when q ~ 'liquido|lucro|sobrou' then 'LIQUIDO'
    when q ~ 'gastei|gasto|despesa|custo' then 'GASTOS'
    when q ~ 'como foi|resumo|meu dia|minha semana|meu mes' then 'RESUMO'
    when q ~ 'fatur|ganhei|recebi|quanto fiz' then 'FATURAMENTO'
    else 'AJUDA' end;
  select * into per from interno.periodo_da_pergunta(p_pergunta, v_tz, case when v_int in ('MELHOR_HORARIO','MELHOR_REGIAO','CORRIDA_MAIS_RENTAVEL') then '30d' else 'hoje' end);

  if v_int in ('RESUMO','FATURAMENTO','GASTOS','LIQUIDO') then
    r := interno.resultado_motorista(v_uid, per.ini, per.fim);
    v_dados := r;
    if (r ->> 'corridas')::int = 0 and (r ->> 'horas_online')::numeric = 0 then
      v_ok := false;
      v_resp := 'Ainda não tenho dados ' || per.rotulo || ': nenhuma corrida paga e nenhum tempo online registrado.';
    elsif v_int = 'FATURAMENTO' then
      v_resp := 'Você faturou ' || interno.reais((r ->> 'receita')::numeric) || ' ' || per.rotulo || ' em ' || (r ->> 'corridas') || ' corrida(s)'
             || case when (r ->> 'gorjetas_e_taxas')::numeric > 0 then ', incluindo ' || interno.reais((r ->> 'gorjetas_e_taxas')::numeric) || ' de gorjetas e taxas' else '' end || '.';
    elsif v_int = 'GASTOS' then
      v_resp := 'Seus custos ' || per.rotulo || ' foram de ' || interno.reais((r ->> 'custos_operacionais')::numeric)
             || ': combustível ' || interno.reais((r ->> 'combustivel')::numeric) || case when (r ->> 'combustivel_estimado')::boolean then ' (estimado pelo km)' else ' (lançado por você)' end
             || ', manutenção ' || interno.reais((r ->> 'manutencao')::numeric) || ', pneus ' || interno.reais((r ->> 'pneus')::numeric)
             || ', depreciação ' || interno.reais((r ->> 'depreciacao')::numeric) || ', seguro ' || interno.reais((r ->> 'seguro')::numeric)
             || ', financiamento ' || interno.reais((r ->> 'financiamento')::numeric) || ', outros ' || interno.reais((r ->> 'outros')::numeric) || '.';
    elsif v_int = 'LIQUIDO' then
      v_resp := 'Seu resultado líquido estimado ' || per.rotulo || ' é ' || interno.reais((r ->> 'resultado')::numeric)
             || ' (receita ' || interno.reais((r ->> 'receita')::numeric) || ' menos custos ' || interno.reais((r ->> 'custos_operacionais')::numeric) || ').';
    else
      v_resp := initcap(per.rotulo) || ': ' || (r ->> 'corridas') || ' corrida(s), receita ' || interno.reais((r ->> 'receita')::numeric)
             || ', custos ' || interno.reais((r ->> 'custos_operacionais')::numeric) || ', resultado ' || interno.reais((r ->> 'resultado')::numeric)
             || '. Online ' || interno.horas_txt((r ->> 'horas_online')::numeric) || ' (' || interno.horas_txt((r ->> 'horas_em_corrida')::numeric)
             || ' em corrida, ' || interno.horas_txt((r ->> 'horas_ociosas')::numeric) || ' parado)'
             || case when r ->> 'resultado_hora' is not null then ', ' || interno.reais((r ->> 'resultado_hora')::numeric) || ' por hora' else '' end || '.';
    end if;
    if v_ok and not (r ->> 'custos_configurados')::boolean then
      v_resp := v_resp || ' Atenção: os custos usam valores padrão; configure os do seu carro para números mais certos.';
    end if;

  elsif v_int = 'MELHOR_HORARIO' then
    v_dados := interno.melhores_horarios(v_uid, 30);
    if jsonb_array_length(v_dados) < 3 then
      v_ok := false; v_resp := 'Ainda não tenho dados suficientes para comparar horários (preciso de pelo menos 3 faixas de horário com 30 min online nos últimos 30 dias).';
    else
      v_resp := 'Nos últimos 30 dias, seu melhor horário foi das ' || (v_dados -> 0 ->> 'hora') || 'h às ' || ((v_dados -> 0 ->> 'hora')::int + 1) || 'h: '
             || interno.reais((v_dados -> 0 ->> 'ganho_por_hora')::numeric) || ' por hora online. Em seguida: '
             || (v_dados -> 1 ->> 'hora') || 'h (' || interno.reais((v_dados -> 1 ->> 'ganho_por_hora')::numeric) || '/h).';
    end if;

  elsif v_int = 'MELHOR_REGIAO' then
    v_dados := interno.melhores_regioes(v_uid, 30);
    if jsonb_array_length(v_dados) = 0 then
      v_ok := false; v_resp := 'Ainda não tenho corridas suas nos últimos 30 dias para comparar regiões.';
    else
      v_resp := 'Nos últimos 30 dias, as corridas que começaram em ' || (v_dados -> 0 ->> 'regiao') || ' renderam mais: média de '
             || interno.reais((v_dados -> 0 ->> 'ganho_medio')::numeric) || ' por corrida (' || (v_dados -> 0 ->> 'corridas') || ' corridas).';
    end if;

  elsif v_int = 'CORRIDA_MAIS_RENTAVEL' then
    v_dados := interno.corridas_mais_rentaveis(v_uid, 30, 3);
    if jsonb_array_length(v_dados) = 0 then
      v_ok := false; v_resp := 'Ainda não tenho corridas pagas nos últimos 30 dias.';
    else
      x := v_dados -> 0;
      v_resp := 'Sua corrida mais rentável nos últimos 30 dias foi em ' || to_char((x ->> 'data')::timestamptz at time zone v_tz, 'DD/MM "às" HH24:MI')
             || ': você recebeu ' || interno.reais((x ->> 'seu_ganho')::numeric) || ' por ' || interno.num((x ->> 'km_total')::numeric) || ' km, resultado estimado de '
             || interno.reais((x ->> 'resultado_estimado')::numeric) || ' (' || interno.reais((x ->> 'resultado_hora_estimado')::numeric) || '/h).';
    end if;

  elsif v_int = 'CUSTO_KM' then
    v_dados := interno.custo_por_km(v_uid);
    v_resp := 'Seu carro custa cerca de ' || interno.reais((v_dados ->> 'variavel_km')::numeric) || ' por km rodado (combustível '
           || interno.reais((v_dados ->> 'combustivel_km')::numeric) || ', manutenção, pneus e depreciação)'
           || case when v_dados ->> 'fixo_por_km' is not null then '. Somando os custos fixos do mês, o total fica em '
                    || interno.reais((v_dados ->> 'total_km')::numeric) || ' por km (com base nos seus ' || interno.num((v_dados ->> 'km_ultimos_30d')::numeric) || ' km dos últimos 30 dias)'
                   else '. Para incluir custos fixos, preciso de corridas nos últimos 30 dias' end || '.'
           || case when not (v_dados ->> 'custos_configurados')::boolean then ' Esses valores são padrão: configure os do seu carro.' else '' end;

  elsif v_int = 'META_AMANHA' then
    select * into m from metas_motorista where motorista_id = v_uid;
    if m.meta_liquida_mensal is null then
      v_ok := false;
      v_resp := 'Para eu calcular quanto você precisa faturar amanhã, defina sua meta de ganho líquido do mês em "Minha meta".';
    else
      v_mes := interno.resultado_motorista(v_uid, date_trunc('month', (now() at time zone v_tz)::date)::timestamp at time zone v_tz, now());
      v_restante := m.meta_liquida_mensal - (v_mes ->> 'resultado')::numeric;
      v_dias_rest := greatest(1, m.dias_trabalho_mes - (select count(distinct (inicio at time zone v_tz)::date) from sessoes_online
                       where motorista_id = v_uid and inicio >= date_trunc('month', (now() at time zone v_tz)::date)::timestamp at time zone v_tz));
      select coalesce(avg(km), 60) into v_km_dia from (
        select (c.finalizada_em at time zone v_tz)::date d, sum(coalesce(c.distancia_real_km, 0) + coalesce(o.distancia_embarque_km, 0)) km
        from corridas c left join ofertas o on o.corrida_id = c.id and o.motorista_id = v_uid and o.status = 'ACEITA'
        where c.motorista_id = v_uid and c.finalizada_em > now() - interval '30 days' group by 1) z;
      x := interno.custo_por_km(v_uid);
      v_custo_dia := round(v_km_dia * (x ->> 'variavel_km')::numeric + (x ->> 'fixos_mes')::numeric / m.dias_trabalho_mes, 2);
      v_dia := round(greatest(v_restante, 0) / v_dias_rest, 2);
      v_dados := jsonb_build_object('meta', m.meta_liquida_mensal, 'resultado_mes', v_mes ->> 'resultado', 'falta', v_restante,
                   'dias_restantes', v_dias_rest, 'liquido_por_dia', v_dia, 'custo_dia_estimado', v_custo_dia, 'km_medio_dia', round(v_km_dia, 1),
                   'faturamento_necessario', v_dia + v_custo_dia);
      if v_restante <= 0 then
        v_resp := 'Você já bateu a meta do mês (' || interno.reais(m.meta_liquida_mensal) || '). Tudo o que fizer agora é extra.';
      else
        v_resp := 'Faltam ' || interno.reais(v_restante) || ' para sua meta de ' || interno.reais(m.meta_liquida_mensal) || ' em ' || v_dias_rest
               || ' dia(s) de trabalho. Amanhã, para ficar com ' || interno.reais(v_dia) || ' líquido, você precisa faturar cerca de '
               || interno.reais(v_dia + v_custo_dia) || ' (estimando ' || interno.reais(v_custo_dia) || ' de custos com base no seu km médio). É uma estimativa, não garantia.';
      end if;
    end if;

  else
    v_ok := false;
    v_resp := 'Posso responder com os seus números reais. Pergunte, por exemplo: "Como foi meu dia?", "Quanto eu faturei esta semana?", '
           || '"Quanto gastei hoje?", "Qual foi meu melhor horário?", "Qual região foi melhor?", "Quanto preciso faturar amanhã?", '
           || '"Qual foi minha corrida mais rentável?", "Quanto meu carro está custando por km?", "Quanto ganhei líquido?"';
  end if;

  insert into assistente_conversas (usuario_id, assistente, pergunta, intencao, resposta, suficiente)
  values (v_uid, 'MOTORISTA', left(p_pergunta, 500), v_int, v_resp, v_ok);
  return jsonb_build_object('intencao', v_int, 'resposta', v_resp, 'dados_suficientes', v_ok, 'dados', v_dados,
    'fonte', 'Calculado com os seus dados reais da plataforma');
end $$;

-- ============================================================
-- IA OPERACIONAL DO ADMINISTRADOR
-- ============================================================
create or replace function public.assistente_admin(p_pergunta text, p_cidade uuid default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,OPERACOES,FINANCEIRO,RISCO,SUPORTE}'); q text := interno.normalizar(p_pergunta);
        v_int text; v_resp text; v_dados jsonb; v_ok boolean := true; per record; x record; n numeric; m numeric;
        v_dur interval;
begin
  perform interno.limitar('assistente_admin', 60, 60);
  v_int := case
    when q ~ 'fraude' then 'FRAUDE'
    when q ~ 'baixa oferta|falta de motorista|poucos motoristas|regioes? com' then 'BAIXA_OFERTA'
    when q ~ 'cresceu|crescimento' then 'CRESCIMENTO_CIDADE'
    when q ~ 'cancel' and q ~ 'cidade' then 'CANCELAMENTO_CIDADE'
    when q ~ 'horario|hora' and q ~ 'demanda|movimento|pedidos' then 'HORARIO_PICO'
    when q ~ 'pagamos|repass|motoristas recebe' then 'PAGO_MOTORISTAS'
    when q ~ 'receita|faturamos|ganhamos' then 'RECEITA'
    when q ~ 'quantas corridas|corridas tivemos|numero de corridas' then 'CORRIDAS'
    when q ~ 'cancel' then 'CANCELAMENTOS'
    else 'AJUDA' end;
  select * into per from interno.periodo_da_pergunta(p_pergunta, 'America/Sao_Paulo', case when v_int in ('CRESCIMENTO_CIDADE','HORARIO_PICO','FRAUDE') then 'semana' else 'hoje' end);
  v_dur := per.fim - per.ini;

  if v_int = 'CORRIDAS' then
    select jsonb_build_object('solicitadas', count(*), 'concluidas', count(*) filter (where status in ('FINALIZADA','PAGA')),
                              'canceladas', count(*) filter (where status = 'CANCELADA'), 'sem_motorista', count(*) filter (where status = 'SEM_MOTORISTA'))
      into v_dados from corridas where solicitada_em >= per.ini and solicitada_em < per.fim and (p_cidade is null or cidade_id = p_cidade);
    v_resp := initcap(per.rotulo) || ': ' || (v_dados ->> 'solicitadas') || ' corridas solicitadas, ' || (v_dados ->> 'concluidas')
           || ' concluídas, ' || (v_dados ->> 'canceladas') || ' canceladas e ' || (v_dados ->> 'sem_motorista') || ' sem motorista.';

  elsif (v_int = 'RECEITA' or v_int = 'PAGO_MOTORISTAS') and not interno.eh_papel('{ADMIN,FINANCEIRO}') then
    -- números financeiros só para quem já vê o financeiro (mesma regra do ledger e do painel do dono)
    v_ok := false; v_dados := '{}';
    v_resp := 'Essa informação é financeira e só aparece para os papéis ADMIN e FINANCEIRO.';

  elsif v_int = 'RECEITA' or v_int = 'PAGO_MOTORISTAS' then
    select coalesce(sum(l.valor) filter (where ct.tipo = 'PLATAFORMA_RECEITA'), 0),
           coalesce(sum(l.valor) filter (where ct.tipo in ('MOTORISTA_PENDENTE','MOTORISTA_DISPONIVEL') and t.tipo in ('LIQUIDACAO_CORRIDA','GORJETA','TAXA_CANCELAMENTO','ESTORNO')), 0)
      into n, m
    from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id join transacoes_ledger t on t.id = l.transacao_id
    left join corridas c on t.referencia = c.id::text
    where l.criado_em >= per.ini and l.criado_em < per.fim and (p_cidade is null or c.cidade_id = p_cidade)
      and t.tipo not in ('LIBERACAO','LIBERACAO_INDICACAO','REPASSE','REPASSE_PAGO','REPASSE_FALHOU');
    v_dados := jsonb_build_object('receita_plataforma', n, 'ganhos_motoristas', m,
      'saques_pagos', (select coalesce(sum(valor), 0) from repasses where status = 'PAGO' and concluido_em >= per.ini and concluido_em < per.fim));
    v_resp := case when v_int = 'RECEITA'
      then 'Receita líquida da plataforma ' || per.rotulo || ': ' || interno.reais(n) || ' (já descontados os bônus de indicação e estornos).'
      else 'Ganhos gerados para motoristas ' || per.rotulo || ': ' || interno.reais(m) || '. Saques efetivamente pagos no período: '
           || interno.reais((v_dados ->> 'saques_pagos')::numeric) || '.' end;

  elsif v_int = 'CRESCIMENTO_CIDADE' then
    select coalesce(jsonb_agg(z order by (z ->> 'crescimento_pct')::numeric desc nulls last), '[]') into v_dados from (
      select jsonb_build_object('cidade', ci.nome,
        'atual', count(*) filter (where c.solicitada_em >= per.ini),
        'anterior', count(*) filter (where c.solicitada_em < per.ini),
        'crescimento_pct', round(100.0 * (count(*) filter (where c.solicitada_em >= per.ini) - count(*) filter (where c.solicitada_em < per.ini))
                                 / nullif(count(*) filter (where c.solicitada_em < per.ini), 0), 1)) z
      from corridas c join cidades ci on ci.id = c.cidade_id
      where c.status in ('FINALIZADA','PAGA') and c.solicitada_em >= per.ini - v_dur and c.solicitada_em < per.fim
      group by ci.nome) y;
    if jsonb_array_length(v_dados) = 0 then v_ok := false; v_resp := 'Não há corridas concluídas no período para comparar.';
    elsif v_dados -> 0 ->> 'crescimento_pct' is null then
      v_resp := (v_dados -> 0 ->> 'cidade') || ' lidera com ' || (v_dados -> 0 ->> 'atual') || ' corridas concluídas ' || per.rotulo || ' (sem período anterior para comparar).';
    else
      v_resp := (v_dados -> 0 ->> 'cidade') || ' foi a que mais cresceu ' || per.rotulo || ': ' || (v_dados -> 0 ->> 'crescimento_pct') || '% ('
             || (v_dados -> 0 ->> 'anterior') || ' → ' || (v_dados -> 0 ->> 'atual') || ' corridas concluídas) contra o período anterior.';
    end if;

  elsif v_int in ('CANCELAMENTO_CIDADE','CANCELAMENTOS') then
    select coalesce(jsonb_agg(z order by (z ->> 'taxa_pct')::numeric desc), '[]') into v_dados from (
      select jsonb_build_object('cidade', ci.nome, 'corridas', count(*), 'canceladas', count(*) filter (where c.status = 'CANCELADA'),
        'taxa_pct', round(100.0 * count(*) filter (where c.status = 'CANCELADA') / count(*), 1),
        'por_passageiro', count(*) filter (where c.cancelado_por = 'PASSAGEIRO'),
        'por_motorista_eventos', (select count(*) from corrida_eventos e join corridas c2 on c2.id = e.corrida_id
                                  where c2.cidade_id = ci.id and e.tipo = 'CANCELAMENTO_MOTORISTA' and e.criado_em >= per.ini and e.criado_em < per.fim)) z
      from corridas c join cidades ci on ci.id = c.cidade_id
      where c.solicitada_em >= per.ini and c.solicitada_em < per.fim and (p_cidade is null or c.cidade_id = p_cidade)
      group by ci.id, ci.nome having count(*) >= 1) y;
    if jsonb_array_length(v_dados) = 0 then v_ok := false; v_resp := 'Não há corridas no período.';
    else
      v_resp := (v_dados -> 0 ->> 'cidade') || ' teve a maior taxa de cancelamento ' || per.rotulo || ': ' || interno.num((v_dados -> 0 ->> 'taxa_pct')::numeric) || '% ('
             || (v_dados -> 0 ->> 'canceladas') || ' de ' || (v_dados -> 0 ->> 'corridas') || '; ' || (v_dados -> 0 ->> 'por_passageiro')
             || ' pelo passageiro e ' || (v_dados -> 0 ->> 'por_motorista_eventos') || ' cancelamentos de motorista com rematching).';
    end if;

  elsif v_int = 'HORARIO_PICO' then
    select coalesce(jsonb_agg(jsonb_build_object('hora', h, 'pedidos', n2, 'sem_motorista', sm) order by n2 desc), '[]') into v_dados from (
      select extract(hour from solicitada_em at time zone 'America/Sao_Paulo')::int h, count(*) n2, count(*) filter (where status = 'SEM_MOTORISTA') sm
      from corridas where solicitada_em >= per.ini and solicitada_em < per.fim and (p_cidade is null or cidade_id = p_cidade)
      group by 1) y;
    if jsonb_array_length(v_dados) = 0 then v_ok := false; v_resp := 'Não há pedidos no período.';
    else
      v_resp := 'O horário de maior demanda ' || per.rotulo || ' foi das ' || (v_dados -> 0 ->> 'hora') || 'h às ' || ((v_dados -> 0 ->> 'hora')::int + 1)
             || 'h, com ' || (v_dados -> 0 ->> 'pedidos') || ' pedidos' || case when (v_dados -> 0 ->> 'sem_motorista')::int > 0
                then ' (' || (v_dados -> 0 ->> 'sem_motorista') || ' ficaram sem motorista)' else '' end || '.';
    end if;

  elsif v_int = 'BAIXA_OFERTA' then
    select coalesce(jsonb_agg(z), '[]') into v_dados from (
      select jsonb_build_object('cidade', ci.nome, 'regiao', e.regiao, 'nivel', interno.nivel_pressao(e.pressao), 'pressao', e.pressao,
                                'pedidos_15min', e.demanda_15, 'motoristas_disponiveis', e.disponiveis) z
      from cidades ci, interno.estado_zonas(ci.id) e
      where ci.ativa and (p_cidade is null or ci.id = p_cidade) and interno.nivel_pressao(e.pressao) in ('ALTA','MODERADA')
      order by e.pressao desc limit 10) y;
    if jsonb_array_length(v_dados) = 0 then v_resp := 'Agora não há regiões com falta de motoristas (estimativa com base nos últimos 15 minutos).';
    else
      v_resp := 'Regiões com baixa oferta agora (estimativa): ' || (select string_agg((z ->> 'regiao') || ' em ' || (z ->> 'cidade') || ' ('
             || (z ->> 'pedidos_15min') || ' pedidos em 15 min, ' || (z ->> 'motoristas_disponiveis') || ' motoristas livres)', '; ')
             from jsonb_array_elements(v_dados) z) || '.';
    end if;

  elsif v_int = 'FRAUDE' then
    select count(*) into n from sinais_fraude where criado_em >= per.ini and criado_em < per.fim;
    select count(*)::numeric / 4 into m from sinais_fraude where criado_em >= per.ini - 4 * v_dur and criado_em < per.ini;
    select coalesce(jsonb_agg(jsonb_build_object('tipo', tipo, 'qtd', q2) order by q2 desc), '[]') into v_dados
    from (select tipo, count(*) q2 from sinais_fraude where criado_em >= per.ini and criado_em < per.fim group by tipo) t;
    v_dados := jsonb_build_object('sinais_periodo', n, 'media_4_periodos_anteriores', round(m, 1), 'por_tipo', v_dados);
    if m = 0 and n = 0 then v_resp := 'Nenhum sinal de fraude ' || per.rotulo || ' nem no histórico recente.';
    elsif m = 0 then v_resp := 'Há ' || n || ' sinais de fraude ' || per.rotulo || ', sem histórico anterior para comparar.';
    elsif n > 1.5 * m then
      v_resp := 'Sim: ' || n || ' sinais de fraude ' || per.rotulo || ', contra média de ' || round(m, 1) || ' nos 4 períodos anteriores (+'
             || round(100 * (n - m) / m) || '%). Principal tipo: ' || coalesce(v_dados -> 'por_tipo' -> 0 ->> 'tipo', '-') || '. Recomendo revisar na fila de Risco.';
    else
      v_resp := 'Não há aumento incomum: ' || n || ' sinais ' || per.rotulo || ', média anterior de ' || round(m, 1) || '.';
    end if;

  else
    v_ok := false;
    v_resp := 'Respondo com os dados reais da plataforma. Exemplos: "Quantas corridas tivemos hoje?", "Qual cidade cresceu mais?", '
           || '"Qual cidade teve mais cancelamento?", "Qual horário apresentou maior demanda?", "Quanto pagamos aos motoristas?", '
           || '"Qual foi nossa receita?", "Quais regiões estão com baixa oferta?", "Existe aumento incomum de fraude?"';
  end if;

  insert into assistente_conversas (usuario_id, assistente, pergunta, intencao, resposta, suficiente)
  values (v_uid, 'ADMIN', left(p_pergunta, 500), v_int, v_resp, v_ok);
  return jsonb_build_object('intencao', v_int, 'resposta', v_resp, 'dados_suficientes', v_ok, 'dados', v_dados,
    'periodo', jsonb_build_object('inicio', per.ini, 'fim', per.fim, 'rotulo', per.rotulo), 'fonte', 'Consulta direta ao banco');
end $$;

-- RLS
do $$
declare t text;
begin
  foreach t in array array['metas_motorista','assistente_conversas'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('metas_motorista', 'proprio', 'motorista_id = auth.uid()');
select interno.criar_politica('assistente_conversas', 'proprio', 'usuario_id = auth.uid()');

select interno.aplicar_permissoes_funcoes();
