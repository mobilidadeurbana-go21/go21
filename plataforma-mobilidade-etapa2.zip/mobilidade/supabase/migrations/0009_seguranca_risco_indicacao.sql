-- ============================================================
-- 0009 — CENTRAL DE SEGURANÇA, IA DE SEGURANÇA, RISK ENGINE,
--        INDICAÇÃO EVOLUÍDA (painel, métricas, antifraude específico)
-- ============================================================

-- ============================================================
-- CENTRAL DE SEGURANÇA
-- fluxo: DETECCAO → ANALISE → CONTATO → INTERVENCAO → ENCERRAMENTO (+ registro)
-- ============================================================
alter table incidentes add column if not exists etapa text not null default 'DETECCAO'
  check (etapa in ('DETECCAO','ANALISE','CONTATO','INTERVENCAO','ENCERRAMENTO'));
alter table incidentes add column if not exists prioridade int not null default 3 check (prioridade between 1 and 4);  -- 1 = mais urgente
alter table incidentes add column if not exists assumido_em timestamptz;
alter table incidentes add column if not exists encerrado_em timestamptz;
alter table incidentes add column if not exists desfecho text
  check (desfecho is null or desfecho in ('SEM_OCORRENCIA','RESOLVIDO_COM_USUARIO','ACIONADO_POLICIA','ACIONADO_SAMU','CONTA_SUSPENSA','ENCAMINHADO_JURIDICO','FALSO_ALARME','OUTRO'));
create index if not exists incidentes_fila_idx on incidentes (status, prioridade, criado_em);

-- prioridade derivada da gravidade (preenchida sozinha)
create or replace function interno.trg_incidente_prioridade() returns trigger language plpgsql as $$
begin
  if tg_op = 'INSERT' or new.gravidade is distinct from old.gravidade then
    new.prioridade := case new.gravidade when 'CRITICA' then 1 when 'ALTA' then 2 when 'MEDIA' then 3 else 4 end;
  end if;
  new.atualizado_em := now();
  return new;
end $$;
drop trigger if exists incidentes_prioridade on incidentes;
create trigger incidentes_prioridade before insert or update on incidentes for each row execute function interno.trg_incidente_prioridade();

create table if not exists incidente_acoes (
  id bigint generated always as identity primary key,
  incidente_id uuid not null references incidentes(id),
  etapa text not null,
  tipo text not null check (tipo in ('NOTA','ASSUMIU','LIGOU_PASSAGEIRO','LIGOU_MOTORISTA','LIGOU_CONTATO','MENSAGEM','ACIONOU_190','ACIONOU_192',
                                     'ESCALONOU','SUSPENDEU_CONTA','ENCERROU')),
  descricao text,
  ator_id uuid,
  criado_em timestamptz not null default now()
);
create index if not exists incidente_acoes_idx on incidente_acoes (incidente_id, id);
drop trigger if exists incidente_acoes_imutavel on incidente_acoes;
create trigger incidente_acoes_imutavel before update or delete on incidente_acoes for each row execute function interno.trg_imutavel();

create or replace function interno.incidente_detalhe(i incidentes, p_tel boolean) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'id', i.id, 'tipo', i.tipo, 'gravidade', i.gravidade, 'prioridade', i.prioridade, 'status', i.status, 'etapa', i.etapa,
    'descricao', i.descricao, 'lat', i.lat, 'lng', i.lng, 'criado_em', i.criado_em, 'assumido_em', i.assumido_em,
    'encerrado_em', i.encerrado_em, 'desfecho', i.desfecho, 'resolucao', i.resolucao,
    'responsavel', (select nome from perfis where id = i.responsavel_id),
    'corrida', (select jsonb_build_object('id', c.id, 'status', c.status, 'categoria', c.categoria,
                 'origem', c.origem_endereco, 'destino', c.destino_endereco, 'solicitada_em', c.solicitada_em,
                 'posicao_motorista', (select jsonb_build_object('lat', p.lat, 'lng', p.lng, 'em', p.atualizado_em)
                                       from motorista_presenca p where p.motorista_id = c.motorista_id))
                from corridas c where c.id = i.corrida_id),
    'passageiro', (select jsonb_build_object('id', p.id, 'nome', p.nome,
                     'telefone', case when p_tel then p.telefone else interno.mascarar_tel(p.telefone) end,
                     'contatos_confianca', case when p_tel then (select jsonb_agg(jsonb_build_object('nome', nome, 'telefone', telefone))
                                                                  from contatos_confianca where usuario_id = p.id) end)
                   from corridas c join perfis p on p.id = c.passageiro_id where c.id = i.corrida_id),
    'motorista', (select jsonb_build_object('id', p.id, 'nome', p.nome,
                    'telefone', case when p_tel then p.telefone else interno.mascarar_tel(p.telefone) end,
                    'veiculo', (select jsonb_build_object('modelo', v.marca || ' ' || v.modelo, 'cor', v.cor, 'placa', v.placa) from veiculos v where v.id = c.veiculo_id),
                    'nota', m.avaliacao_media, 'corridas', m.total_corridas)
                  from corridas c join perfis p on p.id = c.motorista_id join motoristas m on m.id = p.id where c.id = i.corrida_id),
    'reportado_por', (select nome from perfis where id = i.reportado_por),
    'verificacoes', (select coalesce(jsonb_agg(jsonb_build_object('tipo', tipo, 'status', status, 'criada_em', criada_em, 'dados', dados) order by criada_em), '[]')
                     from verificacoes_seguranca where corrida_id = i.corrida_id),
    'historico', (select coalesce(jsonb_agg(jsonb_build_object('quando', a.criado_em, 'etapa', a.etapa, 'tipo', a.tipo, 'descricao', a.descricao,
                     'quem', (select nome from perfis where id = a.ator_id)) order by a.id), '[]')
                  from incidente_acoes a where a.incidente_id = i.id),
    'trilha', (select coalesce(jsonb_agg(jsonb_build_array(lat, lng) order by registrado_em), '[]')
               from (select lat, lng, registrado_em from corrida_trilha where corrida_id = i.corrida_id order by registrado_em desc limit 200) t))
$$;

create or replace function public.seguranca_painel(p_ativos boolean default true, p_limite int default 100) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,ADMIN}'); v_tel boolean := interno.eh_papel('{SUPORTE,OPERACOES,ADMIN}');
begin
  return jsonb_build_object(
    'resumo', (select jsonb_build_object(
                 'ativos', count(*) filter (where status in ('ABERTO','EM_ATENDIMENTO')),
                 'criticos', count(*) filter (where status in ('ABERTO','EM_ATENDIMENTO') and prioridade = 1),
                 'sem_responsavel', count(*) filter (where status = 'ABERTO' and responsavel_id is null),
                 'encerrados_24h', count(*) filter (where status in ('RESOLVIDO','ARQUIVADO') and encerrado_em > now() - interval '24 hours'),
                 'tempo_medio_assumir_min', round((avg(extract(epoch from assumido_em - criado_em)) filter (where assumido_em > now() - interval '7 days') / 60)::numeric, 1))
               from incidentes),
    'incidentes', (select coalesce(jsonb_agg(interno.incidente_detalhe(i, v_tel) order by i.prioridade, i.criado_em), '[]') from (
                     select * from incidentes
                     where (p_ativos and status in ('ABERTO','EM_ATENDIMENTO')) or (not p_ativos and status in ('RESOLVIDO','ARQUIVADO'))
                     order by prioridade, criado_em desc limit least(p_limite, 300)) i));
end $$;

create or replace function interno.travar_incidente(p_id uuid, p_uid uuid) returns incidentes
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare i incidentes;
begin
  select * into i from incidentes where id = p_id for update;
  if not found then perform interno.erro('INCIDENTE_NAO_ENCONTRADO'); end if;
  -- quem é parte da corrida (ou reportou) não atende o próprio incidente
  perform interno.sem_conflito(i.reportado_por);
  perform interno.sem_conflito((select passageiro_id from corridas where id = i.corrida_id));
  perform interno.sem_conflito((select motorista_id from corridas where id = i.corrida_id));
  return i;
end $$;

create or replace function public.seguranca_assumir(p_incidente uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,ADMIN}'); i incidentes;
begin
  i := interno.travar_incidente(p_incidente, v_uid);
  if i.status in ('RESOLVIDO','ARQUIVADO') then perform interno.erro('INCIDENTE_ENCERRADO'); end if;
  if i.responsavel_id is not null and i.responsavel_id <> v_uid then perform interno.erro('JA_ASSUMIDO', (select nome from perfis where id = i.responsavel_id)); end if;
  update incidentes set responsavel_id = v_uid, assumido_em = coalesce(assumido_em, now()), status = 'EM_ATENDIMENTO',
    etapa = case when etapa = 'DETECCAO' then 'ANALISE' else etapa end where id = p_incidente;
  insert into incidente_acoes (incidente_id, etapa, tipo, descricao, ator_id) values (p_incidente, 'ANALISE', 'ASSUMIU', null, v_uid);
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.seguranca_registrar_acao(p_incidente uuid, p_tipo text, p_descricao text, p_avancar_para text default null)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,ADMIN}'); i incidentes; v_etapa text;
begin
  i := interno.travar_incidente(p_incidente, v_uid);
  if i.status in ('RESOLVIDO','ARQUIVADO') then perform interno.erro('INCIDENTE_ENCERRADO'); end if;
  if i.responsavel_id is distinct from v_uid then perform interno.erro('ASSUMA_O_INCIDENTE_ANTES'); end if;
  if p_tipo in ('ENCERROU','ASSUMIU') then perform interno.erro('USE_A_FUNCAO_PROPRIA'); end if;
  if coalesce(trim(p_descricao), '') = '' then perform interno.erro('DESCRICAO_OBRIGATORIA'); end if;
  v_etapa := coalesce(p_avancar_para, case when p_tipo like 'LIGOU%' or p_tipo = 'MENSAGEM' then 'CONTATO'
                                           when p_tipo in ('ACIONOU_190','ACIONOU_192','SUSPENDEU_CONTA','ESCALONOU') then 'INTERVENCAO'
                                           else i.etapa end);
  if v_etapa not in ('ANALISE','CONTATO','INTERVENCAO') then perform interno.erro('ETAPA_INVALIDA'); end if;
  insert into incidente_acoes (incidente_id, etapa, tipo, descricao, ator_id) values (p_incidente, v_etapa, p_tipo, left(p_descricao, 2000), v_uid);
  update incidentes set etapa = v_etapa, status = 'EM_ATENDIMENTO' where id = p_incidente;
  if p_tipo = 'ESCALONOU' then update incidentes set gravidade = 'CRITICA' where id = p_incidente; end if;
  return jsonb_build_object('ok', true, 'etapa', v_etapa);
end $$;

create or replace function public.seguranca_encerrar(p_incidente uuid, p_desfecho text, p_resolucao text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,ADMIN}'); i incidentes;
begin
  i := interno.travar_incidente(p_incidente, v_uid);
  if i.status in ('RESOLVIDO','ARQUIVADO') then return jsonb_build_object('repetido', true); end if;
  if i.responsavel_id is distinct from v_uid then perform interno.erro('ASSUMA_O_INCIDENTE_ANTES'); end if;
  if coalesce(length(trim(p_resolucao)), 0) < 10 then perform interno.erro('RESOLUCAO_OBRIGATORIA'); end if;
  -- incidente crítico não fecha sem registro de contato ou intervenção
  if i.gravidade in ('CRITICA','ALTA') and not exists (select 1 from incidente_acoes where incidente_id = p_incidente
       and tipo in ('LIGOU_PASSAGEIRO','LIGOU_MOTORISTA','LIGOU_CONTATO','MENSAGEM','ACIONOU_190','ACIONOU_192','SUSPENDEU_CONTA')) then
    perform interno.erro('REGISTRE_CONTATO_ANTES', 'incidentes graves exigem registro de contato/intervenção');
  end if;
  update incidentes set status = 'RESOLVIDO', etapa = 'ENCERRAMENTO', desfecho = p_desfecho, resolucao = p_resolucao, encerrado_em = now()
  where id = p_incidente;
  insert into incidente_acoes (incidente_id, etapa, tipo, descricao, ator_id) values (p_incidente, 'ENCERRAMENTO', 'ENCERROU', p_desfecho || ': ' || p_resolucao, v_uid);
  return jsonb_build_object('ok', true);
end $$;

-- ============================================================
-- IA DE SEGURANÇA (v2): alerta → verifica contexto → pergunta → humano
-- Nunca presume crime ou perigo.
-- ============================================================
create or replace function interno.verificar_anomalias(p_corrida uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; v_ult corrida_trilha; v_parado boolean; v_desvio numeric; v_limite numeric; v_od numeric; v_tipo text; v_dados jsonb;
        v_dist_agora numeric; v_dist_antes numeric; v_ctx jsonb := '{}'; v_rapidos int;
begin
  select * into c from corridas where id = p_corrida;
  if c.status <> 'EM_CURSO' then return; end if;
  select * into v_ult from corrida_trilha where corrida_id = p_corrida order by registrado_em desc limit 1;
  v_od := interno.distancia_km(c.origem_lat, c.origem_lng, c.destino_lat, c.destino_lng);

  -- 1) duração anormal
  if now() - c.iniciada_em > make_interval(mins => (c.duracao_estimada_min * interno.cfg_num('seguranca_fator_duracao', 2))::int + 5) then
    v_tipo := 'DURACAO'; v_dados := jsonb_build_object('estimado_min', c.duracao_estimada_min,
      'decorrido_min', round((extract(epoch from now() - c.iniciada_em) / 60)::numeric));
  end if;

  -- 2) parada inesperada (contexto: ignora os 3 primeiros minutos e a chegada ao destino)
  if v_tipo is null and v_ult.lat is not null and now() - c.iniciada_em > interval '3 minutes'
     and interno.distancia_km(v_ult.lat, v_ult.lng, c.destino_lat, c.destino_lng) > 0.5 then
    select count(*) >= 3 and bool_and(interno.distancia_km(t.lat, t.lng, v_ult.lat, v_ult.lng) < 0.1)
      into v_parado
    from corrida_trilha t
    where t.corrida_id = p_corrida and t.registrado_em > now() - make_interval(mins => interno.cfg_num('seguranca_parada_minutos', 6)::int);
    if v_parado and exists (select 1 from corrida_trilha where corrida_id = p_corrida
                            and registrado_em <= now() - make_interval(mins => interno.cfg_num('seguranca_parada_minutos', 6)::int)) then
      v_tipo := 'PARADA'; v_dados := jsonb_build_object('lat', v_ult.lat, 'lng', v_ult.lng);
    end if;
  end if;

  -- 3) desvio relevante (contexto: se o carro já está voltando a se aproximar do destino, não pergunta)
  if v_tipo is null and v_ult.lat is not null then
    v_desvio := interno.distancia_km(c.origem_lat, c.origem_lng, v_ult.lat, v_ult.lng)
              + interno.distancia_km(v_ult.lat, v_ult.lng, c.destino_lat, c.destino_lng) - v_od;
    v_limite := greatest(interno.cfg_num('seguranca_desvio_km', 2), v_od * 0.5);
    if v_desvio > v_limite then
      v_dist_agora := interno.distancia_km(v_ult.lat, v_ult.lng, c.destino_lat, c.destino_lng);
      select interno.distancia_km(lat, lng, c.destino_lat, c.destino_lng) into v_dist_antes
      from corrida_trilha where corrida_id = p_corrida order by registrado_em desc offset 3 limit 1;
      v_ctx := jsonb_build_object('km_do_destino_agora', round(v_dist_agora, 2), 'km_do_destino_3_pontos_atras', round(v_dist_antes, 2));
      if v_dist_antes is null or v_dist_agora > v_dist_antes - 0.3 then
        v_tipo := 'DESVIO'; v_dados := jsonb_build_object('desvio_km', round(v_desvio::numeric, 2), 'lat', v_ult.lat, 'lng', v_ult.lng, 'contexto', v_ctx);
      end if;
    end if;
  end if;

  -- 4) comportamento incomum: velocidade muito alta em pontos seguidos
  if v_tipo is null then
    select count(*) into v_rapidos from (select velocidade_kmh from corrida_trilha where corrida_id = p_corrida order by registrado_em desc limit 3) t
    where velocidade_kmh > interno.cfg_num('seguranca_velocidade_kmh', 130);
    if v_rapidos >= 2 then
      v_tipo := 'COMPORTAMENTO'; v_dados := jsonb_build_object('motivo', 'velocidade alta', 'lat', v_ult.lat, 'lng', v_ult.lng);
      insert into incidentes (corrida_id, tipo, gravidade, descricao, lat, lng)
      values (p_corrida, 'ALERTA_AUTOMATICO', 'MEDIA', 'Velocidade acima de ' || interno.cfg_num('seguranca_velocidade_kmh', 130) || ' km/h em pontos seguidos',
              v_ult.lat, v_ult.lng);
    end if;
  end if;

  if v_tipo is not null then
    begin
      insert into verificacoes_seguranca (corrida_id, tipo, dados) values (p_corrida, v_tipo, v_dados);
      perform interno.evento(p_corrida, 'VERIFICACAO_SEGURANCA', 'EM_CURSO', 'EM_CURSO', jsonb_build_object('tipo', v_tipo) || coalesce(v_dados, '{}'));
      perform interno.notificar(c.passageiro_id, 'SEGURANCA', 'Está tudo bem?',
        'Detectamos uma alteração inesperada. Está tudo bem?', jsonb_build_object('corrida', c.id, 'tipo', v_tipo));
    exception when unique_violation then null;   -- já existe pergunta aberta desse tipo
    end;
  end if;
end $$;
insert into configuracoes (chave, valor, descricao) values
  ('seguranca_velocidade_kmh', '130', 'velocidade considerada incomum'),
  ('seguranca_gps_silencio_min', '4', 'minutos sem GPS durante a corrida para perguntar')
on conflict (chave) do nothing;

-- GPS silencioso durante a corrida (celular desligado? sem sinal?) → pergunta ao passageiro
create or replace function interno.job_seguranca_v2() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n int := 0;
begin
  n := interno.job_seguranca();   -- regras da etapa 1 (sem resposta vira incidente)
  for r in select c.id, c.passageiro_id from corridas c
           where c.status = 'EM_CURSO' and c.iniciada_em < now() - interval '5 minutes'
             and not exists (select 1 from corrida_trilha t where t.corrida_id = c.id
                             and t.registrado_em > now() - make_interval(mins => interno.cfg_num('seguranca_gps_silencio_min', 4)::int)) loop
    begin
      insert into verificacoes_seguranca (corrida_id, tipo, dados) values (r.id, 'COMPORTAMENTO', jsonb_build_object('motivo', 'sem sinal de GPS do motorista'));
      perform interno.notificar(r.passageiro_id, 'SEGURANCA', 'Está tudo bem?', 'Detectamos uma alteração inesperada. Está tudo bem?', jsonb_build_object('corrida', r.id));
      n := n + 1;
    exception when unique_violation then null;
    end;
  end loop;
  return n;
end $$;

-- corrida aparentemente irregular: embarque longe da origem ou fim muito antes do destino
create or replace function interno.trg_corrida_irregular() returns trigger
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare p motorista_presenca; d numeric;
begin
  select * into p from motorista_presenca where motorista_id = new.motorista_id;
  if old.status = 'CHEGOU' and new.status = 'EM_CURSO' and p.lat is not null then
    d := interno.distancia_km(p.lat, p.lng, new.origem_lat, new.origem_lng);
    if d > 0.5 then
      perform interno.registrar_sinal('CORRIDA', new.id::text, 'EMBARQUE_LONGE_DA_ORIGEM', 3, jsonb_build_object('km', round(d, 2)));
    end if;
  elsif old.status = 'EM_CURSO' and new.status = 'FINALIZADA' and p.lat is not null then
    d := interno.distancia_km(p.lat, p.lng, new.destino_lat, new.destino_lng);
    if d > 2 and coalesce(new.distancia_real_km, 0) < new.distancia_estimada_km * 0.3 then
      perform interno.registrar_sinal('CORRIDA', new.id::text, 'CORRIDA_IRREGULAR', 3,
        jsonb_build_object('km_do_destino', round(d, 2), 'km_real', new.distancia_real_km, 'km_estimado', new.distancia_estimada_km));
      insert into incidentes (corrida_id, tipo, gravidade, descricao, lat, lng)
      values (new.id, 'ALERTA_AUTOMATICO', 'BAIXA', 'Corrida finalizada longe do destino e com distância muito menor que a prevista. Verificar com o passageiro.', p.lat, p.lng);
    end if;
  end if;
  return new;
end $$;
drop trigger if exists corridas_irregular on corridas;
create trigger corridas_irregular after update of status on corridas for each row
  when (old.status is distinct from new.status) execute function interno.trg_corrida_irregular();

-- ============================================================
-- MEIOS DE PAGAMENTO (token do gateway — NUNCA o número do cartão)
-- ============================================================
create table if not exists meios_pagamento (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id) on delete cascade,
  tipo text not null check (tipo in ('CARTAO','PIX')),
  gateway text not null,
  gateway_token text not null,               -- referência do cartão guardado no gateway
  impressao_digital text,                    -- fingerprint do cartão fornecido pelo gateway (antifraude: mesmo cartão em várias contas)
  bandeira text, final4 char(4), validade_mes int, validade_ano int,
  padrao boolean not null default false,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  unique (gateway, gateway_token)
);
create index if not exists meios_digital_idx on meios_pagamento (impressao_digital) where impressao_digital is not null;

-- cadastrado pelo servidor depois que o gateway tokeniza o cartão
create or replace function public.registrar_meio_pagamento(p_usuario uuid, p_tipo text, p_gateway text, p_token text, p_digital text,
  p_bandeira text, p_final4 text, p_mes int, p_ano int) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_id uuid;
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  if p_final4 is not null and p_final4 !~ '^\d{4}$' then perform interno.erro('FINAL_INVALIDO'); end if;
  insert into meios_pagamento (usuario_id, tipo, gateway, gateway_token, impressao_digital, bandeira, final4, validade_mes, validade_ano,
    padrao) values (p_usuario, p_tipo, p_gateway, p_token, p_digital, p_bandeira, p_final4, p_mes, p_ano,
    not exists (select 1 from meios_pagamento where usuario_id = p_usuario and ativo))
  on conflict (gateway, gateway_token) do update set ativo = true returning id into v_id;
  if p_digital is not null and (select count(distinct usuario_id) from meios_pagamento where impressao_digital = p_digital) > 2 then
    perform interno.registrar_sinal('USUARIO', p_usuario::text, 'CARTAO_COMPARTILHADO', 3,
      jsonb_build_object('contas', (select jsonb_agg(distinct usuario_id) from meios_pagamento where impressao_digital = p_digital)));
  end if;
  return v_id;
end $$;
insert into funcoes_servidor values ('public.registrar_meio_pagamento(uuid, text, text, text, text, text, text, integer, integer)') on conflict do nothing;

create or replace function public.remover_meio_pagamento(p_id uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  update meios_pagamento set ativo = false, padrao = false where id = p_id and usuario_id = v_uid;
end $$;

-- ============================================================
-- RISK ENGINE: pontuação contextual + grafo de contas relacionadas
-- A pontuação ORDENA a fila do analista. Nunca bloqueia ninguém sozinha.
-- ============================================================
create table if not exists risco_scores (
  usuario_id uuid primary key references perfis(id) on delete cascade,
  score int not null check (score between 0 and 100),
  nivel text not null check (nivel in ('BAIXO','MEDIO','ALTO')),
  fatores jsonb not null,
  calculado_em timestamptz not null default now()
);
create index if not exists risco_scores_idx on risco_scores (nivel, score desc);

create table if not exists risco_analises (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id),
  analista_id uuid not null,
  score_no_momento int,
  conclusao text not null,
  acao text not null check (acao in ('NENHUMA','MONITORAR','SUSPENDER_MOTORISTA','BLOQUEAR_USUARIO')),
  criado_em timestamptz not null default now()
);
drop trigger if exists risco_analises_imutavel on risco_analises;
create trigger risco_analises_imutavel before update or delete on risco_analises for each row execute function interno.trg_imutavel();

-- contas ligadas por um mesmo identificador (aparelho, IP, PIX, cartão, placa) ou por indicação/corridas frequentes
create or replace function interno.relacoes_conta(p_usuario uuid) returns table (outro uuid, ligacao text, detalhe text)
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select d2.usuario_id, 'DISPOSITIVO', d1.dispositivo_id from dispositivos d1 join dispositivos d2 on d2.dispositivo_id = d1.dispositivo_id and d2.usuario_id <> d1.usuario_id where d1.usuario_id = p_usuario
  union
  select d2.usuario_id, 'IP', d1.ultimo_ip from dispositivos d1 join dispositivos d2 on d2.ultimo_ip = d1.ultimo_ip and d2.usuario_id <> d1.usuario_id where d1.usuario_id = p_usuario and d1.ultimo_ip is not null
  union
  select r2.motorista_id, 'PIX', r1.chave_pix from repasses r1 join repasses r2 on r2.chave_pix = r1.chave_pix and r2.motorista_id <> r1.motorista_id where r1.motorista_id = p_usuario
  union
  select m2.usuario_id, 'CARTAO', m1.final4 from meios_pagamento m1 join meios_pagamento m2 on m2.impressao_digital = m1.impressao_digital and m2.usuario_id <> m1.usuario_id where m1.usuario_id = p_usuario and m1.impressao_digital is not null
  union
  select i.indicador_id, 'INDICOU_ESTA_CONTA', null from indicacoes i where i.indicado_id = p_usuario
  union
  select i.indicado_id, 'FOI_INDICADO_POR_ESTA_CONTA', null from indicacoes i where i.indicador_id = p_usuario
  union
  select case when c.passageiro_id = p_usuario then c.motorista_id else c.passageiro_id end, 'CORRIDAS_FREQUENTES', count(*)::text
  from corridas c where (c.passageiro_id = p_usuario or c.motorista_id = p_usuario) and c.motorista_id is not null and c.status in ('FINALIZADA','PAGA')
    and c.solicitada_em > now() - interval '30 days'
  group by 1 having count(*) >= 3
$$;

create or replace function interno.calcular_risco(p_usuario uuid) returns risco_scores
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare f jsonb := '[]'; s numeric := 0; x numeric; r risco_scores; p perfis; m motoristas; v_lig int;
begin
  select * into p from perfis where id = p_usuario;
  if not found then return null; end if;
  select * into m from motoristas where id = p_usuario;

  -- sinais em aberto (pesam pela severidade; perdem força com o tempo)
  select coalesce(sum(severidade * 5 * ocorrencias^0.5 * case when criado_em > now() - interval '30 days' then 1 else 0.5 end), 0) into x
  from sinais_fraude where status in ('ABERTO','EM_ANALISE')
    and ((entidade_tipo in ('USUARIO','INDICACAO') and entidade_id = p_usuario::text)
      or (entidade_tipo = 'CORRIDA' and entidade_id in (select id::text from corridas where passageiro_id = p_usuario or motorista_id = p_usuario)));
  if x > 0 then s := s + least(x, 45); f := f || jsonb_build_object('fator', 'Sinais de risco em aberto', 'pontos', round(least(x, 45))); end if;

  select count(*) * 20 into x from sinais_fraude where status = 'CONFIRMADO' and decidido_em > now() - interval '180 days'
    and entidade_tipo in ('USUARIO','INDICACAO') and entidade_id = p_usuario::text;
  if x > 0 then s := s + least(x, 40); f := f || jsonb_build_object('fator', 'Fraude confirmada nos últimos 6 meses', 'pontos', least(x, 40)); end if;

  select count(distinct outro) into v_lig from interno.relacoes_conta(p_usuario) where ligacao in ('DISPOSITIVO','IP','PIX','CARTAO');
  if v_lig > 0 then x := least(v_lig * 5, 25); s := s + x; f := f || jsonb_build_object('fator', v_lig || ' conta(s) no mesmo aparelho/IP/PIX/cartão', 'pontos', x); end if;

  select count(*) * 10 into x from interno.relacoes_conta(p_usuario) rc join risco_scores rs on rs.usuario_id = rc.outro
  where rs.nivel = 'ALTO' and rc.ligacao in ('DISPOSITIVO','IP','PIX','CARTAO');
  if x > 0 then s := s + least(x, 20); f := f || jsonb_build_object('fator', 'Ligada a conta(s) de risco alto', 'pontos', least(x, 20)); end if;

  if m.id is not null and m.total_cancelamentos >= 5 and m.total_cancelamentos::numeric / greatest(m.total_corridas + m.total_cancelamentos, 1) > 0.3 then
    s := s + 10; f := f || jsonb_build_object('fator', 'Muitos cancelamentos como motorista', 'pontos', 10);
  end if;
  select count(*) into x from pagamentos where pagador_id = p_usuario and status = 'FALHOU' and criado_em > now() - interval '90 days';
  if x > 0 then s := s + least(x * 3, 15); f := f || jsonb_build_object('fator', x || ' pagamento(s) recusado(s) em 90 dias', 'pontos', least(x * 3, 15)); end if;
  select count(*) into x from cupom_usos where usuario_id = p_usuario and usado_em > now() - interval '30 days';
  if x >= 5 then s := s + 5; f := f || jsonb_build_object('fator', 'Uso intenso de cupons', 'pontos', 5); end if;
  if p.criado_em > now() - interval '7 days' then s := s + 5; f := f || jsonb_build_object('fator', 'Conta com menos de 7 dias', 'pontos', 5); end if;

  r.usuario_id := p_usuario; r.score := least(round(s), 100)::int;
  r.nivel := case when r.score >= 60 then 'ALTO' when r.score >= 30 then 'MEDIO' else 'BAIXO' end;
  r.fatores := f; r.calculado_em := now();
  insert into risco_scores values (r.*) on conflict (usuario_id) do update set score = excluded.score, nivel = excluded.nivel,
    fatores = excluded.fatores, calculado_em = excluded.calculado_em;
  return r;
end $$;

-- recalcula sozinho quando surge um sinal
create or replace function interno.trg_sinal_recalcula() returns trigger
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if new.entidade_tipo in ('USUARIO','INDICACAO') then
    perform interno.calcular_risco(new.entidade_id::uuid);
  elsif new.entidade_tipo = 'CORRIDA' then
    perform interno.calcular_risco(c.motorista_id) from corridas c where c.id = new.entidade_id::uuid and c.motorista_id is not null;
    perform interno.calcular_risco(c.passageiro_id) from corridas c where c.id = new.entidade_id::uuid;
  end if;
  return new;
exception when invalid_text_representation then return new;
end $$;
drop trigger if exists sinais_recalcula on sinais_fraude;
create trigger sinais_recalcula after insert or update of status on sinais_fraude for each row execute function interno.trg_sinal_recalcula();

-- painel do analista
create or replace function public.risco_painel(p_nivel text default null, p_limite int default 100) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO}');
begin
  return jsonb_build_object(
    'resumo', (select jsonb_build_object('alto', count(*) filter (where nivel = 'ALTO'), 'medio', count(*) filter (where nivel = 'MEDIO'),
                                         'baixo', count(*) filter (where nivel = 'BAIXO')) from risco_scores),
    'sinais_abertos', (select jsonb_build_object('total', count(*), 'graves', count(*) filter (where severidade >= 4)) from sinais_fraude where status in ('ABERTO','EM_ANALISE')),
    'fila', (select coalesce(jsonb_agg(x order by (x ->> 'score')::int desc), '[]') from (
      select jsonb_build_object('usuario', rs.usuario_id, 'nome', p.nome, 'score', rs.score, 'nivel', rs.nivel, 'fatores', rs.fatores,
               'motorista', exists (select 1 from motoristas where id = p.id), 'status_conta', p.status,
               'sinais_abertos', (select count(*) from sinais_fraude s where s.status in ('ABERTO','EM_ANALISE') and s.entidade_id = p.id::text),
               'ultima_analise', (select jsonb_build_object('quando', criado_em, 'acao', acao) from risco_analises where usuario_id = p.id order by criado_em desc limit 1),
               'calculado_em', rs.calculado_em) x
      from risco_scores rs join perfis p on p.id = rs.usuario_id
      where (p_nivel is null or rs.nivel = p_nivel) and rs.score > 0 and rs.usuario_id <> v_uid
      order by rs.score desc limit least(p_limite, 300)) y),
    'sinais', (select coalesce(jsonb_agg(to_jsonb(s) order by s.severidade desc, s.criado_em desc), '[]') from (
      select * from sinais_fraude where status in ('ABERTO','EM_ANALISE') order by severidade desc, criado_em desc limit 200) s));
end $$;

create or replace function public.risco_detalhe(p_usuario uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO}'); r risco_scores;
begin
  perform interno.sem_conflito(p_usuario);
  r := interno.calcular_risco(p_usuario);
  perform interno.auditar_evento('RISCO_CONSULTA', 'perfis', p_usuario::text, null);
  return jsonb_build_object(
    'usuario', (select jsonb_build_object('id', p.id, 'nome', p.nome, 'status', p.status, 'cpf', interno.mascarar_cpf(p.cpf),
                  'telefone', interno.mascarar_tel(p.telefone), 'criado_em', p.criado_em, 'ultimo_acesso', p.ultimo_acesso) from perfis p where p.id = p_usuario),
    'score', to_jsonb(r),
    'aviso', 'Pontuação é apoio à análise. Não usar isoladamente para bloquear.',
    'relacoes', (select coalesce(jsonb_agg(jsonb_build_object('conta', rc.outro, 'nome', p.nome, 'ligacao', rc.ligacao, 'detalhe', rc.detalhe,
                   'nivel_risco', rs.nivel, 'status', p.status)), '[]')
                 from interno.relacoes_conta(p_usuario) rc join perfis p on p.id = rc.outro left join risco_scores rs on rs.usuario_id = rc.outro),
    'sinais', (select coalesce(jsonb_agg(to_jsonb(s) order by s.criado_em desc), '[]') from sinais_fraude s
               where (s.entidade_tipo in ('USUARIO','INDICACAO') and s.entidade_id = p_usuario::text)
                  or (s.entidade_tipo = 'CORRIDA' and s.entidade_id in (select id::text from corridas where passageiro_id = p_usuario or motorista_id = p_usuario))),
    'corridas_30d', (select jsonb_build_object('como_passageiro', count(*) filter (where passageiro_id = p_usuario),
                       'como_motorista', count(*) filter (where motorista_id = p_usuario),
                       'canceladas', count(*) filter (where status = 'CANCELADA'))
                     from corridas where (passageiro_id = p_usuario or motorista_id = p_usuario) and solicitada_em > now() - interval '30 days'),
    'indicacao', (select jsonb_build_object('indicado_por', (select indicador_id from indicacoes where indicado_id = p_usuario),
                     'indicados_diretos', (select count(*) from indicacoes where indicador_id = p_usuario),
                     'bonus', (select jsonb_object_agg(status, total) from (select status, sum(valor) total from ganhos_indicacao where beneficiario_id = p_usuario group by status) g))),
    'analises', (select coalesce(jsonb_agg(jsonb_build_object('quando', a.criado_em, 'analista', (select nome from perfis where id = a.analista_id),
                   'score', a.score_no_momento, 'conclusao', a.conclusao, 'acao', a.acao) order by a.criado_em desc), '[]')
                 from risco_analises a where a.usuario_id = p_usuario));
end $$;

-- conclusão da análise: bloqueio exige contexto (sinal confirmado OU justificativa detalhada)
create or replace function public.risco_registrar_analise(p_usuario uuid, p_conclusao text, p_acao text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO}'); r risco_scores;
begin
  perform interno.sem_conflito(p_usuario);
  if p_acao not in ('NENHUMA','MONITORAR','SUSPENDER_MOTORISTA','BLOQUEAR_USUARIO') then perform interno.erro('ACAO_INVALIDA'); end if;
  if coalesce(length(trim(p_conclusao)), 0) < 20 then perform interno.erro('CONCLUSAO_OBRIGATORIA', 'descreva o contexto analisado (mín. 20 caracteres)'); end if;
  if p_acao in ('SUSPENDER_MOTORISTA','BLOQUEAR_USUARIO') and length(trim(p_conclusao)) < 60
     and not exists (select 1 from sinais_fraude where status = 'CONFIRMADO' and entidade_id = p_usuario::text) then
    perform interno.erro('CONTEXTO_INSUFICIENTE', 'para suspender/bloquear: confirme um sinal ou detalhe a evidência (mín. 60 caracteres). A pontuação sozinha não basta.');
  end if;
  select * into r from risco_scores where usuario_id = p_usuario;
  insert into risco_analises (usuario_id, analista_id, score_no_momento, conclusao, acao) values (p_usuario, v_uid, r.score, p_conclusao, p_acao);
  if p_acao = 'SUSPENDER_MOTORISTA' then
    perform public.ops_alterar_status_motorista(p_usuario, 'SUSPENSO', 'Análise de risco: ' || p_conclusao);
  elsif p_acao = 'BLOQUEAR_USUARIO' then
    update perfis set status = 'BLOQUEADO' where id = p_usuario;
    update motoristas set status = 'BLOQUEADO', motivo_status = 'Análise de risco: ' || left(p_conclusao, 200) where id = p_usuario;
    update motorista_presenca set online = false, disponivel = false where motorista_id = p_usuario;
  end if;
  perform interno.auditar_evento('ANALISE_RISCO', 'perfis', p_usuario::text, jsonb_build_object('acao', p_acao, 'score', r.score));
  return jsonb_build_object('ok', true, 'acao', p_acao);
end $$;

-- ============================================================
-- INDICAÇÃO EVOLUÍDA — antifraude específico (mantém 20% = 80/3/2/1/14)
-- ============================================================
insert into configuracoes (chave, valor, descricao) values
  ('indicacao_max_dia_por_indicador', '10', 'acima disso, novos vínculos do dia entram EM ANÁLISE'),
  ('indicacao_volume_atipico_fator', '3', 'corridas do dia > média x fator → sinal de volume atípico')
on conflict (chave) do nothing;

drop function if exists interno.vincular_indicacao(uuid, text, text);
create or replace function interno.vincular_indicacao(p_indicado uuid, p_codigo text, p_dispositivo text default null)
returns text language plpgsql security definer set search_path = public, interno, pg_temp as $$
-- devolve NULL quando vinculou, ou o código do problema (não lança: o sinal de risco não pode se perder)
declare v_indicador uuid; v_rel jsonb; v_status text := 'ATIVA'; v_motivo text; v_hoje int;
begin
  select id into v_indicador from perfis where codigo_indicacao = upper(p_codigo) and status = 'ATIVO';
  if v_indicador is null then return 'CODIGO_INDICACAO_INVALIDO'; end if;
  if v_indicador = p_indicado then
    perform interno.registrar_sinal('USUARIO', p_indicado::text, 'AUTOINDICACAO', 3, jsonb_build_object('codigo', p_codigo));
    return 'AUTOINDICACAO';
  end if;
  if exists (select 1 from indicacoes where indicado_id = p_indicado) then return 'JA_POSSUI_INDICADOR'; end if;
  if exists (select 1 from corridas where motorista_id = p_indicado and status in ('FINALIZADA','PAGA')) then return 'INDICACAO_FORA_DO_PRAZO'; end if;
  if exists (select 1 from interno.cadeia_indicacao(v_indicador, 1000) where beneficiario_id = p_indicado) then
    perform interno.registrar_sinal('USUARIO', p_indicado::text, 'CICLO_INDICACAO', 4, jsonb_build_object('indicador', v_indicador));
    return 'CICLO_INDICACAO';
  end if;
  v_rel := interno.contas_relacionadas(p_indicado, v_indicador);
  if v_rel <> '{}'::jsonb then
    v_status := 'EM_ANALISE'; v_motivo := 'Contas relacionadas: revisão humana';
    perform interno.registrar_sinal('INDICACAO', p_indicado::text, 'CONTA_RELACIONADA', 3,
      jsonb_build_object('indicador', v_indicador, 'indicado', p_indicado, 'evidencias', v_rel));
  end if;
  -- indicação em massa (rede artificial sendo montada)
  select count(*) into v_hoje from indicacoes where indicador_id = v_indicador and criado_em > now() - interval '24 hours';
  if v_hoje >= interno.cfg_num('indicacao_max_dia_por_indicador', 10) then
    v_status := 'EM_ANALISE'; v_motivo := coalesce(v_motivo || '; ', '') || 'Volume de indicações acima do normal';
    perform interno.registrar_sinal('USUARIO', v_indicador::text, 'INDICACAO_EM_MASSA', 3, jsonb_build_object('ultimas_24h', v_hoje + 1));
  end if;
  insert into indicacoes (indicado_id, indicador_id, codigo_usado, status, motivo) values (p_indicado, v_indicador, upper(p_codigo), v_status, v_motivo);
  perform interno.notificar_se_pode(v_indicador, 'INDICACAO', 'Nova indicação',
    'Alguém se cadastrou com o seu código. O bônus começa quando a pessoa fizer corridas válidas.', '{}');
  return case when v_status = 'ATIVA' then null else 'INDICACAO_EM_ANALISE' end;
end $$;

-- redes artificiais e volume atípico (job diário de risco, v2)
create or replace function interno.job_risco_v2() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n_rede int := 0; n_vol int := 0; n_score int := 0; v_base int;
begin
  v_base := interno.job_risco();
  -- rede artificial: indicados diretos de alguém que dividem aparelhos/IP ENTRE SI
  for r in select i.indicador_id, count(distinct i.indicado_id) indicados,
                  count(distinct d1.usuario_id) filter (where d2.usuario_id is not null) ligados
           from indicacoes i
           left join dispositivos d1 on d1.usuario_id = i.indicado_id
           left join dispositivos d2 on (d2.dispositivo_id = d1.dispositivo_id or (d2.ultimo_ip = d1.ultimo_ip and d1.ultimo_ip is not null))
                                     and d2.usuario_id <> d1.usuario_id
                                     and d2.usuario_id in (select indicado_id from indicacoes where indicador_id = i.indicador_id)
           group by i.indicador_id having count(distinct i.indicado_id) >= 3 loop
    if r.ligados::numeric / r.indicados >= 0.5 then
      perform interno.registrar_sinal('USUARIO', r.indicador_id::text, 'REDE_ARTIFICIAL', 4,
        jsonb_build_object('indicados', r.indicados, 'indicados_ligados_entre_si', r.ligados));
      n_rede := n_rede + 1;
    end if;
  end loop;
  -- volume atípico de corridas de motoristas indicados (manipulação para gerar bônus)
  for r in select c.motorista_id, count(*) hoje,
                  (select count(*)::numeric / 30 from corridas c2 where c2.motorista_id = c.motorista_id and c2.status = 'PAGA'
                     and c2.finalizada_em between now() - interval '31 days' and now() - interval '1 day') media
           from corridas c where c.status = 'PAGA' and c.finalizada_em > now() - interval '1 day'
             and exists (select 1 from indicacoes where indicado_id = c.motorista_id)
           group by c.motorista_id loop
    if r.hoje >= 10 and r.hoje > greatest(r.media, 1) * interno.cfg_num('indicacao_volume_atipico_fator', 3) then
      perform interno.registrar_sinal('USUARIO', r.motorista_id::text, 'VOLUME_ATIPICO', 3, jsonb_build_object('hoje', r.hoje, 'media_dia', round(r.media, 1)));
      n_vol := n_vol + 1;
    end if;
  end loop;
  -- recalcula scores de quem teve atividade recente
  for r in select distinct id from perfis where ultimo_acesso > now() - interval '7 days' loop
    perform interno.calcular_risco(r.id); n_score := n_score + 1;
  end loop;
  return jsonb_build_object('cancelamento_excessivo', v_base, 'redes_artificiais', n_rede, 'volume_atipico', n_vol, 'scores', n_score);
end $$;

-- painel de indicação do motorista: árvore visual + métricas
create or replace function public.indicacao_painel() returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_arvore jsonb;
begin
  with recursive desce as (
    select i.indicado_id id, i.indicador_id pai, 1 nivel, i.status, i.criado_em from indicacoes i where i.indicador_id = v_uid
    union all
    select i.indicado_id, i.indicador_id, d.nivel + 1, i.status, i.criado_em from desce d join indicacoes i on i.indicador_id = d.id where d.nivel < 3
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', d.id, 'pai', d.pai, 'nivel', d.nivel,
      'nome', split_part(p.nome, ' ', 1) || ' ' || left(split_part(p.nome, ' ', 2), 1) || '.',   -- nome mascarado
      'status_indicacao', d.status, 'desde', d.criado_em,
      'ativo', exists (select 1 from corridas c where c.motorista_id = d.id and c.status = 'PAGA' and c.finalizada_em > now() - interval '30 days'),
      'corridas', (select count(*) from corridas c where c.motorista_id = d.id and c.status = 'PAGA'),
      'receita_gerada', (select coalesce(sum(c.preco_final), 0) from corridas c where c.motorista_id = d.id and c.status = 'PAGA'),
      'seu_bonus', (select coalesce(sum(g.valor), 0) from ganhos_indicacao g where g.beneficiario_id = v_uid and g.indicado_id = d.id
                    and g.status in ('PENDENTE','DISPONIVEL','PAGO'))) order by d.nivel, d.criado_em), '[]')
    into v_arvore
  from desce d join perfis p on p.id = d.id;

  return jsonb_build_object(
    'codigo', (select codigo_indicacao from perfis where id = v_uid),
    'regra', jsonb_build_object('nivel_1_pct', 3, 'nivel_2_pct', 2, 'nivel_3_pct', 1,
               'observacao', 'Bônus calculado sobre corridas válidas pagas dos motoristas da sua rede. Não há bônus por cadastro.'),
    'arvore', v_arvore,
    'metricas', jsonb_build_object(
      'indicados_por_nivel', (select coalesce(jsonb_object_agg(n, q), '{}') from (select (e ->> 'nivel') n, count(*) q from jsonb_array_elements(v_arvore) e group by 1) x),
      'conversao_pct', (select round(100.0 * count(*) filter (where (e ->> 'corridas')::int > 0) / nullif(count(*), 0), 1)
                        from jsonb_array_elements(v_arvore) e where (e ->> 'nivel')::int = 1),
      'ativos_30d', (select count(*) from jsonb_array_elements(v_arvore) e where (e ->> 'ativo')::boolean),
      'corridas_geradas', (select coalesce(sum((e ->> 'corridas')::int), 0) from jsonb_array_elements(v_arvore) e),
      'receita_gerada', (select coalesce(sum((e ->> 'receita_gerada')::numeric), 0) from jsonb_array_elements(v_arvore) e)),
    'bonus', (select jsonb_build_object(
                'pendente', coalesce(sum(valor) filter (where status = 'PENDENTE'), 0),
                'disponivel', coalesce(sum(valor) filter (where status = 'DISPONIVEL'), 0),
                'pago', coalesce(sum(valor) filter (where status = 'PAGO'), 0),
                'em_analise', coalesce(sum(valor) filter (where status = 'BLOQUEADO'), 0),
                'estornado', coalesce(sum(valor) filter (where status = 'ESTORNADO'), 0),
                'por_nivel', (select coalesce(jsonb_object_agg(nivel, v), '{}') from (select nivel, sum(valor) v from ganhos_indicacao
                              where beneficiario_id = v_uid and status in ('PENDENTE','DISPONIVEL','PAGO') group by nivel) y))
              from ganhos_indicacao where beneficiario_id = v_uid),
    'estornos', (select coalesce(jsonb_agg(jsonb_build_object('data', criado_em, 'nivel', nivel, 'valor', valor, 'motivo', motivo) order by criado_em desc), '[]')
                 from ganhos_indicacao where beneficiario_id = v_uid and status = 'ESTORNADO'),
    'auditoria', (select coalesce(jsonb_agg(jsonb_build_object('quando', a.ocorrido_em, 'acao', a.acao,
                     'de', a.antes ->> 'status', 'para', a.depois ->> 'status', 'valor', coalesce(a.depois ->> 'valor', a.antes ->> 'valor')) order by a.ocorrido_em desc), '[]')
                  from auditoria a where a.tabela = 'ganhos_indicacao'
                    and a.registro_id in (select id::text from ganhos_indicacao where beneficiario_id = v_uid)
                    and a.ocorrido_em > now() - interval '90 days'));
end $$;

-- métricas do programa (gestão)
create or replace function public.admin_indicacao_metricas(p_inicio timestamptz, p_fim timestamptz, p_cidade uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,FINANCEIRO,RISCO}');
begin
  return jsonb_build_object(
    'novos_vinculos', (select count(*) from indicacoes i join perfis p on p.id = i.indicado_id
                       where i.criado_em >= p_inicio and i.criado_em < p_fim and (p_cidade is null or p.cidade_id = p_cidade)),
    'vinculos_em_analise', (select count(*) from indicacoes where status <> 'ATIVA'),
    'conversao_pct', (select round(100.0 * count(*) filter (where exists (select 1 from corridas c where c.motorista_id = i.indicado_id and c.status = 'PAGA'))
                                 / nullif(count(*), 0), 1)
                      from indicacoes i where i.criado_em >= p_inicio and i.criado_em < p_fim),
    'corridas_de_indicados', (select count(*) from corridas c where c.status = 'PAGA' and c.finalizada_em >= p_inicio and c.finalizada_em < p_fim
                              and exists (select 1 from indicacoes where indicado_id = c.motorista_id) and (p_cidade is null or c.cidade_id = p_cidade)),
    'gmv_de_indicados', (select coalesce(sum(c.preco_final), 0) from corridas c where c.status = 'PAGA' and c.finalizada_em >= p_inicio and c.finalizada_em < p_fim
                         and exists (select 1 from indicacoes where indicado_id = c.motorista_id) and (p_cidade is null or c.cidade_id = p_cidade)),
    'bonus', (select coalesce(jsonb_object_agg(status, total), '{}') from (select status, sum(valor) total from ganhos_indicacao
               where criado_em >= p_inicio and criado_em < p_fim group by status) g),
    'sinais_indicacao', (select coalesce(jsonb_object_agg(tipo, q), '{}') from (select tipo, count(*) q from sinais_fraude
               where tipo in ('AUTOINDICACAO','CICLO_INDICACAO','CONTA_RELACIONADA','INDICACAO_EM_MASSA','REDE_ARTIFICIAL','VOLUME_ATIPICO',
                              'AUTO_BENEFICIO_INDICACAO','CORRIDA_NA_PROPRIA_REDE')
                 and criado_em >= p_inicio and criado_em < p_fim group by tipo) s),
    'maiores_redes', (select coalesce(jsonb_agg(x), '[]') from (
        select jsonb_build_object('indicador', p.nome, 'diretos', count(*), 'bonus_total',
                 (select coalesce(sum(valor), 0) from ganhos_indicacao g where g.beneficiario_id = i.indicador_id and g.status in ('PENDENTE','DISPONIVEL','PAGO')),
                 'risco', (select nivel from risco_scores where usuario_id = i.indicador_id)) x
        from indicacoes i join perfis p on p.id = i.indicador_id group by i.indicador_id, p.nome order by count(*) desc limit 10) y));
end $$;

-- agenda: risco v2 no diário; segurança v2 no rápido
create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca_v2()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'inteligencia' then
    return jsonb_build_object('inteligencia', interno.rodar_job('inteligencia', 'interno.job_inteligencia()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object('liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco_v2()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;

-- RLS
do $$
declare t text;
begin
  foreach t in array array['incidente_acoes','meios_pagamento','risco_scores','risco_analises'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('incidente_acoes', 'staff', $p$interno.eh_papel('{SUPORTE,OPERACOES,ADMIN}')$p$);
select interno.criar_politica('meios_pagamento', 'proprio', 'usuario_id = auth.uid()');
-- token do gateway não volta para o app (só bandeira/final)
revoke select on meios_pagamento from authenticated;
grant select (id, usuario_id, tipo, gateway, bandeira, final4, validade_mes, validade_ano, padrao, ativo, criado_em) on meios_pagamento to authenticated;
select interno.criar_politica('risco_scores', 'risco', $p$interno.eh_papel('{RISCO}')$p$);
select interno.criar_politica('risco_analises', 'risco', $p$interno.eh_papel('{RISCO}')$p$);

select interno.aplicar_permissoes_funcoes();
