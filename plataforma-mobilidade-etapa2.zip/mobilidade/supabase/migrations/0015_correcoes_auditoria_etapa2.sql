-- ============================================================
-- 0015 — CORREÇÕES DA AUDITORIA INDEPENDENTE DA ETAPA 2
-- (segurança, LGPD, financeiro, UX/DevOps). Funções da Etapa 1 são
-- reescritas aqui com o MESMO texto + as linhas marcadas [0015];
-- as da Etapa 2 foram corrigidas na própria migration de origem.
-- ============================================================

-- ---------- conta bloqueada perde os poderes de equipe (e o acesso às telas de staff) ----------
create or replace function interno.exigir_papel(p_papeis papel[]) returns uuid
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare v uuid := interno.exigir_login();
begin
  if not exists (
    select 1 from usuario_papeis
    where usuario_id = v and ativo and (papel = any(p_papeis) or papel = 'SUPER_ADMIN')
  ) then
    perform interno.erro('SEM_PERMISSAO', array_to_string(p_papeis, ','));
  end if;
  -- [0015] papel de equipe só vale com a conta ATIVA
  if p_papeis && '{ADMIN,SUPER_ADMIN,SUPORTE,FINANCEIRO,OPERACOES,RISCO}'::papel[]
     and coalesce((select status::text from perfis where id = v), 'ATIVO') <> 'ATIVO'
     and not (p_papeis && '{PASSAGEIRO,MOTORISTA}'::papel[]) then
    perform interno.erro('CONTA_' || (select status::text from perfis where id = v));
  end if;
  return v;
end $$;
create or replace function interno.eh_staff(p_usuario uuid default null) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (
    select 1 from usuario_papeis up join perfis pf on pf.id = up.usuario_id and pf.status = 'ATIVO'   -- [0015]
    where up.usuario_id = coalesce(p_usuario, auth.uid()) and up.ativo
      and up.papel in ('ADMIN','SUPER_ADMIN','SUPORTE','FINANCEIRO','OPERACOES','RISCO')
  )
$$;
create or replace function interno.eh_papel(p_papeis papel[]) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from usuario_papeis up join perfis pf on pf.id = up.usuario_id and pf.status = 'ATIVO'   -- [0015]
                 where up.usuario_id = auth.uid() and up.ativo and (up.papel = any(p_papeis) or up.papel = 'SUPER_ADMIN'))
$$;

-- ---------- nomes exibidos em painéis não aceitam HTML (defesa extra além do escape nas telas) ----------
create or replace function interno.trg_sem_html() returns trigger language plpgsql as $$
declare k text; v text;
begin
  for k, v in select key, value from jsonb_each_text(to_jsonb(new)) where key in ('nome','razao_social','nome_fantasia','titulo','descricao','endereco','codigo') loop
    if v ~ '[<>]' then raise exception using errcode = 'P0001', message = 'TEXTO_INVALIDO', detail = k; end if;
  end loop;
  return new;
end $$;
do $$
declare t text;
begin
  foreach t in array array['cidades','regioes','eventos_cidade','parceiros','parceiro_ofertas','empresas','empresa_departamentos','empresa_centros_custo',
                           'empresa_politicas','planos_assinatura','locais_favoritos'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_sem_html', t);
    execute format('create trigger %I before insert or update on public.%I for each row execute function interno.trg_sem_html()', t || '_sem_html', t);
  end loop;
end $$;

-- ---------- quem participa da corrida não vê quais motoristas recusaram ----------
do $$
declare v_cols text;
begin
  select string_agg(quote_ident(column_name), ', ' order by ordinal_position) into v_cols
  from information_schema.columns where table_schema = 'public' and table_name = 'corridas' and column_name not in ('motoristas_excluidos');
  execute 'revoke select on public.corridas from authenticated';
  execute format('grant select (%s) on public.corridas to authenticated', v_cols);
end $$;

-- ---------- erros das telas chegam à equipe (observabilidade do front) ----------
create table if not exists erros_app (
  id bigint generated always as identity primary key,
  usuario_id uuid,
  app text not null,
  mensagem text not null,
  contexto jsonb not null default '{}',
  criado_em timestamptz not null default now()
);
alter table erros_app enable row level security;
revoke all on erros_app from anon, authenticated;
select interno.criar_politica('erros_app', 'staff', 'interno.eh_staff()');
create or replace function public.registrar_erro_app(p_app text, p_mensagem text, p_contexto jsonb default '{}') returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  perform interno.limitar('erro_app', 30, 3600);
  insert into erros_app (usuario_id, app, mensagem, contexto)
  values (auth.uid(), left(coalesce(p_app, '?'), 30), left(coalesce(p_mensagem, ''), 500), coalesce(p_contexto, '{}') - 'token' - 'senha');
end $$;

-- ---------- cobrança no gateway (QR/copia-e-cola PIX, link de cartão) ----------
alter table pagamentos add column if not exists cobranca jsonb;
-- servidor (Edge Function criar-cobranca) grava o que o gateway devolveu
create or replace function public.registrar_cobranca(p_pagamento uuid, p_gateway text, p_gateway_ref text, p_dados jsonb) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  update pagamentos set cobranca = jsonb_build_object('gateway', p_gateway, 'ref', p_gateway_ref, 'criada_em', now())
                                   || (coalesce(p_dados, '{}') - 'token' - 'segredo')
  where id = p_pagamento and status = 'PENDENTE';
end $$;
-- o app do pagador consulta a cobrança (dono do pagamento ou gestor/financeiro da empresa da fatura)
create or replace function public.minha_cobranca(p_pagamento uuid) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); p pagamentos;
begin
  select * into p from pagamentos where id = p_pagamento;
  if not found or (p.pagador_id <> v_uid and not (p.fatura_id is not null and
       coalesce(interno.papel_empresa((select empresa_id from empresa_faturas where id = p.fatura_id), v_uid), '-') in ('GESTOR','FINANCEIRO'))) then
    perform interno.erro('PAGAMENTO_NAO_ENCONTRADO');
  end if;
  return jsonb_build_object('id', p.id, 'tipo', p.tipo, 'metodo', p.metodo, 'valor', p.valor, 'status', p.status, 'cobranca', p.cobranca);
end $$;

-- ---------- vigia: problemas da "saúde do sistema" viram aviso para a equipe (sem esperar alguém abrir a tela) ----------
create or replace function interno.job_vigia() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; d record; n int := 0; v_chave text;
begin
  for r in select x from jsonb_array_elements(interno.saude_sistema_dados() -> 'itens') x where x ->> 'nivel' = 'CRITICO' loop
    v_chave := 'vigia:' || (r.x ->> 'item') || ':' || to_char(now(), 'YYYYMMDDHH24');
    for d in select distinct usuario_id from usuario_papeis where papel in ('ADMIN','SUPER_ADMIN','OPERACOES') and ativo loop
      continue when interno.ja_notificado(d.usuario_id, v_chave);
      perform interno.notificar(d.usuario_id, 'SISTEMA', 'Atenção: ' || (r.x ->> 'item'), 'Situação: ' || (r.x ->> 'valor'), jsonb_build_object('chave', v_chave));
      n := n + 1;
    end loop;
  end loop;
  return jsonb_build_object('avisos', n);
end $$;
create or replace function public.acionar_emergencia(p_corrida uuid, p_lat float8 default null, p_lng float8 default null, p_descricao text default null)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_id uuid; r record; v_token text;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (c.passageiro_id <> v_uid and c.motorista_id is distinct from v_uid) then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  -- [0015] toque repetido em poucos minutos não abre outro incidente nem dispara SMS de novo
  select id into v_id from incidentes where corrida_id = p_corrida and reportado_por = v_uid and tipo = 'EMERGENCIA'
    and status not in ('RESOLVIDO','ARQUIVADO') and criado_em > now() - interval '3 minutes' order by criado_em desc limit 1;
  if v_id is not null then
    if p_lat is not null then update incidentes set lat = p_lat, lng = p_lng where id = v_id; end if;
    return v_id;
  end if;
  insert into incidentes (corrida_id, reportado_por, tipo, gravidade, descricao, lat, lng)
  values (p_corrida, v_uid, 'EMERGENCIA', 'CRITICA', p_descricao, p_lat, p_lng) returning id into v_id;
  perform interno.evento(p_corrida, 'EMERGENCIA', c.status, c.status, jsonb_build_object('incidente', v_id, 'lat', p_lat, 'lng', p_lng));
  v_token := public.compartilhar_corrida(p_corrida);
  for r in select nome, telefone from contatos_confianca where usuario_id = v_uid loop
    perform interno.notificar(v_uid, 'SEGURANCA', 'Emergência acionada',
      'Alerta enviado para ' || r.nome, jsonb_build_object('para_telefone', r.telefone, 'link_token', v_token), '{SMS}');
  end loop;
  -- avisa toda a equipe de suporte
  for r in select usuario_id from usuario_papeis where papel = 'SUPORTE' and ativo loop
    perform interno.notificar(r.usuario_id, 'SEGURANCA', 'EMERGÊNCIA EM CORRIDA', 'Corrida ' || p_corrida, jsonb_build_object('incidente', v_id), '{PUSH,IN_APP}');
  end loop;
  return v_id;
end $$;

create or replace function public.pagar_novamente(p_pagamento uuid, p_metodo metodo_pagamento) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); p pagamentos; n pagamentos; v_tent int;
begin
  perform interno.limitar('pagar_novamente', 10, 3600);
  if p_metodo = 'DINHEIRO' then perform interno.erro('METODO_INVALIDO'); end if;
  select * into p from pagamentos where id = p_pagamento for update;
  if not found or p.pagador_id <> v_uid then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  if p.status not in ('PENDENTE','FALHOU') then perform interno.erro('STATUS_INVALIDO', p.status::text); end if;
  -- [0015] só os métodos do pagador; créditos não pagam recarga de créditos nem fatura de empresa
  if p_metodo::text not in ('PIX','CARTAO','CARTEIRA') then perform interno.erro('METODO_INVALIDO'); end if;
  if p_metodo = 'CARTEIRA' and p.tipo in ('RECARGA','FATURA_EMPRESA') then perform interno.erro('METODO_INVALIDO_PARA_ESTE_PAGAMENTO'); end if;
  if p.tipo = 'ASSINATURA' and (select status from assinaturas where id = p.assinatura_id) not in ('PENDENTE','ATIVA','INADIMPLENTE') then
    perform interno.erro('ASSINATURA_CANCELADA');
  end if;
  if p.status = 'PENDENTE' then update pagamentos set status = 'CANCELADO', motivo_falha = 'Substituído por nova tentativa' where id = p.id; end if;
  select count(*) + 1 into v_tent from pagamentos where corrida_id = p.corrida_id and tipo = p.tipo;
  if p_metodo = 'CARTEIRA' and interno.travar_saldo(v_uid, 'PASSAGEIRO_CARTEIRA') < p.valor then perform interno.erro('SALDO_INSUFICIENTE'); end if;
  -- [0015] a nova tentativa herda a fatura/assinatura da original (senão o pagamento não ativa nada)
  if p.corrida_id is null then select count(*) + 1 into v_tent from pagamentos where split_part(chave_idempotencia, '#', 1) = split_part(p.chave_idempotencia, '#', 1); end if;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia, fatura_id, assinatura_id)
  values (p.corrida_id, v_uid, p.tipo, p_metodo, p.valor, split_part(p.chave_idempotencia, '#', 1) || '#' || v_tent, p.fatura_id, p.assinatura_id)
  returning * into n;
  if p_metodo = 'CARTEIRA' then return interno.confirmar_pagamento(n.id, 'INTERNO', 'INTERNO:' || n.id, n.valor); end if;
  return jsonb_build_object('id', n.id, 'status', n.status, 'valor', n.valor, 'metodo', n.metodo);
end $$;

create or replace function public.meus_dados_exportar() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_res jsonb;
begin
  perform interno.limitar('exportar_dados', 3, 86400);
  select jsonb_build_object(
    'gerado_em', now(),
    'perfil', (select to_jsonb(p) from perfis p where id = v_uid),
    'papeis', (select jsonb_agg(papel) from usuario_papeis where usuario_id = v_uid),
    'consentimentos', (select coalesce(jsonb_agg(to_jsonb(c) - 'usuario_id' order by registrado_em), '[]') from consentimentos c where usuario_id = v_uid),
    'dispositivos', (select coalesce(jsonb_agg(to_jsonb(d) - 'usuario_id'), '[]') from dispositivos d where usuario_id = v_uid),
    'contatos_confianca', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'telefone', telefone)), '[]') from contatos_confianca where usuario_id = v_uid),
    'corridas_como_passageiro', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'data', solicitada_em, 'status', status,
        'origem', origem_endereco, 'destino', destino_endereco, 'valor', preco_final, 'categoria', categoria) order by solicitada_em), '[]')
        from corridas where passageiro_id = v_uid),
    'corridas_como_motorista', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'data', solicitada_em, 'status', status,
        'valor', preco_final, 'km', distancia_real_km) order by solicitada_em), '[]') from corridas where motorista_id = v_uid),
    'pagamentos', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'tipo', tipo, 'metodo', metodo, 'valor', valor, 'status', status, 'data', criado_em)), '[]')
                   from pagamentos where pagador_id = v_uid),
    'motorista', (select to_jsonb(m) from motoristas m where id = v_uid),
    'veiculos', (select coalesce(jsonb_agg(to_jsonb(vc)), '[]') from veiculos vc where vc.motorista_id = v_uid),
    'documentos', (select coalesce(jsonb_agg(jsonb_build_object('tipo', tipo, 'status', status, 'validade', validade, 'enviado_em', criado_em)), '[]')
                   from documentos where motorista_id = v_uid),
    'carteira', public.minha_carteira(500),
    -- [0015] dados das funções novas
    'locais_favoritos', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'endereco', endereco, 'lat', lat, 'lng', lng)), '[]') from locais_favoritos where usuario_id = v_uid),
    'corridas_agendadas', (select coalesce(jsonb_agg(to_jsonb(a) - 'passageiro_id'), '[]') from corridas_agendadas a where passageiro_id = v_uid),
    'meios_pagamento', (select coalesce(jsonb_agg(jsonb_build_object('tipo', tipo, 'bandeira', bandeira, 'final4', final4, 'criado_em', criado_em)), '[]') from meios_pagamento where usuario_id = v_uid),
    'assinaturas', (select coalesce(jsonb_agg(to_jsonb(a) - 'usuario_id'), '[]') from assinaturas a where usuario_id = v_uid),
    'empresas', (select coalesce(jsonb_agg(jsonb_build_object('empresa', coalesce(e.nome_fantasia, e.razao_social), 'papel', m.papel, 'ativo', m.ativo, 'desde', m.criado_em)), '[]')
                 from empresa_membros m join empresas e on e.id = m.empresa_id where m.usuario_id = v_uid),
    'perguntas_ao_assistente', (select coalesce(jsonb_agg(to_jsonb(x) - 'usuario_id'), '[]') from assistente_conversas x where usuario_id = v_uid),
    'aparelhos_com_notificacao', (select coalesce(jsonb_agg(jsonb_build_object('navegador', navegador, 'criado_em', criado_em)), '[]') from push_inscricoes where usuario_id = v_uid),
    'resgates_parceiros', (select coalesce(jsonb_agg(to_jsonb(r) - 'usuario_id'), '[]') from parceiro_resgates r where usuario_id = v_uid)
  ) into v_res;
  perform interno.auditar_evento('LGPD_EXPORTACAO', 'perfis', v_uid::text, null);
  return v_res;
end $$;

create or replace function interno.anonimizar_usuario(p_usuario uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  update perfis set nome = 'Usuário removido', telefone = null, email = null, cpf = null, foto_path = null,
    status = 'INATIVO', codigo_indicacao = null where id = p_usuario;
  delete from contatos_confianca where usuario_id = p_usuario;
  delete from dispositivos where usuario_id = p_usuario;
  delete from consentimentos where usuario_id = p_usuario and tipo in ('MARKETING','COMPARTILHAR_DADOS_PARCEIROS');
  update corridas set origem_endereco = null, destino_endereco = null,
    origem_lat = round(origem_lat::numeric, 2), origem_lng = round(origem_lng::numeric, 2),
    destino_lat = round(destino_lat::numeric, 2), destino_lng = round(destino_lng::numeric, 2)
  where passageiro_id = p_usuario;
  update motoristas set cnh_numero = null, data_nascimento = null, status = 'INATIVO' where id = p_usuario;
  update motorista_presenca set online = false, disponivel = false, lat = null, lng = null where motorista_id = p_usuario;
  update usuario_papeis set ativo = false where usuario_id = p_usuario;
  -- [0015] tabelas das funções novas
  update corridas set opcoes = '{}' where passageiro_id = p_usuario and opcoes <> '{}';
  delete from locais_favoritos where usuario_id = p_usuario;
  update corridas_agendadas set status = 'CANCELADA' where passageiro_id = p_usuario and status = 'AGENDADA';
  update corridas_agendadas set origem_endereco = null, destino_endereco = null, opcoes = '{}',
    origem_lat = round(origem_lat::numeric, 2), origem_lng = round(origem_lng::numeric, 2),
    destino_lat = round(destino_lat::numeric, 2), destino_lng = round(destino_lng::numeric, 2) where passageiro_id = p_usuario;
  delete from push_inscricoes where usuario_id = p_usuario;
  update meios_pagamento set ativo = false where usuario_id = p_usuario;
  delete from assistente_conversas where usuario_id = p_usuario;
  update empresa_membros set ativo = false where usuario_id = p_usuario;
  update assinaturas set status = 'CANCELADA', cancelada_em = coalesce(cancelada_em, now()) where usuario_id = p_usuario and status <> 'CANCELADA';
  update empresa_convites set status = 'CANCELADO' where status = 'PENDENTE' and contato = any(interno.contatos_verificados(p_usuario));
  perform interno.auditar_evento('LGPD_ANONIMIZACAO', 'perfis', p_usuario::text, null);
end $$;

create or replace function public.solicitar_exclusao_conta(p_motivo text default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid;
begin
  if exists (select 1 from corridas where (passageiro_id = v_uid or motorista_id = v_uid)
             and status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO')) then
    perform interno.erro('CORRIDA_EM_ANDAMENTO');
  end if;
  if exists (select 1 from pagamentos where pagador_id = v_uid and status = 'PENDENTE') then perform interno.erro('PAGAMENTO_EM_ABERTO'); end if;
  if interno.saldo(v_uid, 'MOTORISTA_DISPONIVEL') > 0 or interno.saldo(v_uid, 'INDICACAO_DISPONIVEL') > 0 then
    perform interno.erro('SAQUE_SEU_SALDO_ANTES');
  end if;
  -- [0015] viagens agendadas e assinatura não continuam depois do pedido de exclusão
  update corridas_agendadas set status = 'CANCELADA' where passageiro_id = v_uid and status = 'AGENDADA';
  insert into lgpd_solicitacoes (usuario_id, tipo, motivo, executar_em) values (v_uid, 'EXCLUSAO', p_motivo, now() + interval '7 days')
  returning id into v_id;
  perform interno.notificar(v_uid, 'SEGURANCA', 'Pedido de exclusão recebido',
    'Sua conta será anonimizada em 7 dias. Você pode cancelar até lá.', jsonb_build_object('solicitacao', v_id));
  return jsonb_build_object('id', v_id, 'executar_em', now() + interval '7 days');
end $$;

-- agenda: o vigia entra no job de hora em hora
create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'agendadas', interno.rodar_job('agendadas', 'interno.job_agendadas()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca_v2()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'inteligencia' then
    return jsonb_build_object('inteligencia', interno.rodar_job('inteligencia', 'interno.job_inteligencia()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object(
      'liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'),
      'notificacoes', interno.rodar_job('notificacoes', 'interno.job_notificacoes()'),
      'vigia', interno.rodar_job('vigia', 'interno.job_vigia()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco_v2()'),
      'empresas', interno.rodar_job('empresas', 'interno.job_empresas()'),
      'assinaturas', interno.rodar_job('assinaturas', 'interno.job_assinaturas()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;

insert into funcoes_servidor (assinatura) values ('public.registrar_cobranca(uuid, text, text, jsonb)') on conflict do nothing;
select interno.aplicar_permissoes_funcoes();

-- ---------- rede de segurança: toda tabela pública com RLS e sem acesso direto dos apps ----------
-- (no Supabase, tabelas novas nascem com GRANT ALL para anon/authenticated por "default privileges")
alter table empresa_creditos enable row level security;
revoke all on empresa_creditos from anon, authenticated;
select interno.criar_politica('empresa_creditos', 'financeiro', $p$interno.eh_papel('{FINANCEIRO,ADMIN}')$p$);
do $$
declare t record;
begin
  for t in select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
           where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity loop
    execute format('alter table public.%I enable row level security', t.relname);
    execute format('revoke all on public.%I from anon, authenticated', t.relname);
    raise notice 'RLS ligado por segurança em %', t.relname;
  end loop;
  -- nenhuma tabela aceita escrita direta dos apps (tudo passa pelas funções)
  for t in select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind in ('r','v','m') loop
    execute format('revoke insert, update, delete, truncate, references, trigger on public.%I from anon, authenticated', t.relname);
  end loop;
end $$;
select interno.aplicar_permissoes_funcoes();
