-- ============================================================
-- 0011 — CATEGORIAS ESPECIAIS (requisitos e regras geográficas),
--        AGENDAMENTO, EXPERIÊNCIA DO PASSAGEIRO, PAINEL DO DONO
--        (CAC, LTV, lucro operacional estimado), MAPA NACIONAL,
--        ANALYTICS (coortes e funil), NOTIFICAÇÕES INTELIGENTES
-- Não altera as funções antigas: só acrescenta e estende.
-- ============================================================

-- ============================================================
-- 1) REQUISITOS POR CATEGORIA (padrão nacional + ajuste por cidade)
-- ============================================================
alter table categorias add column if not exists requisitos_padrao jsonb not null default '{}';
alter table categorias add column if not exists regra_geografica text;
alter table categorias drop constraint if exists categorias_regra_geo_check;
alter table categorias add constraint categorias_regra_geo_check
  check (regra_geografica is null or regra_geografica in ('AEROPORTO','TERMINAL','EVENTOS','INTERMUNICIPAL'));

alter table veiculos add column if not exists itens_declarados text[] not null default '{}';
alter table veiculos add column if not exists itens_verificados text[] not null default '{}';
alter table motoristas add column if not exists treinamentos text[] not null default '{}';

-- requisitos_padrao: {"acessivel":true, "itens":["cadeirinha"], "capacidade_min":6, "nota_min":4.8,
--                     "corridas_min":50, "treinamentos":["ACESSIBILIDADE"]}
-- cidade_categorias.requisitos (já existia) sobrepõe chave a chave.
update categorias set requisitos_padrao = '{"acessivel":true,"treinamentos":["ACESSIBILIDADE"]}' where codigo = 'ACESSIVEL';
update categorias set requisitos_padrao = '{"itens":["cadeirinha"],"treinamentos":["TRANSPORTE_INFANTIL"]}' where codigo = 'FAMILIAR';
update categorias set requisitos_padrao = '{"capacidade_min":6}' where codigo = 'SETE_LUGARES';
update categorias set requisitos_padrao = '{"itens":["porta_malas_grande"]}', regra_geografica = 'AEROPORTO' where codigo = 'AEROPORTO';
update categorias set regra_geografica = 'TERMINAL' where codigo = 'TERMINAL';
update categorias set regra_geografica = 'EVENTOS' where codigo = 'EVENTOS';
update categorias set requisitos_padrao = '{"nota_min":4.7,"corridas_min":50}', regra_geografica = 'INTERMUNICIPAL' where codigo = 'INTERMUNICIPAL';
update categorias set requisitos_padrao = '{"nota_min":4.8,"corridas_min":100}' where codigo = 'VIAGENS';
update categorias set requisitos_padrao = '{"nota_min":4.8}' where codigo = 'PREMIUM';

insert into configuracoes (chave, valor, descricao) values
  ('itens_veiculo', '["cadeirinha","assento_elevacao","rampa","porta_malas_grande","ar_condicionado","suporte_bicicleta"]', 'itens que o motorista pode declarar (a operação verifica)'),
  ('treinamentos', '["ACESSIBILIDADE","TRANSPORTE_INFANTIL","DIRECAO_DEFENSIVA","ATENDIMENTO_EXECUTIVO"]', 'treinamentos registrados pela operação'),
  ('intermunicipal_max_km', '150', 'distância máxima de uma corrida intermunicipal'),
  ('eventos_raio_km', '1.5', 'raio em volta de um evento cadastrado para a categoria Eventos'),
  ('agendamento_min_antecedencia_min', '30', 'antecedência mínima para agendar'),
  ('agendamento_max_dias', '30', 'antecedência máxima para agendar'),
  ('agendamento_ativos_max', '5', 'agendamentos ativos por passageiro'),
  ('agendamento_disparo_min', '15', 'minutos antes do horário em que a busca de motorista começa'),
  ('manutencao_km', '10000', 'km rodados na plataforma desde a última manutenção lançada para sugerir revisão'),
  ('taxa_gateway_estimada_pct', '1.5', 'custo estimado do gateway sobre pagamentos online (só para o lucro ESTIMADO)')
on conflict (chave) do nothing;

create or replace function interno.requisitos_categoria(p_cidade uuid, p_categoria text) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((select requisitos_padrao from categorias where codigo = p_categoria), '{}')
      || coalesce((select requisitos from cidade_categorias where cidade_id = p_cidade and categoria = p_categoria), '{}')
$$;

-- pendências específicas da categoria (somam às pendências gerais de compliance)
create or replace function interno.pendencias_categoria(p_motorista uuid, p_categoria text) returns text[]
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare m motoristas; v veiculos; req jsonb; pend text[] := '{}'; t text;
begin
  select * into m from motoristas where id = p_motorista;
  select * into v from veiculos where id = m.veiculo_ativo_id;
  if v.id is null then return array['SEM_VEICULO_ATIVO']; end if;
  req := interno.requisitos_categoria(m.cidade_id, p_categoria);
  if coalesce((req ->> 'acessivel')::boolean, false) and not v.acessivel then pend := pend || 'VEICULO_SEM_ACESSIBILIDADE'::text; end if;
  if (req ->> 'capacidade_min') is not null and v.capacidade < (req ->> 'capacidade_min')::int then pend := pend || 'CAPACIDADE_INSUFICIENTE'::text; end if;
  for t in select jsonb_array_elements_text(coalesce(req -> 'itens', '[]')) loop
    if not (t = any(v.itens_verificados)) then pend := pend || ('ITEM_NAO_VERIFICADO_' || upper(t)); end if;
  end loop;
  for t in select jsonb_array_elements_text(coalesce(req -> 'treinamentos', '[]')) loop
    if not (t = any(m.treinamentos)) then pend := pend || ('TREINAMENTO_' || t); end if;
  end loop;
  -- nota só conta com histórico mínimo (sem histórico = ainda não elegível, não "nota ruim")
  if (req ->> 'nota_min') is not null and (m.total_avaliacoes < 10 or m.avaliacao_media < (req ->> 'nota_min')::numeric) then
    pend := pend || 'NOTA_OU_HISTORICO_INSUFICIENTE'::text;
  end if;
  if (req ->> 'corridas_min') is not null and m.total_corridas < (req ->> 'corridas_min')::int then pend := pend || 'POUCAS_CORRIDAS'::text; end if;
  return pend;
end $$;

-- categorias liberadas agora também exigem os requisitos da categoria
create or replace function interno.categorias_liberadas(p_motorista uuid)
returns text[] language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(array_agg(cc.categoria order by cat.ordem), '{}')
  from motoristas m
  join cidade_categorias cc on cc.cidade_id = m.cidade_id and cc.habilitada
  join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
  where m.id = p_motorista
    and cardinality(interno.pendencias_motorista(p_motorista, cc.categoria)) = 0
    and cardinality(interno.pendencias_categoria(p_motorista, cc.categoria)) = 0
$$;

-- o motorista vê o que falta para cada categoria da cidade
create or replace function public.minhas_categorias() returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}');
begin
  return (select coalesce(jsonb_agg(jsonb_build_object('categoria', cc.categoria, 'nome', cat.nome,
            'liberada', cardinality(p.geral) + cardinality(p.especifica) = 0,
            'pendencias', to_jsonb(p.geral || p.especifica), 'requisitos', interno.requisitos_categoria(m.cidade_id, cc.categoria))
            order by cat.ordem), '[]')
          from motoristas m
          join cidade_categorias cc on cc.cidade_id = m.cidade_id and cc.habilitada
          join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
          cross join lateral (select interno.pendencias_motorista(m.id, cc.categoria) geral, interno.pendencias_categoria(m.id, cc.categoria) especifica) p
          where m.id = v_uid);
end $$;

create or replace function public.motorista_declarar_itens(p_veiculo uuid, p_itens text[]) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); t text;
begin
  perform interno.limitar('declarar_itens', 10, 3600);
  foreach t in array coalesce(p_itens, '{}') loop
    if not (interno.cfg('itens_veiculo') ? t) then perform interno.erro('ITEM_INVALIDO', t); end if;
  end loop;
  update veiculos set itens_declarados = coalesce(p_itens, '{}'),
    -- item retirado deixa de valer na hora; item novo só vale depois da verificação
    itens_verificados = array(select unnest(itens_verificados) intersect select unnest(coalesce(p_itens, '{}')))
  where id = p_veiculo and motorista_id = v_uid;
  if not found then perform interno.erro('VEICULO_NAO_ENCONTRADO'); end if;
  return jsonb_build_object('ok', true, 'aviso', 'A operação vai verificar os itens antes de liberar categorias que dependem deles.');
end $$;

create or replace function public.ops_verificar_itens_veiculo(p_veiculo uuid, p_itens text[]) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v veiculos;
begin
  select * into v from veiculos where id = p_veiculo for update;
  if not found then perform interno.erro('VEICULO_NAO_ENCONTRADO'); end if;
  perform interno.sem_conflito(v.motorista_id);
  -- só verifica o que o motorista declarou
  update veiculos set itens_verificados = array(select unnest(coalesce(p_itens, '{}')) intersect select unnest(itens_declarados)) where id = p_veiculo;
  perform interno.auditar_evento('ITENS_VEICULO', 'veiculos', p_veiculo::text, jsonb_build_object('itens', p_itens));
end $$;

create or replace function public.ops_definir_treinamento(p_motorista uuid, p_treinamento text, p_ativo boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}');
begin
  perform interno.sem_conflito(p_motorista);
  if not (interno.cfg('treinamentos') ? p_treinamento) then perform interno.erro('TREINAMENTO_INVALIDO'); end if;
  update motoristas set treinamentos = case when p_ativo then array(select distinct unnest(treinamentos || p_treinamento))
                                            else array_remove(treinamentos, p_treinamento) end
  where id = p_motorista;
  if not found then perform interno.erro('MOTORISTA_NAO_ENCONTRADO'); end if;
  perform interno.auditar_evento('TREINAMENTO', 'motoristas', p_motorista::text, jsonb_build_object('treinamento', p_treinamento, 'ativo', p_ativo));
end $$;

-- AGENDADA e CORPORATIVA não são categorias de veículo (agendamento e Mobi Empresas valem para
-- qualquer categoria). COMPARTILHADA exige algoritmo de agrupamento ainda não implementado:
-- fica bloqueada para não vender algo que o sistema não entrega.
create or replace function public.admin_categoria_sistema(p_codigo text, p_disponivel boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN}');
begin
  if p_disponivel and p_codigo in ('AGENDADA','CORPORATIVA') then
    perform interno.erro('NAO_E_CATEGORIA', 'use o agendamento ou o Mobi Empresas, que valem para qualquer categoria');
  end if;
  if p_disponivel and p_codigo = 'COMPARTILHADA' then perform interno.erro('CATEGORIA_AINDA_NAO_IMPLEMENTADA'); end if;
  update categorias set disponivel_no_sistema = p_disponivel where codigo = p_codigo;
  if not found then perform interno.erro('CATEGORIA_NAO_ENCONTRADA'); end if;
  perform interno.auditar_evento('CATEGORIA_SISTEMA', 'categorias', p_codigo, jsonb_build_object('disponivel', p_disponivel));
end $$;

-- ============================================================
-- 2) REGRAS GEOGRÁFICAS (aeroporto, terminal, eventos, intermunicipal)
-- ============================================================
create or replace function interno.validar_regra_categoria(p_cidade uuid, p_categoria text,
  p_o_lat float8, p_o_lng float8, p_d_lat float8, p_d_lng float8) returns text
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_regra text; c cidades; v_dist numeric;
begin
  select regra_geografica into v_regra from categorias where codigo = p_categoria;
  if v_regra is null then return null; end if;
  select * into c from cidades where id = p_cidade;
  if v_regra in ('AEROPORTO','TERMINAL') then
    if not exists (select 1 from regioes r where r.cidade_id = p_cidade and r.ativa and r.tipo = v_regra
                   and (interno.distancia_km(r.centro_lat, r.centro_lng, p_o_lat, p_o_lng) <= r.raio_km
                        or interno.distancia_km(r.centro_lat, r.centro_lng, p_d_lat, p_d_lng) <= r.raio_km)) then
      return case v_regra when 'AEROPORTO' then 'CATEGORIA_SO_DE_OU_PARA_AEROPORTO' else 'CATEGORIA_SO_DE_OU_PARA_TERMINAL' end;
    end if;
  elsif v_regra = 'EVENTOS' then
    if not exists (select 1 from regioes r where r.cidade_id = p_cidade and r.ativa and r.tipo = 'EVENTOS'
                   and interno.distancia_km(r.centro_lat, r.centro_lng, p_o_lat, p_o_lng) <= r.raio_km)
       and not exists (select 1 from eventos_cidade e where e.cidade_id = p_cidade
                       and now() between e.inicio - interval '2 hours' and e.fim + interval '3 hours'
                       and interno.distancia_km(e.lat, e.lng, p_o_lat, p_o_lng) <= interno.cfg_num('eventos_raio_km', 1.5)) then
      return 'CATEGORIA_SO_SAINDO_DE_EVENTO';
    end if;
  elsif v_regra = 'INTERMUNICIPAL' then
    if interno.distancia_km(c.centro_lat, c.centro_lng, p_d_lat, p_d_lng) <= c.raio_atendimento_km then
      return 'DESTINO_DENTRO_DO_MUNICIPIO';
    end if;
    v_dist := interno.distancia_km(p_o_lat, p_o_lng, p_d_lat, p_d_lng);
    if v_dist > interno.cfg_num('intermunicipal_max_km', 150) then return 'DISTANCIA_ACIMA_DO_PERMITIDO'; end if;
  end if;
  return null;
end $$;

create or replace function interno.trg_corrida_regra_categoria() returns trigger
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_err text;
begin
  v_err := interno.validar_regra_categoria(new.cidade_id, new.categoria, new.origem_lat, new.origem_lng, new.destino_lat, new.destino_lng);
  if v_err is not null then raise exception using errcode = 'P0001', message = v_err; end if;
  return new;
end $$;
drop trigger if exists corridas_regra_categoria on corridas;
create trigger corridas_regra_categoria before insert on corridas for each row execute function interno.trg_corrida_regra_categoria();

-- ============================================================
-- 3) EXPERIÊNCIA DO PASSAGEIRO: opções da corrida, favoritos,
--    estimativa detalhada (faixas), recibo e histórico
-- ============================================================
alter table corridas add column if not exists opcoes jsonb not null default '{}';

create or replace function interno.sanear_opcoes(p jsonb) returns jsonb
language plpgsql immutable as $$
declare r jsonb := '{}';
begin
  if p is null then return '{}'; end if;
  if p ? 'observacao' then r := r || jsonb_build_object('observacao', left(regexp_replace(p ->> 'observacao', '[<>]', '', 'g'), 200)); end if;
  if p ? 'ponto_encontro' then r := r || jsonb_build_object('ponto_encontro', left(regexp_replace(p ->> 'ponto_encontro', '[<>]', '', 'g'), 100)); end if;
  if p ? 'voo' then r := r || jsonb_build_object('voo', upper(left(regexp_replace(p ->> 'voo', '[^A-Za-z0-9]', '', 'g'), 8))); end if;
  if p ? 'bagagens' then r := r || jsonb_build_object('bagagens', least(greatest(coalesce((p ->> 'bagagens')::int, 0), 0), 10)); end if;
  if p ? 'precisa_cadeirinha' then r := r || jsonb_build_object('precisa_cadeirinha', coalesce((p ->> 'precisa_cadeirinha')::boolean, false)); end if;
  if p ? 'cadeira_de_rodas' then r := r || jsonb_build_object('cadeira_de_rodas', coalesce((p ->> 'cadeira_de_rodas')::boolean, false)); end if;
  return r;
end $$;

create or replace function public.definir_opcoes_corrida(p_corrida uuid, p_opcoes jsonb) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas;
begin
  perform interno.limitar('opcoes_corrida', 20, 3600);
  select * into c from corridas where id = p_corrida for update;
  if not found or c.passageiro_id <> v_uid then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if c.status not in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU') then perform interno.erro('STATUS_INVALIDO'); end if;
  update corridas set opcoes = interno.sanear_opcoes(p_opcoes) where id = p_corrida;
  if c.motorista_id is not null then
    perform interno.notificar(c.motorista_id, 'CORRIDA', 'Passageiro atualizou a corrida', coalesce(interno.sanear_opcoes(p_opcoes) ->> 'observacao', 'Veja os detalhes.'),
      jsonb_build_object('corrida', c.id));
  end if;
  return interno.sanear_opcoes(p_opcoes);
end $$;

create table if not exists locais_favoritos (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id) on delete cascade,
  nome text not null check (length(nome) between 1 and 40),
  endereco text not null,
  lat float8 not null, lng float8 not null,
  criado_em timestamptz not null default now(),
  unique (usuario_id, nome)
);

create or replace function public.salvar_local_favorito(p_nome text, p_endereco text, p_lat float8, p_lng float8) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid;
begin
  if (select count(*) from locais_favoritos where usuario_id = v_uid) >= 20 then perform interno.erro('LIMITE_DE_FAVORITOS'); end if;
  if p_lat not between -90 and 90 or p_lng not between -180 and 180 then perform interno.erro('COORDENADA_INVALIDA'); end if;
  insert into locais_favoritos (usuario_id, nome, endereco, lat, lng) values (v_uid, left(trim(p_nome), 40), left(p_endereco, 200), p_lat, p_lng)
  on conflict (usuario_id, nome) do update set endereco = excluded.endereco, lat = excluded.lat, lng = excluded.lng
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.remover_local_favorito(p_id uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  delete from locais_favoritos where id = p_id and usuario_id = interno.exigir_login();
end $$;

-- estimativa para a tela de escolha: faixas, não números "exatos"
create or replace function public.estimar_corrida_detalhada(p_cidade uuid, p_o_lat float8, p_o_lng float8, p_d_lat float8, p_d_lng float8,
  p_rota_km numeric default null, p_rota_min numeric default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); e jsonb; x jsonb; v_out jsonb := '[]'; v_err text; a jsonb; v_desc numeric; v_eta int; req jsonb;
begin
  e := public.estimar_corrida(p_cidade, p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  a := interno.assinatura_ativa(v_uid);
  for x in select * from jsonb_array_elements(e) loop
    v_err := interno.validar_regra_categoria(p_cidade, x ->> 'categoria', p_o_lat, p_o_lng, p_d_lat, p_d_lng);
    continue when v_err is not null;      -- não oferece o que não vale para este trajeto
    v_eta := (x ->> 'chegada_min')::int;
    req := interno.requisitos_categoria(p_cidade, x ->> 'categoria');
    v_desc := case when a is not null and coalesce((a -> 'beneficios' ->> 'desconto_pct')::numeric, 0) > 0
                     and (a -> 'beneficios' -> 'categorias' is null or (a -> 'beneficios' -> 'categorias') ? (x ->> 'categoria'))
                   then least(round((x ->> 'preco')::numeric * (a -> 'beneficios' ->> 'desconto_pct')::numeric / 100, 2),
                              coalesce((a -> 'beneficios' ->> 'desconto_max_corrida')::numeric, 1e9)) else 0 end;
    v_out := v_out || (x || jsonb_build_object(
      'preco_estimado', (x ->> 'preco')::numeric,
      'desconto_mobi_mais_estimado', v_desc,
      'chegada_faixa', case when x ->> 'disponivel' = 'true' then v_eta || '–' || (v_eta + greatest(2, ceil(v_eta * 0.5)::int)) || ' min'
                            else 'sem motoristas por perto agora' end,
      'inclui', (select coalesce(jsonb_agg(i), '[]') from (
                   select case when (req ->> 'acessivel')::boolean then 'veículo adaptado' end i
                   union all select 'item: ' || replace(t, '_', ' ') from jsonb_array_elements_text(coalesce(req -> 'itens', '[]')) t
                   union all select case when (req ->> 'capacidade_min') is not null then 'até ' || (req ->> 'capacidade_min') || ' passageiros' end) z
                 where i is not null)));
  end loop;
  return jsonb_build_object('estimativa', true,
    'aviso', 'Valores e tempos são estimativas. O preço final considera o trajeto realmente percorrido.',
    'opcoes', v_out);
end $$;

create or replace function public.recibo_corrida(p_corrida uuid) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v veiculos;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (v_uid <> c.passageiro_id and v_uid is distinct from c.motorista_id and not interno.eh_staff()) then
    perform interno.erro('CORRIDA_NAO_ENCONTRADA');
  end if;
  select * into v from veiculos where id = c.veiculo_id;
  return jsonb_build_object(
    'corrida', c.id, 'status', c.status, 'categoria', c.categoria,
    'data', c.solicitada_em, 'inicio', c.iniciada_em, 'fim', c.finalizada_em,
    'origem', c.origem_endereco, 'destino', c.destino_endereco,
    'distancia_km', c.distancia_real_km, 'duracao_min', c.duracao_real_min,
    'valor_corrida', c.preco_final, 'desconto', c.desconto, 'valor_pago', coalesce(c.preco_final, 0) - c.desconto,
    'taxa_cancelamento', c.taxa_cancelamento,
    'gorjeta', (select valor from pagamentos where corrida_id = c.id and tipo = 'GORJETA' and status = 'CONFIRMADO'),
    'metodo', c.metodo_pagamento,
    'motorista', (select split_part(nome, ' ', 1) from perfis where id = c.motorista_id),
    'veiculo', case when v.id is not null then v.marca || ' ' || v.modelo || ' · ' || v.placa end,
    'empresa', (select coalesce(nome_fantasia, razao_social) from empresas where id = c.empresa_id));
end $$;

create or replace function public.historico_passageiro(p_limite int default 30) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(x order by x ->> 'data' desc), '[]') from (
    select jsonb_build_object('corrida', c.id, 'data', c.solicitada_em, 'status', c.status, 'categoria', c.categoria,
             'origem', c.origem_endereco, 'destino', c.destino_endereco, 'valor_pago', coalesce(c.preco_final, 0) - c.desconto,
             'avaliada', exists (select 1 from avaliacoes a where a.corrida_id = c.id and a.avaliador_id = auth.uid())) x
    from corridas c where c.passageiro_id = auth.uid() order by c.solicitada_em desc limit least(greatest(p_limite, 1), 100)) y
$$;

-- ============================================================
-- 4) CORRIDAS AGENDADAS
-- ============================================================
create table if not exists corridas_agendadas (
  id uuid primary key default gen_random_uuid(),
  passageiro_id uuid not null references perfis(id),
  chave_idempotencia text not null,
  cidade_id uuid not null references cidades(id),
  categoria text not null references categorias(codigo),
  origem_lat float8 not null, origem_lng float8 not null, origem_endereco text,
  destino_lat float8 not null, destino_lng float8 not null, destino_endereco text,
  metodo_pagamento metodo_pagamento not null,
  passageiros int not null default 1,
  opcoes jsonb not null default '{}',
  agendada_para timestamptz not null,
  preco_estimado numeric(10,2),
  status text not null default 'AGENDADA' check (status in ('AGENDADA','DISPARADA','CANCELADA','FALHOU')),
  corrida_id uuid references corridas(id),
  falha text,
  lembrete_enviado boolean not null default false,
  criado_em timestamptz not null default now(),
  unique (passageiro_id, chave_idempotencia)
);
create index if not exists agendadas_fila_idx on corridas_agendadas (agendada_para) where status = 'AGENDADA';

create or replace function public.agendar_corrida(p_chave_idempotencia text, p_cidade uuid, p_categoria text,
  p_o_lat float8, p_o_lng float8, p_o_endereco text, p_d_lat float8, p_d_lng float8, p_d_endereco text,
  p_metodo metodo_pagamento, p_agendada_para timestamptz, p_opcoes jsonb default '{}', p_passageiros int default 1,
  p_rota_km numeric default null, p_rota_min numeric default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); g corridas_agendadas; v_rota record; v_err text; v_preco numeric; cid cidades;
begin
  perform interno.limitar('agendar', 10, 3600);
  if coalesce(length(p_chave_idempotencia), 0) < 8 then perform interno.erro('CHAVE_IDEMPOTENCIA_OBRIGATORIA'); end if;
  select * into g from corridas_agendadas where passageiro_id = v_uid and chave_idempotencia = p_chave_idempotencia;
  if found then return jsonb_build_object('agendamento', g.id, 'status', g.status, 'repetido', true); end if;
  if p_agendada_para < now() + make_interval(mins => interno.cfg_num('agendamento_min_antecedencia_min', 30)::int) then
    perform interno.erro('ANTECEDENCIA_MINIMA', interno.cfg_num('agendamento_min_antecedencia_min', 30)::text || ' minutos');
  end if;
  if p_agendada_para > now() + make_interval(days => interno.cfg_num('agendamento_max_dias', 30)::int) then perform interno.erro('ANTECEDENCIA_MAXIMA'); end if;
  if (select count(*) from corridas_agendadas where passageiro_id = v_uid and status = 'AGENDADA') >= interno.cfg_num('agendamento_ativos_max', 5) then
    perform interno.erro('LIMITE_DE_AGENDAMENTOS');
  end if;
  if p_metodo::text = 'EMPRESA' then perform interno.erro('AGENDAMENTO_CORPORATIVO_INDISPONIVEL'); end if;
  if p_passageiros not between 1 and 8 then perform interno.erro('PASSAGEIROS_INVALIDO'); end if;
  if not exists (select 1 from perfis where id = v_uid and status = 'ATIVO') then perform interno.erro('CONTA_INATIVA'); end if;
  select * into cid from cidades where id = p_cidade and ativa;
  if not found then perform interno.erro('CIDADE_NAO_ATENDIDA'); end if;
  if interno.distancia_km(cid.centro_lat, cid.centro_lng, p_o_lat, p_o_lng) > cid.raio_atendimento_km then perform interno.erro('FORA_DA_AREA_DE_ATENDIMENTO'); end if;
  if not exists (select 1 from cidade_categorias cc join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
                 where cc.cidade_id = p_cidade and cc.categoria = p_categoria and cc.habilitada) then
    perform interno.erro('CATEGORIA_INDISPONIVEL');
  end if;
  v_err := interno.validar_regra_categoria(p_cidade, p_categoria, p_o_lat, p_o_lng, p_d_lat, p_d_lng);
  if v_err is not null then perform interno.erro(v_err); end if;
  select * into v_rota from interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  v_preco := interno.calcular_preco(p_cidade, p_categoria, v_rota.km, v_rota.minutos);
  insert into corridas_agendadas (passageiro_id, chave_idempotencia, cidade_id, categoria, origem_lat, origem_lng, origem_endereco,
    destino_lat, destino_lng, destino_endereco, metodo_pagamento, passageiros, opcoes, agendada_para, preco_estimado)
  values (v_uid, p_chave_idempotencia, p_cidade, p_categoria, p_o_lat, p_o_lng, left(p_o_endereco, 200), p_d_lat, p_d_lng, left(p_d_endereco, 200),
    p_metodo, p_passageiros, interno.sanear_opcoes(p_opcoes), p_agendada_para, v_preco)
  returning * into g;
  return jsonb_build_object('agendamento', g.id, 'status', g.status, 'agendada_para', g.agendada_para, 'preco_estimado', v_preco,
    'aviso', 'A busca por motorista começa ' || interno.cfg_num('agendamento_disparo_min', 15)::int
             || ' minutos antes. O valor é uma estimativa e pode variar com o trânsito do dia.');
end $$;

create or replace function public.cancelar_agendamento(p_agendamento uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  update corridas_agendadas set status = 'CANCELADA'
  where id = p_agendamento and passageiro_id = interno.exigir_login() and status = 'AGENDADA';
  if not found then perform interno.erro('AGENDAMENTO_NAO_CANCELAVEL', 'já disparado: cancele a corrida em andamento'); end if;
end $$;

create or replace function public.minhas_agendadas() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'agendada_para', agendada_para, 'status', status, 'categoria', categoria,
           'origem', origem_endereco, 'destino', destino_endereco, 'preco_estimado', preco_estimado, 'corrida', corrida_id, 'falha', falha)
           order by agendada_para desc), '[]')
  from corridas_agendadas where passageiro_id = auth.uid() and agendada_para > now() - interval '30 days'
$$;

-- o job age "em nome" do passageiro só para reaproveitar a MESMA regra de solicitação
-- (limites, dívidas, preço, matching). O contexto é restaurado logo depois.
create or replace function interno.job_agendadas() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare g corridas_agendadas; r jsonb; n_disp int := 0; n_falha int := 0; n_lemb int := 0;
        v_sub text := current_setting('request.jwt.claim.sub', true); v_claims text := current_setting('request.jwt.claims', true);
        v_role text := current_setting('request.jwt.claim.role', true);
begin
  -- lembrete 1 h antes (respeita preferências e horário de silêncio)
  for g in select * from corridas_agendadas where status = 'AGENDADA' and not lembrete_enviado
             and agendada_para <= now() + interval '60 minutes' and agendada_para > now() + interval '20 minutes' loop
    if interno.notificar_se_pode(g.passageiro_id, 'AGENDADA', 'Sua viagem agendada',
         'Às ' || to_char(g.agendada_para at time zone 'America/Sao_Paulo', 'HH24:MI') || ' · ' || coalesce(g.destino_endereco, 'destino'),
         jsonb_build_object('agendamento', g.id, 'chave', 'agendada:' || g.id)) then
      update corridas_agendadas set lembrete_enviado = true where id = g.id;
      n_lemb := n_lemb + 1;
    end if;
  end loop;
  -- disparo
  for g in select * from corridas_agendadas where status = 'AGENDADA'
             and agendada_para <= now() + make_interval(mins => interno.cfg_num('agendamento_disparo_min', 15)::int)
           order by agendada_para limit 200 for update skip locked loop
    if g.agendada_para < now() - interval '30 minutes' then
      update corridas_agendadas set status = 'FALHOU', falha = 'HORARIO_PASSOU' where id = g.id;
      perform interno.notificar(g.passageiro_id, 'CORRIDA', 'Viagem agendada não iniciada', 'Não conseguimos iniciar sua viagem a tempo. Nenhum valor foi cobrado.', jsonb_build_object('agendamento', g.id));
      n_falha := n_falha + 1; continue;
    end if;
    begin
      perform set_config('request.jwt.claim.sub', g.passageiro_id::text, true);
      perform set_config('request.jwt.claim.role', 'authenticated', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', g.passageiro_id, 'role', 'authenticated')::text, true);
      r := public.solicitar_corrida('AGENDA:' || g.id, g.cidade_id, g.categoria, g.origem_lat, g.origem_lng, g.origem_endereco,
                                    g.destino_lat, g.destino_lng, g.destino_endereco, g.metodo_pagamento, null, null, g.passageiros);
      update corridas set opcoes = g.opcoes || jsonb_build_object('agendada', true) where id = (r ->> 'corrida')::uuid;
      update corridas_agendadas set status = 'DISPARADA', corrida_id = (r ->> 'corrida')::uuid where id = g.id;
      n_disp := n_disp + 1;
    exception when others then
      update corridas_agendadas set status = 'FALHOU', falha = left(sqlerrm, 200) where id = g.id;
      perform interno.notificar(g.passageiro_id, 'CORRIDA', 'Não foi possível iniciar sua viagem agendada',
        'Motivo: ' || replace(left(sqlerrm, 80), '_', ' ') || '. Nenhum valor foi cobrado.', jsonb_build_object('agendamento', g.id));
      n_falha := n_falha + 1;
    end;
    perform set_config('request.jwt.claim.sub', coalesce(v_sub, ''), true);
    perform set_config('request.jwt.claim.role', coalesce(v_role, ''), true);
    perform set_config('request.jwt.claims', coalesce(v_claims, ''), true);
  end loop;
  return jsonb_build_object('disparadas', n_disp, 'falhas', n_falha, 'lembretes', n_lemb);
end $$;

-- ============================================================
-- 5) CUSTOS OPERACIONAIS (base do lucro operacional estimado e do CAC)
-- ============================================================
create table if not exists custos_operacionais (
  id uuid primary key default gen_random_uuid(),
  data date not null,
  categoria text not null check (categoria in ('MARKETING','INFRAESTRUTURA','PESSOAL','SUPORTE','JURIDICO','SEGUROS','IMPOSTOS','OUTROS')),
  cidade_id uuid references cidades(id),     -- null = custo nacional
  valor numeric(12,2) not null check (valor <> 0),   -- negativo = correção de lançamento
  descricao text not null,
  lancado_por uuid not null,
  criado_em timestamptz not null default now()
);
create index if not exists custos_operacionais_idx on custos_operacionais (data, cidade_id);
drop trigger if exists custos_operacionais_imutavel on custos_operacionais;
create trigger custos_operacionais_imutavel before update or delete on custos_operacionais for each row execute function interno.trg_imutavel();
drop trigger if exists custos_operacionais_auditar on custos_operacionais;
create trigger custos_operacionais_auditar after insert on custos_operacionais for each row execute function interno.trg_auditar();

create or replace function public.fin_lancar_custo_operacional(p_data date, p_categoria text, p_valor numeric, p_descricao text, p_cidade uuid default null)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO}'); v_id uuid;
begin
  if coalesce(length(trim(p_descricao)), 0) < 3 then perform interno.erro('DESCRICAO_OBRIGATORIA'); end if;
  insert into custos_operacionais (data, categoria, cidade_id, valor, descricao, lancado_por)
  values (p_data, p_categoria, p_cidade, round(p_valor, 2), p_descricao, v_uid) returning id into v_id;
  return v_id;
end $$;

-- ============================================================
-- 6) PAINEL DO DONO
-- ============================================================
create or replace function public.dono_dashboard(p_inicio timestamptz, p_fim timestamptz, p_cidade uuid default null,
  p_categoria text default null, p_motorista uuid default null, p_passageiro uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,FINANCEIRO}');
        v_ids uuid[]; v_txt text[];
        v_gmv numeric; v_desc numeric; v_n int; v_online numeric; v_dinheiro numeric;
        v_receita numeric; v_estornos numeric; v_taxas numeric; v_ind numeric; v_mot numeric;
        v_canc int; v_total int; v_reemb numeric; v_assin numeric; v_custos numeric; v_mkt numeric; v_novos int;
        v_gateway numeric; v_lucro numeric; v_cac numeric; v_ltv numeric; v_arpu numeric; v_churn numeric; v_filtro boolean;
begin
  if p_fim <= p_inicio or p_fim - p_inicio > interval '400 days' then perform interno.erro('PERIODO_INVALIDO'); end if;
  v_filtro := p_categoria is not null or p_motorista is not null or p_passageiro is not null;

  -- corridas pagas do período (com os filtros)
  select coalesce(array_agg(id), '{}'), coalesce(array_agg(id::text), '{}'), coalesce(sum(preco_final), 0), coalesce(sum(desconto), 0), count(*),
         coalesce(sum(preco_final - desconto) filter (where metodo_pagamento::text not in ('DINHEIRO','CARTEIRA','EMPRESA')), 0),
         coalesce(sum(preco_final - desconto) filter (where metodo_pagamento = 'DINHEIRO'), 0)
    into v_ids, v_txt, v_gmv, v_desc, v_n, v_online, v_dinheiro
  from corridas
  where status = 'PAGA' and finalizada_em >= p_inicio and finalizada_em < p_fim
    and (p_cidade is null or cidade_id = p_cidade) and (p_categoria is null or categoria = p_categoria)
    and (p_motorista is null or motorista_id = p_motorista) and (p_passageiro is null or passageiro_id = p_passageiro)
    -- corrida estornada sai de tudo (GMV, motoristas, descontos): o estorno desfez a liquidação inteira
    and not exists (select 1 from pagamentos pg where pg.corrida_id = corridas.id and pg.tipo = 'CORRIDA' and pg.status = 'ESTORNADO');

  -- tudo o que é dinheiro vem do LEDGER (não de recálculo)
  select coalesce(sum(l.valor) filter (where ct.tipo = 'PLATAFORMA_RECEITA'), 0),
         coalesce(sum(l.valor) filter (where ct.tipo in ('MOTORISTA_PENDENTE','MOTORISTA_DISPONIVEL')), 0)
    into v_receita, v_mot
  from transacoes_ledger t join lancamentos_ledger l on l.transacao_id = t.id join contas_ledger ct on ct.id = l.conta_id
  where t.tipo = 'LIQUIDACAO_CORRIDA' and t.referencia = any(v_txt);
  -- estornos do período (informativo: as corridas estornadas já ficaram fora dos números acima)
  select coalesce(sum(pg.valor), 0) into v_estornos from pagamentos pg join corridas c on c.id = pg.corrida_id
  where pg.tipo = 'CORRIDA' and pg.status = 'ESTORNADO' and pg.estornado_em >= p_inicio and pg.estornado_em < p_fim
    and (p_cidade is null or c.cidade_id = p_cidade) and (p_categoria is null or c.categoria = p_categoria)
    and (p_motorista is null or c.motorista_id = p_motorista) and (p_passageiro is null or c.passageiro_id = p_passageiro);
  v_mot := v_mot + v_dinheiro;    -- em dinheiro o motorista recebeu na mão e o ledger registra só a parte da plataforma
  select coalesce(sum(valor) filter (where status <> 'ESTORNADO'), 0) into v_ind from ganhos_indicacao where corrida_id = any(v_ids);

  select coalesce(sum(l.valor), 0) into v_taxas
  from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id and ct.tipo = 'PLATAFORMA_RECEITA'
  join transacoes_ledger t on t.id = l.transacao_id join corridas c on c.id::text = t.referencia
  where t.tipo = 'TAXA_CANCELAMENTO' and t.criado_em >= p_inicio and t.criado_em < p_fim
    and (p_cidade is null or c.cidade_id = p_cidade) and (p_categoria is null or c.categoria = p_categoria)
    and (p_motorista is null or c.motorista_id = p_motorista) and (p_passageiro is null or c.passageiro_id = p_passageiro);

  select count(*), count(*) filter (where status = 'CANCELADA') into v_total, v_canc from corridas
  where solicitada_em >= p_inicio and solicitada_em < p_fim and (p_cidade is null or cidade_id = p_cidade)
    and (p_categoria is null or categoria = p_categoria) and (p_motorista is null or motorista_id = p_motorista)
    and (p_passageiro is null or passageiro_id = p_passageiro);

  -- o que não pertence a uma corrida só entra sem filtro de categoria/motorista/passageiro
  select coalesce(-sum(l.valor), 0) into v_reemb from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id and ct.tipo = 'PLATAFORMA_PROMOCOES'
  join transacoes_ledger t on t.id = l.transacao_id left join corridas c on c.id::text = t.referencia
  where t.tipo = 'REEMBOLSO_CREDITO' and t.criado_em >= p_inicio and t.criado_em < p_fim and (p_cidade is null or c.cidade_id = p_cidade) and not v_filtro;
  select coalesce(sum(l.valor), 0) into v_assin from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id and ct.tipo = 'PLATAFORMA_ASSINATURAS'
  join transacoes_ledger t on t.id = l.transacao_id
  where t.criado_em >= p_inicio and t.criado_em < p_fim and not v_filtro and p_cidade is null;
  select coalesce(sum(valor), 0), coalesce(sum(valor) filter (where categoria = 'MARKETING'), 0) into v_custos, v_mkt
  from custos_operacionais where data >= p_inicio::date and data < p_fim::date and (p_cidade is null or cidade_id = p_cidade) and not v_filtro;

  v_gateway := round(v_online * interno.cfg_num('taxa_gateway_estimada_pct', 1.5) / 100, 2);
  v_lucro := v_receita + v_taxas + v_assin - v_desc - v_reemb - v_custos - v_gateway;

  -- CAC = (marketing + cupons de 1ª corrida) ÷ passageiros que fizeram a 1ª corrida no período
  select count(*) into v_novos from (
    select passageiro_id, min(finalizada_em) primeira from corridas where status = 'PAGA' and (p_cidade is null or cidade_id = p_cidade)
    group by passageiro_id) x where primeira >= p_inicio and primeira < p_fim;
  v_cac := case when v_novos > 0 and not v_filtro then round((v_mkt + coalesce((select sum(u.desconto) from cupom_usos u join cupons cp on cp.codigo = u.cupom_codigo
                     where cp.somente_primeira_corrida and u.usado_em >= p_inicio and u.usado_em < p_fim), 0)) / v_novos, 2) end;
  -- LTV estimado = receita mensal por passageiro ativo (90 dias) ÷ churn mensal (vida limitada a 24 meses)
  select round(coalesce(sum(l.valor), 0) / nullif(count(distinct c.passageiro_id), 0) / 3, 2) into v_arpu
  from corridas c join transacoes_ledger t on t.referencia = c.id::text and t.tipo = 'LIQUIDACAO_CORRIDA'
  join lancamentos_ledger l on l.transacao_id = t.id join contas_ledger ct on ct.id = l.conta_id and ct.tipo = 'PLATAFORMA_RECEITA'
  where c.status = 'PAGA' and c.finalizada_em >= now() - interval '90 days' and (p_cidade is null or c.cidade_id = p_cidade);
  select 1 - count(*) filter (where ativo_mes_passado)::numeric / nullif(count(*), 0) into v_churn from (
    select passageiro_id, bool_or(finalizada_em >= date_trunc('month', now()) - interval '1 month') ativo_mes_passado
    from corridas where status = 'PAGA' and (p_cidade is null or cidade_id = p_cidade)
      and finalizada_em >= date_trunc('month', now()) - interval '2 months' and finalizada_em < date_trunc('month', now())
    group by passageiro_id having bool_or(finalizada_em < date_trunc('month', now()) - interval '1 month')) z;
  v_ltv := case when v_arpu is not null and v_churn is not null then round(v_arpu * least(1 / greatest(v_churn, 1.0 / 24), 24), 2) end;

  return jsonb_build_object(
    'periodo', jsonb_build_object('inicio', p_inicio, 'fim', p_fim),
    'filtros', jsonb_build_object('cidade', p_cidade, 'categoria', p_categoria, 'motorista', p_motorista, 'passageiro', p_passageiro),
    'corridas', jsonb_build_object('pagas', v_n, 'solicitadas', v_total, 'canceladas', v_canc,
                                   'taxa_cancelamento_pct', round(100.0 * v_canc / nullif(v_total, 0), 1),
                                   'ticket_medio', round(v_gmv / nullif(v_n, 0), 2)),
    'financeiro', jsonb_build_object('gmv', v_gmv, 'pago_aos_motoristas', v_mot, 'bonus_indicacao', v_ind,
      'receita_comissoes', v_receita, 'corridas_estornadas_valor', v_estornos, 'receita_taxas_cancelamento', v_taxas, 'receita_assinaturas', v_assin,
      'descontos_cupons_mobi_mais', v_desc, 'reembolsos_em_creditos', v_reemb,
      'custos_operacionais', v_custos, 'custo_gateway_estimado', v_gateway,
      'conferencia', jsonb_build_object('ok', abs(v_gmv - v_mot - v_ind - v_receita) < 0.01,
                                        'regra', 'GMV = motoristas + indicação + comissão da plataforma')),
    'lucro_operacional_estimado', jsonb_build_object('valor', v_lucro, 'estimativa', true,
      'composicao', 'comissões + taxas + assinaturas − descontos − reembolsos − custos lançados − gateway estimado (corridas estornadas ficam fora)',
      'aviso', case when v_filtro then 'Com filtro de categoria/motorista/passageiro, custos gerais e assinaturas não entram.' end),
    'cac', jsonb_build_object('valor', v_cac, 'novos_passageiros', v_novos, 'marketing', v_mkt,
      'aviso', case when v_cac is null then 'Sem novos passageiros no período ou filtro incompatível.' end),
    'ltv_estimado', jsonb_build_object('valor', v_ltv, 'estimativa', true, 'receita_mensal_por_passageiro', v_arpu, 'churn_mensal', round(v_churn, 3),
      'aviso', 'Estimativa com base nos últimos 90 dias e na retenção do último mês. Melhora com mais histórico.'),
    'serie_diaria', (select coalesce(jsonb_agg(jsonb_build_object('dia', d, 'corridas', n, 'gmv', g) order by d), '[]') from (
        select (finalizada_em at time zone 'America/Sao_Paulo')::date d, count(*) n, sum(preco_final) g from corridas where id = any(v_ids) group by 1) s),
    'por_categoria', (select coalesce(jsonb_agg(jsonb_build_object('categoria', categoria, 'corridas', n, 'gmv', g) order by g desc), '[]') from (
        select categoria, count(*) n, sum(preco_final) g from corridas where id = any(v_ids) group by 1) s),
    'por_cidade', (select coalesce(jsonb_agg(jsonb_build_object('cidade', ci.nome, 'uf', ci.uf, 'corridas', n, 'gmv', g) order by g desc), '[]') from (
        select cidade_id, count(*) n, sum(preco_final) g from corridas where id = any(v_ids) group by 1) s join cidades ci on ci.id = s.cidade_id));
end $$;

-- ============================================================
-- 7) MAPA OPERACIONAL: BRASIL → UF → CIDADE → REGIÃO
-- ============================================================
create or replace function public.mapa_operacional(p_uf text default null, p_cidade uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,SUPORTE,ADMIN}');
begin
  if p_cidade is not null then
    return jsonb_build_object('nivel', 'CIDADE',
      'cidade', (select jsonb_build_object('id', id, 'nome', nome, 'uf', uf, 'lat', centro_lat, 'lng', centro_lng, 'raio_km', raio_atendimento_km) from cidades where id = p_cidade),
      'zonas', (select coalesce(jsonb_agg(to_jsonb(e) || jsonb_build_object('nivel', interno.nivel_pressao(e.pressao))), '[]') from interno.estado_zonas(p_cidade) e),
      'regioes', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'nome', nome, 'tipo', tipo, 'lat', centro_lat, 'lng', centro_lng, 'raio_km', raio_km)), '[]') from regioes where cidade_id = p_cidade and ativa),
      -- posição aproximada (~100 m): a operação vê onde há oferta sem rastrear pessoas
      'motoristas', (select coalesce(jsonb_agg(jsonb_build_object('lat', round(lat::numeric, 3), 'lng', round(lng::numeric, 3), 'disponivel', disponivel)), '[]')
                     from motorista_presenca where cidade_id = p_cidade and online and atualizado_em > now() - interval '2 minutes'),
      'incidentes', (select coalesce(jsonb_agg(jsonb_build_object('id', i.id, 'tipo', i.tipo, 'gravidade', i.gravidade, 'lat', i.lat, 'lng', i.lng, 'etapa', i.etapa)), '[]')
                     from incidentes i join corridas c on c.id = i.corrida_id where c.cidade_id = p_cidade and i.status not in ('RESOLVIDO','ARQUIVADO')),
      'eventos', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'lat', lat, 'lng', lng, 'inicio', inicio, 'fim', fim)), '[]')
                  from eventos_cidade where cidade_id = p_cidade and fim > now() and inicio < now() + interval '24 hours'));
  end if;
  return jsonb_build_object('nivel', case when p_uf is null then 'BRASIL' else 'UF' end, 'uf', p_uf,
    'itens', (select coalesce(jsonb_agg(x order by (x ->> 'pedidos_15min')::int desc), '[]') from (
      select jsonb_build_object(
        'chave', case when p_uf is null then ci.uf else ci.id::text end,
        'nome', case when p_uf is null then ci.uf else ci.nome end,
        'cidades', count(distinct ci.id),
        'lat', avg(ci.centro_lat), 'lng', avg(ci.centro_lng),
        'motoristas_online', sum(st.online), 'motoristas_disponiveis', sum(st.disponiveis),
        'corridas_em_andamento', sum(st.andamento), 'pedidos_15min', sum(st.pedidos),
        'sem_motorista_1h', sum(st.sem_mot), 'incidentes_abertos', sum(st.incid),
        'nivel', interno.nivel_pressao(sum(st.pedidos)::numeric / (sum(st.disponiveis) + 1))) x
      from cidades ci
      cross join lateral (select
        (select count(*) from motorista_presenca p where p.cidade_id = ci.id and p.online and p.atualizado_em > now() - interval '2 minutes') online,
        (select count(*) from motorista_presenca p where p.cidade_id = ci.id and p.online and p.disponivel and p.atualizado_em > now() - interval '2 minutes') disponiveis,
        (select count(*) from corridas c where c.cidade_id = ci.id and c.status in ('A_CAMINHO','CHEGOU','EM_CURSO')) andamento,
        (select count(*) from corridas c where c.cidade_id = ci.id and c.solicitada_em > now() - interval '15 minutes') pedidos,
        (select count(*) from corridas c where c.cidade_id = ci.id and c.status = 'SEM_MOTORISTA' and c.solicitada_em > now() - interval '1 hour') sem_mot,
        (select count(*) from incidentes i join corridas c on c.id = i.corrida_id where c.cidade_id = ci.id and i.status not in ('RESOLVIDO','ARQUIVADO')) incid) st
      where ci.ativa and (p_uf is null or ci.uf = upper(p_uf))
      group by case when p_uf is null then ci.uf else ci.id::text end, case when p_uf is null then ci.uf else ci.nome end) y));
end $$;

-- ============================================================
-- 8) ANALYTICS: coortes e funil
-- ============================================================
create or replace function interno.meses_entre(a timestamptz, b timestamptz) returns int language sql immutable as $$
  select ((extract(year from b) - extract(year from a)) * 12 + extract(month from b) - extract(month from a))::int
$$;

create or replace function public.analytics_coortes(p_publico text default 'PASSAGEIRO', p_meses int default 6, p_cidade uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,FINANCEIRO,OPERACOES}'); v_m int := least(greatest(p_meses, 1), 24);
begin
  if p_publico not in ('PASSAGEIRO','MOTORISTA') then perform interno.erro('PUBLICO_INVALIDO'); end if;
  return (
    with uso as (
      select case when p_publico = 'PASSAGEIRO' then passageiro_id else motorista_id end u, date_trunc('month', finalizada_em) mes
      from corridas where status = 'PAGA' and (p_cidade is null or cidade_id = p_cidade)),
    membros as (select u, min(mes) coorte from uso group by u),
    ret as (select m.coorte, interno.meses_entre(m.coorte, a.mes) k, count(distinct m.u) n
            from membros m join uso a on a.u = m.u group by 1, 2),
    tam as (select coorte, count(*) tamanho from membros
            where coorte >= date_trunc('month', now()) - make_interval(months => v_m - 1) group by 1)
    select jsonb_build_object('publico', p_publico,
      'definicao', 'coorte = mês da primeira corrida paga; retenção = % da coorte com corrida paga N meses depois',
      'coortes', coalesce(jsonb_agg(jsonb_build_object('coorte', to_char(t.coorte, 'YYYY-MM'), 'tamanho', t.tamanho,
        'retencao_pct', (select jsonb_agg(round(100.0 * coalesce((select n from ret where ret.coorte = t.coorte and ret.k = g), 0) / t.tamanho, 1) order by g)
                         from generate_series(0, interno.meses_entre(t.coorte, date_trunc('month', now()))) g))
        order by t.coorte), '[]'))
    from tam t);
end $$;

create or replace function public.analytics_funil(p_inicio timestamptz, p_fim timestamptz, p_cidade uuid default null, p_categoria text default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,FINANCEIRO,OPERACOES}');
begin
  return (select jsonb_build_object(
      'solicitadas', count(*),
      'com_motorista', count(*) filter (where aceita_em is not null),
      'iniciadas', count(*) filter (where iniciada_em is not null),
      'finalizadas', count(*) filter (where finalizada_em is not null),
      'pagas', count(*) filter (where status = 'PAGA'),
      'sem_motorista', count(*) filter (where status = 'SEM_MOTORISTA'),
      'canceladas', jsonb_build_object('passageiro', count(*) filter (where status = 'CANCELADA' and cancelado_por = 'PASSAGEIRO'),
                                       'motorista', count(*) filter (where status = 'CANCELADA' and cancelado_por = 'MOTORISTA'),
                                       'sistema', count(*) filter (where status = 'CANCELADA' and cancelado_por not in ('PASSAGEIRO','MOTORISTA'))),
      'tempo_ate_aceite_seg', jsonb_build_object(
          'p50', round(percentile_cont(0.5) within group (order by extract(epoch from aceita_em - solicitada_em)) filter (where aceita_em is not null)::numeric),
          'p90', round(percentile_cont(0.9) within group (order by extract(epoch from aceita_em - solicitada_em)) filter (where aceita_em is not null)::numeric)),
      'tempo_ate_chegada_min', jsonb_build_object(
          'p50', round((percentile_cont(0.5) within group (order by extract(epoch from chegou_em - aceita_em)) filter (where chegou_em is not null) / 60)::numeric, 1),
          'p90', round((percentile_cont(0.9) within group (order by extract(epoch from chegou_em - aceita_em)) filter (where chegou_em is not null) / 60)::numeric, 1)),
      'motivos_cancelamento', (select coalesce(jsonb_agg(jsonb_build_object('motivo', m, 'n', n) order by n desc), '[]') from (
          select coalesce(nullif(trim(motivo_cancelamento), ''), '(sem motivo)') m, count(*) n from corridas
          where status = 'CANCELADA' and solicitada_em >= p_inicio and solicitada_em < p_fim
            and (p_cidade is null or cidade_id = p_cidade) and (p_categoria is null or categoria = p_categoria)
          group by 1 order by 2 desc limit 10) mc))
    from corridas where solicitada_em >= p_inicio and solicitada_em < p_fim
      and (p_cidade is null or cidade_id = p_cidade) and (p_categoria is null or categoria = p_categoria));
end $$;

-- ============================================================
-- 9) NOTIFICAÇÕES INTELIGENTES (contexto real, sem spam)
-- ============================================================
insert into configuracoes (chave, valor, descricao) values
  ('notif_documento_dias', '[30,7,1]', 'avisos antes do vencimento de documentos')
on conflict (chave) do nothing;
-- intervalos dos eventos novos (mantém os existentes)
update configuracoes set valor = valor || '{"DOCUMENTO_VENCENDO":60,"AGENDADA":30}'::jsonb where chave = 'notif_intervalo_min' and not (valor ? 'DOCUMENTO_VENCENDO');

create or replace function interno.ja_notificado(p_usuario uuid, p_chave text) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from notificacoes where usuario_id = p_usuario and dados ->> 'chave' = p_chave)
$$;

create or replace function interno.job_notificacoes() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n_doc int := 0; n_bonus int := 0; n_manut int := 0; v_dias int; v_chave text; v_ofi int;
begin
  -- documentos vencendo (30, 7 e 1 dia antes): uma vez por marco
  for r in select d.id, d.tipo, d.validade, coalesce(d.motorista_id, v.motorista_id) uid
           from documentos d left join veiculos v on d.dono_tipo = 'VEICULO' and v.id = d.dono_id
           where d.status = 'APROVADO' and d.validade between current_date and current_date + 30 loop
    v_dias := r.validade - current_date;
    select min(x::int) into v_dias from jsonb_array_elements_text(interno.cfg('notif_documento_dias')) x where x::int >= v_dias;
    continue when v_dias is null;
    v_chave := 'doc:' || r.id || ':' || v_dias;
    continue when interno.ja_notificado(r.uid, v_chave);
    if interno.notificar_se_pode(r.uid, 'DOCUMENTO_VENCENDO', 'Documento vencendo',
         replace(r.tipo, '_', ' ') || ' vence em ' || to_char(r.validade, 'DD/MM/YYYY') || '. Envie o novo para não ficar offline.',
         jsonb_build_object('documento', r.id, 'chave', v_chave)) then n_doc := n_doc + 1; end if;
  end loop;
  -- bônus de indicação liberado hoje (um resumo por dia)
  for r in select beneficiario_id uid, sum(valor) v from ganhos_indicacao
           where status = 'DISPONIVEL' and liberado_em >= current_date group by 1 loop
    v_chave := 'bonus:' || current_date;
    continue when interno.ja_notificado(r.uid, v_chave);
    if interno.notificar_se_pode(r.uid, 'BONUS', 'Bônus de indicação disponível', interno.reais(r.v) || ' liberados hoje na sua carteira.',
         jsonb_build_object('chave', v_chave)) then n_bonus := n_bonus + 1; end if;
  end loop;
  -- manutenção sugerida por km rodado (no máximo 1 vez a cada 30 dias)
  for r in select m.id uid, coalesce(sum(c.distancia_real_km), 0) km, mp.lat, mp.lng
           from motoristas m left join motorista_presenca mp on mp.motorista_id = m.id
           join corridas c on c.motorista_id = m.id and c.status = 'PAGA'
             and c.finalizada_em > coalesce((select max(cl.data) from custos_lancados cl where cl.motorista_id = m.id and cl.tipo in ('MANUTENCAO','PNEUS')), m.aprovado_em, m.criado_em)
           where m.status = 'ATIVO' group by m.id, mp.lat, mp.lng
           having coalesce(sum(c.distancia_real_km), 0) >= interno.cfg_num('manutencao_km', 10000) loop
    v_chave := 'manut:' || to_char(now(), 'YYYY-MM');
    continue when interno.ja_notificado(r.uid, v_chave);
    select count(*) into v_ofi from parceiros p where p.ativo and p.tipo = 'OFICINA' and p.lat is not null and r.lat is not null
      and interno.distancia_km(r.lat, r.lng, p.lat, p.lng) <= 10;
    if interno.notificar_se_pode(r.uid, 'MANUTENCAO', 'Hora de revisar o carro?',
         'Você rodou ' || interno.num(round(r.km)) || ' km desde a última manutenção lançada.'
         || case when v_ofi > 0 then ' Há ' || v_ofi || ' oficina(s) parceira(s) perto de você.' else '' end,
         jsonb_build_object('chave', v_chave)) then n_manut := n_manut + 1; end if;
  end loop;
  return jsonb_build_object('documentos', n_doc, 'bonus', n_bonus, 'manutencao', n_manut);
end $$;

-- campanhas: só para quem consentiu (PROMOCAO exige consentimento de MARKETING) e com limite diário
create table if not exists campanhas (
  id uuid primary key default gen_random_uuid(),
  titulo text not null, mensagem text not null,
  publico text not null, cidade_id uuid, cupom text,
  enviadas int not null default 0, puladas int not null default 0,
  criado_por uuid not null, criado_em timestamptz not null default now()
);

create or replace function public.ops_enviar_campanha(p_titulo text, p_mensagem text, p_publico text, p_cidade uuid default null, p_cupom text default null)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); r record; n_env int := 0; n_pul int := 0; v_id uuid;
begin
  perform interno.limitar('campanha', 3, 86400);
  if p_publico not in ('PASSAGEIROS','MOTORISTAS','TODOS') then perform interno.erro('PUBLICO_INVALIDO'); end if;
  if coalesce(length(trim(p_titulo)), 0) < 3 or coalesce(length(trim(p_mensagem)), 0) < 5 then perform interno.erro('TEXTO_OBRIGATORIO'); end if;
  if p_cupom is not null and not exists (select 1 from cupons where codigo = upper(p_cupom) and ativo) then perform interno.erro('CUPOM_INVALIDO'); end if;
  insert into campanhas (titulo, mensagem, publico, cidade_id, cupom, criado_por) values (left(p_titulo, 60), left(p_mensagem, 240), p_publico, p_cidade, upper(p_cupom), v_uid)
  returning id into v_id;
  for r in select p.id from perfis p where p.status = 'ATIVO' and (p_cidade is null or p.cidade_id = p_cidade)
             and (p_publico = 'TODOS' or (p_publico = 'MOTORISTAS') = exists (select 1 from motoristas m where m.id = p.id)) loop
    if interno.notificar_se_pode(r.id, 'PROMOCAO', left(p_titulo, 60), left(p_mensagem, 240), jsonb_build_object('campanha', v_id, 'cupom', upper(p_cupom))) then
      n_env := n_env + 1; else n_pul := n_pul + 1; end if;
  end loop;
  update campanhas set enviadas = n_env, puladas = n_pul where id = v_id;
  return jsonb_build_object('campanha', v_id, 'enviadas', n_env, 'puladas_sem_consentimento_ou_limite', n_pul);
end $$;

-- ============================================================
-- RLS, agenda e permissões
-- ============================================================
do $$
declare t text;
begin
  foreach t in array array['locais_favoritos','corridas_agendadas','custos_operacionais','campanhas'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('locais_favoritos', 'proprio', 'usuario_id = auth.uid()');
select interno.criar_politica('corridas_agendadas', 'proprio', 'passageiro_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('custos_operacionais', 'financeiro', $p$interno.eh_papel('{FINANCEIRO,ADMIN}')$p$);
select interno.criar_politica('campanhas', 'staff', $p$interno.eh_papel('{OPERACOES,ADMIN}')$p$);

create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'agendadas', interno.rodar_job('agendadas', 'interno.job_agendadas()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca_v2()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'inteligencia' then
    return jsonb_build_object('inteligencia', interno.rodar_job('inteligencia', 'interno.job_inteligencia()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object(
      'liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'),
      'notificacoes', interno.rodar_job('notificacoes', 'interno.job_notificacoes()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco_v2()'),
      'empresas', interno.rodar_job('empresas', 'interno.job_empresas()'),
      'assinaturas', interno.rodar_job('assinaturas', 'interno.job_assinaturas()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;

select interno.aplicar_permissoes_funcoes();
