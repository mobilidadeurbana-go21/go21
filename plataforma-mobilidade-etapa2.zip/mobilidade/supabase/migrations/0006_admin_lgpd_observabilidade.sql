-- ============================================================
-- 0006 — PAPÉIS E PERMISSÕES, ADMINISTRAÇÃO DE CIDADES/TARIFAS,
--        LGPD (mascaramento, consentimento, exportação, exclusão,
--        retenção), WEBHOOKS AUTENTICADOS, OBSERVABILIDADE
-- ============================================================

-- ============================================================
-- MATRIZ DE PERMISSÕES (menor privilégio)
-- Papéis administrativos pedidos -> papéis do banco:
--   SUPER ADMIN        = SUPER_ADMIN (tudo, inclusive conceder ADMIN e mudar ambiente)
--   ADMIN FINANCEIRO   = FINANCEIRO
--   ADMIN OPERAÇÕES    = OPERACOES
--   ANALISTA DE RISCO  = RISCO
--   SUPORTE            = SUPORTE
--   (ADMIN = administrador geral, sem acesso a CPF nem a mudar ambiente)
-- A tabela abaixo é a referência; cada função confere o papel na entrada.
-- ============================================================
create table if not exists permissoes_papel (
  papel papel not null,
  acao text not null,
  descricao text,
  primary key (papel, acao)
);
insert into permissoes_papel (papel, acao, descricao) values
  ('SUPORTE','VER_CORRIDAS','Ver corridas e passageiros/motoristas envolvidos'),
  ('SUPORTE','ATENDER_INCIDENTES','Assumir, contatar, intervir e encerrar incidentes'),
  ('SUPORTE','ENCERRAR_CORRIDA_TRAVADA','Finalizar/cancelar corrida travada'),
  ('SUPORTE','VER_TELEFONE','Ver telefone completo para contato'),
  ('OPERACOES','ANALISAR_MOTORISTAS','Aprovar/reprovar documentos, veículos e status'),
  ('OPERACOES','CONFIGURAR_CIDADES','Cidades, regiões, tarifas, categorias por cidade'),
  ('OPERACOES','VER_INTELIGENCIA','Radar, previsões, alertas e sugestões de incentivo'),
  ('OPERACOES','ATENDER_INCIDENTES','Central de segurança'),
  ('OPERACOES','VER_TELEFONE','Contato com motoristas'),
  ('FINANCEIRO','COMISSOES','Regras de comissão e campanhas'),
  ('FINANCEIRO','ESTORNOS','Estornos e reembolsos'),
  ('FINANCEIRO','REPASSES','Confirmar/recusar saques'),
  ('FINANCEIRO','LEDGER','Ler ledger e saldos'),
  ('FINANCEIRO','EMPRESAS_FATURAMENTO','Faturas de empresas'),
  ('FINANCEIRO','TARIFAS','Tarifas por cidade'),
  ('RISCO','SINAIS','Analisar e decidir sinais de fraude'),
  ('RISCO','SCORE_RISCO','Ver pontuação e grafo de contas relacionadas'),
  ('RISCO','BLOQUEAR','Bloquear conta (sempre com motivo)'),
  ('RISCO','VER_CPF','Ver CPF completo (com justificativa auditada)'),
  ('RISCO','AUDITORIA','Ler auditoria'),
  ('ADMIN','TUDO_OPERACIONAL','Todas as telas operacionais, sem CPF e sem ambiente'),
  ('ADMIN','EQUIPE','Conceder SUPORTE/OPERACOES/FINANCEIRO/RISCO/EMPRESA'),
  ('ADMIN','AUDITORIA','Ler auditoria'),
  ('SUPER_ADMIN','TUDO','Tudo, inclusive conceder ADMIN, ver CPF com justificativa e mudar ambiente')
on conflict do nothing;

create or replace function public.minhas_permissoes() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'papeis', coalesce((select jsonb_agg(papel) from usuario_papeis where usuario_id = auth.uid() and ativo), '[]'),
    'acoes', coalesce((select jsonb_agg(distinct pp.acao) from permissoes_papel pp
                       join usuario_papeis up on up.papel = pp.papel and up.usuario_id = auth.uid() and up.ativo), '[]'))
$$;

-- concessão de papéis: ninguém mexe nos próprios papéis; ADMIN só concede papéis abaixo dele
create or replace function public.admin_definir_papel(p_usuario uuid, p_papel papel, p_ativo boolean, p_cidade uuid default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN}'); v_super boolean;
begin
  perform interno.sem_conflito(p_usuario);
  v_super := exists (select 1 from usuario_papeis where usuario_id = v_uid and papel = 'SUPER_ADMIN' and ativo);
  if p_papel in ('ADMIN','SUPER_ADMIN') and not v_super then perform interno.erro('SEM_PERMISSAO', 'só SUPER_ADMIN concede ' || p_papel); end if;
  if p_papel in ('PASSAGEIRO','MOTORISTA') then perform interno.erro('PAPEL_NAO_ADMINISTRATIVO'); end if;
  if not exists (select 1 from perfis where id = p_usuario) then perform interno.erro('USUARIO_NAO_ENCONTRADO'); end if;
  insert into usuario_papeis (usuario_id, papel, ativo, cidade_id, concedido_por)
  values (p_usuario, p_papel, p_ativo, p_cidade, v_uid)
  on conflict (usuario_id, papel) do update set ativo = excluded.ativo, cidade_id = excluded.cidade_id, concedido_por = v_uid;
end $$;

-- ============================================================
-- ADMINISTRAÇÃO DE CIDADES, TARIFAS, CATEGORIAS E CONFIGURAÇÕES
-- ============================================================
drop trigger if exists cidades_auditar on cidades;
create trigger cidades_auditar after insert or update or delete on cidades for each row execute function interno.trg_auditar();
drop trigger if exists cidade_categorias_auditar on cidade_categorias;
create trigger cidade_categorias_auditar after insert or update or delete on cidade_categorias for each row execute function interno.trg_auditar();
drop trigger if exists categorias_auditar on categorias;
create trigger categorias_auditar after update on categorias for each row execute function interno.trg_auditar();

create or replace function public.admin_salvar_cidade(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  if v_id is null then
    if coalesce(p ->> 'nome', '') = '' or coalesce(p ->> 'uf', '') !~ '^[A-Z]{2}$' or coalesce(p ->> 'slug', '') !~ '^[a-z0-9-]{2,60}$' then
      perform interno.erro('DADOS_INVALIDOS', 'nome, uf (2 letras) e slug (minúsculas-e-hifens) são obrigatórios');
    end if;
    insert into cidades (nome, uf, slug, ativa, centro_lat, centro_lng, raio_atendimento_km, regulamentacao)
    values (p ->> 'nome', p ->> 'uf', p ->> 'slug', coalesce((p ->> 'ativa')::boolean, false),
            (p ->> 'centro_lat')::float8, (p ->> 'centro_lng')::float8, coalesce((p ->> 'raio_atendimento_km')::numeric, 30), p ->> 'regulamentacao')
    returning id into v_id;
  else
    update cidades set
      nome = coalesce(p ->> 'nome', nome),
      ativa = coalesce((p ->> 'ativa')::boolean, ativa),
      centro_lat = coalesce((p ->> 'centro_lat')::float8, centro_lat),
      centro_lng = coalesce((p ->> 'centro_lng')::float8, centro_lng),
      raio_atendimento_km = coalesce((p ->> 'raio_atendimento_km')::numeric, raio_atendimento_km),
      regulamentacao = coalesce(p ->> 'regulamentacao', regulamentacao)
    where id = v_id;
    if not found then perform interno.erro('CIDADE_NAO_ENCONTRADA'); end if;
  end if;
  -- blocos livres: mescla (não apaga o que não foi enviado)
  update cidades set
    regras = regras || coalesce(p -> 'regras', '{}'),
    requisitos = requisitos || coalesce(p -> 'requisitos', '{}'),
    tributos = tributos || coalesce(p -> 'tributos', '{}'),
    horario_operacao = horario_operacao || coalesce(p -> 'horario_operacao', '{}')
  where id = v_id;
  return v_id;
end $$;

create or replace function public.admin_salvar_tarifa(p_cidade uuid, p_categoria text, p jsonb) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,FINANCEIRO,ADMIN}');
begin
  insert into cidade_categorias (cidade_id, categoria) values (p_cidade, p_categoria) on conflict do nothing;
  update cidade_categorias set
    habilitada = coalesce((p ->> 'habilitada')::boolean, habilitada),
    tarifa_base = coalesce((p ->> 'tarifa_base')::numeric, tarifa_base),
    preco_km = coalesce((p ->> 'preco_km')::numeric, preco_km),
    preco_minuto = coalesce((p ->> 'preco_minuto')::numeric, preco_minuto),
    tarifa_minima = coalesce((p ->> 'tarifa_minima')::numeric, tarifa_minima),
    taxa_cancelamento = coalesce((p ->> 'taxa_cancelamento')::numeric, taxa_cancelamento),
    multiplicador_maximo = coalesce((p ->> 'multiplicador_maximo')::numeric, multiplicador_maximo),
    idade_max_veiculo_anos = coalesce((p ->> 'idade_max_veiculo_anos')::int, idade_max_veiculo_anos),
    requisitos = requisitos || coalesce(p -> 'requisitos', '{}')
  where cidade_id = p_cidade and categoria = p_categoria;
end $$;

create or replace function public.admin_categoria_sistema(p_codigo text, p_disponivel boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN}');
begin
  update categorias set disponivel_no_sistema = p_disponivel where codigo = p_codigo;
  if not found then perform interno.erro('CATEGORIA_NAO_ENCONTRADA'); end if;
end $$;

create or replace function public.admin_salvar_config(p_chave text, p_valor jsonb) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN}');
begin
  -- ambiente (liga/desliga simulador) e prazos de retenção (apagam provas e auditoria): só SUPER_ADMIN
  if (p_chave = 'ambiente' or p_chave like 'retencao\_%') and not exists (select 1 from usuario_papeis where usuario_id = v_uid and papel = 'SUPER_ADMIN' and ativo) then
    perform interno.erro('SEM_PERMISSAO', 'só SUPER_ADMIN altera ' || p_chave);
  end if;
  if p_chave like 'retencao\_%' and (jsonb_typeof(p_valor) <> 'number' or (p_valor #>> '{}')::numeric < interno.retencao_minima(p_chave)) then
    perform interno.erro('VALOR_ABAIXO_DO_MINIMO_LEGAL', 'mínimo ' || interno.retencao_minima(p_chave) || ' dias');
  end if;
  if p_chave = 'ambiente' and p_valor #>> '{}' not in ('desenvolvimento','homologacao','producao') then perform interno.erro('VALOR_INVALIDO'); end if;
  insert into configuracoes (chave, valor, atualizado_por) values (p_chave, p_valor, v_uid)
  on conflict (chave) do update set valor = excluded.valor, atualizado_em = now(), atualizado_por = v_uid;
end $$;

-- ============================================================
-- LGPD: MASCARAMENTO, ACESSO AO CPF, CONSENTIMENTO,
--       EXPORTAÇÃO, EXCLUSÃO (anonimização) E RETENÇÃO
-- ============================================================
create or replace function interno.mascarar_cpf(c text) returns text language sql immutable as $$
  select case when c is null then null else '***.***.' || substr(c, 7, 3) || '-' || right(c, 2) end
$$;
create or replace function interno.mascarar_tel(t text) returns text language sql immutable as $$
  select case when t is null then null else '(' || left(t, 2) || ') *****-' || right(t, 4) end
$$;
create or replace function interno.mascarar_email(e text) returns text language sql immutable as $$
  select case when e is null then null else left(e, 2) || '***@' || split_part(e, '@', 2) end
$$;

-- CPF não pode ser lido direto por ninguém pelo app (nem pela equipe): só por função auditada
revoke select on perfis from authenticated;
grant select (id, nome, telefone, email, foto_path, status, cidade_id, codigo_indicacao, criado_em, ultimo_acesso,
              aceite_termos_em, aceite_privacidade_em, versao_termos) on perfis to authenticated;

create or replace function public.risco_ver_cpf(p_usuario uuid, p_justificativa text) returns text
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO}'); v text;
begin
  if coalesce(length(trim(p_justificativa)), 0) < 10 then perform interno.erro('JUSTIFICATIVA_OBRIGATORIA'); end if;
  perform interno.sem_conflito(p_usuario);
  perform interno.limitar('ver_cpf', 30, 3600);
  select cpf into v from perfis where id = p_usuario;
  perform interno.auditar_evento('ACESSO_CPF', 'perfis', p_usuario::text, jsonb_build_object('justificativa', p_justificativa));
  return v;
end $$;

-- busca de usuários para a equipe, com mascaramento conforme o papel
create or replace function public.admin_buscar_usuarios(p_texto text, p_limite int default 20) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,FINANCEIRO,RISCO,ADMIN}');
        v_tel boolean := interno.eh_papel('{SUPORTE,OPERACOES,ADMIN}');
        v_txt text := '%' || lower(trim(coalesce(p_texto, ''))) || '%';
begin
  if length(trim(coalesce(p_texto, ''))) < 3 then return '[]'; end if;
  return coalesce((select jsonb_agg(x) from (
    select p.id, p.nome, p.status,
           case when v_tel then p.telefone else interno.mascarar_tel(p.telefone) end as telefone,
           interno.mascarar_email(p.email) as email, interno.mascarar_cpf(p.cpf) as cpf,
           (select jsonb_agg(papel) from usuario_papeis where usuario_id = p.id and ativo) as papeis,
           (select status from motoristas where id = p.id) as status_motorista,
           p.criado_em, p.ultimo_acesso
    from perfis p
    where lower(p.nome) like v_txt or p.telefone like '%' || interno.so_digitos(p_texto) || '%' and length(interno.so_digitos(p_texto)) >= 4
       or lower(coalesce(p.email, '')) like v_txt or p.id::text = trim(p_texto)
    order by p.nome limit least(p_limite, 100)) x), '[]');
end $$;

create table if not exists consentimentos (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id) on delete cascade,
  tipo text not null check (tipo in ('TERMOS','PRIVACIDADE','MARKETING','LOCALIZACAO_SEGUNDO_PLANO','COMPARTILHAR_DADOS_PARCEIROS')),
  versao text not null,
  aceito boolean not null,
  registrado_em timestamptz not null default now(),
  ip text
);
create index if not exists consentimentos_usuario_idx on consentimentos (usuario_id, tipo, registrado_em desc);

create or replace function public.registrar_consentimento(p_tipo text, p_versao text, p_aceito boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  insert into consentimentos (usuario_id, tipo, versao, aceito, ip) values (v_uid, p_tipo, p_versao, p_aceito, interno.ip_requisicao());
end $$;

create or replace function interno.consentiu(p_usuario uuid, p_tipo text) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((select aceito from consentimentos where usuario_id = p_usuario and tipo = p_tipo order by registrado_em desc limit 1), false)
$$;

-- portabilidade / acesso: o titular baixa os próprios dados
create or replace function public.meus_dados_exportar() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_res jsonb;
begin
  perform interno.limitar('exportar_dados', 3, 86400);
  select jsonb_build_object(
    'gerado_em', now(),
    'perfil', (select to_jsonb(p) from perfis p where id = v_uid),
    'papeis', (select jsonb_agg(papel) from usuario_papeis where usuario_id = v_uid),
    'consentimentos', (select coalesce(jsonb_agg(to_jsonb(c) - 'usuario_id' order by registrado_em), '[]') from consentimentos c where usuario_id = v_uid),
    'dispositivos', (select coalesce(jsonb_agg(to_jsonb(d) - 'usuario_id'), '[]') from dispositivos d where usuario_id = v_uid),
    'contatos_confianca', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'telefone', telefone)), '[]') from contatos_confianca where usuario_id = v_uid),
    'corridas_como_passageiro', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'data', solicitada_em, 'status', status,
        'origem', origem_endereco, 'destino', destino_endereco, 'valor', preco_final, 'categoria', categoria) order by solicitada_em), '[]')
        from corridas where passageiro_id = v_uid),
    'corridas_como_motorista', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'data', solicitada_em, 'status', status,
        'valor', preco_final, 'km', distancia_real_km) order by solicitada_em), '[]') from corridas where motorista_id = v_uid),
    'pagamentos', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'tipo', tipo, 'metodo', metodo, 'valor', valor, 'status', status, 'data', criado_em)), '[]')
                   from pagamentos where pagador_id = v_uid),
    'motorista', (select to_jsonb(m) from motoristas m where id = v_uid),
    'veiculos', (select coalesce(jsonb_agg(to_jsonb(vc)), '[]') from veiculos vc where vc.motorista_id = v_uid),
    'documentos', (select coalesce(jsonb_agg(jsonb_build_object('tipo', tipo, 'status', status, 'validade', validade, 'enviado_em', criado_em)), '[]')
                   from documentos where motorista_id = v_uid),
    'carteira', public.minha_carteira(500)
  ) into v_res;
  perform interno.auditar_evento('LGPD_EXPORTACAO', 'perfis', v_uid::text, null);
  return v_res;
end $$;

create table if not exists lgpd_solicitacoes (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null,
  tipo text not null check (tipo in ('EXCLUSAO','CORRECAO','REVOGACAO')),
  motivo text,
  status text not null default 'PENDENTE' check (status in ('PENDENTE','EXECUTADA','RECUSADA','CANCELADA')),
  executar_em timestamptz,
  decidido_por uuid,
  resultado text,
  criado_em timestamptz not null default now()
);
drop trigger if exists lgpd_auditar on lgpd_solicitacoes;
create trigger lgpd_auditar after insert or update on lgpd_solicitacoes for each row execute function interno.trg_auditar();

-- pedido de exclusão: carência de 7 dias para desistir; pendências financeiras impedem
create or replace function public.solicitar_exclusao_conta(p_motivo text default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid;
begin
  if exists (select 1 from corridas where (passageiro_id = v_uid or motorista_id = v_uid)
             and status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO')) then
    perform interno.erro('CORRIDA_EM_ANDAMENTO');
  end if;
  if exists (select 1 from pagamentos where pagador_id = v_uid and status = 'PENDENTE') then perform interno.erro('PAGAMENTO_EM_ABERTO'); end if;
  if interno.saldo(v_uid, 'MOTORISTA_DISPONIVEL') > 0 or interno.saldo(v_uid, 'INDICACAO_DISPONIVEL') > 0 then
    perform interno.erro('SAQUE_SEU_SALDO_ANTES');
  end if;
  insert into lgpd_solicitacoes (usuario_id, tipo, motivo, executar_em) values (v_uid, 'EXCLUSAO', p_motivo, now() + interval '7 days')
  returning id into v_id;
  perform interno.notificar(v_uid, 'SEGURANCA', 'Pedido de exclusão recebido',
    'Sua conta será anonimizada em 7 dias. Você pode cancelar até lá.', jsonb_build_object('solicitacao', v_id));
  return jsonb_build_object('id', v_id, 'executar_em', now() + interval '7 days');
end $$;

create or replace function public.cancelar_exclusao_conta() returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  update lgpd_solicitacoes set status = 'CANCELADA' where usuario_id = v_uid and tipo = 'EXCLUSAO' and status = 'PENDENTE';
end $$;

-- anonimização: apaga o que identifica a pessoa; mantém registros financeiros/fiscais
-- (obrigação legal) sem dados pessoais. O usuário do Auth é removido pela Edge Function.
create or replace function interno.anonimizar_usuario(p_usuario uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  update perfis set nome = 'Usuário removido', telefone = null, email = null, cpf = null, foto_path = null,
    status = 'INATIVO', codigo_indicacao = null where id = p_usuario;
  delete from contatos_confianca where usuario_id = p_usuario;
  delete from dispositivos where usuario_id = p_usuario;
  delete from consentimentos where usuario_id = p_usuario and tipo in ('MARKETING','COMPARTILHAR_DADOS_PARCEIROS');
  update corridas set origem_endereco = null, destino_endereco = null,
    origem_lat = round(origem_lat::numeric, 2), origem_lng = round(origem_lng::numeric, 2),
    destino_lat = round(destino_lat::numeric, 2), destino_lng = round(destino_lng::numeric, 2)
  where passageiro_id = p_usuario;
  update motoristas set cnh_numero = null, data_nascimento = null, status = 'INATIVO' where id = p_usuario;
  update motorista_presenca set online = false, disponivel = false, lat = null, lng = null where motorista_id = p_usuario;
  update usuario_papeis set ativo = false where usuario_id = p_usuario;
  perform interno.auditar_evento('LGPD_ANONIMIZACAO', 'perfis', p_usuario::text, null);
end $$;

-- ============================================================
-- RETENÇÃO: apaga o que já cumpriu a finalidade.
-- Registros imutáveis (auditoria, eventos) só podem ser apagados
-- por esta rotina, e só depois do prazo legal.
-- ============================================================
create or replace function interno.trg_imutavel() returns trigger
language plpgsql as $$
begin
  if tg_op = 'DELETE' and current_setting('app.retencao', true) = 'on' then
    return old;   -- expurgo por prazo de retenção (somente dentro de interno.job_retencao)
  end if;
  raise exception using errcode = 'P0001', message = 'REGISTRO_IMUTAVEL',
    detail = tg_table_name || ' não pode ser alterado nem apagado. Use um lançamento de correção.';
end $$;

insert into configuracoes (chave, valor, descricao) values
  ('retencao_trilha_dias', '180', 'trilha GPS das corridas (disputas e segurança)'),
  ('retencao_notificacoes_dias', '365', 'notificações'),
  ('retencao_eventos_dias', '1825', 'eventos de corrida (5 anos)'),
  ('retencao_auditoria_dias', '1825', 'auditoria (5 anos)'),
  ('retencao_webhooks_dias', '730', 'payload de webhooks (2 anos)')
on conflict (chave) do nothing;

-- pisos de retenção: nem configuração errada nem um admin apagam antes do prazo mínimo
-- (auditoria 5 anos; trilha GPS 180 dias, que é prova em caso de incidente; webhooks 2 anos; notificações 90 dias)
create or replace function interno.retencao_minima(p_chave text) returns int language sql immutable as $$
  select case p_chave when 'retencao_auditoria_dias' then 1825 when 'retencao_trilha_dias' then 180
                      when 'retencao_webhooks_dias' then 730 when 'retencao_notificacoes_dias' then 90 else 30 end
$$;
create or replace function interno.dias_retencao(p_chave text, p_padrao int) returns int language sql stable as $$
  select greatest(interno.cfg_num(p_chave, p_padrao)::int, interno.retencao_minima(p_chave))
$$;

create or replace function interno.job_retencao() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r jsonb := '{}'; n int; s record;
begin
  delete from corrida_trilha where registrado_em < now() - make_interval(days => interno.dias_retencao('retencao_trilha_dias', 180));
  get diagnostics n = row_count; r := r || jsonb_build_object('trilha', n);
  delete from notificacoes where criado_em < now() - make_interval(days => interno.dias_retencao('retencao_notificacoes_dias', 365));
  get diagnostics n = row_count; r := r || jsonb_build_object('notificacoes', n);
  update webhooks_recebidos set payload = null where recebido_em < now() - make_interval(days => interno.dias_retencao('retencao_webhooks_dias', 730)) and payload is not null;
  get diagnostics n = row_count; r := r || jsonb_build_object('webhooks', n);
  perform set_config('app.retencao', 'on', true);
  delete from auditoria where ocorrido_em < now() - make_interval(days => interno.dias_retencao('retencao_auditoria_dias', 1825));
  get diagnostics n = row_count; r := r || jsonb_build_object('auditoria', n);
  perform set_config('app.retencao', 'off', true);
  -- exclusões LGPD vencidas
  for s in select * from lgpd_solicitacoes where tipo = 'EXCLUSAO' and status = 'PENDENTE' and executar_em <= now() loop
    perform interno.anonimizar_usuario(s.usuario_id);
    update lgpd_solicitacoes set status = 'EXECUTADA', resultado = 'Anonimizado' where id = s.id;
  end loop;
  return r;
end $$;

-- ============================================================
-- WEBHOOKS: toda tentativa fica registrada (inclusive assinatura inválida)
-- A assinatura HMAC é conferida na Edge Function (o segredo nunca vem ao banco).
-- ============================================================
create table if not exists webhook_tentativas (
  id bigint generated always as identity primary key,
  gateway text not null,
  evento_id text,
  tipo text,
  assinatura_valida boolean not null,
  ip text,
  status_resposta int,
  erro text,
  duracao_ms int,
  recebido_em timestamptz not null default now()
);
create index if not exists webhook_tentativas_idx on webhook_tentativas (recebido_em desc);

create or replace function public.registrar_tentativa_webhook(p_gateway text, p_evento_id text, p_tipo text, p_assinatura_valida boolean,
  p_ip text, p_status int, p_erro text, p_duracao_ms int) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  insert into webhook_tentativas (gateway, evento_id, tipo, assinatura_valida, ip, status_resposta, erro, duracao_ms)
  values (p_gateway, p_evento_id, p_tipo, p_assinatura_valida, p_ip, p_status, left(p_erro, 1000), p_duracao_ms);
  if not p_assinatura_valida then
    perform interno.registrar_sinal('PAGAMENTO', coalesce(p_ip, 'sem-ip'), 'WEBHOOK_ASSINATURA_INVALIDA', 3,
      jsonb_build_object('gateway', p_gateway, 'evento', p_evento_id));
  end if;
end $$;

-- ============================================================
-- OBSERVABILIDADE: execução de jobs, métricas e saúde do sistema
-- ============================================================
create table if not exists jobs_execucoes (
  id bigint generated always as identity primary key,
  job text not null,
  inicio timestamptz not null,
  fim timestamptz,
  duracao_ms int,
  ok boolean,
  resultado jsonb,
  erro text
);
create index if not exists jobs_execucoes_idx on jobs_execucoes (job, inicio desc);

create table if not exists metricas (
  id bigint generated always as identity primary key,
  nome text not null,                 -- ex.: api_latencia_ms, webhook_latencia_ms, push_falhas
  valor numeric not null,
  tags jsonb not null default '{}',
  registrado_em timestamptz not null default now()
);
create index if not exists metricas_idx on metricas (nome, registrado_em desc);

create or replace function public.registrar_metrica(p_nome text, p_valor numeric, p_tags jsonb default '{}') returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  insert into metricas (nome, valor, tags) values (p_nome, p_valor, coalesce(p_tags, '{}'));
end $$;

-- roda um job registrando duração, resultado e erro (um job com erro não derruba os outros)
create or replace function interno.rodar_job(p_nome text, p_sql text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_ini timestamptz := clock_timestamp(); v_res jsonb; v_id bigint;
begin
  insert into jobs_execucoes (job, inicio) values (p_nome, v_ini) returning id into v_id;
  begin
    execute 'select to_jsonb((' || p_sql || '))' into v_res;
    update jobs_execucoes set fim = clock_timestamp(), duracao_ms = (extract(epoch from clock_timestamp() - v_ini) * 1000)::int,
      ok = true, resultado = v_res where id = v_id;
  exception when others then
    update jobs_execucoes set fim = clock_timestamp(), duracao_ms = (extract(epoch from clock_timestamp() - v_ini) * 1000)::int,
      ok = false, erro = sqlerrm where id = v_id;
    v_res := jsonb_build_object('erro', sqlerrm);
  end;
  return v_res;
end $$;

create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object('liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;
revoke execute on function public.executar_jobs(text) from public, anon, authenticated;

-- painel de saúde (equipe) — cada item: ok / atenção / crítico
-- cálculo (usado pela tela e pelo vigia automático) + porta de entrada com checagem de papel
create or replace function interno.saude_sistema_dados() returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v jsonb := '[]'; x numeric;
begin
  -- jobs
  select extract(epoch from now() - max(inicio)) into x from jobs_execucoes where job = 'matching';
  v := v || jsonb_build_object('item', 'Job de matching', 'valor', coalesce(round(x) || ' s atrás', 'nunca rodou'),
           'nivel', case when x is null or x > 120 then 'CRITICO' when x > 30 then 'ATENCAO' else 'OK' end);
  select count(*) into x from jobs_execucoes where ok = false and inicio > now() - interval '1 hour';
  v := v || jsonb_build_object('item', 'Jobs com erro (1h)', 'valor', x, 'nivel', case when x > 0 then 'ATENCAO' else 'OK' end);
  -- dinheiro
  select coalesce(sum(valor), 0) into x from lancamentos_ledger;
  v := v || jsonb_build_object('item', 'Soma do ledger', 'valor', x, 'nivel', case when x <> 0 then 'CRITICO' else 'OK' end);
  select count(*) into x from pagamentos where status = 'PENDENTE' and metodo in ('PIX','CARTAO') and criado_em < now() - interval '1 hour';
  v := v || jsonb_build_object('item', 'Pagamentos pendentes há +1h', 'valor', x, 'nivel', case when x > 20 then 'ATENCAO' else 'OK' end);
  select count(*) into x from webhook_tentativas where not assinatura_valida and recebido_em > now() - interval '1 hour';
  v := v || jsonb_build_object('item', 'Webhooks com assinatura inválida (1h)', 'valor', x, 'nivel', case when x > 0 then 'CRITICO' else 'OK' end);
  select count(*) into x from repasses where status in ('SOLICITADO','PROCESSANDO') and solicitado_em < now() - interval '24 hours';
  v := v || jsonb_build_object('item', 'Saques parados há +24h', 'valor', x, 'nivel', case when x > 0 then 'ATENCAO' else 'OK' end);
  -- operação
  select count(*) into x from notificacoes where status in ('PENDENTE','FALHOU') and canal <> 'IN_APP' and criado_em < now() - interval '5 minutes';
  v := v || jsonb_build_object('item', 'Notificações atrasadas', 'valor', x, 'nivel', case when x > 100 then 'CRITICO' when x > 0 then 'ATENCAO' else 'OK' end);
  select count(*) into x from incidentes where gravidade = 'CRITICA' and status in ('ABERTO','EM_ATENDIMENTO');
  v := v || jsonb_build_object('item', 'Incidentes críticos abertos', 'valor', x, 'nivel', case when x > 0 then 'CRITICO' else 'OK' end);
  select count(*) into x from sinais_fraude where severidade >= 4 and status in ('ABERTO','EM_ANALISE');
  v := v || jsonb_build_object('item', 'Sinais de fraude graves abertos', 'valor', x, 'nivel', case when x > 10 then 'ATENCAO' else 'OK' end);
  select count(*) into x from corridas where status = 'SEM_MOTORISTA' and solicitada_em > now() - interval '1 hour';
  v := v || jsonb_build_object('item', 'Corridas sem motorista (1h)', 'valor', x, 'nivel', case when x > 10 then 'ATENCAO' else 'OK' end);
  select percentile_cont(0.95) within group (order by valor) into x from metricas where nome = 'api_latencia_ms' and registrado_em > now() - interval '15 minutes';
  v := v || jsonb_build_object('item', 'Latência API p95 (15 min)', 'valor', coalesce(round(x) || ' ms', 'sem dados'),
           'nivel', case when x > 1500 then 'CRITICO' when x > 600 then 'ATENCAO' else 'OK' end);
  return jsonb_build_object('verificado_em', now(), 'itens', v);
end $$;
create or replace function public.saude_sistema() returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,OPERACOES,FINANCEIRO,RISCO,SUPORTE}');
begin
  return interno.saude_sistema_dados();
end $$;

-- RLS das tabelas novas
do $$
declare t text;
begin
  foreach t in array array['permissoes_papel','consentimentos','lgpd_solicitacoes','webhook_tentativas','jobs_execucoes','metricas'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('permissoes_papel', 'todos', 'true');
select interno.criar_politica('consentimentos', 'proprio', 'usuario_id = auth.uid()');
select interno.criar_politica('lgpd_solicitacoes', 'proprio', 'usuario_id = auth.uid() or interno.eh_papel(''{ADMIN}'')');
select interno.criar_politica('webhook_tentativas', 'financeiro', $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('jobs_execucoes', 'staff', 'interno.eh_staff()');
select interno.criar_politica('metricas', 'staff', 'interno.eh_staff()');

-- ============================================================
-- PERMISSÃO DE EXECUÇÃO DAS FUNÇÕES (reaplicada ao fim de cada migration)
-- Regra: interno.* fechado; public.* só para quem está logado;
-- funções de servidor (lista abaixo) só para service_role.
-- ============================================================
create table if not exists funcoes_servidor (assinatura text primary key);
alter table funcoes_servidor enable row level security;
revoke all on funcoes_servidor from anon, authenticated;
insert into funcoes_servidor values
  ('public.processar_webhook(text, text, text, jsonb)'),
  ('public.notificacoes_para_enviar(text, integer)'),
  ('public.notificacao_resultado(uuid, boolean, text)'),
  ('public.executar_jobs(text)'),
  ('public.registrar_tentativa_webhook(text, text, text, boolean, text, integer, text, integer)'),
  ('public.registrar_metrica(text, numeric, jsonb)')
on conflict do nothing;
create table if not exists funcoes_publicas_anon (assinatura text primary key);
alter table funcoes_publicas_anon enable row level security;
revoke all on funcoes_publicas_anon from anon, authenticated;
insert into funcoes_publicas_anon values
  ('public.ver_corrida_compartilhada(text)'),
  ('public.estimar_corrida(uuid, double precision, double precision, double precision, double precision, numeric, numeric)')
on conflict do nothing;

create or replace function interno.aplicar_permissoes_funcoes() returns void
language plpgsql as $$
declare r record;
begin
  execute 'revoke execute on all functions in schema interno from public, anon, authenticated';
  execute 'grant execute on function interno.eh_staff(uuid), interno.eh_papel(papel[]) to authenticated';
  execute 'revoke execute on all functions in schema public from public, anon';
  execute 'grant execute on all functions in schema public to authenticated';
  for r in select assinatura from funcoes_publicas_anon loop
    execute 'grant execute on function ' || r.assinatura || ' to anon';
  end loop;
  for r in select assinatura from funcoes_servidor loop
    execute 'revoke execute on function ' || r.assinatura || ' from public, anon, authenticated';
    execute 'grant execute on function ' || r.assinatura || ' to service_role';
  end loop;
  execute 'grant execute on function public.fin_concluir_repasse(uuid, boolean, text, text) to service_role';
end $$;
select interno.aplicar_permissoes_funcoes();
