-- ============================================================
-- 0010 — ECOSSISTEMA: MOBI EMPRESAS, MOBI WALLET (cupons, recarga,
--        reembolso em créditos), MOBI+ (assinatura), DRIVER+,
--        PARCEIROS (marketplace por proximidade)
-- Toda movimentação de dinheiro passa pelo ledger.
-- ============================================================

-- ---------- novos tipos de conta, pagamento e método ----------

alter table contas_ledger drop constraint if exists contas_ledger_tipo_check;
alter table contas_ledger add constraint contas_ledger_tipo_check check (tipo in (
  'MOTORISTA_PENDENTE','MOTORISTA_DISPONIVEL','INDICACAO_PENDENTE','INDICACAO_DISPONIVEL','PASSAGEIRO_CARTEIRA',
  'PLATAFORMA_RECEITA','PLATAFORMA_PROMOCOES','INDICACAO_RETIDA','GATEWAY_RECEBIVEIS','REPASSES_EM_PROCESSAMENTO','REPASSES_PAGOS',
  'EMPRESA_A_RECEBER','PLATAFORMA_ASSINATURAS'));

alter table pagamentos drop constraint if exists pagamentos_tipo_check;
alter table pagamentos add constraint pagamentos_tipo_check check (tipo in ('CORRIDA','GORJETA','TAXA_CANCELAMENTO','RECARGA','ASSINATURA','FATURA_EMPRESA'));

-- ============================================================
-- MOBI EMPRESAS
-- ============================================================
create table if not exists empresas (
  id uuid primary key default gen_random_uuid(),
  razao_social text not null,
  nome_fantasia text,
  cnpj text not null unique check (cnpj ~ '^\d{14}$'),
  cidade_id uuid references cidades(id),
  email_financeiro text,
  status text not null default 'PENDENTE' check (status in ('PENDENTE','ATIVA','SUSPENSA','ENCERRADA')),
  limite_credito_mensal numeric(12,2) not null default 0,
  dia_fechamento int not null default 1 check (dia_fechamento between 1 and 28),
  prazo_pagamento_dias int not null default 10 check (prazo_pagamento_dias between 0 and 60),
  criado_por uuid,
  aprovado_por uuid, aprovado_em timestamptz,
  criado_em timestamptz not null default now()
);
drop trigger if exists empresas_auditar on empresas;
create trigger empresas_auditar after insert or update on empresas for each row execute function interno.trg_auditar();

create table if not exists empresa_departamentos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  unique (empresa_id, nome)
);
create table if not exists empresa_centros_custo (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  codigo text not null, nome text not null,
  unique (empresa_id, codigo)
);
create table if not exists empresa_membros (
  empresa_id uuid not null references empresas(id) on delete cascade,
  usuario_id uuid not null references perfis(id) on delete cascade,
  papel text not null default 'FUNCIONARIO' check (papel in ('GESTOR','FINANCEIRO','FUNCIONARIO')),
  departamento_id uuid references empresa_departamentos(id),
  centro_custo_id uuid references empresa_centros_custo(id),
  limite_mensal numeric(10,2),                     -- sobrepõe a política
  ativo boolean not null default true,
  adicionado_por uuid,
  criado_em timestamptz not null default now(),
  primary key (empresa_id, usuario_id)
);
drop trigger if exists empresa_membros_auditar on empresa_membros;
create trigger empresa_membros_auditar after insert or update or delete on empresa_membros for each row execute function interno.trg_auditar();

create table if not exists empresa_convites (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  contato text not null,                           -- telefone (dígitos) ou e-mail
  papel text not null default 'FUNCIONARIO',
  departamento_id uuid, centro_custo_id uuid,
  limite_mensal numeric(10,2),
  status text not null default 'PENDENTE' check (status in ('PENDENTE','ACEITO','RECUSADO','CANCELADO')),
  criado_por uuid, criado_em timestamptz not null default now()
);

create table if not exists empresa_politicas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  departamento_id uuid references empresa_departamentos(id),   -- null = todos
  categorias_permitidas text[] not null default '{ECONOMICO}',
  limite_por_corrida numeric(10,2),
  limite_mensal_por_pessoa numeric(10,2),
  dias_semana int[],                                           -- 1=seg..7=dom; null = todos
  hora_inicio time, hora_fim time,
  exige_justificativa boolean not null default false,
  exige_centro_custo boolean not null default false,
  ativa boolean not null default true,
  criado_em timestamptz not null default now()
);
drop trigger if exists empresa_politicas_auditar on empresa_politicas;
create trigger empresa_politicas_auditar after insert or update or delete on empresa_politicas for each row execute function interno.trg_auditar();

create table if not exists empresa_faturas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id),
  periodo_inicio timestamptz not null, periodo_fim timestamptz not null,
  valor numeric(12,2) not null,
  corridas int not null,
  status text not null default 'FECHADA' check (status in ('FECHADA','PAGA','VENCIDA','CANCELADA')),
  vencimento date not null,
  paga_em timestamptz,
  criado_em timestamptz not null default now()
);
drop trigger if exists empresa_faturas_auditar on empresa_faturas;
create trigger empresa_faturas_auditar after insert or update on empresa_faturas for each row execute function interno.trg_auditar();

alter table corridas add column if not exists empresa_id uuid references empresas(id);
alter table corridas add column if not exists centro_custo_id uuid references empresa_centros_custo(id);
alter table corridas add column if not exists departamento_id uuid references empresa_departamentos(id);
alter table corridas add column if not exists justificativa_corporativa text;
alter table corridas add column if not exists fatura_id uuid references empresa_faturas(id);
create index if not exists corridas_empresa_idx on corridas (empresa_id, solicitada_em desc) where empresa_id is not null;

alter table pagamentos add column if not exists fatura_id uuid references empresa_faturas(id);

-- método EMPRESA só pode nascer pela função corporativa (que valida a política)
create or replace function interno.trg_corrida_empresa() returns trigger language plpgsql as $$
begin
  if new.metodo_pagamento::text = 'EMPRESA' and coalesce(current_setting('app.corporativa', true), '') <> 'on' then
    raise exception using errcode = 'P0001', message = 'USE_A_SOLICITACAO_CORPORATIVA';
  end if;
  return new;
end $$;
drop trigger if exists corridas_empresa on corridas;
create trigger corridas_empresa before insert on corridas for each row execute function interno.trg_corrida_empresa();

create or replace function interno.cnpj_valido(p text) returns boolean language plpgsql immutable as $$
declare c text := interno.so_digitos(p); pesos1 int[] := '{5,4,3,2,9,8,7,6,5,4,3,2}'; pesos2 int[] := '{6,5,4,3,2,9,8,7,6,5,4,3,2}'; s int; d1 int; d2 int; i int;
begin
  if length(c) <> 14 or c ~ '^(\d)\1{13}$' then return false; end if;
  s := 0; for i in 1..12 loop s := s + substr(c, i, 1)::int * pesos1[i]; end loop;
  d1 := case when s % 11 < 2 then 0 else 11 - s % 11 end;
  s := 0; for i in 1..13 loop s := s + substr(c, i, 1)::int * pesos2[i]; end loop;
  d2 := case when s % 11 < 2 then 0 else 11 - s % 11 end;
  return d1 = substr(c, 13, 1)::int and d2 = substr(c, 14, 1)::int;
end $$;

create or replace function interno.papel_empresa(p_empresa uuid, p_usuario uuid default null) returns text
language sql stable security definer set search_path = public, pg_temp as $$
  select m.papel from empresa_membros m join empresas e on e.id = m.empresa_id
  where m.empresa_id = p_empresa and m.usuario_id = coalesce(p_usuario, auth.uid()) and m.ativo
$$;

create or replace function interno.exigir_papel_empresa(p_empresa uuid, p_papeis text[]) returns uuid
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  if not (coalesce(interno.papel_empresa(p_empresa, v_uid), '-') = any(p_papeis)) then perform interno.erro('SEM_PERMISSAO_NA_EMPRESA'); end if;
  return v_uid;
end $$;

-- cadastro self-service: a empresa nasce PENDENTE até o financeiro aprovar o crédito
create or replace function public.empresa_cadastrar(p_razao text, p_fantasia text, p_cnpj text, p_cidade uuid, p_email_financeiro text)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid; v_cnpj text := interno.so_digitos(p_cnpj);
begin
  perform interno.limitar('empresa_cadastro', 3, 86400);
  if not interno.cnpj_valido(v_cnpj) then perform interno.erro('CNPJ_INVALIDO'); end if;
  if exists (select 1 from empresas where cnpj = v_cnpj) then perform interno.erro('CNPJ_JA_CADASTRADO'); end if;
  insert into empresas (razao_social, nome_fantasia, cnpj, cidade_id, email_financeiro, criado_por)
  values (trim(p_razao), nullif(trim(p_fantasia), ''), v_cnpj, p_cidade, lower(trim(p_email_financeiro)), v_uid) returning id into v_id;
  insert into empresa_membros (empresa_id, usuario_id, papel, adicionado_por) values (v_id, v_uid, 'GESTOR', v_uid);
  insert into empresa_politicas (empresa_id, nome) values (v_id, 'Padrão');
  return v_id;
end $$;

create or replace function public.fin_aprovar_empresa(p_empresa uuid, p_aprovar boolean, p_limite numeric, p_dia_fechamento int default 1, p_prazo int default 10)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,ADMIN}');
begin
  if interno.papel_empresa(p_empresa, v_uid) is not null then perform interno.erro('CONFLITO_DE_INTERESSE'); end if;
  update empresas set status = case when p_aprovar then 'ATIVA' else 'SUSPENSA' end, limite_credito_mensal = coalesce(p_limite, 0),
    dia_fechamento = p_dia_fechamento, prazo_pagamento_dias = p_prazo, aprovado_por = v_uid, aprovado_em = now() where id = p_empresa;
  if not found then perform interno.erro('EMPRESA_NAO_ENCONTRADA'); end if;
end $$;

create or replace function public.empresa_salvar_estrutura(p_empresa uuid, p_tipo text, p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel_empresa(p_empresa, '{GESTOR}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  -- um id informado precisa já pertencer a esta empresa (nunca sobrescreve registro de outra)
  if v_id is not null and not exists (select 1 from empresa_departamentos where id = v_id and empresa_id = p_empresa
                 union all select 1 from empresa_centros_custo where id = v_id and empresa_id = p_empresa
                 union all select 1 from empresa_politicas where id = v_id and empresa_id = p_empresa) then
    perform interno.erro('REGISTRO_NAO_ENCONTRADO');
  end if;
  if nullif(p ->> 'departamento_id', '') is not null
     and not exists (select 1 from empresa_departamentos where id = (p ->> 'departamento_id')::uuid and empresa_id = p_empresa) then
    perform interno.erro('DEPARTAMENTO_INVALIDO');
  end if;
  if coalesce(trim(p ->> 'nome'), '') = '' then perform interno.erro('NOME_OBRIGATORIO'); end if;
  if p_tipo = 'DEPARTAMENTO' then
    insert into empresa_departamentos (id, empresa_id, nome) values (coalesce(v_id, gen_random_uuid()), p_empresa, p ->> 'nome')
    on conflict (id) do update set nome = excluded.nome returning id into v_id;
  elsif p_tipo = 'CENTRO_CUSTO' then
    insert into empresa_centros_custo (id, empresa_id, codigo, nome) values (coalesce(v_id, gen_random_uuid()), p_empresa, p ->> 'codigo', p ->> 'nome')
    on conflict (id) do update set codigo = excluded.codigo, nome = excluded.nome returning id into v_id;
  elsif p_tipo = 'POLITICA' then
    insert into empresa_politicas (id, empresa_id, nome, departamento_id, categorias_permitidas, limite_por_corrida, limite_mensal_por_pessoa,
      dias_semana, hora_inicio, hora_fim, exige_justificativa, exige_centro_custo, ativa)
    values (coalesce(v_id, gen_random_uuid()), p_empresa, p ->> 'nome', nullif(p ->> 'departamento_id', '')::uuid,
      coalesce(array(select jsonb_array_elements_text(p -> 'categorias_permitidas')), '{ECONOMICO}'),
      nullif(p ->> 'limite_por_corrida', '')::numeric, nullif(p ->> 'limite_mensal_por_pessoa', '')::numeric,
      case when jsonb_typeof(p -> 'dias_semana') = 'array' then array(select jsonb_array_elements_text(p -> 'dias_semana')::int) end,
      nullif(p ->> 'hora_inicio', '')::time, nullif(p ->> 'hora_fim', '')::time,
      coalesce((p ->> 'exige_justificativa')::boolean, false), coalesce((p ->> 'exige_centro_custo')::boolean, false), coalesce((p ->> 'ativa')::boolean, true))
    on conflict (id) do update set nome = excluded.nome, departamento_id = excluded.departamento_id, categorias_permitidas = excluded.categorias_permitidas,
      limite_por_corrida = excluded.limite_por_corrida, limite_mensal_por_pessoa = excluded.limite_mensal_por_pessoa, dias_semana = excluded.dias_semana,
      hora_inicio = excluded.hora_inicio, hora_fim = excluded.hora_fim, exige_justificativa = excluded.exige_justificativa,
      exige_centro_custo = excluded.exige_centro_custo, ativa = excluded.ativa
    returning id into v_id;
  else
    perform interno.erro('TIPO_INVALIDO');
  end if;
  if not exists (select 1 from empresa_departamentos where id = v_id and empresa_id = p_empresa
                 union all select 1 from empresa_centros_custo where id = v_id and empresa_id = p_empresa
                 union all select 1 from empresa_politicas where id = v_id and empresa_id = p_empresa) then
    perform interno.erro('SEM_PERMISSAO_NA_EMPRESA');
  end if;
  return v_id;
end $$;

-- adiciona funcionário: SEMPRE vira convite (a pessoa aceita no app). Nunca vincula direto,
-- para não revelar quem tem conta nem incluir alguém sem consentimento. Só empresa ATIVA convida.
create or replace function public.empresa_adicionar_membro(p_empresa uuid, p_contato text, p_papel text default 'FUNCIONARIO',
  p_departamento uuid default null, p_centro_custo uuid default null, p_limite_mensal numeric default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel_empresa(p_empresa, '{GESTOR}'); v_contato text; v_id uuid;
begin
  perform interno.limitar('empresa_membro', 200, 3600);
  if (select status from empresas where id = p_empresa) <> 'ATIVA' then perform interno.erro('EMPRESA_AINDA_NAO_ATIVA'); end if;
  if p_papel not in ('GESTOR','FINANCEIRO','FUNCIONARIO') then perform interno.erro('PAPEL_INVALIDO'); end if;
  if p_departamento is not null and not exists (select 1 from empresa_departamentos where id = p_departamento and empresa_id = p_empresa) then
    perform interno.erro('DEPARTAMENTO_INVALIDO');
  end if;
  if p_centro_custo is not null and not exists (select 1 from empresa_centros_custo where id = p_centro_custo and empresa_id = p_empresa) then
    perform interno.erro('CENTRO_DE_CUSTO_INVALIDO');
  end if;
  v_contato := interno.contato_normalizado(p_contato);
  if v_contato is null then perform interno.erro('CONTATO_INVALIDO'); end if;
  update empresa_convites set status = 'CANCELADO' where empresa_id = p_empresa and contato = v_contato and status = 'PENDENTE';
  insert into empresa_convites (empresa_id, contato, papel, departamento_id, centro_custo_id, limite_mensal, criado_por)
  values (p_empresa, v_contato, p_papel, p_departamento, p_centro_custo, p_limite_mensal, v_uid) returning id into v_id;
  return jsonb_build_object('convite', v_id, 'aviso', 'A pessoa recebe o convite ao entrar no app com esse contato verificado e precisa aceitar.');
end $$;

create or replace function public.empresa_remover_membro(p_empresa uuid, p_usuario uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel_empresa(p_empresa, '{GESTOR}');
begin
  if p_usuario = v_uid and (select count(*) from empresa_membros where empresa_id = p_empresa and papel = 'GESTOR' and ativo) <= 1 then
    perform interno.erro('ULTIMO_GESTOR');
  end if;
  update empresa_membros set ativo = false where empresa_id = p_empresa and usuario_id = p_usuario;
end $$;

-- contato em formato único: e-mail minúsculo ou celular com DDD (11 dígitos, sem +55)
create or replace function interno.contato_normalizado(p text) returns text language sql immutable as $$
  select case when p like '%@%' then lower(trim(p))
              when length(regexp_replace(coalesce(p, ''), '\D', '', 'g')) >= 10 then right(regexp_replace(p, '\D', '', 'g'), 11) end
$$;
-- contatos que o Auth CONFIRMOU para este login (o que o usuário digita no perfil não vale para convite)
create or replace function interno.contatos_verificados(p_usuario uuid) returns text[]
language sql stable security definer set search_path = public, auth, pg_temp as $$
  select array_remove(array[
    case when u.email_confirmed_at is not null then interno.contato_normalizado(u.email) end,
    case when u.phone_confirmed_at is not null then interno.contato_normalizado(u.phone) end], null)
  from auth.users u where u.id = p_usuario
$$;

create or replace function public.meus_convites_empresa() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'empresa', coalesce(e.nome_fantasia, e.razao_social), 'papel', c.papel, 'enviado_em', c.criado_em)), '[]')
  from empresa_convites c join empresas e on e.id = c.empresa_id
  where c.status = 'PENDENTE' and e.status = 'ATIVA' and c.contato = any(interno.contatos_verificados(auth.uid()))
$$;

create or replace function public.responder_convite_empresa(p_convite uuid, p_aceitar boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); r empresa_convites;
begin
  select * into r from empresa_convites where id = p_convite and status = 'PENDENTE' for update;
  if not found or not (r.contato = any(interno.contatos_verificados(v_uid))) then perform interno.erro('CONVITE_NAO_ENCONTRADO'); end if;
  if not exists (select 1 from perfis where id = v_uid) then perform interno.erro('CADASTRO_INCOMPLETO'); end if;
  if p_aceitar then
    insert into empresa_membros (empresa_id, usuario_id, papel, departamento_id, centro_custo_id, limite_mensal, adicionado_por)
    values (r.empresa_id, v_uid, r.papel, r.departamento_id, r.centro_custo_id, r.limite_mensal, r.criado_por)
    on conflict (empresa_id, usuario_id) do update set papel = excluded.papel, departamento_id = excluded.departamento_id,
      centro_custo_id = excluded.centro_custo_id, limite_mensal = excluded.limite_mensal, ativo = true;
  end if;
  update empresa_convites set status = case when p_aceitar then 'ACEITO' else 'RECUSADO' end where id = r.id;
end $$;

-- compatibilidade: aceita de uma vez os convites dos contatos VERIFICADOS (chamada explícita do usuário)
create or replace function public.aceitar_convites_empresa() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); r record; n int := 0;
begin
  for r in select c.id from empresa_convites c join empresas e on e.id = c.empresa_id
           where c.status = 'PENDENTE' and e.status = 'ATIVA' and c.contato = any(interno.contatos_verificados(v_uid)) loop
    perform public.responder_convite_empresa(r.id, true);
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.minhas_empresas() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('empresa', e.id, 'nome', coalesce(e.nome_fantasia, e.razao_social), 'status', e.status,
    'papel', m.papel, 'departamento', (select nome from empresa_departamentos where id = m.departamento_id),
    'centro_custo_padrao', m.centro_custo_id,
    'centros_custo', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'codigo', codigo, 'nome', nome)), '[]') from empresa_centros_custo where empresa_id = e.id),
    'politica', (select to_jsonb(pp) from empresa_politicas pp where pp.empresa_id = e.id and pp.ativa
                   and (pp.departamento_id is null or pp.departamento_id = m.departamento_id) order by pp.departamento_id nulls last limit 1),
    'gasto_mes', (select coalesce(sum(preco_final), 0) from corridas where empresa_id = e.id and passageiro_id = m.usuario_id
                    and status in ('FINALIZADA','PAGA') and solicitada_em >= date_trunc('month', now())))), '[]')
  from empresa_membros m join empresas e on e.id = m.empresa_id where m.usuario_id = auth.uid() and m.ativo
$$;

-- confere a política e cria a corrida corporativa
create or replace function public.solicitar_corrida_empresa(p_empresa uuid, p_chave_idempotencia text, p_cidade uuid, p_categoria text,
  p_o_lat float8, p_o_lng float8, p_o_endereco text, p_d_lat float8, p_d_lng float8, p_d_endereco text,
  p_centro_custo uuid default null, p_justificativa text default null, p_rota_km numeric default null, p_rota_min numeric default null)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); e empresas; m empresa_membros; pol empresa_politicas; v_rota record; v_preco numeric;
        v_gasto numeric; v_aberto numeric; v_tz text; v_agora timestamptz := now(); r jsonb;
begin
  -- trava a empresa: pedidos simultâneos de funcionários diferentes passam um de cada vez pelo limite
  select * into e from empresas where id = p_empresa for update;
  select * into m from empresa_membros where empresa_id = p_empresa and usuario_id = v_uid and ativo;
  if m.usuario_id is null then perform interno.erro('SEM_PERMISSAO_NA_EMPRESA'); end if;
  if e.status <> 'ATIVA' then perform interno.erro('EMPRESA_' || e.status); end if;
  if exists (select 1 from empresa_faturas where empresa_id = p_empresa and status = 'VENCIDA') then perform interno.erro('EMPRESA_COM_FATURA_VENCIDA'); end if;
  select * into pol from empresa_politicas where empresa_id = p_empresa and ativa and (departamento_id is null or departamento_id = m.departamento_id)
  order by departamento_id nulls last limit 1;
  if pol.id is null then perform interno.erro('EMPRESA_SEM_POLITICA'); end if;
  if not (p_categoria = any(pol.categorias_permitidas)) then perform interno.erro('CATEGORIA_FORA_DA_POLITICA', array_to_string(pol.categorias_permitidas, ',')); end if;
  if pol.exige_justificativa and coalesce(length(trim(p_justificativa)), 0) < 5 then perform interno.erro('JUSTIFICATIVA_OBRIGATORIA'); end if;
  if pol.exige_centro_custo and coalesce(p_centro_custo, m.centro_custo_id) is null then perform interno.erro('CENTRO_DE_CUSTO_OBRIGATORIO'); end if;
  if p_centro_custo is not null and not exists (select 1 from empresa_centros_custo where id = p_centro_custo and empresa_id = p_empresa) then
    perform interno.erro('CENTRO_DE_CUSTO_INVALIDO');
  end if;
  select coalesce(c.fuso, 'America/Sao_Paulo') into v_tz from cidades c where c.id = p_cidade;
  if pol.dias_semana is not null and not (extract(isodow from v_agora at time zone v_tz)::int = any(pol.dias_semana)) then perform interno.erro('FORA_DO_DIA_PERMITIDO'); end if;
  if pol.hora_inicio is not null and not ((v_agora at time zone v_tz)::time between pol.hora_inicio and pol.hora_fim) then perform interno.erro('FORA_DO_HORARIO_PERMITIDO'); end if;

  select * into v_rota from interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  v_preco := interno.calcular_preco(p_cidade, p_categoria, v_rota.km, v_rota.minutos);
  if pol.limite_por_corrida is not null and v_preco > pol.limite_por_corrida then perform interno.erro('ACIMA_DO_LIMITE_POR_CORRIDA', pol.limite_por_corrida::text); end if;
  select coalesce(sum(coalesce(preco_final, preco_estimado)), 0) into v_gasto from corridas
  where empresa_id = p_empresa and passageiro_id = v_uid and status not in ('CANCELADA','SEM_MOTORISTA') and solicitada_em >= date_trunc('month', now());
  if coalesce(m.limite_mensal, pol.limite_mensal_por_pessoa) is not null and v_gasto + v_preco > coalesce(m.limite_mensal, pol.limite_mensal_por_pessoa) then
    perform interno.erro('LIMITE_MENSAL_ATINGIDO');
  end if;
  -- limite de crédito da empresa (o que ainda não foi pago + esta corrida)
  v_aberto := -interno.saldo(p_empresa, 'EMPRESA_A_RECEBER')
              + (select coalesce(sum(preco_estimado), 0) from corridas where empresa_id = p_empresa and status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO'));
  if v_aberto + v_preco > e.limite_credito_mensal then perform interno.erro('LIMITE_DE_CREDITO_DA_EMPRESA'); end if;

  perform set_config('app.corporativa', 'on', true);
  r := public.solicitar_corrida(p_chave_idempotencia, p_cidade, p_categoria, p_o_lat, p_o_lng, p_o_endereco, p_d_lat, p_d_lng, p_d_endereco,
                                'EMPRESA'::metodo_pagamento, p_rota_km, p_rota_min, 1);
  perform set_config('app.corporativa', 'off', true);
  update corridas set empresa_id = p_empresa, centro_custo_id = coalesce(p_centro_custo, m.centro_custo_id), departamento_id = m.departamento_id,
    justificativa_corporativa = left(p_justificativa, 300)
  where id = (r ->> 'corrida')::uuid and empresa_id is null;
  return r || jsonb_build_object('empresa', p_empresa);
end $$;

-- relatório e exportação
create or replace function public.empresa_relatorio(p_empresa uuid, p_inicio timestamptz, p_fim timestamptz) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel_empresa(p_empresa, '{GESTOR,FINANCEIRO}');
begin
  return jsonb_build_object(
    'empresa', (select jsonb_build_object('nome', coalesce(nome_fantasia, razao_social), 'status', status, 'limite_credito', limite_credito_mensal,
                  'em_aberto', -interno.saldo(id, 'EMPRESA_A_RECEBER')) from empresas where id = p_empresa),
    'totais', (select jsonb_build_object('corridas', count(*), 'valor', coalesce(sum(preco_final), 0), 'ticket_medio', round(avg(preco_final), 2))
               from corridas where empresa_id = p_empresa and status in ('FINALIZADA','PAGA') and finalizada_em >= p_inicio and finalizada_em < p_fim),
    'por_departamento', (select coalesce(jsonb_agg(jsonb_build_object('departamento', coalesce(d.nome, 'Sem departamento'), 'corridas', x.n, 'valor', x.v)), '[]')
       from (select departamento_id, count(*) n, sum(preco_final) v from corridas where empresa_id = p_empresa and status in ('FINALIZADA','PAGA')
             and finalizada_em >= p_inicio and finalizada_em < p_fim group by 1) x left join empresa_departamentos d on d.id = x.departamento_id),
    'por_centro_custo', (select coalesce(jsonb_agg(jsonb_build_object('centro', coalesce(cc.codigo || ' ' || cc.nome, 'Sem centro'), 'corridas', x.n, 'valor', x.v)), '[]')
       from (select centro_custo_id, count(*) n, sum(preco_final) v from corridas where empresa_id = p_empresa and status in ('FINALIZADA','PAGA')
             and finalizada_em >= p_inicio and finalizada_em < p_fim group by 1) x left join empresa_centros_custo cc on cc.id = x.centro_custo_id),
    'por_funcionario', (select coalesce(jsonb_agg(jsonb_build_object('funcionario', p.nome, 'corridas', x.n, 'valor', x.v) order by x.v desc), '[]')
       from (select passageiro_id, count(*) n, sum(preco_final) v from corridas where empresa_id = p_empresa and status in ('FINALIZADA','PAGA')
             and finalizada_em >= p_inicio and finalizada_em < p_fim group by 1) x join perfis p on p.id = x.passageiro_id),
    'faturas', (select coalesce(jsonb_agg(to_jsonb(f) order by f.criado_em desc), '[]') from empresa_faturas f where f.empresa_id = p_empresa),
    'membros', (select coalesce(jsonb_agg(jsonb_build_object('usuario', m.usuario_id, 'nome', p.nome, 'papel', m.papel, 'ativo', m.ativo,
                   'departamento', (select nome from empresa_departamentos where id = m.departamento_id), 'limite_mensal', m.limite_mensal)), '[]')
                from empresa_membros m join perfis p on p.id = m.usuario_id where m.empresa_id = p_empresa),
    'politicas', (select coalesce(jsonb_agg(to_jsonb(pp)), '[]') from empresa_politicas pp where pp.empresa_id = p_empresa),
    'departamentos', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'nome', nome)), '[]') from empresa_departamentos where empresa_id = p_empresa),
    'centros_custo', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'codigo', codigo, 'nome', nome)), '[]') from empresa_centros_custo where empresa_id = p_empresa));
end $$;

create or replace function public.empresa_exportar_csv(p_empresa uuid, p_inicio timestamptz, p_fim timestamptz) returns text
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel_empresa(p_empresa, '{GESTOR,FINANCEIRO}'); v text;
begin
  select 'data;funcionario;departamento;centro_custo;categoria;origem;destino;km;valor;justificativa;status' || chr(10) ||
         coalesce(string_agg(concat_ws(';', to_char(c.solicitada_em at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'), p.nome,
           coalesce(d.nome, ''), coalesce(cc.codigo, ''), c.categoria, replace(coalesce(c.origem_endereco, ''), ';', ','),
           replace(coalesce(c.destino_endereco, ''), ';', ','), replace(coalesce(c.distancia_real_km, c.distancia_estimada_km)::text, '.', ','),
           replace(coalesce(c.preco_final, 0)::text, '.', ','), replace(coalesce(c.justificativa_corporativa, ''), ';', ','), c.status), chr(10)
           order by c.solicitada_em), '')
    into v
  from corridas c join perfis p on p.id = c.passageiro_id
  left join empresa_departamentos d on d.id = c.departamento_id left join empresa_centros_custo cc on cc.id = c.centro_custo_id
  where c.empresa_id = p_empresa and c.solicitada_em >= p_inicio and c.solicitada_em < p_fim;
  perform interno.auditar_evento('EXPORTACAO_EMPRESA', 'empresas', p_empresa::text, jsonb_build_object('inicio', p_inicio, 'fim', p_fim));
  return v;
end $$;

-- corrida corporativa estornada depois de entrar numa fatura: vira crédito da empresa.
-- Fatura ainda não paga e sem cobrança em andamento: o valor sai da própria fatura.
-- Fatura já paga (ou com cobrança gerada): o crédito é abatido na próxima fatura.
create table if not exists empresa_creditos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id),
  corrida_id uuid unique references corridas(id),          -- null = sobra de crédito de fatura anterior
  valor numeric(12,2) not null check (valor > 0),
  usado_na_fatura uuid references empresa_faturas(id),
  criado_em timestamptz not null default now()
);
create or replace function interno.trg_estorno_corporativo() returns trigger
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; f empresa_faturas;
begin
  if new.status <> 'ESTORNADO' or old.status = 'ESTORNADO' or new.tipo <> 'CORRIDA' or new.metodo::text <> 'EMPRESA' then return new; end if;
  select * into c from corridas where id = new.corrida_id;
  if c.fatura_id is null then return new; end if;     -- ainda não faturada: o estorno já sai do que será faturado
  select * into f from empresa_faturas where id = c.fatura_id for update;
  if f.status in ('FECHADA','VENCIDA') and not exists (select 1 from pagamentos where fatura_id = f.id and status in ('PENDENTE','AUTORIZADO','CONFIRMADO')) then
    update empresa_faturas set valor = greatest(valor - new.valor, 0), corridas = greatest(corridas - 1, 0),
      status = case when valor - new.valor <= 0 then 'PAGA' else status end, paga_em = case when valor - new.valor <= 0 then now() end where id = f.id;
    insert into empresa_creditos (empresa_id, corrida_id, valor, usado_na_fatura) values (c.empresa_id, c.id, new.valor, f.id) on conflict do nothing;
  else
    insert into empresa_creditos (empresa_id, corrida_id, valor) values (c.empresa_id, c.id, new.valor) on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists pagamentos_estorno_corporativo on pagamentos;
create trigger pagamentos_estorno_corporativo after update of status on pagamentos for each row execute function interno.trg_estorno_corporativo();

-- fechamento de fatura (job diário ou financeiro na mão)
create or replace function interno.fechar_fatura(p_empresa uuid) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare e empresas; v_ini timestamptz; v_id uuid; v_valor numeric; v_n int; v_cred numeric;
begin
  select * into e from empresas where id = p_empresa for update;
  select coalesce(max(periodo_fim), e.criado_em) into v_ini from empresa_faturas where empresa_id = p_empresa and status <> 'CANCELADA';
  select coalesce(sum(p.valor), 0), count(*) into v_valor, v_n from pagamentos p join corridas c on c.id = p.corrida_id
  where c.empresa_id = p_empresa and p.metodo = 'EMPRESA' and p.status = 'CONFIRMADO' and c.fatura_id is null;
  select coalesce(sum(valor), 0) into v_cred from empresa_creditos where empresa_id = p_empresa and usado_na_fatura is null;
  if v_n = 0 then return null; end if;
  insert into empresa_faturas (empresa_id, periodo_inicio, periodo_fim, valor, corridas, vencimento)
  values (p_empresa, v_ini, now(), greatest(v_valor - v_cred, 0), v_n, (now() + make_interval(days => e.prazo_pagamento_dias))::date) returning id into v_id;
  -- créditos abatidos; se sobrar crédito, ele continua para a próxima fatura
  if v_cred > 0 then
    update empresa_creditos set usado_na_fatura = v_id where empresa_id = p_empresa and usado_na_fatura is null;
    if v_cred > v_valor then
      insert into empresa_creditos (empresa_id, corrida_id, valor) values (p_empresa, null, v_cred - v_valor);   -- sobra segue para a próxima
    end if;
  end if;
  update empresa_faturas set status = 'PAGA', paga_em = now() where id = v_id and valor = 0;   -- tudo coberto por créditos
  update corridas c set fatura_id = v_id where c.empresa_id = p_empresa and c.fatura_id is null
    and exists (select 1 from pagamentos p where p.corrida_id = c.id and p.metodo = 'EMPRESA' and p.status = 'CONFIRMADO');
  perform interno.notificar(m.usuario_id, 'PAGAMENTO', 'Fatura fechada', 'Valor ' || interno.reais(v_valor) || ', vencimento ' ||
    to_char((now() + make_interval(days => e.prazo_pagamento_dias))::date, 'DD/MM/YYYY'), jsonb_build_object('fatura', v_id))
  from empresa_membros m where m.empresa_id = p_empresa and m.papel in ('GESTOR','FINANCEIRO') and m.ativo;
  return v_id;
end $$;

create or replace function public.fin_fechar_fatura(p_empresa uuid) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,ADMIN}');
begin
  return interno.fechar_fatura(p_empresa);
end $$;

create or replace function public.empresa_pagar_fatura(p_fatura uuid, p_metodo metodo_pagamento default 'PIX') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare f empresa_faturas; v_uid uuid; p pagamentos;
begin
  select * into f from empresa_faturas where id = p_fatura for update;
  if not found then perform interno.erro('FATURA_NAO_ENCONTRADA'); end if;
  v_uid := interno.exigir_papel_empresa(f.empresa_id, '{GESTOR,FINANCEIRO}');
  if f.status not in ('FECHADA','VENCIDA') then perform interno.erro('FATURA_' || f.status); end if;
  if p_metodo not in ('PIX','CARTAO') then perform interno.erro('METODO_INVALIDO'); end if;
  insert into pagamentos (pagador_id, tipo, metodo, valor, chave_idempotencia, fatura_id)
  values (v_uid, 'FATURA_EMPRESA', p_metodo, f.valor, 'FATURA:' || f.id, f.id)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then select * into p from pagamentos where chave_idempotencia = 'FATURA:' || f.id; end if;
  return jsonb_build_object('pagamento', p.id, 'status', p.status, 'valor', p.valor);
end $$;

create or replace function interno.job_empresas() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n_fech int := 0; n_venc int := 0;
begin
  for r in select id from empresas where status = 'ATIVA' and dia_fechamento = extract(day from now() at time zone 'America/Sao_Paulo')::int
             and not exists (select 1 from empresa_faturas f where f.empresa_id = empresas.id and f.criado_em::date = current_date) loop
    if interno.fechar_fatura(r.id) is not null then n_fech := n_fech + 1; end if;
  end loop;
  update empresa_faturas set status = 'VENCIDA' where status = 'FECHADA' and vencimento < current_date;
  get diagnostics n_venc = row_count;
  return jsonb_build_object('faturas_fechadas', n_fech, 'faturas_vencidas', n_venc);
end $$;

-- ============================================================
-- MOBI WALLET: cupons, recarga, reembolso em créditos
-- ============================================================
create or replace function public.admin_salvar_cupom(p jsonb) returns text
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,ADMIN}'); v_cod text := upper(trim(p ->> 'codigo'));
begin
  if v_cod !~ '^[A-Z0-9]{4,20}$' then perform interno.erro('CODIGO_INVALIDO'); end if;
  insert into cupons (codigo, tipo, valor, desconto_maximo, cidade_id, categoria, validade_inicio, validade_fim, usos_maximos, usos_por_usuario,
                      somente_primeira_corrida, ativo, criado_por)
  values (v_cod, p ->> 'tipo', (p ->> 'valor')::numeric, nullif(p ->> 'desconto_maximo', '')::numeric, nullif(p ->> 'cidade_id', '')::uuid,
          nullif(p ->> 'categoria', ''), nullif(p ->> 'validade_inicio', '')::timestamptz, nullif(p ->> 'validade_fim', '')::timestamptz,
          nullif(p ->> 'usos_maximos', '')::int, coalesce((p ->> 'usos_por_usuario')::int, 1), coalesce((p ->> 'somente_primeira_corrida')::boolean, false),
          coalesce((p ->> 'ativo')::boolean, true), v_uid)
  on conflict (codigo) do update set ativo = excluded.ativo, validade_fim = excluded.validade_fim, usos_maximos = excluded.usos_maximos;
  return v_cod;
end $$;
drop trigger if exists cupons_auditar on cupons;
create trigger cupons_auditar after insert or update on cupons for each row execute function interno.trg_auditar();

-- regras do cupom (sem efeito colateral); devolve o motivo quando não vale
create or replace function interno.checar_cupom(p_codigo text, p_usuario uuid, p_cidade uuid, p_categoria text, p_corrida uuid default null)
returns text language plpgsql stable security definer set search_path = public, pg_temp as $$
declare cp cupons;
begin
  select * into cp from cupons where codigo = upper(trim(p_codigo));
  if not found or not cp.ativo then return 'CUPOM_INVALIDO'; end if;
  if cp.validade_inicio is not null and now() < cp.validade_inicio then return 'CUPOM_AINDA_NAO_VALE'; end if;
  if cp.validade_fim is not null and now() > cp.validade_fim then return 'CUPOM_EXPIRADO'; end if;
  if cp.cidade_id is not null and cp.cidade_id <> p_cidade then return 'CUPOM_NAO_VALE_NESTA_CIDADE'; end if;
  if cp.categoria is not null and cp.categoria <> p_categoria then return 'CUPOM_NAO_VALE_NESTA_CATEGORIA'; end if;
  if cp.usos_maximos is not null and (select count(*) from cupom_usos where cupom_codigo = cp.codigo and corrida_id is distinct from p_corrida) >= cp.usos_maximos then
    return 'CUPOM_ESGOTADO';
  end if;
  if (select count(*) from cupom_usos where cupom_codigo = cp.codigo and usuario_id = p_usuario and corrida_id is distinct from p_corrida) >= cp.usos_por_usuario then
    return 'CUPOM_JA_USADO';
  end if;
  if cp.somente_primeira_corrida and exists (select 1 from corridas where passageiro_id = p_usuario and status = 'PAGA' and id is distinct from p_corrida) then
    return 'CUPOM_SO_PRIMEIRA_CORRIDA';
  end if;
  return null;
end $$;

create or replace function public.validar_cupom(p_codigo text, p_cidade uuid, p_categoria text, p_valor_estimado numeric default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_err text; cp cupons;
begin
  v_err := interno.checar_cupom(p_codigo, v_uid, p_cidade, p_categoria);
  if v_err is not null then return jsonb_build_object('valido', false, 'erro', v_err); end if;
  select * into cp from cupons where codigo = upper(trim(p_codigo));
  return jsonb_build_object('valido', true, 'codigo', cp.codigo, 'tipo', cp.tipo, 'valor', cp.valor, 'desconto_maximo', cp.desconto_maximo,
    'desconto_estimado', case when p_valor_estimado is null then null when cp.tipo = 'VALOR' then least(cp.valor, p_valor_estimado)
                              else least(round(p_valor_estimado * cp.valor / 100, 2), coalesce(cp.desconto_maximo, 1e9)) end);
end $$;

create or replace function public.aplicar_cupom(p_corrida uuid, p_codigo text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_err text;
begin
  perform interno.limitar('cupom', 10, 3600);
  select * into c from corridas where id = p_corrida for update;
  if not found or c.passageiro_id <> v_uid then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if c.status not in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO') then perform interno.erro('CUPOM_SO_ANTES_DE_FINALIZAR'); end if;
  if c.metodo_pagamento::text = 'EMPRESA' then perform interno.erro('CUPOM_NAO_VALE_EM_CORRIDA_CORPORATIVA'); end if;
  v_err := interno.checar_cupom(p_codigo, v_uid, c.cidade_id, c.categoria, c.id);
  if v_err is not null then return jsonb_build_object('ok', false, 'erro', v_err); end if;
  update corridas set cupom_codigo = upper(trim(p_codigo)) where id = p_corrida;
  return jsonb_build_object('ok', true, 'codigo', upper(trim(p_codigo)));
end $$;

-- ============================================================
-- MOBI+ (assinatura) — benefícios de desconto e cancelamento grátis
-- ============================================================
create table if not exists planos_assinatura (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  preco_mensal numeric(10,2) not null check (preco_mensal > 0),
  cidade_id uuid references cidades(id),                    -- null = todas
  beneficios jsonb not null default '{}',
  -- ex.: {"desconto_pct":5,"desconto_max_corrida":4,"categorias":["ECONOMICO","CONFORTO"],"cancelamentos_gratis_mes":2,"suporte_prioritario":true}
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);
drop trigger if exists planos_auditar on planos_assinatura;
create trigger planos_auditar after insert or update on planos_assinatura for each row execute function interno.trg_auditar();

create table if not exists assinaturas (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id),
  plano_id uuid not null references planos_assinatura(id),
  status text not null default 'PENDENTE' check (status in ('PENDENTE','ATIVA','INADIMPLENTE','CANCELADA')),
  inicio timestamptz not null default now(),
  renova_em timestamptz,
  cancelada_em timestamptz,
  inadimplente_desde timestamptz,
  criado_em timestamptz not null default now()
);
create unique index if not exists uma_assinatura_viva on assinaturas (usuario_id) where status in ('PENDENTE','ATIVA','INADIMPLENTE');
create table if not exists assinatura_usos (
  id bigint generated always as identity primary key,
  assinatura_id uuid not null references assinaturas(id),
  tipo text not null check (tipo in ('DESCONTO','CANCELAMENTO_GRATIS')),
  corrida_id uuid references corridas(id),
  valor numeric(10,2),
  criado_em timestamptz not null default now(),
  unique (assinatura_id, tipo, corrida_id)
);
alter table pagamentos add column if not exists assinatura_id uuid references assinaturas(id);

create or replace function interno.assinatura_ativa(p_usuario uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('assinatura', a.id, 'plano', p.nome, 'beneficios', p.beneficios, 'renova_em', a.renova_em)
  from assinaturas a join planos_assinatura p on p.id = a.plano_id
  where a.usuario_id = p_usuario and a.status in ('ATIVA','CANCELADA') and a.renova_em > now()   -- cancelada vale até o fim do período pago
  order by a.renova_em desc limit 1
$$;

create or replace function interno.cancelamento_gratis_disponivel(p_usuario uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((
    select (p.beneficios ->> 'cancelamentos_gratis_mes')::int > (select count(*) from assinatura_usos u where u.assinatura_id = a.id
             and u.tipo = 'CANCELAMENTO_GRATIS' and u.criado_em >= date_trunc('month', now()))
    from assinaturas a join planos_assinatura p on p.id = a.plano_id
    where a.usuario_id = p_usuario and a.status in ('ATIVA','CANCELADA') and a.renova_em > now() order by a.renova_em desc limit 1), false)
$$;

create or replace function public.admin_salvar_plano(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,ADMIN}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  if v_id is null then
    insert into planos_assinatura (nome, preco_mensal, cidade_id, beneficios) values (p ->> 'nome', (p ->> 'preco_mensal')::numeric,
      nullif(p ->> 'cidade_id', '')::uuid, coalesce(p -> 'beneficios', '{}')) returning id into v_id;
  else
    update planos_assinatura set nome = coalesce(p ->> 'nome', nome), ativo = coalesce((p ->> 'ativo')::boolean, ativo),
      beneficios = coalesce(p -> 'beneficios', beneficios) where id = v_id;  -- preço de plano existente não muda (cria-se outro)
  end if;
  return v_id;
end $$;

create or replace function public.assinar_plano(p_plano uuid, p_metodo metodo_pagamento default 'PIX') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); pl planos_assinatura; a assinaturas; p pagamentos;
begin
  perform interno.limitar('assinar', 5, 3600);
  select * into pl from planos_assinatura where id = p_plano and ativo;
  if not found then perform interno.erro('PLANO_INDISPONIVEL'); end if;
  if p_metodo not in ('PIX','CARTAO','CARTEIRA') then perform interno.erro('METODO_INVALIDO'); end if;
  if exists (select 1 from assinaturas where usuario_id = v_uid and status in ('ATIVA','INADIMPLENTE')) then perform interno.erro('JA_ASSINANTE'); end if;
  -- cancelou mas o período pago ainda vale: reativa o mesmo plano sem cobrar de novo
  select * into a from assinaturas where usuario_id = v_uid and status = 'CANCELADA' and renova_em > now() order by renova_em desc limit 1;
  if a.id is not null then
    if a.plano_id <> p_plano then perform interno.erro('TROCA_DE_PLANO_APOS_FIM_DO_PERIODO', to_char(a.renova_em, 'DD/MM/YYYY')); end if;
    update assinaturas set status = 'ATIVA', cancelada_em = null where id = a.id;
    return jsonb_build_object('assinatura', a.id, 'reativada', true, 'renova_em', a.renova_em);
  end if;
  a := null;
  select * into a from assinaturas where usuario_id = v_uid and status = 'PENDENTE';
  if a.id is null then
    insert into assinaturas (usuario_id, plano_id) values (v_uid, p_plano) returning * into a;
  end if;
  if p_metodo = 'CARTEIRA' and interno.travar_saldo(v_uid, 'PASSAGEIRO_CARTEIRA') < pl.preco_mensal then perform interno.erro('SALDO_INSUFICIENTE'); end if;
  -- cobrança pendente com OUTRO método é cancelada (nunca reaproveitada com método diferente)
  update pagamentos set status = 'CANCELADO', motivo_falha = 'Trocou o método de pagamento'
  where assinatura_id = a.id and tipo = 'ASSINATURA' and status = 'PENDENTE' and metodo <> p_metodo;
  insert into pagamentos (pagador_id, tipo, metodo, valor, chave_idempotencia, assinatura_id)
  values (v_uid, 'ASSINATURA', p_metodo, pl.preco_mensal, 'ASSIN:' || a.id || ':' || to_char(now(), 'YYYYMM') || ':' || p_metodo, a.id)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then select * into p from pagamentos where chave_idempotencia = 'ASSIN:' || a.id || ':' || to_char(now(), 'YYYYMM') || ':' || p_metodo; end if;
  if p.metodo = 'CARTEIRA' and p.status = 'PENDENTE' then return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor); end if;
  return jsonb_build_object('assinatura', a.id, 'pagamento', p.id, 'status', p.status, 'valor', p.valor);
end $$;

create or replace function public.cancelar_assinatura() returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login();
begin
  -- benefícios continuam até o fim do período já pago; cobranças ainda não pagas são canceladas
  update pagamentos set status = 'CANCELADO', motivo_falha = 'Assinatura cancelada'
  where tipo = 'ASSINATURA' and status = 'PENDENTE' and assinatura_id in (select id from assinaturas where usuario_id = v_uid);
  update assinaturas set status = 'CANCELADA', cancelada_em = now() where usuario_id = v_uid and status in ('ATIVA','PENDENTE','INADIMPLENTE');
end $$;

create or replace function interno.job_assinaturas() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n_ren int := 0; n_inad int := 0;
begin
  -- vence hoje: gera cobrança de renovação (cartão é cobrado pelo servidor; PIX fica pendente)
  for r in select a.*, pl.preco_mensal from assinaturas a join planos_assinatura pl on pl.id = a.plano_id
           where a.status = 'ATIVA' and a.renova_em <= now() + interval '1 day' loop
    insert into pagamentos (pagador_id, tipo, metodo, valor, chave_idempotencia, assinatura_id)
    values (r.usuario_id, 'ASSINATURA', coalesce((select 'CARTAO'::metodo_pagamento from meios_pagamento where usuario_id = r.usuario_id and tipo = 'CARTAO' and ativo and padrao limit 1), 'PIX'),
            r.preco_mensal, 'RENOV:' || r.id || ':' || to_char(r.renova_em, 'YYYYMMDD'), r.id)   -- chave por período (30 dias), não por mês
    on conflict (chave_idempotencia) do nothing;
    if found then n_ren := n_ren + 1; end if;
  end loop;
  update assinaturas set status = 'INADIMPLENTE', inadimplente_desde = now() where status = 'ATIVA' and renova_em < now() - interval '3 days';
  get diagnostics n_inad = row_count;
  return jsonb_build_object('renovacoes_geradas', n_ren, 'inadimplentes', n_inad);
end $$;

-- desconto aplicado na cobrança: cupom + Mobi+ (mín. R$ 1,00 cobrado; empresa não tem desconto)
create or replace function interno.aplicar_descontos(c corridas) returns numeric
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare cp cupons; v_cupom numeric := 0; v_mobi numeric := 0; v_total numeric; v_err text; a jsonb; v_pct numeric;
begin
  if exists (select 1 from pagamentos where corrida_id = c.id and tipo = 'CORRIDA') then return c.desconto; end if;   -- já cobrado: não recalcula
  if c.metodo_pagamento::text = 'EMPRESA' then return 0; end if;
  if c.cupom_codigo is not null then
    select * into cp from cupons where codigo = c.cupom_codigo for update;   -- trava: limite de usos sob concorrência
    v_err := interno.checar_cupom(c.cupom_codigo, c.passageiro_id, c.cidade_id, c.categoria, c.id);
    if v_err is null then
      v_cupom := case when cp.tipo = 'VALOR' then cp.valor else least(round(c.preco_final * cp.valor / 100, 2), coalesce(cp.desconto_maximo, 1e9)) end;
    else
      perform interno.evento(c.id, 'CUPOM_RECUSADO', c.status, c.status, jsonb_build_object('codigo', c.cupom_codigo, 'motivo', v_err));
    end if;
  end if;
  a := interno.assinatura_ativa(c.passageiro_id);
  if a is not null then
    v_pct := coalesce((a -> 'beneficios' ->> 'desconto_pct')::numeric, 0);
    if v_pct > 0 and (a -> 'beneficios' -> 'categorias' is null or (a -> 'beneficios' -> 'categorias') ? c.categoria) then
      v_mobi := least(round(c.preco_final * v_pct / 100, 2), coalesce((a -> 'beneficios' ->> 'desconto_max_corrida')::numeric, 1e9));
    end if;
  end if;
  v_total := greatest(least(v_cupom + v_mobi, c.preco_final - 1.00), 0);
  if v_total <= 0 then return 0; end if;
  -- se o teto cortou, o cupom fica com o que sobrou depois do Mobi+
  v_cupom := least(v_cupom, v_total - least(v_mobi, v_total)); v_mobi := v_total - v_cupom;
  update corridas set desconto = v_total where id = c.id;
  if v_cupom > 0 then
    insert into cupom_usos (cupom_codigo, usuario_id, corrida_id, desconto) values (c.cupom_codigo, c.passageiro_id, c.id, v_cupom) on conflict do nothing;
  end if;
  if v_mobi > 0 then
    insert into assinatura_usos (assinatura_id, tipo, corrida_id, valor) values ((a ->> 'assinatura')::uuid, 'DESCONTO', c.id, v_mobi) on conflict do nothing;
  end if;
  perform interno.evento(c.id, 'DESCONTO', c.status, c.status, jsonb_build_object('cupom', v_cupom, 'mobi_mais', v_mobi, 'total', v_total));
  return v_total;
end $$;

-- recarga de créditos e reembolso em créditos
create or replace function public.recarregar_carteira(p_valor numeric, p_metodo metodo_pagamento, p_chave_idempotencia text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); p pagamentos;
begin
  perform interno.limitar('recarga', 10, 3600);
  if p_valor < 10 or p_valor > 1000 then perform interno.erro('VALOR_INVALIDO', 'entre R$ 10 e R$ 1.000'); end if;
  if p_metodo not in ('PIX','CARTAO') then perform interno.erro('METODO_INVALIDO'); end if;
  if coalesce(length(p_chave_idempotencia), 0) < 8 then perform interno.erro('CHAVE_IDEMPOTENCIA_OBRIGATORIA'); end if;
  insert into pagamentos (pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (v_uid, 'RECARGA', p_metodo, round(p_valor, 2), 'RECARGA:' || v_uid || ':' || p_chave_idempotencia)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then select * into p from pagamentos where chave_idempotencia = 'RECARGA:' || v_uid || ':' || p_chave_idempotencia; end if;
  return jsonb_build_object('pagamento', p.id, 'status', p.status, 'valor', p.valor);
end $$;

drop function if exists public.fin_reembolsar_em_creditos(uuid, numeric, text);
-- teto = o que o passageiro EFETIVAMENTE pagou (preço − desconto), menos créditos já dados; corrida estornada não recebe crédito.
-- p_chave: identificador do pedido de reembolso (a tela gera um por atendimento) — repetir o pedido não credita duas vezes.
create or replace function public.fin_reembolsar_em_creditos(p_corrida uuid, p_valor numeric, p_motivo text, p_chave text default null) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,SUPORTE,ADMIN}'); c corridas; v_tx uuid; v_ja numeric; v_pago numeric; v_chave text;
begin
  if coalesce(length(trim(p_motivo)), 0) < 5 then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  select * into c from corridas where id = p_corrida for update;
  if not found or c.status not in ('PAGA','FINALIZADA','CANCELADA') then perform interno.erro('CORRIDA_NAO_ELEGIVEL'); end if;
  perform interno.sem_conflito(c.passageiro_id);
  if exists (select 1 from pagamentos where corrida_id = c.id and tipo = 'CORRIDA' and status = 'ESTORNADO') then perform interno.erro('CORRIDA_JA_ESTORNADA'); end if;
  v_chave := 'REEMB:' || p_corrida || ':' || coalesce(nullif(trim(p_chave), ''), md5(lower(trim(p_motivo)) || ':' || round(p_valor, 2)));
  if exists (select 1 from transacoes_ledger where chave_idempotencia = v_chave) then
    return (select id from transacoes_ledger where chave_idempotencia = v_chave);   -- mesmo pedido repetido
  end if;
  select coalesce(sum(l.valor), 0) into v_ja from lancamentos_ledger l join transacoes_ledger t on t.id = l.transacao_id join contas_ledger ct on ct.id = l.conta_id
  where t.tipo = 'REEMBOLSO_CREDITO' and t.referencia = p_corrida::text and ct.tipo = 'PASSAGEIRO_CARTEIRA';
  v_pago := case when c.status = 'CANCELADA' then coalesce(c.taxa_cancelamento, 0) else greatest(coalesce(c.preco_final, 0) - c.desconto, 0) end;
  if p_valor <= 0 or v_ja + p_valor > v_pago then perform interno.erro('VALOR_ACIMA_DO_PAGO', 'máximo ' || (v_pago - v_ja)); end if;
  v_tx := interno.lancar('REEMBOLSO_CREDITO', p_corrida::text, v_chave, 'Reembolso em créditos: ' || p_motivo,
    jsonb_build_array(jsonb_build_object('conta', 'PLATAFORMA_PROMOCOES', 'valor', -p_valor),
                      jsonb_build_object('titular', c.passageiro_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', p_valor)));
  perform interno.notificar(c.passageiro_id, 'PAGAMENTO', 'Você recebeu créditos', interno.reais(p_valor) || ' de reembolso na sua carteira.', jsonb_build_object('corrida', c.id));
  return v_tx;
end $$;

create or replace function public.minha_wallet() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'creditos', interno.saldo(auth.uid(), 'PASSAGEIRO_CARTEIRA'),
    'mobi_mais', interno.assinatura_ativa(auth.uid()),
    'meios_pagamento', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'tipo', tipo, 'bandeira', bandeira, 'final4', final4, 'padrao', padrao)), '[]')
                        from meios_pagamento where usuario_id = auth.uid() and ativo),
    'cupons_usados', (select coalesce(jsonb_agg(jsonb_build_object('codigo', cupom_codigo, 'desconto', desconto, 'data', usado_em) order by usado_em desc), '[]')
                      from cupom_usos where usuario_id = auth.uid()),
    'gorjetas', (select coalesce(jsonb_agg(jsonb_build_object('valor', valor, 'data', criado_em, 'status', status) order by criado_em desc), '[]')
                 from pagamentos where pagador_id = auth.uid() and tipo = 'GORJETA'),
    'reembolsos', (select coalesce(jsonb_agg(jsonb_build_object('valor', l.valor, 'data', l.criado_em, 'descricao', t.descricao) order by l.criado_em desc), '[]')
                   from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id and ct.titular_id = auth.uid() and ct.tipo = 'PASSAGEIRO_CARTEIRA'
                   join transacoes_ledger t on t.id = l.transacao_id where t.tipo in ('REEMBOLSO_CREDITO','ESTORNO_DINHEIRO')),
    'pagamentos_pendentes', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'tipo', tipo, 'valor', valor, 'metodo', metodo, 'criado_em', criado_em)), '[]')
                             from pagamentos where pagador_id = auth.uid() and status in ('PENDENTE','FALHOU')),
    'planos_disponiveis', (select coalesce(jsonb_agg(jsonb_build_object('id', pl.id, 'nome', pl.nome, 'preco_mensal', pl.preco_mensal, 'beneficios', pl.beneficios)), '[]')
                           from planos_assinatura pl where pl.ativo and (pl.cidade_id is null or pl.cidade_id = (select cidade_id from perfis where id = auth.uid()))))
$$;

-- ============================================================
-- PARCEIROS (marketplace) + DRIVER+
-- ============================================================
create table if not exists parceiros (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  tipo text not null check (tipo in ('POSTO','OFICINA','PNEUS','LAVAGEM','PECAS','SEGURO','FINANCIAMENTO','ESTACIONAMENTO','ASSISTENCIA','OUTRO')),
  cnpj text,
  cidade_id uuid references cidades(id),
  lat float8, lng float8,                    -- null = parceiro online (seguro, financiamento)
  endereco text, telefone text, horario text,
  ativo boolean not null default true,
  contrato_fim date,
  criado_em timestamptz not null default now()
);
create index if not exists parceiros_busca_idx on parceiros (cidade_id, tipo) where ativo;
drop trigger if exists parceiros_auditar on parceiros;
create trigger parceiros_auditar after insert or update on parceiros for each row execute function interno.trg_auditar();

create table if not exists parceiro_ofertas (
  id uuid primary key default gen_random_uuid(),
  parceiro_id uuid not null references parceiros(id) on delete cascade,
  titulo text not null,
  descricao text,
  publico text not null default 'MOTORISTA' check (publico in ('MOTORISTA','PASSAGEIRO','AMBOS')),
  nivel_minimo text not null default 'BRONZE' check (nivel_minimo in ('BRONZE','PRATA','OURO')),
  so_assinantes boolean not null default false,
  desconto_pct numeric(5,2), desconto_valor numeric(10,2),
  validade date,
  limite_por_usuario int not null default 1,
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);
create table if not exists parceiro_resgates (
  id uuid primary key default gen_random_uuid(),
  oferta_id uuid not null references parceiro_ofertas(id),
  usuario_id uuid not null references perfis(id),
  codigo text not null unique,
  status text not null default 'GERADO' check (status in ('GERADO','USADO','EXPIRADO')),
  expira_em timestamptz not null,
  usado_em timestamptz,
  criado_em timestamptz not null default now()
);

insert into configuracoes (chave, valor, descricao) values
  ('driver_plus_niveis', '{"PRATA":{"corridas_30d":80,"nota_min":4.7,"cancel_max_pct":10},"OURO":{"corridas_30d":200,"nota_min":4.8,"cancel_max_pct":5}}',
   'níveis por ATIVIDADE (nunca promessa de renda)')
on conflict (chave) do nothing;

create or replace function interno.nivel_motorista(p_uid uuid) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare n int; m motoristas; c numeric; cfg jsonb := interno.cfg('driver_plus_niveis'); v text := 'BRONZE'; prox text; req jsonb;
begin
  select * into m from motoristas where id = p_uid;
  select count(*) into n from corridas where motorista_id = p_uid and status = 'PAGA' and finalizada_em > now() - interval '30 days';
  select round(100.0 * count(*) filter (where e.tipo = 'CANCELAMENTO_MOTORISTA') / greatest(count(*) filter (where e.tipo in ('ACEITE')), 1), 1) into c
  from corrida_eventos e where e.ator_id = p_uid and e.criado_em > now() - interval '30 days' and e.tipo in ('ACEITE','CANCELAMENTO_MOTORISTA');
  if n >= (cfg -> 'OURO' ->> 'corridas_30d')::int and m.avaliacao_media >= (cfg -> 'OURO' ->> 'nota_min')::numeric and c <= (cfg -> 'OURO' ->> 'cancel_max_pct')::numeric then v := 'OURO';
  elsif n >= (cfg -> 'PRATA' ->> 'corridas_30d')::int and m.avaliacao_media >= (cfg -> 'PRATA' ->> 'nota_min')::numeric and c <= (cfg -> 'PRATA' ->> 'cancel_max_pct')::numeric then v := 'PRATA';
  end if;
  prox := case v when 'BRONZE' then 'PRATA' when 'PRATA' then 'OURO' end;
  req := case when prox is not null then cfg -> prox end;
  return jsonb_build_object('nivel', v, 'corridas_30d', n, 'nota', m.avaliacao_media, 'cancelamento_pct', c,
    'proximo_nivel', prox, 'requisitos_proximo', req,
    'aviso', 'Níveis são por atividade e qualidade. Não representam garantia ou promessa de renda.');
end $$;

create or replace function public.parceiros_proximos(p_lat float8, p_lng float8, p_tipo text default null, p_raio_km numeric default 10) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_mot boolean := exists (select 1 from motoristas where id = v_uid);
        v_nivel text := case when exists (select 1 from motoristas where id = v_uid) then interno.nivel_motorista(v_uid) ->> 'nivel' else 'BRONZE' end;
        v_assin boolean := interno.assinatura_ativa(v_uid) is not null; v_cid uuid := (select cidade_id from perfis where id = v_uid);
begin
  return coalesce((select jsonb_agg(x order by (x ->> 'distancia_km')::numeric nulls last) from (
    select jsonb_build_object('parceiro', p.id, 'nome', p.nome, 'tipo', p.tipo, 'endereco', p.endereco, 'telefone', p.telefone, 'horario', p.horario,
      'lat', p.lat, 'lng', p.lng,
      'distancia_km', case when p.lat is not null then round(interno.distancia_km(p_lat, p_lng, p.lat, p.lng)::numeric, 1) end,
      'texto', case p.tipo when 'POSTO' then 'Posto parceiro' when 'OFICINA' then 'Oficina parceira' when 'PNEUS' then 'Borracharia parceira'
                 when 'LAVAGEM' then 'Lava-rápido parceiro' when 'PECAS' then 'Loja de peças parceira' when 'SEGURO' then 'Seguro parceiro'
                 when 'FINANCIAMENTO' then 'Financiamento parceiro' when 'ESTACIONAMENTO' then 'Estacionamento parceiro'
                 when 'ASSISTENCIA' then 'Assistência parceira' else 'Parceiro' end || case when p.lat is not null then ' a '
               || interno.num(round(interno.distancia_km(p_lat, p_lng, p.lat, p.lng)::numeric, 1)) || ' km' else ' (online)' end || '.',
      'ofertas', (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'titulo', o.titulo, 'descricao', o.descricao,
                     'desconto_pct', o.desconto_pct, 'desconto_valor', o.desconto_valor, 'validade', o.validade,
                     'disponivel', (o.nivel_minimo = 'BRONZE' or (o.nivel_minimo = 'PRATA' and v_nivel in ('PRATA','OURO')) or (o.nivel_minimo = 'OURO' and v_nivel = 'OURO'))
                                   and (not o.so_assinantes or v_assin),
                     'requisito', case when o.nivel_minimo <> 'BRONZE' then 'Nível ' || o.nivel_minimo end)), '[]')
                  from parceiro_ofertas o where o.parceiro_id = p.id and o.ativo and (o.validade is null or o.validade >= current_date)
                    and (o.publico = 'AMBOS' or (o.publico = 'MOTORISTA' and v_mot) or (o.publico = 'PASSAGEIRO'))))
    as x
    from parceiros p
    where p.ativo and (p.contrato_fim is null or p.contrato_fim >= current_date) and (p_tipo is null or p.tipo = p_tipo)
      and (p.cidade_id is null or p.cidade_id = v_cid)
      and (p.lat is null or interno.distancia_km(p_lat, p_lng, p.lat, p.lng) <= p_raio_km)
    limit 50) y), '[]');
end $$;

create or replace function public.resgatar_oferta(p_oferta uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); o parceiro_ofertas; v_nivel text; v_cod text;
begin
  perform interno.limitar('resgate', 20, 3600);
  select * into o from parceiro_ofertas where id = p_oferta and ativo and (validade is null or validade >= current_date);
  if not found then perform interno.erro('OFERTA_INDISPONIVEL'); end if;
  if o.publico = 'MOTORISTA' and not exists (select 1 from motoristas where id = v_uid and status = 'ATIVO') then perform interno.erro('SO_PARA_MOTORISTAS'); end if;
  v_nivel := case when exists (select 1 from motoristas where id = v_uid) then interno.nivel_motorista(v_uid) ->> 'nivel' else 'BRONZE' end;
  if (o.nivel_minimo = 'PRATA' and v_nivel = 'BRONZE') or (o.nivel_minimo = 'OURO' and v_nivel <> 'OURO') then perform interno.erro('NIVEL_INSUFICIENTE', o.nivel_minimo); end if;
  if o.so_assinantes and interno.assinatura_ativa(v_uid) is null then perform interno.erro('SO_ASSINANTES_MOBI_MAIS'); end if;
  if (select count(*) from parceiro_resgates where oferta_id = p_oferta and usuario_id = v_uid) >= o.limite_por_usuario then perform interno.erro('LIMITE_DE_RESGATES'); end if;
  v_cod := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));
  insert into parceiro_resgates (oferta_id, usuario_id, codigo, expira_em) values (p_oferta, v_uid, v_cod, now() + interval '7 days');
  return jsonb_build_object('codigo', v_cod, 'expira_em', now() + interval '7 days',
    'instrucao', 'Mostre este código no parceiro. Nenhum dado pessoal seu é enviado ao parceiro.');
end $$;

create or replace function public.ops_validar_resgate(p_codigo text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); r parceiro_resgates;
begin
  select * into r from parceiro_resgates where codigo = upper(trim(p_codigo)) for update;
  if not found then return jsonb_build_object('valido', false, 'erro', 'CODIGO_INEXISTENTE'); end if;
  if r.status <> 'GERADO' or r.expira_em < now() then return jsonb_build_object('valido', false, 'erro', 'CODIGO_' || case when r.expira_em < now() then 'EXPIRADO' else r.status end); end if;
  update parceiro_resgates set status = 'USADO', usado_em = now() where id = r.id;
  return jsonb_build_object('valido', true, 'oferta', (select titulo from parceiro_ofertas where id = r.oferta_id));
end $$;

create or replace function public.admin_salvar_parceiro(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  insert into parceiros (id, nome, tipo, cnpj, cidade_id, lat, lng, endereco, telefone, horario, ativo, contrato_fim)
  values (coalesce(v_id, gen_random_uuid()), p ->> 'nome', p ->> 'tipo', interno.so_digitos(p ->> 'cnpj'), nullif(p ->> 'cidade_id', '')::uuid,
          (p ->> 'lat')::float8, (p ->> 'lng')::float8, p ->> 'endereco', p ->> 'telefone', p ->> 'horario', coalesce((p ->> 'ativo')::boolean, true),
          nullif(p ->> 'contrato_fim', '')::date)
  on conflict (id) do update set nome = excluded.nome, tipo = excluded.tipo, lat = excluded.lat, lng = excluded.lng, endereco = excluded.endereco,
    telefone = excluded.telefone, horario = excluded.horario, ativo = excluded.ativo, contrato_fim = excluded.contrato_fim
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.admin_salvar_oferta_parceiro(p jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  insert into parceiro_ofertas (id, parceiro_id, titulo, descricao, publico, nivel_minimo, so_assinantes, desconto_pct, desconto_valor, validade, limite_por_usuario, ativo)
  values (coalesce(v_id, gen_random_uuid()), (p ->> 'parceiro_id')::uuid, p ->> 'titulo', p ->> 'descricao', coalesce(p ->> 'publico', 'MOTORISTA'),
          coalesce(p ->> 'nivel_minimo', 'BRONZE'), coalesce((p ->> 'so_assinantes')::boolean, false), nullif(p ->> 'desconto_pct', '')::numeric,
          nullif(p ->> 'desconto_valor', '')::numeric, nullif(p ->> 'validade', '')::date, coalesce((p ->> 'limite_por_usuario')::int, 1), coalesce((p ->> 'ativo')::boolean, true))
  on conflict (id) do update set titulo = excluded.titulo, descricao = excluded.descricao, publico = excluded.publico, nivel_minimo = excluded.nivel_minimo,
    so_assinantes = excluded.so_assinantes, desconto_pct = excluded.desconto_pct, desconto_valor = excluded.desconto_valor, validade = excluded.validade,
    limite_por_usuario = excluded.limite_por_usuario, ativo = excluded.ativo
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.driver_plus() returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); p motorista_presenca;
begin
  select * into p from motorista_presenca where motorista_id = v_uid;
  return jsonb_build_object(
    'nivel', interno.nivel_motorista(v_uid),
    'ferramentas', jsonb_build_object('painel', 'painel_motorista', 'historico', 'rentabilidade_historico', 'meta', 'salvar_meta',
                                      'custos', 'salvar_custos', 'assistente', 'assistente_motorista'),
    'manutencao', (select jsonb_build_object('km_30d', round(coalesce(sum(coalesce(distancia_real_km, 0)), 0), 0),
                     'ultima_manutencao_lancada', (select max(data) from custos_lancados where motorista_id = v_uid and tipo in ('MANUTENCAO','PNEUS')))
                   from corridas where motorista_id = v_uid and finalizada_em > now() - interval '30 days'),
    'parceiros', case when p.lat is not null then public.parceiros_proximos(p.lat, p.lng, null, 15) else '[]'::jsonb end,
    'resgates', (select coalesce(jsonb_agg(jsonb_build_object('codigo', r.codigo, 'status', r.status, 'expira_em', r.expira_em,
                    'oferta', (select titulo from parceiro_ofertas where id = r.oferta_id)) order by r.criado_em desc), '[]')
                 from parceiro_resgates r where r.usuario_id = v_uid));
end $$;
create or replace function interno.cobrar_corrida(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; p pagamentos; v_valor numeric; v_metodo metodo_pagamento; v_desc numeric;
begin
  select * into c from corridas where id = p_corrida for update;
  -- cupom e Mobi+ (a plataforma absorve o desconto; o motorista recebe sobre o preço cheio)
  v_desc := interno.aplicar_descontos(c);
  v_valor := c.preco_final - v_desc;
  v_metodo := c.metodo_pagamento;
  if v_metodo = 'CARTEIRA' and interno.travar_saldo(c.passageiro_id, 'PASSAGEIRO_CARTEIRA') < v_valor then
    v_metodo := 'PIX';   -- saldo insuficiente: cobra por PIX (e avisa)
  end if;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p_corrida, c.passageiro_id, 'CORRIDA', v_metodo, v_valor, 'CORRIDA:' || p_corrida)
  on conflict (chave_idempotencia) do nothing
  returning * into p;
  if p.id is null then
    select * into p from pagamentos where chave_idempotencia = 'CORRIDA:' || p_corrida;
    return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'metodo', p.metodo, 'repetido', true);
  end if;

  if v_metodo in ('DINHEIRO','CARTEIRA','EMPRESA') then
    -- dinheiro: o motorista já recebeu na mão | carteira: débito interno | empresa: vai para a fatura
    return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor);
  end if;
  perform interno.notificar(c.passageiro_id, 'PAGAMENTO', 'Pagamento da corrida',
    'Valor: R$ ' || to_char(v_valor, 'FM999990D00') || case when v_metodo = 'PIX' then ' · pague pelo PIX' else '' end,
    jsonb_build_object('pagamento', p.id, 'corrida', p_corrida));
  return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'metodo', p.metodo);
end $$;

create or replace function interno.confirmar_pagamento(p_pagamento uuid, p_gateway text, p_gateway_ref text, p_valor numeric)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare p pagamentos; c corridas; v_tx uuid; r regras_comissao; v_motorista_val numeric; v_origem text;
begin
  select * into p from pagamentos where id = p_pagamento for update;
  if not found then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  if p.status = 'CONFIRMADO' then
    return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'repetido', true);
  end if;
  if p.status in ('ESTORNADO','CANCELADO') then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'CONFIRMACAO_APOS_CANCELAMENTO', 3, jsonb_build_object('gateway_ref', p_gateway_ref));
    return jsonb_build_object('id', p.id, 'status', p.status, 'erro', 'PAGAMENTO_NAO_CONFIRMAVEL');
  end if;
  if round(p_valor, 2) <> p.valor then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'VALOR_DIVERGENTE', 4,
      jsonb_build_object('esperado', p.valor, 'recebido', p_valor, 'gateway_ref', p_gateway_ref));
    return jsonb_build_object('id', p.id, 'status', p.status, 'erro', 'VALOR_DIVERGENTE');
  end if;
  -- [auditoria] cobrança que falhou, foi substituída e o gateway confirmou depois: o dinheiro entrou duas vezes.
  -- Não quebra o webhook (senão ele fica sendo reenviado para sempre): registra para devolução.
  if p.status = 'FALHOU' and p.corrida_id is not null and exists (select 1 from pagamentos o where o.corrida_id = p.corrida_id and o.tipo = p.tipo
       and o.id <> p.id and o.status in ('PENDENTE','AUTORIZADO','CONFIRMADO')) then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'PAGAMENTO_SUBSTITUIDO_CONFIRMADO', 2,
      jsonb_build_object('gateway', p_gateway, 'gateway_ref', p_gateway_ref, 'valor', p_valor, 'acao', 'devolver ao cliente'));
    update pagamentos set motivo_falha = left('Confirmado pelo gateway depois de substituído (' || coalesce(p_gateway_ref, '') || '): DEVOLVER', 300) where id = p.id;
    return jsonb_build_object('id', p.id, 'status', p.status, 'erro', 'PAGAMENTO_SUBSTITUIDO_DEVOLVER');
  end if;
  if p.tipo = 'ASSINATURA' and (select status from assinaturas where id = p.assinatura_id) = 'CANCELADA' then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'ASSINATURA_CANCELADA_PAGA', 2, jsonb_build_object('gateway_ref', p_gateway_ref, 'acao', 'devolver ao cliente'));
    update pagamentos set status = 'CANCELADO', motivo_falha = 'Pago depois do cancelamento da assinatura: DEVOLVER' where id = p.id;
    return jsonb_build_object('id', p.id, 'status', 'CANCELADO', 'erro', 'ASSINATURA_CANCELADA_DEVOLVER');
  end if;
  -- créditos da carteira não podem pagar recarga de créditos nem fatura de empresa
  if p.metodo = 'CARTEIRA' and p.tipo in ('RECARGA','FATURA_EMPRESA') then perform interno.erro('METODO_INVALIDO_PARA_ESTE_PAGAMENTO'); end if;

  update pagamentos set status = 'CONFIRMADO', gateway = p_gateway, gateway_ref = p_gateway_ref, confirmado_em = now()
  where id = p.id;
  v_origem := case when p.metodo = 'DINHEIRO' then 'DINHEIRO' when p.metodo = 'CARTEIRA' then 'CARTEIRA' when p.metodo = 'EMPRESA' then 'EMPRESA' else 'GATEWAY' end;

  if p.tipo = 'CORRIDA' then
    v_tx := interno.liquidar_corrida(p.corrida_id, p.id, v_origem);

  elsif p.tipo = 'GORJETA' then
    select * into c from corridas where id = p.corrida_id;
    v_tx := interno.lancar('GORJETA', p.corrida_id::text, 'GORJETA:' || p.id, 'Gorjeta (100% para o motorista)',
      jsonb_build_array(
        case when v_origem = 'CARTEIRA' then jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -p.valor)
             else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor) end,
        jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', p.valor)));
    insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
    values (p.corrida_id, p.id, c.motorista_id, 'GORJETA', p.valor, now() + make_interval(days => interno.cfg_num('motorista_liberacao_dias', 1)::int))
    on conflict (pagamento_id) do nothing;
    perform interno.notificar(c.motorista_id, 'PAGAMENTO', 'Você recebeu uma gorjeta!', 'R$ ' || to_char(p.valor, 'FM999990D00'), jsonb_build_object('corrida', c.id));

  elsif p.tipo = 'TAXA_CANCELAMENTO' then
    select * into c from corridas where id = p.corrida_id;
    r := interno.resolver_comissao(c.cidade_id, c.categoria, c.motorista_id, c.solicitada_em);
    v_motorista_val := case when c.motorista_id is null then 0 else p.valor - round(p.valor * coalesce(r.taxa_plataforma_pct, 0) / 100, 2) end;
    v_tx := interno.lancar('TAXA_CANCELAMENTO', p.corrida_id::text, 'TAXA:' || p.id, 'Taxa de cancelamento',
      jsonb_build_array(
        case when v_origem = 'CARTEIRA' then jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -p.valor)
             when v_origem = 'EMPRESA' then jsonb_build_object('titular', c.empresa_id, 'conta', 'EMPRESA_A_RECEBER', 'valor', -p.valor)
             else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor) end,
        jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', v_motorista_val),
        jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', p.valor - v_motorista_val)));
    if v_motorista_val > 0 then
      insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
      values (p.corrida_id, p.id, c.motorista_id, 'TAXA_CANCELAMENTO', v_motorista_val,
              now() + make_interval(days => interno.cfg_num('motorista_liberacao_dias', 1)::int))
      on conflict (pagamento_id) do nothing;
    end if;

  elsif p.tipo = 'ASSINATURA' then
    v_tx := interno.lancar('ASSINATURA', p.id::text, 'ASSIN:' || p.id, 'Mobi+ (assinatura mensal)',
      jsonb_build_array(
        case when v_origem = 'CARTEIRA' then jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -p.valor)
             else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor) end,
        jsonb_build_object('conta', 'PLATAFORMA_ASSINATURAS', 'valor', p.valor)));
    update assinaturas set status = 'ATIVA', renova_em = greatest(coalesce(renova_em, now()), now()) + interval '30 days', inadimplente_desde = null
    where id = p.assinatura_id;
    perform interno.notificar(p.pagador_id, 'PAGAMENTO', 'Mobi+ ativo', 'Seus benefícios estão valendo.', '{}');

  elsif p.tipo = 'FATURA_EMPRESA' then
    v_tx := interno.lancar('FATURA_EMPRESA', p.fatura_id::text, 'FAT:' || p.id, 'Pagamento de fatura corporativa',
      jsonb_build_array(jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor),
                        jsonb_build_object('titular', (select empresa_id from empresa_faturas where id = p.fatura_id), 'conta', 'EMPRESA_A_RECEBER', 'valor', p.valor)));
    update empresa_faturas set status = 'PAGA', paga_em = now() where id = p.fatura_id;

  elsif p.tipo = 'RECARGA' then
    v_tx := interno.lancar('RECARGA', p.id::text, 'RECARGA:' || p.id, 'Recarga de carteira',
      jsonb_build_array(jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor),
                        jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', p.valor)));
  end if;

  update pagamentos set transacao_ledger_id = v_tx where id = p.id;
  return jsonb_build_object('id', p.id, 'status', 'CONFIRMADO', 'valor', p.valor, 'transacao', v_tx);
end $$;

create or replace function interno.liquidar_corrida(p_corrida uuid, p_pagamento uuid, p_origem text) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare
  c corridas; r regras_comissao; v_bruto numeric; v_pago numeric; v_plat numeric; v_motorista numeric; v_ref_total numeric := 0;
  v_linhas jsonb := '[]'; v_tx uuid; a record; v_pct numeric; v_val numeric; v_status status_ganho; v_motivo text;
  v_min_corr int; v_valida boolean; v_corridas_indicado int; v_suspeita boolean; v_ganhos jsonb := '[]';
begin
  select * into c from corridas where id = p_corrida for update;
  if exists (select 1 from transacoes_ledger where chave_idempotencia = 'LIQ:' || p_corrida) then
    return (select id from transacoes_ledger where chave_idempotencia = 'LIQ:' || p_corrida);
  end if;

  -- antifraude roda ANTES de decidir bônus
  perform interno.detectar_fraude_corrida(p_corrida);

  r := interno.resolver_comissao(c.cidade_id, c.categoria, c.motorista_id, c.solicitada_em);
  if r.id is null then perform interno.erro('SEM_REGRA_DE_COMISSAO'); end if;

  v_bruto := c.preco_final;                         -- base da comissão (sem gorjeta)
  v_pago := c.preco_final - c.desconto;             -- o que o passageiro efetivamente pagou
  v_plat := round(v_bruto * r.taxa_plataforma_pct / 100, 2);
  v_motorista := v_bruto - v_plat;

  -- elegibilidade da corrida para bônus de indicação
  v_valida := coalesce(c.distancia_real_km, 0) >= interno.cfg_num('corrida_valida_min_km', 1)
          and coalesce(c.duracao_real_min, 0) >= interno.cfg_num('corrida_valida_min_minutos', 3);
  v_min_corr := interno.cfg_num('indicacao_min_corridas_indicado', 5)::int;
  select count(*) into v_corridas_indicado from corridas
  where motorista_id = c.motorista_id and status in ('FINALIZADA','PAGA') and id <> c.id
    and coalesce(distancia_real_km, 0) >= interno.cfg_num('corrida_valida_min_km', 1);
  v_suspeita := exists (select 1 from sinais_fraude where status in ('ABERTO','EM_ANALISE') and severidade >= 3
                        and ((entidade_tipo = 'CORRIDA' and entidade_id = c.id::text)
                          or (entidade_tipo = 'USUARIO' and entidade_id = c.motorista_id::text)));

  for a in select * from interno.cadeia_indicacao(c.motorista_id, 3) loop
    v_pct := case a.nivel when 1 then r.indicacao_n1_pct when 2 then r.indicacao_n2_pct else r.indicacao_n3_pct end;
    v_val := least(round(v_bruto * v_pct / 100, 2), v_plat - v_ref_total);   -- arredondamento nunca deixa a plataforma negativa
    continue when v_val <= 0;
    -- regras de atividade válida (não paga só por cadastro): sem bônus, plataforma fica com o valor
    continue when not v_valida or v_corridas_indicado < v_min_corr;
    continue when not exists (select 1 from motoristas m join perfis p on p.id = m.id
                              where m.id = a.beneficiario_id and m.status not in ('BLOQUEADO','INATIVO') and p.status = 'ATIVO');
    -- o beneficiário não pode ser o próprio passageiro (corrida "fabricada")
    if a.beneficiario_id = c.passageiro_id then
      perform interno.registrar_sinal('CORRIDA', c.id::text, 'AUTO_BENEFICIO_INDICACAO', 4,
        jsonb_build_object('beneficiario', a.beneficiario_id, 'nivel', a.nivel));
      v_suspeita := true;
    end if;

    if v_suspeita or a.status <> 'ATIVA' then
      v_status := 'BLOQUEADO';
      v_motivo := case when a.status <> 'ATIVA' then 'Indicação ' || a.status else 'Corrida em análise antifraude' end;
      v_linhas := v_linhas || jsonb_build_object('conta', 'INDICACAO_RETIDA', 'valor', v_val);   -- retido até decisão humana
    else
      v_status := 'PENDENTE'; v_motivo := null;
      v_linhas := v_linhas || jsonb_build_object('titular', a.beneficiario_id, 'conta', 'INDICACAO_PENDENTE', 'valor', v_val);
    end if;
    v_ref_total := v_ref_total + v_val;
    v_ganhos := v_ganhos || jsonb_build_object('nivel', a.nivel, 'beneficiario', a.beneficiario_id, 'pct', v_pct,
                                               'valor', v_val, 'status', v_status, 'motivo', v_motivo);
  end loop;

  -- origem do dinheiro
  if p_origem = 'DINHEIRO' then
    -- motorista já está com o dinheiro: fica devendo a parte da plataforma (descontada nos próximos ganhos)
    v_linhas := v_linhas || jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_DISPONIVEL', 'valor', -(v_plat - c.desconto));
  else
    v_linhas := v_linhas
      || case when p_origem = 'CARTEIRA' then jsonb_build_object('titular', c.passageiro_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -v_pago)
              when p_origem = 'EMPRESA' then jsonb_build_object('titular', c.empresa_id, 'conta', 'EMPRESA_A_RECEBER', 'valor', -v_pago)
              else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -v_pago) end
      || jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', v_motorista);
  end if;
  v_linhas := v_linhas
    || jsonb_build_object('conta', 'PLATAFORMA_PROMOCOES', 'valor', -c.desconto)
    || jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', v_plat - v_ref_total);

  v_tx := interno.lancar('LIQUIDACAO_CORRIDA', p_corrida::text, 'LIQ:' || p_corrida,
    'Corrida R$ ' || v_bruto || ' · taxa ' || r.taxa_plataforma_pct || '% (' || r.nome || ')', v_linhas);

  insert into ganhos_indicacao (corrida_id, beneficiario_id, indicado_id, nivel, percentual, valor, status, motivo, libera_em)
  select p_corrida, (g ->> 'beneficiario')::uuid, c.motorista_id, (g ->> 'nivel')::int, (g ->> 'pct')::numeric, (g ->> 'valor')::numeric,
         (g ->> 'status')::status_ganho, g ->> 'motivo',
         now() + make_interval(days => interno.cfg_num('indicacao_carencia_dias', 7)::int)
  from jsonb_array_elements(v_ganhos) g;

  if p_origem <> 'DINHEIRO' then
    insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
    values (p_corrida, p_pagamento, c.motorista_id, 'CORRIDA', v_motorista,
            now() + make_interval(days => interno.regra_num(c.cidade_id, 'motorista_liberacao_dias', 1)::int));
  end if;

  update corridas set status = 'PAGA', paga_em = now(), versao = versao + 1 where id = p_corrida;
  perform interno.evento(p_corrida, 'PAGAMENTO', 'FINALIZADA', 'PAGA',
    jsonb_build_object('transacao', v_tx, 'bruto', v_bruto, 'motorista', v_motorista, 'plataforma', v_plat - v_ref_total,
                       'indicacao', v_ref_total, 'regra', r.nome, 'origem', p_origem, 'ganhos_indicacao', v_ganhos));
  perform interno.notificar(c.motorista_id, 'PAGAMENTO', 'Corrida paga',
    'Seu ganho: R$ ' || to_char(v_motorista, 'FM999990D00') || case when p_origem = 'DINHEIRO' then ' (recebido em dinheiro)' else '' end,
    jsonb_build_object('corrida', c.id));
  return v_tx;
end $$;

create or replace function interno.cobrar_taxa_cancelamento(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; p pagamentos; v_metodo metodo_pagamento; v_isento boolean;
begin
  select * into c from corridas where id = p_corrida;
  if coalesce(c.taxa_cancelamento, 0) <= 0 or c.motorista_id is null and c.cancelado_por = 'PASSAGEIRO' and c.aceita_em is null then return null; end if;
  -- Mobi+: cancelamentos grátis no mês
  v_isento := interno.cancelamento_gratis_disponivel(c.passageiro_id);
  if v_isento then
    insert into assinatura_usos (assinatura_id, tipo, corrida_id)
    select a.id, 'CANCELAMENTO_GRATIS', c.id from assinaturas a where a.usuario_id = c.passageiro_id and a.status in ('ATIVA','CANCELADA') and a.renova_em > now()
    order by a.renova_em desc limit 1;
    perform interno.evento(c.id, 'TAXA_DISPENSADA', c.status, c.status, jsonb_build_object('motivo', 'benefício Mobi+'));
    return jsonb_build_object('isento', true, 'motivo', 'Mobi+');
  end if;
  -- empresa: a taxa vai para a fatura
  if c.metodo_pagamento = 'EMPRESA' then
    insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
    values (p_corrida, c.passageiro_id, 'TAXA_CANCELAMENTO', 'EMPRESA', c.taxa_cancelamento, 'TAXA_CANC:' || p_corrida)
    on conflict (chave_idempotencia) do nothing returning * into p;
    if p.id is null then return null; end if;
    return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor);
  end if;
  v_metodo := case when c.metodo_pagamento = 'DINHEIRO' then 'PIX'
                   when c.metodo_pagamento = 'CARTEIRA' and interno.travar_saldo(c.passageiro_id, 'PASSAGEIRO_CARTEIRA') < c.taxa_cancelamento then 'PIX'
                   else c.metodo_pagamento end;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p_corrida, c.passageiro_id, 'TAXA_CANCELAMENTO', v_metodo, c.taxa_cancelamento, 'TAXA_CANC:' || p_corrida)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then return null; end if;
  if v_metodo = 'CARTEIRA' then
    return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor);
  end if;
  return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor);
end $$;
-- ============================================================
-- RLS das tabelas novas (apps leem pelas RPCs; leitura direta mínima)
-- ============================================================
do $$
declare t text;
begin
  foreach t in array array['empresas','empresa_departamentos','empresa_centros_custo','empresa_membros','empresa_convites',
                           'empresa_politicas','empresa_faturas','planos_assinatura','assinaturas','assinatura_usos',
                           'parceiros','parceiro_ofertas','parceiro_resgates'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;
select interno.criar_politica('empresa_membros', 'proprio', 'usuario_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('empresas', 'membros',
  $p$interno.eh_staff() or exists (select 1 from empresa_membros m where m.empresa_id = empresas.id and m.usuario_id = auth.uid() and m.ativo)$p$);
select interno.criar_politica('empresa_departamentos', 'membros',
  $p$interno.eh_staff() or exists (select 1 from empresa_membros m where m.empresa_id = empresa_departamentos.empresa_id and m.usuario_id = auth.uid() and m.ativo)$p$);
select interno.criar_politica('empresa_centros_custo', 'membros',
  $p$interno.eh_staff() or exists (select 1 from empresa_membros m where m.empresa_id = empresa_centros_custo.empresa_id and m.usuario_id = auth.uid() and m.ativo)$p$);
select interno.criar_politica('empresa_politicas', 'membros',
  $p$interno.eh_staff() or exists (select 1 from empresa_membros m where m.empresa_id = empresa_politicas.empresa_id and m.usuario_id = auth.uid() and m.ativo)$p$);
-- faturas e convites: só staff lê direto; gestor/financeiro da empresa usam empresa_relatorio
select interno.criar_politica('empresa_faturas', 'staff', $p$interno.eh_papel('{FINANCEIRO,ADMIN}')$p$);
select interno.criar_politica('empresa_convites', 'staff', 'interno.eh_staff()');
select interno.criar_politica('planos_assinatura', 'todos', 'ativo or interno.eh_staff()');
select interno.criar_politica('assinaturas', 'proprio', 'usuario_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('assinatura_usos', 'proprio',
  $p$interno.eh_staff() or exists (select 1 from assinaturas a where a.id = assinatura_usos.assinatura_id and a.usuario_id = auth.uid())$p$);
select interno.criar_politica('parceiros', 'todos', 'ativo or interno.eh_staff()');
select interno.criar_politica('parceiro_ofertas', 'todos', 'ativo or interno.eh_staff()');
select interno.criar_politica('parceiro_resgates', 'proprio', 'usuario_id = auth.uid() or interno.eh_staff()');

-- ============================================================
-- Agenda: faturas e assinaturas entram no job diário
-- ============================================================
create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object(
      'matching', interno.rodar_job('matching', 'interno.job_matching()'),
      'seguranca', interno.rodar_job('seguranca', 'interno.job_seguranca_v2()'),
      'travadas', interno.rodar_job('corridas_travadas', 'interno.job_corridas_travadas()'));
  elsif p_qual = 'inteligencia' then
    return jsonb_build_object('inteligencia', interno.rodar_job('inteligencia', 'interno.job_inteligencia()'));
  elsif p_qual = 'horario' then
    return jsonb_build_object('liberacao', interno.rodar_job('liberar_saldos', 'interno.job_liberar_saldos()'));
  else
    return jsonb_build_object(
      'limites', interno.rodar_job('limpar_limites', 'interno.limpar_limites()'),
      'documentos', interno.rodar_job('documentos', 'interno.job_documentos()'),
      'risco', interno.rodar_job('risco', 'interno.job_risco_v2()'),
      'empresas', interno.rodar_job('empresas', 'interno.job_empresas()'),
      'assinaturas', interno.rodar_job('assinaturas', 'interno.job_assinaturas()'),
      'retencao', interno.rodar_job('retencao', 'interno.job_retencao()'));
  end if;
end $$;

insert into funcoes_servidor (assinatura) values ('public.executar_jobs(text)') on conflict do nothing;
select interno.aplicar_permissoes_funcoes();
