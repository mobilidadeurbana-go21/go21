// Edge Function: POST /functions/v1/criar-cobranca  { "pagamento_id": "<uuid>" }   (exige login)
// Segredos: GATEWAY=simulado|<nome do adaptador real>, AMBIENTE=producao|homologacao, APP_ORIGEM=https://seu-dominio
import { criarRpc } from '../_shared/rpc.ts';
import { tratarCobranca, gatewaySimulado, type Gateway } from '../_shared/cobranca.ts';

const ORIGEM = Deno.env.get('APP_ORIGEM') ?? '*';
const CORS = { 'Access-Control-Allow-Origin': ORIGEM, 'Access-Control-Allow-Headers': 'authorization, apikey, content-type', 'Content-Type': 'application/json' };
const GATEWAYS: Record<string, Gateway> = { simulado: gatewaySimulado /* , meugateway: gatewayReal */ };

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405, headers: CORS });
  const jwt = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!jwt) return new Response(JSON.stringify({ erro: 'LOGIN_NECESSARIO' }), { status: 401, headers: CORS });
  let corpo: any; try { corpo = await req.json(); } catch { corpo = {}; }
  const url = Deno.env.get('SUPABASE_URL')!;
  const r = await tratarCobranca({
    pagamentoId: corpo?.pagamento_id,
    rpcUsuario: criarRpc(url, Deno.env.get('SUPABASE_ANON_KEY')!, jwt),
    rpcServidor: criarRpc(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!),
    gateway: GATEWAYS[Deno.env.get('GATEWAY') ?? ''] ?? null,
    producao: (Deno.env.get('AMBIENTE') ?? 'producao') === 'producao',
  }).catch((e) => ({ status: 502, corpo: { erro: 'FALHA_NO_GATEWAY', detalhe: String(e?.message ?? e).slice(0, 200) } }));
  return new Response(JSON.stringify(r.corpo), { status: r.status, headers: CORS });
});
