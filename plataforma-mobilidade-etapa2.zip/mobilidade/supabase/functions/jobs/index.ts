// Alternativa ao pg_cron: um agendador externo chama POST /functions/v1/jobs?qual=rapido|inteligencia|horario|diario
// com o cabeçalho x-segredo-cron. Se o pg_cron estiver ligado no projeto, esta função não é necessária.
import { criarRpc } from '../_shared/rpc.ts';
import { compararSeguro } from '../_shared/seguranca.ts';

Deno.serve(async (req: Request) => {
  const segredo = Deno.env.get('CRON_SEGREDO');
  if (!segredo || !compararSeguro(segredo, req.headers.get('x-segredo-cron') ?? '')) return new Response('Unauthorized', { status: 401 });
  const qual = new URL(req.url).searchParams.get('qual') ?? 'rapido';
  if (!['rapido', 'inteligencia', 'horario', 'diario'].includes(qual)) return new Response('Bad Request', { status: 400 });
  const rpc = criarRpc(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  try {
    return new Response(JSON.stringify(await rpc('executar_jobs', { p_qual: qual })), { headers: { 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ erro: e instanceof Error ? e.message : 'ERRO' }), { status: 500 });
  }
});
