// Edge Function: POST /functions/v1/webhook-pagamento?gateway=generico
// Publicar SEM verificação de JWT (o gateway não tem login): supabase functions deploy webhook-pagamento --no-verify-jwt
// A autenticação é a assinatura HMAC do próprio gateway. Segredos (supabase secrets set ...):
//   WEBHOOK_SEGREDO_GENERICO=...   (um por gateway: WEBHOOK_SEGREDO_<NOME>)
// SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY já existem no ambiente das Edge Functions.
import { tratarWebhook } from '../_shared/webhook.ts';
import { criarRpc } from '../_shared/rpc.ts';

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const gateway = (new URL(req.url).searchParams.get('gateway') || 'generico').toLowerCase();
  const corpoCru = await req.text();
  const rpc = criarRpc(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const r = await tratarWebhook({
    gateway, headers: req.headers, corpoCru, agoraSeg: Math.floor(Date.now() / 1000),
    segredo: Deno.env.get(`WEBHOOK_SEGREDO_${gateway.toUpperCase()}`), rpc,
  });
  return new Response(JSON.stringify(r.corpo), { status: r.status, headers: { 'Content-Type': 'application/json' } });
});
