// Núcleo do webhook de pagamento — sem Deno/Node específicos, testável.
// Fluxo: autentica (HMAC + janela de tempo) → valida o conteúdo → traduz o formato
// do gateway → processa no banco (idempotente por gateway+evento) → registra a tentativa.
// Resposta: 200 processado/duplicado · 401 assinatura · 400 conteúdo inválido (não reenviar)
//           500 falha temporária (o gateway reenvia; como nada foi gravado, o reenvio funciona).
import { verificarAssinatura, ipDaRequisicao, UUID_RE } from './seguranca.ts';
import { ErroRpc, type Rpc } from './rpc.ts';

export type EventoInterno = {
  evento_id: string;
  tipo: 'PAGAMENTO_CONFIRMADO' | 'PAGAMENTO_FALHOU' | 'ESTORNO_CONFIRMADO' | 'OUTRO';
  pagamento_id: string;        // o id do NOSSO pagamento, enviado ao gateway como referência externa
  valor?: number;
  gateway_ref?: string;
  motivo?: string;
};

// Cada gateway manda um formato. O adaptador traduz para o formato interno.
// "generico" é o contrato próprio da plataforma (usado em homologação e por um intermediário).
// Para um gateway real (Pagar.me, Mercado Pago, Asaas, Stripe…), crie um adaptador seguindo a
// documentação dele — e use o mecanismo de assinatura que ELE define (ver docs/INTEGRACOES.md).
export const adaptadores: Record<string, (c: any) => EventoInterno> = {
  generico: (c) => ({
    evento_id: String(c.evento_id ?? ''),
    tipo: (['PAGAMENTO_CONFIRMADO', 'PAGAMENTO_FALHOU', 'ESTORNO_CONFIRMADO'].includes(c.tipo) ? c.tipo : 'OUTRO'),
    pagamento_id: String(c.pagamento_id ?? ''),
    valor: c.valor === undefined ? undefined : Number(c.valor),
    gateway_ref: c.gateway_ref === undefined ? undefined : String(c.gateway_ref),
    motivo: c.motivo === undefined ? undefined : String(c.motivo).slice(0, 300),
  }),
};

export function validarEvento(e: EventoInterno): string | null {
  if (!e.evento_id || e.evento_id.length > 200) return 'EVENTO_ID_INVALIDO';
  if (!UUID_RE.test(e.pagamento_id)) return 'PAGAMENTO_ID_INVALIDO';
  if (e.tipo === 'PAGAMENTO_CONFIRMADO') {
    if (typeof e.valor !== 'number' || !Number.isFinite(e.valor) || e.valor <= 0 || e.valor > 100000) return 'VALOR_INVALIDO';
    if (Math.abs(e.valor * 100 - Math.round(e.valor * 100)) > 1e-6) return 'VALOR_COM_MAIS_DE_2_CASAS';
  }
  if (e.gateway_ref && e.gateway_ref.length > 200) return 'GATEWAY_REF_INVALIDO';
  return null;
}

export type Resposta = { status: number; corpo: Record<string, unknown> };

export async function tratarWebhook(opts: {
  gateway: string; headers: Headers; corpoCru: string; agoraSeg: number;
  segredo: string | undefined; rpc: Rpc; registrarTentativas?: boolean;
}): Promise<Resposta> {
  const { gateway, headers, corpoCru, agoraSeg, segredo, rpc } = opts;
  const t0 = Date.now();
  const ip = ipDaRequisicao(headers);
  let eventoId: string | null = null, tipo: string | null = null, assinaturaOk = false;

  const registrar = async (status: number, erro: string | null) => {
    if (opts.registrarTentativas === false) return;
    try {
      await rpc('registrar_tentativa_webhook', { p_gateway: gateway, p_evento_id: eventoId, p_tipo: tipo, p_assinatura_valida: assinaturaOk,
        p_ip: ip, p_status: status, p_erro: erro, p_duracao_ms: Date.now() - t0 });
    } catch { /* log nunca derruba o webhook */ }
  };
  const responder = async (status: number, corpo: Record<string, unknown>, erro: string | null = null): Promise<Resposta> => {
    await registrar(status, erro);
    return { status, corpo };
  };

  if (!/^[a-z0-9_-]{2,30}$/.test(gateway) || !adaptadores[gateway]) return responder(404, { erro: 'GATEWAY_DESCONHECIDO' }, 'gateway desconhecido');
  if (!segredo) return responder(500, { erro: 'SEGREDO_NAO_CONFIGURADO' }, 'segredo do gateway não configurado');   // fecha por padrão
  if (corpoCru.length > 64 * 1024) return responder(413, { erro: 'CORPO_GRANDE_DEMAIS' }, 'corpo > 64 KB');

  const ass = await verificarAssinatura({ segredo, corpo: corpoCru, timestamp: headers.get('x-timestamp'), assinatura: headers.get('x-assinatura'), agoraSeg });
  if (!ass.ok) return responder(401, { erro: ass.motivo }, ass.motivo);
  assinaturaOk = true;

  let bruto: unknown;
  try { bruto = JSON.parse(corpoCru); } catch { return responder(400, { erro: 'JSON_INVALIDO' }, 'json inválido'); }
  const ev = adaptadores[gateway](bruto);
  eventoId = ev.evento_id || null; tipo = ev.tipo;
  const inval = validarEvento(ev);
  if (inval) return responder(400, { erro: inval }, inval);
  if (ev.tipo === 'OUTRO') return responder(200, { ignorado: true });

  try {
    const r = await rpc('processar_webhook', {
      p_gateway: gateway, p_evento_id: ev.evento_id, p_tipo: ev.tipo,
      p_payload: { pagamento_id: ev.pagamento_id, valor: ev.valor, gateway_ref: ev.gateway_ref, motivo: ev.motivo },
    }) as Record<string, unknown>;
    // valor divergente / pagamento cancelado: o banco registrou o sinal de fraude; não adianta reenviar
    return responder(200, { ok: true, resultado: r }, (r && (r as any).erro) ? String((r as any).erro) : null);
  } catch (e) {
    if (e instanceof ErroRpc && e.definitivo) return responder(422, { erro: e.message }, e.message);
    return responder(500, { erro: 'FALHA_TEMPORARIA' }, e instanceof Error ? e.message : String(e));
  }
}
