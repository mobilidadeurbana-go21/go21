// Camada OPCIONAL de linguagem natural para os assistentes (motorista e admin).
// Quem decide os números é sempre o BANCO (assistente_motorista / assistente_admin).
// O modelo de linguagem só reescreve o texto — e a resposta dele é descartada se trouxer
// qualquer número que não esteja nos dados. Sem chave configurada, a resposta é a do banco.

export type Fatos = { intencao: string; resposta: string; dados_suficientes: boolean; dados?: unknown };

// "R$ 1.234,56" → 1234.56 · "4–7 minutos" → 4 e 7 · "32%" → 32 · datas "05/10" → 5 e 10
export function numerosDe(texto: string): number[] {
  const out: number[] = [];
  const re = /\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:[.,]\d+)?/g;
  for (const m of texto.matchAll(re)) {
    let s = m[0];
    if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(',', '.');
    const n = Number(s);
    if (Number.isFinite(n)) out.push(n);
  }
  return out;
}

function numerosDosDados(v: unknown, acc: number[] = []): number[] {
  if (typeof v === 'number') acc.push(v);
  else if (typeof v === 'string') acc.push(...numerosDe(v));
  else if (Array.isArray(v)) v.forEach((x) => numerosDosDados(x, acc));
  else if (v && typeof v === 'object') Object.values(v).forEach((x) => numerosDosDados(x, acc));
  return acc;
}

export function textoSeguro(fatos: Fatos, textoModelo: string | null | undefined): { texto: string; usouModelo: boolean; motivo?: string } {
  if (!textoModelo || !textoModelo.trim()) return { texto: fatos.resposta, usouModelo: false, motivo: 'sem texto do modelo' };
  const t = textoModelo.trim();
  if (t.length > 900) return { texto: fatos.resposta, usouModelo: false, motivo: 'texto longo demais' };
  if (/https?:\/\/|www\./i.test(t)) return { texto: fatos.resposta, usouModelo: false, motivo: 'link não permitido' };
  if (!fatos.dados_suficientes) return { texto: fatos.resposta, usouModelo: false, motivo: 'dados insuficientes: resposta do banco' };
  const permitidos = numerosDosDados([fatos.resposta, fatos.dados]);
  const perto = (n: number) => permitidos.some((p) => Math.abs(p - n) < 0.005 || Math.abs(Math.round(p) - n) < 0.005);
  const intrusos = numerosDe(t).filter((n) => !perto(n));
  if (intrusos.length) return { texto: fatos.resposta, usouModelo: false, motivo: 'número fora dos dados: ' + intrusos.join(', ') };
  return { texto: t, usouModelo: true };
}

export function montarPrompt(pergunta: string, fatos: Fatos, publico: 'motorista' | 'admin') {
  const sistema = [
    `Você reescreve respostas de um painel para ${publico === 'motorista' ? 'um motorista de aplicativo' : 'o gestor da plataforma'}, em português do Brasil, de forma curta e clara.`,
    'Regras obrigatórias:',
    '- Use SOMENTE os números que aparecem em FATOS. Não calcule números novos, não arredonde de outro jeito, não estime.',
    '- Não prometa ganhos, não garanta demanda e não dê conselho financeiro ou jurídico.',
    '- Se FATOS disser que faltam dados, diga isso e nada mais.',
    '- Não compare pessoas por aparência ou características pessoais.',
    '- No máximo 3 frases. Sem links.',
  ].join('\n');
  const usuario = `PERGUNTA: ${pergunta.slice(0, 300)}\n\nFATOS (resposta do sistema):\n${fatos.resposta}\n\nDADOS:\n${JSON.stringify(fatos.dados ?? {}).slice(0, 3000)}`;
  return { sistema, usuario };
}

// Chamada à API de mensagens da Anthropic (modelo e chave por variável de ambiente).
export async function reescreverComModelo(pergunta: string, fatos: Fatos, publico: 'motorista' | 'admin',
  cfg: { chave?: string; modelo?: string; url?: string }, fetchImpl: typeof fetch = fetch): Promise<string | null> {
  if (!cfg.chave || !cfg.modelo) return null;
  const { sistema, usuario } = montarPrompt(pergunta, fatos, publico);
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 8000);
  try {
    const r = await fetchImpl(cfg.url ?? 'https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: ctrl.signal,
      headers: { 'x-api-key': cfg.chave, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: cfg.modelo, max_tokens: 300, system: sistema, messages: [{ role: 'user', content: usuario }] }),
    });
    if (!r.ok) return null;
    const j: any = await r.json();
    return (j?.content ?? []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('\n') || null;
  } catch { return null; } finally { clearTimeout(to); }
}
