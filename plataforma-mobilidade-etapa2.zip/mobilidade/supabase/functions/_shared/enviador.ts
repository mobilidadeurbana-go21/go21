// Enviador de notificações: pega a fila (canal PUSH), agrupa por usuário e dá um "toque" em cada aparelho.
// Canais SMS / WhatsApp / e-mail ficam com o provedor escolhido (ver docs/INTEGRACOES.md): a fila já existe,
// basta um enviador igual a este chamando a API do provedor.
import type { Rpc } from './rpc.ts';
import type { ResultadoPush } from './push.ts';

export async function processarFilaPush(rpc: Rpc, tocar: (endpoint: string) => Promise<ResultadoPush>, limite = 200) {
  const fila = (await rpc('notificacoes_para_enviar', { p_canal: 'PUSH', p_limite: limite })) as Array<{ id: string; usuario_id: string }>;
  if (!fila?.length) return { notificacoes: 0, toques: 0, falhas: 0, removidos: 0 };
  const usuarios = [...new Set(fila.map((n) => n.usuario_id))];
  const destinos = (await rpc('push_destinos', { p_usuarios: usuarios })) as Array<{ id: string; usuario_id: string; endpoint: string }>;
  const porUsuario = new Map<string, typeof destinos>();
  for (const d of destinos ?? []) porUsuario.set(d.usuario_id, [...(porUsuario.get(d.usuario_id) ?? []), d]);

  let toques = 0, falhas = 0, removidos = 0;
  const entregue = new Map<string, boolean>();
  // um toque por aparelho, mesmo que o usuário tenha várias notificações na fila (sem spam)
  await Promise.all(usuarios.map(async (u) => {
    let algum = false;
    for (const d of porUsuario.get(u) ?? []) {
      try {
        const r = await tocar(d.endpoint);
        await rpc('push_resultado', { p_inscricao: d.id, p_ok: r.ok, p_remover: r.remover });
        if (r.ok) { algum = true; toques++; } else { falhas++; if (r.remover) removidos++; }
      } catch { falhas++; await rpc('push_resultado', { p_inscricao: d.id, p_ok: false, p_remover: false }).catch(() => {}); }
    }
    entregue.set(u, algum);
  }));
  for (const n of fila) {
    const semAparelho = !(porUsuario.get(n.usuario_id)?.length);
    // sem aparelho cadastrado: conta como entregue (a notificação continua no app, canal IN_APP)
    const ok = semAparelho || entregue.get(n.usuario_id) === true;
    await rpc('notificacao_resultado', { p_id: n.id, p_ok: ok, p_erro: ok ? (semAparelho ? 'sem aparelho com push' : null) : 'push falhou' });
  }
  return { notificacoes: fila.length, toques, falhas, removidos };
}
