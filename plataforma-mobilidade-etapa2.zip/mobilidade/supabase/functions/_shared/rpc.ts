// Chamada de RPC no PostgREST do Supabase (sem dependências externas).
export type Rpc = (fn: string, args: Record<string, unknown>) => Promise<unknown>;

export class ErroRpc extends Error {
  status: number; codigo: string | null; detalhe: unknown;
  constructor(status: number, codigo: string | null, mensagem: string, detalhe?: unknown) {
    super(mensagem); this.status = status; this.codigo = codigo; this.detalhe = detalhe;
  }
  // erro de regra de negócio (P0001) = não adianta repetir; erro de rede/banco = vale tentar de novo
  get definitivo(): boolean { return this.codigo === 'P0001' || (this.status >= 400 && this.status < 500 && this.status !== 408 && this.status !== 429); }
}

export function criarRpc(url: string, chave: string, jwt?: string, fetchImpl: typeof fetch = fetch): Rpc {
  const base = url.replace(/\/+$/, '');
  return async (fn, args) => {
    const r = await fetchImpl(`${base}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: { apikey: chave, Authorization: `Bearer ${jwt ?? chave}`, 'Content-Type': 'application/json', Prefer: 'return=representation' },
      body: JSON.stringify(args),
    });
    const texto = await r.text();
    let corpo: any = null;
    try { corpo = texto ? JSON.parse(texto) : null; } catch { corpo = texto; }
    if (!r.ok) throw new ErroRpc(r.status, corpo?.code ?? null, corpo?.message ?? `HTTP ${r.status}`, corpo);
    return corpo;
  };
}
