// Criação da cobrança no gateway (PIX copia-e-cola / link de cartão).
// O app chama com o login do PAGADOR; quem confere se o pagamento é dele é o banco (minha_cobranca).
// A gravação do que o gateway devolveu é feita com a chave de servidor (registrar_cobranca).
// A CONFIRMAÇÃO do pagamento NUNCA vem daqui: só do webhook assinado do gateway.
import type { Rpc } from './rpc.ts';

export type PedidoCobranca = { pagamento_id: string; valor: number; metodo: 'PIX' | 'CARTAO'; tipo: string };
export type Cobranca = { ref: string; dados: { pix_copia_cola?: string; link?: string; expira_em?: string } };
export interface Gateway { nome: string; criar(p: PedidoCobranca): Promise<Cobranca> }

// Homologação: gera um código claramente FALSO (não é PIX de verdade). Recusado em produção.
export const gatewaySimulado: Gateway = {
  nome: 'simulado',
  async criar(p) {
    const expira = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    if (p.metodo === 'CARTAO') return { ref: 'SIM-' + p.pagamento_id, dados: { link: 'https://exemplo.invalid/checkout/' + p.pagamento_id, expira_em: expira } };
    return { ref: 'SIM-' + p.pagamento_id, dados: { pix_copia_cola: `SIMULADO-NAO-PAGAR|${p.pagamento_id}|${p.valor.toFixed(2)}`, expira_em: expira } };
  },
};

// Modelo para um gateway real (preencher com a API do gateway contratado — ver docs/INTEGRACOES.md):
// export const gatewayReal: Gateway = { nome: 'meugateway', async criar(p) {
//   const r = await fetch('https://api.gateway.com/v1/charges', { method: 'POST', headers: { Authorization: 'Bearer ' + Deno.env.get('GATEWAY_CHAVE') },
//     body: JSON.stringify({ amount: Math.round(p.valor * 100), method: p.metodo === 'PIX' ? 'pix' : 'card', external_reference: p.pagamento_id }) });
//   const j = await r.json(); return { ref: j.id, dados: { pix_copia_cola: j.pix?.qr_code, link: j.checkout_url, expira_em: j.expires_at } };
// } };

export async function tratarCobranca(opts: { pagamentoId: unknown; rpcUsuario: Rpc; rpcServidor: Rpc; gateway: Gateway | null; producao: boolean }) {
  const { pagamentoId, rpcUsuario, rpcServidor, gateway, producao } = opts;
  if (typeof pagamentoId !== 'string' || !/^[0-9a-f-]{36}$/i.test(pagamentoId)) return { status: 400, corpo: { erro: 'PAGAMENTO_ID_INVALIDO' } };
  if (!gateway) return { status: 503, corpo: { erro: 'GATEWAY_NAO_CONFIGURADO' } };
  if (producao && gateway.nome === 'simulado') return { status: 503, corpo: { erro: 'SIMULADOR_PROIBIDO_EM_PRODUCAO' } };
  let p: any;
  try { p = await rpcUsuario('minha_cobranca', { p_pagamento: pagamentoId }); }        // confere que o pagamento é de quem pediu
  catch { return { status: 404, corpo: { erro: 'PAGAMENTO_NAO_ENCONTRADO' } }; }
  if (p.status !== 'PENDENTE') return { status: 409, corpo: { erro: 'PAGAMENTO_' + p.status } };
  if (p.cobranca) return { status: 200, corpo: { ok: true, cobranca: p.cobranca, repetido: true } };
  if (!['PIX', 'CARTAO'].includes(p.metodo)) return { status: 400, corpo: { erro: 'METODO_SEM_COBRANCA_ONLINE' } };
  const c = await gateway.criar({ pagamento_id: p.id, valor: Number(p.valor), metodo: p.metodo, tipo: p.tipo });
  await rpcServidor('registrar_cobranca', { p_pagamento: p.id, p_gateway: gateway.nome, p_gateway_ref: c.ref, p_dados: c.dados });
  return { status: 200, corpo: { ok: true, cobranca: c.dados } };
}
