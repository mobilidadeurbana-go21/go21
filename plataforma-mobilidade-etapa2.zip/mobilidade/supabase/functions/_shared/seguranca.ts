// Utilitários de segurança usados pelas Edge Functions.
// Só Web APIs (crypto.subtle, TextEncoder): roda igual no Deno (Supabase) e no Node 22 (testes).

const enc = new TextEncoder();

export async function hmacSha256Hex(segredo: string, mensagem: string): Promise<string> {
  const chave = await crypto.subtle.importKey('raw', enc.encode(segredo), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const assinatura = await crypto.subtle.sign('HMAC', chave, enc.encode(mensagem));
  return [...new Uint8Array(assinatura)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

// comparação em tempo constante (não vaza, pelo tempo de resposta, quantos caracteres bateram)
export function compararSeguro(a: string, b: string): boolean {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  // percorre sempre o tamanho do valor esperado (a), independente do recebido
  let dif = a.length ^ b.length;
  for (let i = 0; i < a.length; i++) dif |= a.charCodeAt(i) ^ (b.charCodeAt(i) || 0);
  return dif === 0;
}

export type ResultadoAssinatura = { ok: true } | { ok: false; motivo: 'SEM_ASSINATURA' | 'TIMESTAMP_INVALIDO' | 'FORA_DA_JANELA' | 'ASSINATURA_INVALIDA' };

// Assinatura = HMAC-SHA256( segredo, `${timestamp}.${corpo_cru}` ) em hex.
// O timestamp (segundos) dentro de uma janela curta impede reenvio de um webhook antigo capturado (replay).
export async function verificarAssinatura(opts: {
  segredo: string; corpo: string; timestamp: string | null; assinatura: string | null; agoraSeg: number; janelaSeg?: number;
}): Promise<ResultadoAssinatura> {
  const { segredo, corpo, timestamp, assinatura, agoraSeg } = opts;
  const janela = opts.janelaSeg ?? 300;
  if (!assinatura || !timestamp) return { ok: false, motivo: 'SEM_ASSINATURA' };
  if (!/^\d{9,11}$/.test(timestamp)) return { ok: false, motivo: 'TIMESTAMP_INVALIDO' };
  if (Math.abs(agoraSeg - Number(timestamp)) > janela) return { ok: false, motivo: 'FORA_DA_JANELA' };
  const esperado = await hmacSha256Hex(segredo, `${timestamp}.${corpo}`);
  const recebido = assinatura.replace(/^sha256=/, '').toLowerCase();
  return compararSeguro(esperado, recebido) ? { ok: true } : { ok: false, motivo: 'ASSINATURA_INVALIDA' };
}

export function ipDaRequisicao(h: Headers): string | null {
  // mesma ordem de confiança do banco: proxy da borda primeiro, nunca o 1º item do X-Forwarded-For
  const cf = h.get('cf-connecting-ip'); if (cf) return cf;
  const real = h.get('x-real-ip'); if (real) return real;
  const xff = h.get('x-forwarded-for'); if (xff) { const p = xff.split(',').map((s) => s.trim()).filter(Boolean); return p[p.length - 1] || null; }
  return null;
}

export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
