// Web Push "sem conteúdo" com VAPID (RFC 8292). Só Web Crypto: sem bibliotecas.
// O push só acorda o app; o service worker busca o texto pela API (minhas_notificacoes).
// Gerar as chaves VAPID uma vez (ex.: `npx web-push generate-vapid-keys`) e guardar:
//   VAPID_PUBLICA (base64url, 65 bytes) · VAPID_PRIVADA (base64url, 32 bytes) · VAPID_CONTATO (mailto:...)

export function b64url(bytes: Uint8Array): string {
  let s = ''; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function deB64url(s: string): Uint8Array {
  const b = atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4));
  return Uint8Array.from(b, (c) => c.charCodeAt(0));
}

async function chavePrivada(publica: string, privada: string): Promise<CryptoKey> {
  const pub = deB64url(publica);
  if (pub.length !== 65 || pub[0] !== 4) throw new Error('VAPID_PUBLICA inválida (esperado ponto não comprimido de 65 bytes)');
  const jwk = { kty: 'EC', crv: 'P-256', d: privada, x: b64url(pub.slice(1, 33)), y: b64url(pub.slice(33, 65)), ext: true };
  return crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
}

export async function jwtVapid(endpoint: string, vapid: { publica: string; privada: string; contato: string }, agoraSeg: number): Promise<string> {
  const aud = new URL(endpoint).origin;
  const enc = new TextEncoder();
  const cab = b64url(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const corpo = b64url(enc.encode(JSON.stringify({ aud, exp: agoraSeg + 12 * 3600, sub: vapid.contato })));
  const chave = await chavePrivada(vapid.publica, vapid.privada);
  const ass = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, chave, enc.encode(`${cab}.${corpo}`)));
  return `${cab}.${corpo}.${b64url(ass)}`;
}

export type ResultadoPush = { ok: boolean; remover: boolean; status: number };

export async function enviarToque(endpoint: string, vapid: { publica: string; privada: string; contato: string },
  fetchImpl: typeof fetch = fetch, agoraSeg = Math.floor(Date.now() / 1000)): Promise<ResultadoPush> {
  if (!/^https:\/\//.test(endpoint)) return { ok: false, remover: true, status: 0 };
  const jwt = await jwtVapid(endpoint, vapid, agoraSeg);
  const r = await fetchImpl(endpoint, { method: 'POST', headers: { TTL: '300', Urgency: 'high', Authorization: `vapid t=${jwt}, k=${vapid.publica}`, 'Content-Length': '0' } });
  // 404/410 = inscrição não existe mais (app desinstalado, permissão revogada)
  return { ok: r.status >= 200 && r.status < 300, remover: r.status === 404 || r.status === 410, status: r.status };
}
