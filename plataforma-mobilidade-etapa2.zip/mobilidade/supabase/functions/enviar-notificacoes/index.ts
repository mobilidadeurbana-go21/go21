// Edge Function chamada por agendamento (a cada minuto) — ver README, passo "Agendar funções".
// Protegida por segredo próprio no cabeçalho: x-segredo-cron = CRON_SEGREDO
import { criarRpc } from '../_shared/rpc.ts';
import { enviarToque } from '../_shared/push.ts';
import { processarFilaPush } from '../_shared/enviador.ts';
import { compararSeguro } from '../_shared/seguranca.ts';

Deno.serve(async (req: Request) => {
  const segredo = Deno.env.get('CRON_SEGREDO');
  if (!segredo || !compararSeguro(segredo, req.headers.get('x-segredo-cron') ?? '')) return new Response('Unauthorized', { status: 401 });
  const vapid = { publica: Deno.env.get('VAPID_PUBLICA')!, privada: Deno.env.get('VAPID_PRIVADA')!, contato: Deno.env.get('VAPID_CONTATO') ?? 'mailto:suporte@exemplo.com' };
  if (!vapid.publica || !vapid.privada) return new Response(JSON.stringify({ erro: 'VAPID_NAO_CONFIGURADO' }), { status: 500 });
  const rpc = criarRpc(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const r = await processarFilaPush(rpc, (endpoint) => enviarToque(endpoint, vapid));
  await rpc('registrar_metrica', { p_nome: 'push_enviados', p_valor: r.toques, p_tags: { falhas: r.falhas } }).catch(() => {});
  return new Response(JSON.stringify(r), { headers: { 'Content-Type': 'application/json' } });
});
