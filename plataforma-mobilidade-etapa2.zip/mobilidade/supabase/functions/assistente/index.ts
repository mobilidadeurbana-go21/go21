// Edge Function: POST /functions/v1/assistente  { "pergunta": "...", "publico": "motorista" | "admin", "cidade": uuid? }
// Exige login (verificação de JWT ligada). A pergunta vai para o BANCO com o token do próprio
// usuário — as permissões e os dados são os dele. O modelo de linguagem é opcional:
//   ASSISTENTE_LLM_CHAVE, ASSISTENTE_MODELO (sem eles, a resposta é a do banco, que já é completa).
import { criarRpc, ErroRpc } from '../_shared/rpc.ts';
import { reescreverComModelo, textoSeguro, type Fatos } from '../_shared/assistente.ts';

const CORS = { 'Access-Control-Allow-Origin': Deno.env.get('APP_ORIGEM') ?? '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type' };

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405, headers: CORS });
  const jwt = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!jwt) return new Response(JSON.stringify({ erro: 'LOGIN_NECESSARIO' }), { status: 401, headers: CORS });
  let corpo: any; try { corpo = await req.json(); } catch { return new Response(JSON.stringify({ erro: 'JSON_INVALIDO' }), { status: 400, headers: CORS }); }
  const pergunta = String(corpo?.pergunta ?? '').slice(0, 300);
  const publico = corpo?.publico === 'admin' ? 'admin' : 'motorista';
  const rpc = criarRpc(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, jwt);
  try {
    const fatos = (publico === 'admin'
      ? await rpc('assistente_admin', { p_pergunta: pergunta, p_cidade: corpo?.cidade ?? null })
      : await rpc('assistente_motorista', { p_pergunta: pergunta })) as Fatos;
    const texto = await reescreverComModelo(pergunta, fatos, publico,
      { chave: Deno.env.get('ASSISTENTE_LLM_CHAVE'), modelo: Deno.env.get('ASSISTENTE_MODELO') });
    const seguro = textoSeguro(fatos, texto);
    return new Response(JSON.stringify({ ...fatos, resposta: seguro.texto, resposta_do_sistema: fatos.resposta, fonte: seguro.usouModelo ? 'dados+modelo' : 'dados' }),
      { headers: { ...CORS, 'Content-Type': 'application/json' } });
  } catch (e) {
    const status = e instanceof ErroRpc ? (e.definitivo ? 403 : 502) : 500;
    return new Response(JSON.stringify({ erro: e instanceof Error ? e.message : 'ERRO' }), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
  }
});
