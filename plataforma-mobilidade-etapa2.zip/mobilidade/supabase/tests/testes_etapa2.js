// ============================================================
// TESTES DA ETAPA 2 (PostgreSQL real) — inteligência, risco, segurança, LGPD, ecossistema
// Cada ator (passageiro, motorista, admin, servidor) usa a SUA conexão,
// com o mesmo papel que teria no Supabase (authenticated / service_role).
// Testes de concorrência usam conexões em paralelo de verdade.
//
// Uso: PGHOST=... PGPORT=... PGUSER=... PGDATABASE=... node supabase/tests/testes.js
// ============================================================
const { Client } = require('pg');

let ok = 0, falhas = 0;
const resultados = [];
function check(cond, nome, extra) {
  if (cond) { ok++; resultados.push(['✔', nome]); }
  else { falhas++; resultados.push(['✘', nome + (extra !== undefined ? '  →  ' + JSON.stringify(extra) : '')]); }
}
async function secao(nome, fn) {
  resultados.push(['', '\n■ ' + nome]);
  try { await fn(); }
  catch (e) { falhas++; resultados.push(['✘', 'ERRO INESPERADO: ' + (e.message || e) + (e.detail ? ' | ' + e.detail : '')]); }
}

// ---------- conexões ----------
const conexoes = [];
async function conectar(uid, papel = 'authenticated') {
  const c = new Client();
  await c.connect();
  conexoes.push(c);
  if (papel === 'postgres') return c;
  await c.query(`select set_config('request.jwt.claim.sub', $1, false), set_config('request.jwt.claim.role', $2, false)`, [uid || '', papel]);
  await c.query(`set role ${papel}`);
  return c;
}
async function rpc(c, fn, args = {}) {
  const ks = Object.keys(args);
  const sql = `select public.${fn}(${ks.map((k, i) => `${k} => $${i + 1}`).join(', ')}) as r`;
  const r = await c.query(sql, ks.map(k => args[k]));
  return r.rows[0].r;
}
async function erroDe(p) {
  try { await p; return null; } catch (e) { return e.message; }
}
function cpf() {
  const n = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10));
  let s = n.reduce((a, d, i) => a + d * (10 - i), 0); let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0; n.push(d1);
  s = n.reduce((a, d, i) => a + d * (11 - i), 0); let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0; n.push(d2);
  return n.join('');
}
let telSeq = 900000000;
const tel = () => '219' + String(telSeq++).slice(-8);
const uuidv4 = () => require('crypto').randomUUID();
let placaSeq = 0;   // sequencial: placa aleatória colidia de vez em quando e derrubava o teste
const placa = () => { const n = placaSeq++; return 'TST' + (n % 10) + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(n / 10) % 26] + String(Math.floor(n / 260) % 100).padStart(2, '0'); };

// ponto de origem padrão e destino a ~6 km
const O = { lat: -22.9068, lng: -43.1729 };
const D = { lat: -22.9500, lng: -43.2100 };
function perto(km, angGraus = 0) {   // ponto a "km" da origem
  const r = km / 111;
  return { lat: O.lat + r * Math.cos(angGraus * Math.PI / 180), lng: O.lng + r * Math.sin(angGraus * Math.PI / 180) / Math.cos(O.lat * Math.PI / 180) };
}

(async () => {
  const pg = await conectar(null, 'postgres');
  const q = async (sql, p) => (await pg.query(sql, p)).rows;
  const CID = (await q(`select id from cidades where slug='piloto'`))[0].id;

  // ---------- helpers de cenário ----------
  async function novoUsuario(nome, { motorista = false, codigo = null, dispositivo = null } = {}) {
    const id = uuidv4();
    await q(`insert into auth.users (id, email, email_confirmed_at) values ($1, $2, now())`, [id, id + '@teste.com']);
    const c = await conectar(id);
    const r = await rpc(c, 'completar_cadastro', {
      p_nome: nome, p_telefone: tel(), p_cpf: cpf(), p_email: id + '@teste.com', p_cidade: CID,
      p_quer_ser_motorista: motorista, p_codigo_indicacao: codigo, p_dispositivo: dispositivo || ('disp-' + id)
    });
    return { id, c, codigo: r.codigo_indicacao, nome };
  }
  let admin;
  async function aprovarMotorista(m, { nota = null, pos = perto(1) } = {}) {
    await rpc(m.c, 'motorista_salvar_dados', { p_cnh_numero: '12345678900', p_cnh_categoria: 'B', p_cnh_validade: '2030-01-01', p_cnh_ear: true, p_data_nascimento: '1985-05-05' });
    const v = (await rpc(m.c, 'motorista_cadastrar_veiculo', { p_marca: 'Fiat', p_modelo: 'Cronos', p_ano: 2022, p_placa: placa(), p_cor: 'Prata', p_capacidade: 4, p_acessivel: false, p_categorias: '{ECONOMICO,CONFORTO}' })).veiculo;
    m.veiculo = v;
    for (const t of ['CNH', 'SELFIE', 'ANTECEDENTES']) {
      const d = await rpc(m.c, 'motorista_enviar_documento', { p_dono_tipo: 'MOTORISTA', p_dono: m.id, p_tipo: t, p_arquivo_path: `${m.id}/${t}.jpg`, p_numero: null, p_validade: t === 'CNH' ? '2030-01-01' : null });
      await rpc(admin.c, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    for (const t of ['CRLV', 'SEGURO']) {
      const d = await rpc(m.c, 'motorista_enviar_documento', { p_dono_tipo: 'VEICULO', p_dono: v, p_tipo: t, p_arquivo_path: `${m.id}/${t}.pdf`, p_numero: null, p_validade: '2030-01-01' });
      await rpc(admin.c, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    await rpc(admin.c, 'ops_analisar_veiculo', { p_veiculo: v, p_aprovado: true, p_categorias: '{ECONOMICO,CONFORTO}' });
    await rpc(admin.c, 'ops_alterar_status_motorista', { p_motorista: m.id, p_status: 'ATIVO', p_motivo: 'Documentação aprovada' });
    if (nota !== null) await q(`update motoristas set avaliacao_media=$2 where id=$1`, [m.id, nota]);
    await rpc(m.c, 'ficar_online', { p_lat: pos.lat, p_lng: pos.lng });
    return m;
  }
  async function pedir(p, chave = uuidv4(), extra = {}) {
    return rpc(p.c, 'solicitar_corrida', Object.assign({
      p_chave_idempotencia: chave, p_cidade: CID, p_categoria: 'ECONOMICO',
      p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Origem', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Destino',
      p_metodo: 'PIX', p_rota_km: null, p_rota_min: null
    }, extra));
  }
  async function ofertaDe(m) { return rpc(m.c, 'minha_oferta'); }
  async function offline(...ms) { for (const m of ms) await rpc(m.c, 'ficar_offline'); }
  async function online(m, pos = perto(1)) { await rpc(m.c, 'ficar_online', { p_lat: pos.lat, p_lng: pos.lng }); }
  // motorista chega ao embarque (GPS no ponto de origem) e marca "cheguei"
  async function chegar(m, corrida) {
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m.id, O.lat + 0.0005, O.lng]);
    return rpc(m.c, 'cheguei', { p_corrida: corrida });
  }
  const pinDe = async (corrida) => (await q(`select pin from corrida_segredos where corrida_id=$1`, [corrida]))[0].pin;
  // trilha GPS realista: pontos espaçados de minutos (como um celular de verdade mandaria)
  const ROTA = [[O.lat, O.lng], [-22.9165, -43.1800], [-22.9260, -43.1880], [-22.9360, -43.1970], [-22.9440, -43.2050], [D.lat, D.lng]];
  async function trilha(corrida, m, pontos = ROTA, minutosEntre = 3) {
    const n = pontos.length;
    for (let i = 0; i < n; i++) {
      await q(`insert into corrida_trilha (corrida_id, registrado_em, lat, lng, velocidade_kmh) values ($1, now() - make_interval(secs => $2), $3, $4, 30)`,
        [corrida, Math.round((n - 1 - i) * minutosEntre * 60), pontos[i][0], pontos[i][1]]);
    }
    const ult = pontos[n - 1];
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m.id, ult[0], ult[1]]);
  }
  async function correrAteFinalizar(p, m, corrida, kmPassos = true) {
    const r = await ofertaDe(m);
    await rpc(m.c, 'aceitar_oferta', { p_oferta: r.oferta });
    await chegar(m, corrida);
    await rpc(m.c, 'iniciar_corrida', { p_corrida: corrida, p_pin: await pinDe(corrida) });
    await q(`update corridas set iniciada_em = now() - interval '15 minutes' where id=$1`, [corrida]);
    if (kmPassos) await trilha(corrida, m);
    return rpc(m.c, 'finalizar_corrida', { p_corrida: corrida, p_km_app: null });
  }
  const saldo = async (uid, conta) => Number((await q(`select interno.saldo($1::uuid, $2) s`, [uid, conta]))[0].s);
  const saldoPlat = async (conta) => Number((await q(`select interno.saldo(null, $1) s`, [conta]))[0].s);

  // ---------- admin ----------
  const adminId = uuidv4();
  await q(`insert into auth.users (id) values ($1)`, [adminId]);
  admin = { id: adminId, c: await conectar(adminId) };
  await rpc(admin.c, 'completar_cadastro', { p_nome: 'Admin Teste', p_telefone: tel(), p_cpf: cpf(), p_email: 'admin@teste.com', p_cidade: CID });
  await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'ADMIN'),($1,'OPERACOES'),($1,'FINANCEIRO'),($1,'RISCO'),($1,'SUPORTE') on conflict do nothing`, [adminId]);
  const servidor = await conectar(null, 'service_role');
  // para os testes, indicação vale desde a 1ª corrida e corrida curta conta
  await q(`update configuracoes set valor='0' where chave in ('indicacao_min_corridas_indicado','corrida_valida_min_minutos')`);

  function cnpj() {
    const n = Array.from({ length: 12 }, () => Math.floor(Math.random() * 10));
    const dv = (arr, pesos) => { const s = arr.reduce((a, d, i) => a + d * pesos[i], 0) % 11; return s < 2 ? 0 : 11 - s; };
    n.push(dv(n, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]));
    n.push(dv(n, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]));
    return n.join('');
  }
  const telDe = async (u) => (await q(`select telefone from perfis where id=$1`, [u.id]))[0].telefone;
  async function confirmarWebhook(pag, evento = uuidv4()) {
    return rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: evento, p_tipo: 'PAGAMENTO_CONFIRMADO',
      p_payload: JSON.stringify({ pagamento_id: pag.id || pag.pagamento, gateway_ref: 'gw-' + evento, valor: pag.valor }) });
  }
  // corrida completa paga por PIX (webhook) — devolve a corrida
  async function corridaPaga(p, m, extra = {}) {
    const r = await pedir(p, uuidv4(), extra);
    const fin = await correrAteFinalizar(p, m, r.corrida);
    if (fin.pagamento && fin.pagamento.status === 'PENDENTE') await confirmarWebhook(fin.pagamento);
    return { corrida: r.corrida, fin };
  }

  // =====================================================================
  await secao('PAPÉIS ADMINISTRATIVOS E MENOR PRIVILÉGIO', async () => {
    const perm = await rpc(admin.c, 'minhas_permissoes');
    check(perm && JSON.stringify(perm).includes('FINANCEIRO'), 'painel recebe a matriz de permissões do usuário', perm);
    const alvo = await novoUsuario('Futuro Suporte');
    check(await erroDe(rpc(admin.c, 'admin_definir_papel', { p_usuario: alvo.id, p_papel: 'ADMIN', p_ativo: true })) === 'SEM_PERMISSAO', 'ADMIN comum não concede ADMIN (só SUPER_ADMIN)');
    await rpc(admin.c, 'admin_definir_papel', { p_usuario: alvo.id, p_papel: 'SUPORTE', p_ativo: true });
    check((await rpc(alvo.c, 'meu_perfil')).papeis.includes('SUPORTE'), 'ADMIN concede SUPORTE');
    check(await erroDe(rpc(alvo.c, 'admin_salvar_config', { p_chave: 'taxa_x', p_valor: '1' })) === 'SEM_PERMISSAO', 'SUPORTE não altera configuração');
    check(await erroDe(rpc(alvo.c, 'risco_painel', {})) === 'SEM_PERMISSAO', 'SUPORTE não vê painel de risco');
    check(await erroDe(rpc(admin.c, 'admin_definir_papel', { p_usuario: admin.id, p_papel: 'SUPORTE', p_ativo: false })) === 'CONFLITO_DE_INTERESSE', 'ninguém altera os próprios papéis');
    check(await erroDe(rpc(admin.c, 'admin_salvar_config', { p_chave: 'ambiente', p_valor: '"desenvolvimento"' })) === 'SEM_PERMISSAO', 'só SUPER_ADMIN muda o ambiente (liga/desliga simulador)');
    check((await erroDe(rpc(alvo.c, 'executar_jobs', { p_qual: 'diario' })) || '').includes('permission denied'), 'usuário logado não dispara jobs');
  });

  await secao('LGPD: CPF, CONSENTIMENTO, EXPORTAÇÃO, EXCLUSÃO', async () => {
    const u = await novoUsuario('Titular Dos Dados');
    check((await erroDe(u.c.query(`select cpf from perfis where id=$1`, [u.id]))) !== null, 'app não lê a coluna CPF nem do próprio perfil (só mascarado)');
    const lista = await rpc(admin.c, 'admin_buscar_usuarios', { p_texto: 'Titular' });
    check(JSON.stringify(lista).includes('***') && !JSON.stringify(lista).includes((await q(`select cpf from perfis where id=$1`, [u.id]))[0].cpf), 'busca do admin devolve dados mascarados', lista);
    check(await erroDe(rpc(admin.c, 'risco_ver_cpf', { p_usuario: u.id, p_justificativa: 'curta' })) === 'JUSTIFICATIVA_OBRIGATORIA', 'ver CPF exige justificativa');
    const cpfVisto = await rpc(admin.c, 'risco_ver_cpf', { p_usuario: u.id, p_justificativa: 'Conferência de documento em análise de fraude' });
    const aud = await q(`select count(*)::int n from auditoria where acao='ACESSO_CPF' and registro_id=$1`, [u.id]);
    check(/^\d{11}$/.test(cpfVisto) && aud[0].n === 1, 'acesso ao CPF por RISCO é registrado na auditoria');
    await rpc(u.c, 'registrar_consentimento', { p_tipo: 'MARKETING', p_versao: 'v1', p_aceito: false });
    const exp = await rpc(u.c, 'meus_dados_exportar');
    check(exp && exp.perfil && exp.consentimentos, 'titular exporta os próprios dados (portabilidade)', Object.keys(exp || {}));
    const s = await rpc(u.c, 'solicitar_exclusao_conta', { p_motivo: 'não uso mais' });
    check(!!s.executar_em, 'exclusão agendada com carência (pode desistir)');
    await rpc(u.c, 'cancelar_exclusao_conta');
    check((await q(`select status from lgpd_solicitacoes where id=$1`, [s.id]))[0].status === 'CANCELADA', 'titular cancela o pedido dentro da carência');
    const s2 = await rpc(u.c, 'solicitar_exclusao_conta', {});
    await q(`update lgpd_solicitacoes set executar_em = now() - interval '1 minute' where id=$1`, [s2.id]);
    await q(`select interno.job_retencao()`);
    const pf = (await q(`select nome, cpf, telefone, email, status from perfis where id=$1`, [u.id]))[0];
    check(pf.cpf === null || !/^\d{11}$/.test(pf.cpf || ''), 'após a carência, dados pessoais são anonimizados', pf);
    check(pf.nome !== 'Titular Dos Dados', 'nome removido na anonimização');
  });

  await secao('OBSERVABILIDADE E JOBS', async () => {
    const r = await rpc(servidor, 'executar_jobs', { p_qual: 'diario' });
    check(r && r.empresas && r.assinaturas && r.risco, 'job diário inclui empresas, assinaturas e risco', Object.keys(r || {}));
    const ex = await q(`select count(*)::int n from jobs_execucoes where job in ('empresas','assinaturas','risco')`);
    check(ex[0].n >= 3, 'cada execução de job fica registrada (duração, resultado, erro)');
    const sd = await rpc(admin.c, 'saude_sistema');
    check(sd && Array.isArray(sd.itens) && sd.itens.length > 0, 'painel de saúde do sistema responde', Object.keys(sd || {}));
  });

  // motoristas e passageiros usados nas seções seguintes
  const M1 = await aprovarMotorista(await novoUsuario('Motorista Radar', { motorista: true }));
  const P1 = await novoUsuario('Passageira Radar');

  await secao('RADAR E INTELIGÊNCIA (sempre como estimativa)', async () => {
    // demanda recente na zona de origem
    for (let i = 0; i < 4; i++) {
      const p = await novoUsuario('Pedinte ' + i);
      const r = await pedir(p);
      await rpc(p.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'teste radar' });
    }
    await q(`select interno.job_inteligencia()`);
    const rd = await rpc(M1.c, 'radar', {});
    check(rd.estimativa === true && /estimativa/i.test(rd.aviso) && /garantia/i.test(rd.aviso), 'radar se apresenta como estimativa, sem garantia', rd.aviso);
    const z = rd.zonas[0];
    check(z && ['ALTA', 'MODERADA', 'NORMAL', 'BAIXA'].includes(z.nivel), 'zona com nível ALTA/MODERADA/NORMAL/BAIXA', z && z.nivel);
    check(z && Array.isArray(z.explicacao) && z.explicacao.some(t => /motoristas disponíveis/.test(t || '')), 'nível vem com explicação (região, tendência, motoristas, espera)', z && z.explicacao);
    check(z && z.distancia_km !== undefined && z.oportunidade_estimada.estimativa === true, 'mostra distância até a zona e oportunidade marcada como estimativa');
    check(await erroDe(rpc(P1.c, 'radar', {})) === 'SEM_PERMISSAO', 'passageiro não acessa o radar');
    const painel = await rpc(admin.c, 'inteligencia_painel', { p_cidade: CID });
    check(painel && painel.zonas !== undefined, 'painel de inteligência da operação responde', Object.keys(painel || {}));
    check((await erroDe(rpc(M1.c, 'registrar_clima', { p_cidade: CID, p_condicao: 'CHUVA', p_temperatura: 20, p_fonte: 'x' })) || '').includes('permission denied'), 'clima só entra pelo servidor (fonte externa)');
  });

  await secao('ASSISTENTE DO MOTORISTA (só dados reais)', async () => {
    const novo = await aprovarMotorista(await novoUsuario('Motorista Sem Histórico', { motorista: true }));
    const r0 = await rpc(novo.c, 'assistente_motorista', { p_pergunta: 'Quanto faturei hoje?' });
    check(r0.dados_suficientes === false || /ainda não|sem corridas|nenhuma/i.test(r0.resposta), 'sem histórico, diz que não há dados (não inventa número)', r0.resposta);
    await offline(novo);
    const { corrida } = await corridaPaga(P1, M1);
    // "quanto faturei" para o motorista = o ganho dele (80%), somado do banco
    const real = (await q(`select coalesce(sum(r.valor),0) v from recebiveis r join corridas c on c.id=r.corrida_id
                           where r.motorista_id=$1 and r.tipo='CORRIDA' and c.finalizada_em >= date_trunc('day', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'`, [M1.id]))[0];
    const r1 = await rpc(M1.c, 'assistente_motorista', { p_pergunta: 'Quanto faturei hoje?' });
    const valorBR = Number(real.v).toFixed(2).replace('.', ',');
    check(r1.intencao === 'FATURAMENTO' && r1.resposta.includes(valorBR), 'faturamento respondido com o valor exato do banco (ganho do motorista)', { resp: r1.resposta, valorBR });
    const r2 = await rpc(M1.c, 'assistente_motorista', { p_pergunta: 'Quanto o carro está custando por km?' });
    check(r2.intencao === 'CUSTO_KM', 'entende pergunta de custo por km', r2.intencao);
    const r3 = await rpc(M1.c, 'assistente_motorista', { p_pergunta: 'Quanto preciso faturar amanhã?' });
    check(r3.intencao === 'META_AMANHA' && (r3.dados_suficientes === false || /meta/i.test(r3.resposta)), 'sem meta cadastrada, pede a meta em vez de chutar', r3.resposta);
    const hist = await rpc(M1.c, 'rentabilidade_historico', { p_dias: 7 });
    check(hist && JSON.stringify(hist).includes('custo'), 'rentabilidade traz detalhamento de custos', Object.keys(hist || {}));
    check(!/ranking|aparência|beleza/i.test(JSON.stringify(hist)), 'comparação só com o próprio histórico (sem ranking pessoal)');
    const ad = await rpc(admin.c, 'assistente_admin', { p_pergunta: 'Quantas corridas tivemos hoje?' });
    const n = (await q(`select count(*)::int n from corridas where solicitada_em >= date_trunc('day', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'`))[0].n;
    check(ad.intencao === 'CORRIDAS' && ad.resposta.includes(String(n)), 'assistente do admin responde com a contagem real', { resp: ad.resposta, n });
  });

  await secao('CENTRAL DE SEGURANÇA (alerta → contexto → contato → humano)', async () => {
    const r = await pedir(P1);
    const of = await ofertaDe(M1);
    await rpc(M1.c, 'aceitar_oferta', { p_oferta: of.oferta });
    const inc = await rpc(P1.c, 'acionar_emergencia', { p_corrida: r.corrida, p_lat: O.lat, p_lng: O.lng, p_descricao: 'Teste central' });
    const incId = inc.incidente || inc.id || inc;
    const painel = await rpc(admin.c, 'seguranca_painel', {});
    check(JSON.stringify(painel).includes(incId), 'incidente aparece na central', painel && Object.keys(painel));
    check(await erroDe(rpc(admin.c, 'seguranca_registrar_acao', { p_incidente: incId, p_tipo: 'MENSAGEM', p_descricao: 'Oi' })) === 'ASSUMA_O_INCIDENTE_ANTES', 'precisa assumir antes de agir (responsável claro)');
    await rpc(admin.c, 'seguranca_assumir', { p_incidente: incId });
    check(await erroDe(rpc(admin.c, 'seguranca_encerrar', { p_incidente: incId, p_desfecho: 'FALSO_ALARME', p_resolucao: 'ok' })) !== null, 'emergência não encerra sem contato registrado');
    await rpc(admin.c, 'seguranca_registrar_acao', { p_incidente: incId, p_tipo: 'LIGOU_PASSAGEIRO', p_descricao: 'Passageira atendeu, está bem' });
    const enc = await rpc(admin.c, 'seguranca_encerrar', { p_incidente: incId, p_desfecho: 'FALSO_ALARME', p_resolucao: 'Acionado por engano, confirmado por ligação' });
    check(enc && (enc.ok || enc.encerrado || enc.status), 'encerra após contato, com desfecho', enc);
    const acoes = await q(`select tipo from incidente_acoes where incidente_id=$1 order by criado_em`, [incId]);
    check(acoes.length >= 3, 'linha do tempo do incidente registrada', acoes.map(a => a.tipo));
    check((await erroDe(q(`update incidente_acoes set descricao='x' where incidente_id=$1`, [incId]))) !== null, 'registro de ações é imutável');
    await rpc(P1.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'fim do teste' }).catch(() => {});
  });

  await secao('MOTOR DE RISCO (pontua, relaciona, nunca bloqueia sozinho)', async () => {
    // duas contas no mesmo aparelho
    const a = await novoUsuario('Conta A', { dispositivo: 'aparelho-compartilhado' });
    const b = await novoUsuario('Conta B', { dispositivo: 'aparelho-compartilhado' });
    await q(`select interno.job_risco_v2()`);
    const det = await rpc(admin.c, 'risco_detalhe', { p_usuario: b.id });
    check(JSON.stringify(det).includes(a.id) || JSON.stringify(det).toLowerCase().includes('dispositivo'), 'relaciona contas pelo aparelho', det && Object.keys(det));
    const st = (await q(`select status from perfis where id=$1`, [b.id]))[0].status;
    check(st === 'ATIVO', 'pontuação alta não bloqueia a conta automaticamente');
    check(await erroDe(rpc(admin.c, 'risco_registrar_analise', { p_usuario: b.id, p_conclusao: 'Suspeito pelo score alto apenas', p_acao: 'BLOQUEAR_USUARIO' })) === 'CONTEXTO_INSUFICIENTE', 'bloqueio exige evidência além da pontuação');
    const ok = await rpc(admin.c, 'risco_registrar_analise', { p_usuario: b.id, p_conclusao: 'Mesmo aparelho de outra conta; família confirmada', p_acao: 'MONITORAR' });
    check(ok.ok === true, 'analista registra conclusão e decide monitorar');
    check(await erroDe(rpc(P1.c, 'risco_detalhe', { p_usuario: b.id })) === 'SEM_PERMISSAO', 'usuário comum não vê o motor de risco');
  });

  await secao('INDICAÇÃO EVOLUÍDA (20% = 80/3/2/1/14 mantido)', async () => {
    const regra = (await q(`select taxa_plataforma_pct, indicacao_n1_pct, indicacao_n2_pct, indicacao_n3_pct from regras_comissao where nome='Padrão nacional'`))[0];
    check(Number(regra.taxa_plataforma_pct) === 20 && Number(regra.indicacao_n1_pct) === 3 && Number(regra.indicacao_n2_pct) === 2 && Number(regra.indicacao_n3_pct) === 1, 'regra padrão continua 20 / 3 / 2 / 1 (configurável, não fixa no código)', regra);
    const pai = await aprovarMotorista(await novoUsuario('Indicador Pai', { motorista: true }));
    const filho = await aprovarMotorista(await novoUsuario('Indicado Filho', { motorista: true, codigo: pai.codigo }));
    await offline(M1, pai);
    const { corrida } = await corridaPaga(P1, filho);
    const g = await q(`select nivel, valor from ganhos_indicacao where corrida_id=$1`, [corrida]);
    const preco = Number((await q(`select preco_final from corridas where id=$1`, [corrida]))[0].preco_final);
    check(g.length === 1 && Math.abs(Number(g[0].valor) - Math.round(preco * 3) / 100) < 0.011, 'nível 1 recebe 3% da corrida do indicado', { g, preco });
    const painel = await rpc(pai.c, 'indicacao_painel');
    check(painel && JSON.stringify(painel).includes('arvore') || JSON.stringify(painel).includes('rede'), 'painel de indicação traz árvore/rede', Object.keys(painel || {}));
    check(!JSON.stringify(painel).includes('Indicado Filho'), 'nomes da rede aparecem mascarados');
    await offline(filho); await online(M1);
  });

  await secao('MOBI EMPRESAS (política, corrida corporativa, fatura)', async () => {
    const G = await novoUsuario('Gestora Acme');
    check(await erroDe(rpc(G.c, 'empresa_cadastrar', { p_razao: 'X', p_fantasia: 'X', p_cnpj: '11111111111111', p_cidade: CID, p_email_financeiro: 'f@x.com' })) === 'CNPJ_INVALIDO', 'CNPJ inválido é recusado');
    const emp = await rpc(G.c, 'empresa_cadastrar', { p_razao: 'Acme Ltda', p_fantasia: 'Acme', p_cnpj: cnpj(), p_cidade: CID, p_email_financeiro: 'fin@acme.com' });
    const F = await novoUsuario('Funcionário Acme');
    check(await erroDe(rpc(G.c, 'empresa_adicionar_membro', { p_empresa: emp, p_contato: F.id + '@teste.com' })) === 'EMPRESA_AINDA_NAO_ATIVA', 'empresa em análise ainda não convida ninguém');
    const pedidoEmp = (extra = {}) => rpc(F.c, 'solicitar_corrida_empresa', Object.assign({ p_empresa: emp, p_chave_idempotencia: uuidv4(), p_cidade: CID, p_categoria: 'ECONOMICO',
      p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Sede', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Cliente', p_justificativa: 'Visita a cliente' }, extra));
    check(await erroDe(rpc(G.c, 'solicitar_corrida_empresa', { p_empresa: emp, p_chave_idempotencia: uuidv4(), p_cidade: CID, p_categoria: 'ECONOMICO',
      p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Sede', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Cliente', p_justificativa: 'Visita' })) === 'EMPRESA_PENDENTE', 'empresa pendente não usa crédito');
    check(await erroDe(rpc(F.c, 'fin_aprovar_empresa', { p_empresa: emp, p_aprovar: true, p_limite: 500 })) === 'SEM_PERMISSAO', 'funcionário não aprova crédito');
    await rpc(admin.c, 'fin_aprovar_empresa', { p_empresa: emp, p_aprovar: true, p_limite: 500 });
    // convite: nunca vincula direto; só o dono do contato VERIFICADO aceita
    const ad = await rpc(G.c, 'empresa_adicionar_membro', { p_empresa: emp, p_contato: F.id + '@teste.com' });
    check(ad.convite && !ad.membro && !JSON.stringify(ad).includes('Funcionário'), 'adicionar pessoa sempre vira convite (não revela quem tem conta)', ad);
    const intruso = await novoUsuario('Intruso');
    await q(`update perfis set email=$2 where id=$1`, [intruso.id, F.id + '@teste.com']);   // e-mail digitado no perfil, sem verificação
    check((await rpc(intruso.c, 'meus_convites_empresa')).length === 0 && (await rpc(intruso.c, 'aceitar_convites_empresa')) === 0, 'quem só digitou o e-mail no perfil (sem verificar) não pega o convite');
    const conv = await rpc(F.c, 'meus_convites_empresa');
    check(conv.length === 1 && conv[0].empresa === 'Acme', 'convidado vê o convite (contato verificado)', conv);
    await rpc(F.c, 'responder_convite_empresa', { p_convite: conv[0].id, p_aceitar: true });
    check((await rpc(F.c, 'minhas_empresas')).some((e) => e.empresa === emp), 'convidado aceita e passa a ser membro');
    const pol = (await q(`select id from empresa_politicas where empresa_id=$1`, [emp]))[0].id;
    await rpc(G.c, 'empresa_salvar_estrutura', { p_empresa: emp, p_tipo: 'POLITICA', p: JSON.stringify({ id: pol, nome: 'Padrão', categorias_permitidas: ['ECONOMICO'], exige_justificativa: true }) });
    check(await erroDe(pedidoEmp({ p_categoria: 'CONFORTO' })) === 'CATEGORIA_FORA_DA_POLITICA', 'categoria fora da política é recusada');
    check(await erroDe(pedidoEmp({ p_justificativa: '' })) === 'JUSTIFICATIVA_OBRIGATORIA', 'política exige justificativa');
    check(await erroDe(pedir(F, uuidv4(), { p_metodo: 'EMPRESA' })) === 'USE_A_SOLICITACAO_CORPORATIVA', 'não dá para usar o método EMPRESA fora do fluxo corporativo');
    // outra empresa não mexe na estrutura da Acme
    const G2 = await novoUsuario('Gestor Outra');
    const emp2 = await rpc(G2.c, 'empresa_cadastrar', { p_razao: 'Outra SA', p_fantasia: 'Outra', p_cnpj: cnpj(), p_cidade: CID, p_email_financeiro: 'f@outra.com' });
    check(await erroDe(rpc(G2.c, 'empresa_salvar_estrutura', { p_empresa: emp2, p_tipo: 'POLITICA', p: JSON.stringify({ id: pol, nome: 'Sequestro', categorias_permitidas: ['PREMIUM'] }) })) === 'REGISTRO_NAO_ENCONTRADO', 'gestor de outra empresa não sobrescreve política alheia');
    check(await erroDe(rpc(G2.c, 'empresa_salvar_estrutura', { p_empresa: emp, p_tipo: 'DEPARTAMENTO', p: JSON.stringify({ nome: 'Invasão' }) })) === 'SEM_PERMISSAO_NA_EMPRESA', 'gestor de outra empresa não cria estrutura na Acme');
    check((await q(`select categorias_permitidas from empresa_politicas where id=$1`, [pol]))[0].categorias_permitidas.join() === 'ECONOMICO', 'política da Acme intacta');
    check(await erroDe(rpc(F.c, 'empresa_relatorio', { p_empresa: emp, p_inicio: '2020-01-01', p_fim: '2100-01-01' })) === 'SEM_PERMISSAO_NA_EMPRESA', 'funcionário não vê relatório da empresa');
    // auto-aprovação
    const empAdm = await rpc(admin.c, 'empresa_cadastrar', { p_razao: 'Do Admin', p_fantasia: 'Adm', p_cnpj: cnpj(), p_cidade: CID, p_email_financeiro: 'a@adm.com' });
    check(await erroDe(rpc(admin.c, 'fin_aprovar_empresa', { p_empresa: empAdm, p_aprovar: true, p_limite: 99999 })) === 'CONFLITO_DE_INTERESSE', 'financeiro não aprova crédito da própria empresa');

    // corrida corporativa ponta a ponta
    const r = await pedidoEmp();
    const fin = await correrAteFinalizar(F, M1, r.corrida);
    const c = (await q(`select status, preco_final, empresa_id from corridas where id=$1`, [r.corrida]))[0];
    check(c.status === 'PAGA' && c.empresa_id === emp, 'corrida corporativa é liquidada na hora (vai para a fatura)', c);
    check(Math.abs(await saldo(emp, 'EMPRESA_A_RECEBER') + Number(c.preco_final)) < 0.01, 'empresa fica devendo o valor da corrida (conta a receber no ledger)');
    const ganho = (await q(`select valor from recebiveis where corrida_id=$1`, [r.corrida]))[0];
    check(Math.abs(Number(ganho.valor) - Number(c.preco_final) * 0.8) < 0.011, 'motorista recebe 80% normalmente');
    const rel = await rpc(G.c, 'empresa_relatorio', { p_empresa: emp, p_inicio: '2020-01-01', p_fim: '2100-01-01' });
    check(Number(rel.totais.corridas) === 1 && rel.por_funcionario.length === 1, 'relatório por funcionário/departamento/centro de custo', rel.totais);
    const csv = await rpc(G.c, 'empresa_exportar_csv', { p_empresa: emp, p_inicio: '2020-01-01', p_fim: '2100-01-01' });
    check(csv.split('\n').length === 2 && csv.includes('Visita a cliente'), 'exportação CSV com justificativa');
    const fat = await rpc(admin.c, 'fin_fechar_fatura', { p_empresa: emp });
    const f = (await q(`select valor, corridas, status from empresa_faturas where id=$1`, [fat]))[0];
    check(Math.abs(Number(f.valor) - Number(c.preco_final)) < 0.01 && f.corridas === 1, 'fatura fecha com o valor das corridas', f);
    check((await rpc(admin.c, 'fin_fechar_fatura', { p_empresa: emp })) === null, 'fechar de novo não duplica (corrida já faturada)');
    const pg1 = await rpc(G.c, 'empresa_pagar_fatura', { p_fatura: fat, p_metodo: 'PIX' });
    const pg2 = await rpc(G.c, 'empresa_pagar_fatura', { p_fatura: fat, p_metodo: 'PIX' });
    check(pg1.pagamento === pg2.pagamento, 'gerar cobrança da fatura duas vezes devolve a mesma cobrança');
    await confirmarWebhook(pg1, 'fat-1');
    const d = await confirmarWebhook(pg1, 'fat-1');
    check(d.duplicado === true, 'webhook duplicado da fatura é ignorado');
    check((await q(`select status from empresa_faturas where id=$1`, [fat]))[0].status === 'PAGA' && Math.abs(await saldo(emp, 'EMPRESA_A_RECEBER')) < 0.01, 'fatura paga zera a conta da empresa');
    // limite de crédito
    await q(`update empresas set limite_credito_mensal = 1 where id=$1`, [emp]);
    check(await erroDe(pedidoEmp()) === 'LIMITE_DE_CREDITO_DA_EMPRESA', 'limite de crédito da empresa é respeitado');
    // fatura vencida bloqueia
    await q(`update empresas set limite_credito_mensal = 500 where id=$1`, [emp]);
    await q(`insert into empresa_faturas (empresa_id, periodo_inicio, periodo_fim, valor, corridas, vencimento, status) values ($1, now(), now(), 10, 1, current_date - 1, 'VENCIDA')`, [emp]);
    check(await erroDe(pedidoEmp()) === 'EMPRESA_COM_FATURA_VENCIDA', 'fatura vencida bloqueia novas corridas corporativas');
  });

  await secao('MOBI WALLET: recarga, cupom, reembolso em créditos', async () => {
    const P = await novoUsuario('Passageiro Wallet');
    const rc = await rpc(P.c, 'recarregar_carteira', { p_valor: 100, p_metodo: 'PIX', p_chave_idempotencia: 'rec-0001' });
    const rc2 = await rpc(P.c, 'recarregar_carteira', { p_valor: 100, p_metodo: 'PIX', p_chave_idempotencia: 'rec-0001' });
    check(rc.pagamento === rc2.pagamento, 'recarga repetida (clique duplo) não gera 2 cobranças');
    check(await saldo(P.id, 'PASSAGEIRO_CARTEIRA') === 0, 'crédito só entra depois da confirmação do gateway');
    await confirmarWebhook(rc);
    check(await saldo(P.id, 'PASSAGEIRO_CARTEIRA') === 100, 'recarga confirmada entra na carteira via ledger');
    await rpc(admin.c, 'admin_salvar_cupom', { p: JSON.stringify({ codigo: 'BEMVINDO10', tipo: 'PERCENTUAL', valor: 10, desconto_maximo: 5, usos_maximos: 1, usos_por_usuario: 1 }) });
    const v = await rpc(P.c, 'validar_cupom', { p_codigo: 'bemvindo10', p_cidade: CID, p_categoria: 'ECONOMICO', p_valor_estimado: 30 });
    check(v.valido === true && Number(v.desconto_estimado) === 3, 'cupom validado com desconto estimado', v);
    check((await rpc(P.c, 'validar_cupom', { p_codigo: 'NAOEXISTE', p_cidade: CID, p_categoria: 'ECONOMICO' })).erro === 'CUPOM_INVALIDO', 'cupom inexistente recusado');
    // dois passageiros disputando o último uso do cupom
    const P2 = await novoUsuario('Passageiro Concorrente');
    const rA = await pedir(P, uuidv4(), { p_metodo: 'CARTEIRA' });
    await rpc(P.c, 'aplicar_cupom', { p_corrida: rA.corrida, p_codigo: 'BEMVINDO10' });
    const finA = await correrAteFinalizar(P, M1, rA.corrida);
    const rB = await pedir(P2);
    const apB = await rpc(P2.c, 'aplicar_cupom', { p_corrida: rB.corrida, p_codigo: 'BEMVINDO10' });
    check(apB.ok === false && apB.erro === 'CUPOM_ESGOTADO', 'cupom com 1 uso não vale para o segundo', apB);
    await rpc(P2.c, 'cancelar_corrida', { p_corrida: rB.corrida, p_motivo: 'teste' });
    const cA = (await q(`select preco_final, desconto, status from corridas where id=$1`, [rA.corrida]))[0];
    const esperado = Math.min(5, Math.round(Number(cA.preco_final) * 10) / 100);
    check(Math.abs(Number(cA.desconto) - esperado) < 0.01 && cA.status === 'PAGA', 'desconto aplicado na cobrança (10%, teto R$ 5)', cA);
    check(Math.abs(await saldo(P.id, 'PASSAGEIRO_CARTEIRA') - (100 - Number(cA.preco_final) + Number(cA.desconto))) < 0.01, 'carteira debitada só do valor com desconto');
    const rec = (await q(`select valor from recebiveis where corrida_id=$1`, [rA.corrida]))[0];
    check(Math.abs(Number(rec.valor) - Number(cA.preco_final) * 0.8) < 0.011, 'motorista recebe 80% do preço cheio (desconto sai da verba de promoções)');
    // reembolso em créditos
    const saldoAntes = await saldo(P.id, 'PASSAGEIRO_CARTEIRA');
    await rpc(admin.c, 'fin_reembolsar_em_creditos', { p_corrida: rA.corrida, p_valor: 5, p_motivo: 'Rota mais longa que o necessário' });
    check(Math.abs(await saldo(P.id, 'PASSAGEIRO_CARTEIRA') - saldoAntes - 5) < 0.01, 'reembolso em créditos cai na carteira');
    check(await erroDe(rpc(admin.c, 'fin_reembolsar_em_creditos', { p_corrida: rA.corrida, p_valor: 9999, p_motivo: 'Exagero de reembolso' })) === 'VALOR_ACIMA_DO_PAGO', 'reembolso não passa do valor efetivamente pago');
    const w = await rpc(P.c, 'minha_wallet');
    check(Number(w.creditos) === await saldo(P.id, 'PASSAGEIRO_CARTEIRA') && w.cupons_usados.length === 1 && w.reembolsos.length === 1, 'tela da wallet mostra créditos, cupons e reembolsos', { cred: w.creditos, cup: w.cupons_usados.length, re: w.reembolsos.length });
  });

  await secao('MOBI+ (assinatura)', async () => {
    const plano = await rpc(admin.c, 'admin_salvar_plano', { p: JSON.stringify({ nome: 'Mobi+ Teste', preco_mensal: 19.9, beneficios: { desconto_pct: 5, desconto_max_corrida: 3, cancelamentos_gratis_mes: 1 } }) });
    const P = await novoUsuario('Assinante');
    const r1 = await rpc(P.c, 'assinar_plano', { p_plano: plano, p_metodo: 'PIX' });
    check(r1.status === 'PENDENTE', 'assinatura só ativa depois do pagamento');
    await confirmarWebhook({ id: r1.pagamento, valor: r1.valor });
    const w = await rpc(P.c, 'minha_wallet');
    check(w.mobi_mais && w.mobi_mais.plano === 'Mobi+ Teste', 'Mobi+ ativo após pagamento', w.mobi_mais);
    check(await erroDe(rpc(P.c, 'assinar_plano', { p_plano: plano, p_metodo: 'PIX' })) === 'JA_ASSINANTE', 'não assina duas vezes');
    check(Math.abs(await saldoPlat('PLATAFORMA_ASSINATURAS') - 19.9) < 0.01 || (await saldoPlat('PLATAFORMA_ASSINATURAS')) >= 19.9, 'receita de assinatura registrada no ledger');
    const { corrida } = await corridaPaga(P, M1);
    const c = (await q(`select preco_final, desconto from corridas where id=$1`, [corrida]))[0];
    check(Math.abs(Number(c.desconto) - Math.min(3, Math.round(Number(c.preco_final) * 5) / 100)) < 0.01, 'desconto Mobi+ (5%, teto R$ 3) aplicado', c);
    await rpc(P.c, 'cancelar_assinatura');
    check((await rpc(P.c, 'minha_wallet')).mobi_mais !== null, 'cancelou: benefícios continuam até o fim do período pago');
    const re = await rpc(P.c, 'assinar_plano', { p_plano: plano, p_metodo: 'PIX' });
    check(re.reativada === true && (await q(`select count(*)::int n from pagamentos where pagador_id=$1 and tipo='ASSINATURA'`, [P.id]))[0].n === 1, 'reativar no mesmo período não cobra de novo');
    // cancelamento grátis
    const r = await pedir(P);
    const of = await ofertaDe(M1);
    await rpc(M1.c, 'aceitar_oferta', { p_oferta: of.oferta });
    await chegar(M1, r.corrida);
    await q(`update corridas set chegou_em = now() - interval '10 minutes', aceita_em = now() - interval '12 minutes' where id=$1`, [r.corrida]);
    const can = await rpc(P.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'Desisti' });
    const taxa = await q(`select count(*)::int n from pagamentos where corrida_id=$1 and tipo='TAXA_CANCELAMENTO'`, [r.corrida]);
    const uso = await q(`select count(*)::int n from assinatura_usos u join assinaturas a on a.id=u.assinatura_id where a.usuario_id=$1 and u.tipo='CANCELAMENTO_GRATIS'`, [P.id]);
    check(taxa[0].n === 0 && uso[0].n === 1, 'cancelamento grátis do Mobi+ isenta a taxa (1 por mês)', { can, taxa: taxa[0].n, uso: uso[0].n });
  });

  await secao('DRIVER+ E PARCEIROS', async () => {
    const parc = await rpc(admin.c, 'admin_salvar_parceiro', { p: JSON.stringify({ nome: 'Oficina Boa', tipo: 'OFICINA', cidade_id: CID, lat: O.lat + 0.016, lng: O.lng, endereco: 'Rua A, 1' }) });
    const of1 = await rpc(admin.c, 'admin_salvar_oferta_parceiro', { p: JSON.stringify({ parceiro_id: parc, titulo: '10% na revisão', desconto_pct: 10 }) });
    const of2 = await rpc(admin.c, 'admin_salvar_oferta_parceiro', { p: JSON.stringify({ parceiro_id: parc, titulo: 'Alinhamento grátis', nivel_minimo: 'OURO' }) });
    const lista = await rpc(M1.c, 'parceiros_proximos', { p_lat: O.lat, p_lng: O.lng });
    check(lista.length >= 1 && /Oficina parceira a 1,8 km/.test(lista[0].texto), 'mostra "Oficina parceira a 1,8 km"', lista[0] && lista[0].texto);
    const dp = await rpc(M1.c, 'driver_plus');
    check(/não representam garantia/i.test(dp.nivel.aviso), 'Driver+ deixa claro que nível não é promessa de renda', dp.nivel.aviso);
    check(await erroDe(rpc(M1.c, 'resgatar_oferta', { p_oferta: of2 })) === 'NIVEL_INSUFICIENTE', 'oferta de nível OURO exige o nível');
    const res = await rpc(M1.c, 'resgatar_oferta', { p_oferta: of1 });
    check(/^[A-F0-9]{8}$/.test(res.codigo), 'resgate gera código para mostrar no parceiro');
    check(await erroDe(rpc(M1.c, 'resgatar_oferta', { p_oferta: of1 })) === 'LIMITE_DE_RESGATES', 'limite de resgates por pessoa');
    check((await rpc(admin.c, 'ops_validar_resgate', { p_codigo: res.codigo })).valido === true, 'parceiro valida o código uma vez');
    check((await rpc(admin.c, 'ops_validar_resgate', { p_codigo: res.codigo })).valido === false, 'código não vale duas vezes');
    check(await erroDe(rpc(P1.c, 'resgatar_oferta', { p_oferta: of1 })) === 'SO_PARA_MOTORISTAS', 'oferta de motorista não vale para passageiro');
  });

  await secao('CATEGORIAS ESPECIAIS (requisitos verificados pela operação)', async () => {
    await q(`insert into cidade_categorias (cidade_id, categoria, habilitada, tarifa_base, preco_km, preco_minuto, tarifa_minima, taxa_cancelamento)
             select cidade_id, x, true, tarifa_base, preco_km, preco_minuto, tarifa_minima, taxa_cancelamento from cidade_categorias, unnest('{FAMILIAR,AEROPORTO}'::text[]) x
             where cidade_id=$1 and categoria='ECONOMICO' on conflict do nothing`, [CID]);
    check(await erroDe(rpc(admin.c, 'admin_categoria_sistema', { p_codigo: 'COMPARTILHADA', p_disponivel: true })) === 'CATEGORIA_AINDA_NAO_IMPLEMENTADA', 'Compartilhada não pode ser ligada (ainda não implementada)');
    for (const c of ['FAMILIAR', 'AEROPORTO']) await rpc(admin.c, 'admin_categoria_sistema', { p_codigo: c, p_disponivel: true });
    const MF = await aprovarMotorista(await novoUsuario('Motorista Família', { motorista: true }));
    await offline(MF);
    await q(`update veiculos set categorias_aprovadas = categorias_aprovadas || '{FAMILIAR}' where id=$1`, [MF.veiculo]);
    let cats = await rpc(MF.c, 'minhas_categorias');
    let fam = cats.find(c => c.categoria === 'FAMILIAR');
    check(fam && !fam.liberada && fam.pendencias.includes('ITEM_NAO_VERIFICADO_CADEIRINHA') && fam.pendencias.includes('TREINAMENTO_TRANSPORTE_INFANTIL'),
      'Familiar exige cadeirinha verificada e treinamento', fam && fam.pendencias);
    check(await erroDe(rpc(MF.c, 'motorista_declarar_itens', { p_veiculo: MF.veiculo, p_itens: '{foguete}' })) === 'ITEM_INVALIDO', 'item fora da lista é recusado');
    await rpc(MF.c, 'motorista_declarar_itens', { p_veiculo: MF.veiculo, p_itens: '{cadeirinha}' });
    fam = (await rpc(MF.c, 'minhas_categorias')).find(c => c.categoria === 'FAMILIAR');
    check(!fam.liberada, 'declarar não basta: precisa da verificação da operação');
    check(await erroDe(rpc(MF.c, 'ops_verificar_itens_veiculo', { p_veiculo: MF.veiculo, p_itens: '{cadeirinha}' })) === 'SEM_PERMISSAO', 'motorista não verifica o próprio item');
    await rpc(admin.c, 'ops_verificar_itens_veiculo', { p_veiculo: MF.veiculo, p_itens: '{cadeirinha,rampa}' });
    const itens = (await q(`select itens_verificados from veiculos where id=$1`, [MF.veiculo]))[0].itens_verificados;
    check(itens.join() === 'cadeirinha', 'operação só verifica o que foi declarado (rampa ignorada)', itens);
    await rpc(admin.c, 'ops_definir_treinamento', { p_motorista: MF.id, p_treinamento: 'TRANSPORTE_INFANTIL', p_ativo: true });
    fam = (await rpc(MF.c, 'minhas_categorias')).find(c => c.categoria === 'FAMILIAR');
    check(fam.liberada, 'com item verificado e treinamento, Familiar é liberada');
    const on = await rpc(MF.c, 'ficar_online', { p_lat: perto(1).lat, p_lng: perto(1).lng });
    check(JSON.stringify(on).includes('FAMILIAR'), 'ao ficar online já recebe corridas Familiar', on);
    await rpc(MF.c, 'motorista_declarar_itens', { p_veiculo: MF.veiculo, p_itens: '{}' });
    check(!(await q(`select interno.categorias_liberadas($1) c`, [MF.id]))[0].c.includes('FAMILIAR'), 'retirou a cadeirinha: perde a categoria na hora');
    await offline(MF);
    // regra geográfica
    const P = await novoUsuario('Passageiro Aeroporto');
    check(await erroDe(pedir(P, uuidv4(), { p_categoria: 'AEROPORTO' })) === 'CATEGORIA_SO_DE_OU_PARA_AEROPORTO', 'Aeroporto só vale de/para aeroporto cadastrado');
    let est = await rpc(P.c, 'estimar_corrida_detalhada', { p_cidade: CID, p_o_lat: O.lat, p_o_lng: O.lng, p_d_lat: D.lat, p_d_lng: D.lng });
    check(est.estimativa === true && !est.opcoes.some(o => o.categoria === 'AEROPORTO'), 'estimativa não oferece Aeroporto fora do aeroporto');
    await rpc(admin.c, 'ops_salvar_regiao', { p: JSON.stringify({ cidade_id: CID, nome: 'Aeroporto Teste', centro_lat: D.lat, centro_lng: D.lng, raio_km: 2, tipo: 'AEROPORTO' }) });
    est = await rpc(P.c, 'estimar_corrida_detalhada', { p_cidade: CID, p_o_lat: O.lat, p_o_lng: O.lng, p_d_lat: D.lat, p_d_lng: D.lng });
    const aer = est.opcoes.find(o => o.categoria === 'AEROPORTO');
    check(aer && aer.inclui.some(i => /porta malas/.test(i)) && /min|motoristas/.test(aer.chegada_faixa), 'indo ao aeroporto: categoria aparece com requisitos e faixa de chegada', aer);
    const r = await pedir(P, uuidv4(), { p_categoria: 'AEROPORTO' });
    check(!!r.corrida, 'corrida Aeroporto aceita quando o destino é o aeroporto');
    const op = await rpc(P.c, 'definir_opcoes_corrida', { p_corrida: r.corrida, p_opcoes: JSON.stringify({ voo: 'G3-1234<', bagagens: 40, observacao: '<b>porta 3</b>', hack: 'x' }) });
    check(op.voo === 'G31234' && op.bagagens === 10 && !('hack' in op) && !op.observacao.includes('<'), 'opções da corrida saneadas (voo, bagagens, observação)', op);
    await rpc(P.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'teste' });
  });

  await secao('EXPERIÊNCIA DO PASSAGEIRO (favoritos, recibo, histórico)', async () => {
    const P = await novoUsuario('Passageira Experiente');
    await rpc(P.c, 'salvar_local_favorito', { p_nome: 'Casa', p_endereco: 'Rua X, 10', p_lat: O.lat, p_lng: O.lng });
    await rpc(P.c, 'salvar_local_favorito', { p_nome: 'Casa', p_endereco: 'Rua Y, 20', p_lat: O.lat, p_lng: O.lng });
    const fav = (await P.c.query(`select nome, endereco from locais_favoritos`)).rows;
    check(fav.length === 1 && fav[0].endereco === 'Rua Y, 20', 'favorito com mesmo nome é atualizado (sem duplicar)');
    const outro = await novoUsuario('Bisbilhoteiro');
    check((await outro.c.query(`select count(*)::int n from locais_favoritos`)).rows[0].n === 0, 'ninguém vê favoritos dos outros');
    const { corrida } = await corridaPaga(P, M1);
    const rec = await rpc(P.c, 'recibo_corrida', { p_corrida: corrida });
    check(rec.valor_pago !== undefined && rec.motorista === 'Motorista' && /·/.test(rec.veiculo), 'recibo com valores, 1º nome do motorista e veículo', rec);
    check(await erroDe(rpc(outro.c, 'recibo_corrida', { p_corrida: corrida })) === 'CORRIDA_NAO_ENCONTRADA', 'outro usuário não vê o recibo');
    const h = await rpc(P.c, 'historico_passageiro', {});
    check(h.length === 1 && h[0].avaliada === false, 'histórico mostra a corrida e se já foi avaliada');
  });

  await secao('CORRIDAS AGENDADAS', async () => {
    const P = await novoUsuario('Passageiro Agenda');
    const base = { p_cidade: CID, p_categoria: 'ECONOMICO', p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Casa', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Trabalho', p_metodo: 'PIX' };
    const em = (min) => new Date(Date.now() + min * 60000).toISOString();
    check(await erroDe(rpc(P.c, 'agendar_corrida', Object.assign({ p_chave_idempotencia: uuidv4(), p_agendada_para: em(10) }, base))) === 'ANTECEDENCIA_MINIMA', 'agendamento exige antecedência mínima');
    const k = uuidv4();
    const a1 = await rpc(P.c, 'agendar_corrida', Object.assign({ p_chave_idempotencia: k, p_agendada_para: em(45) }, base));
    const a1b = await rpc(P.c, 'agendar_corrida', Object.assign({ p_chave_idempotencia: k, p_agendada_para: em(45) }, base));
    check(a1.agendamento === a1b.agendamento && a1b.repetido, 'agendar duas vezes com a mesma chave não duplica');
    check(Number(a1.preco_estimado) > 0 && /estimativa/.test(a1.aviso), 'agendamento mostra preço como estimativa');
    await rpc(P.c, 'cancelar_agendamento', { p_agendamento: a1.agendamento });
    check((await rpc(P.c, 'minhas_agendadas'))[0].status === 'CANCELADA', 'passageiro cancela agendamento sem custo');
    const a2 = await rpc(P.c, 'agendar_corrida', Object.assign({ p_chave_idempotencia: uuidv4(), p_agendada_para: em(45), p_opcoes: JSON.stringify({ observacao: 'Portão azul' }) }, base));
    await q(`select interno.job_agendadas()`);
    check((await q(`select lembrete_enviado from corridas_agendadas where id=$1`, [a2.agendamento]))[0].lembrete_enviado === true, 'lembrete enviado 1 h antes');
    await q(`update corridas_agendadas set agendada_para = now() + interval '10 minutes' where id=$1`, [a2.agendamento]);
    const j = (await q(`select interno.job_agendadas() r`))[0].r;
    const ag = (await q(`select status, corrida_id from corridas_agendadas where id=$1`, [a2.agendamento]))[0];
    const c = ag.corrida_id && (await q(`select passageiro_id, opcoes, status from corridas where id=$1`, [ag.corrida_id]))[0];
    check(ag.status === 'DISPARADA' && c && c.passageiro_id === P.id && c.opcoes.observacao === 'Portão azul', 'no horário, a corrida é criada para o passageiro com as opções', { j, ag, c });
    const ctx = (await q(`select current_setting('request.jwt.claim.sub', true) s`))[0].s;
    check(!ctx, 'job devolve o contexto (não fica "logado" como o passageiro)', ctx);
    if (c) await rpc(P.c, 'cancelar_corrida', { p_corrida: ag.corrida_id, p_motivo: 'teste' });
    // falha no disparo: conta bloqueada
    const a3 = await rpc(P.c, 'agendar_corrida', Object.assign({ p_chave_idempotencia: uuidv4(), p_agendada_para: em(45) }, base));
    await q(`update corridas_agendadas set agendada_para = now() + interval '5 minutes' where id=$1`, [a3.agendamento]);
    await q(`update perfis set status='BLOQUEADO' where id=$1`, [P.id]);
    await q(`select interno.job_agendadas()`);
    const f = (await q(`select status, falha from corridas_agendadas where id=$1`, [a3.agendamento]))[0];
    const nt = await q(`select count(*)::int n from notificacoes where usuario_id=$1 and titulo like 'Não foi possível%'`, [P.id]);
    check(f.status === 'FALHOU' && nt[0].n >= 1, 'se não der para disparar, marca FALHOU e avisa o passageiro (nada é cobrado)', f);
    await q(`update perfis set status='ATIVO' where id=$1`, [P.id]);
  });

  await secao('PAINEL DO DONO, MAPA NACIONAL E ANALYTICS', async () => {
    const ini = new Date(Date.now() - 86400000).toISOString(), fim = new Date(Date.now() + 86400000).toISOString();
    check(await erroDe(rpc(M1.c, 'dono_dashboard', { p_inicio: ini, p_fim: fim })) === 'SEM_PERMISSAO', 'motorista não vê o painel do dono');
    await rpc(admin.c, 'fin_lancar_custo_operacional', { p_data: new Date().toISOString().slice(0, 10), p_categoria: 'MARKETING', p_valor: 100, p_descricao: 'Anúncios' });
    const d = await rpc(admin.c, 'dono_dashboard', { p_inicio: ini, p_fim: fim });
    const gmv = Number((await q(`select coalesce(sum(preco_final),0) s from corridas where status='PAGA'`))[0].s);
    check(Math.abs(Number(d.financeiro.gmv) - gmv) < 0.01, 'GMV do painel = soma real das corridas pagas', { painel: d.financeiro.gmv, gmv });
    check(d.financeiro.conferencia.ok === true, 'conferência: GMV = motoristas + indicação + comissão', d.financeiro);
    check(d.lucro_operacional_estimado.estimativa === true && Number(d.financeiro.custos_operacionais) === 100, 'lucro operacional marcado como estimativa e considera custos lançados');
    check(d.cac.valor !== null && Number(d.cac.marketing) === 100, 'CAC calculado com marketing ÷ novos passageiros', d.cac);
    check(d.ltv_estimado.estimativa === true, 'LTV marcado como estimativa');
    const dm = await rpc(admin.c, 'dono_dashboard', { p_inicio: ini, p_fim: fim, p_motorista: M1.id });
    check(Number(dm.financeiro.gmv) <= Number(d.financeiro.gmv) && dm.lucro_operacional_estimado.aviso, 'filtro por motorista funciona e avisa o que sai da conta');
    check((await erroDe(q(`update custos_operacionais set valor = 1`))) !== null, 'custo lançado é imutável (corrige-se com lançamento negativo)');
    const br = await rpc(admin.c, 'mapa_operacional', {});
    check(br.nivel === 'BRASIL' && br.itens.some(i => i.chave === 'RJ'), 'mapa nacional agrega por UF', br.itens.map(i => i.chave));
    const uf = await rpc(admin.c, 'mapa_operacional', { p_uf: 'RJ' });
    check(uf.nivel === 'UF' && uf.itens.some(i => i.chave === CID), 'UF → cidades');
    const ci = await rpc(admin.c, 'mapa_operacional', { p_cidade: CID });
    check(ci.nivel === 'CIDADE' && Array.isArray(ci.zonas) && ci.motoristas.every(m => String(m.lat).split('.')[1].length <= 3), 'cidade → zonas; posição de motoristas aproximada (~100 m)');
    check(await erroDe(rpc(P1.c, 'mapa_operacional', {})) === 'SEM_PERMISSAO', 'passageiro não vê o mapa operacional');
    const co = await rpc(admin.c, 'analytics_coortes', { p_publico: 'PASSAGEIRO', p_meses: 3 });
    check(co.coortes.length >= 1 && co.coortes[co.coortes.length - 1].retencao_pct[0] === 100, 'coorte do mês atual com 100% no mês 0', co.coortes);
    const fu = await rpc(admin.c, 'analytics_funil', { p_inicio: ini, p_fim: fim });
    check(fu.solicitadas >= fu.com_motorista && fu.com_motorista >= fu.pagas && fu.tempo_ate_aceite_seg.p50 !== undefined, 'funil coerente (solicitadas ≥ aceitas ≥ pagas) com tempos', fu);
  });

  await secao('NOTIFICAÇÕES INTELIGENTES (contexto real, sem spam)', async () => {
    await q(`update configuracoes set valor='{}' where chave='notif_silencio'`);   // teste roda a qualquer hora
    await q(`update documentos set validade = current_date + 7 where motorista_id=$1 and tipo='CNH'`, [M1.id]);
    await q(`select interno.job_notificacoes()`);
    await q(`select interno.job_notificacoes()`);
    const n = await q(`select count(*)::int n from notificacoes where usuario_id=$1 and evento='DOCUMENTO_VENCENDO' and canal='PUSH'`, [M1.id]);
    check(n[0].n === 1, 'documento vencendo em 7 dias: avisa uma vez (rodar o job de novo não repete)', n[0].n);
    await q(`update documentos set validade = '2030-01-01' where motorista_id=$1 and tipo='CNH'`, [M1.id]);
    const sim = await novoUsuario('Quer Promoções');
    await rpc(sim.c, 'registrar_consentimento', { p_tipo: 'MARKETING', p_versao: 'v1', p_aceito: true });
    const camp = await rpc(admin.c, 'ops_enviar_campanha', { p_titulo: 'Fim de semana', p_mensagem: '10% off com BEMVINDO10', p_publico: 'PASSAGEIROS' });
    const recebeu = await q(`select count(*)::int n from notificacoes where evento='PROMOCAO' and usuario_id=$1`, [sim.id]);
    const naoConsentiu = await q(`select count(*)::int n from notificacoes where evento='PROMOCAO' and usuario_id=$1`, [P1.id]);
    check(recebeu[0].n >= 1 && naoConsentiu[0].n === 0 && camp.puladas_sem_consentimento_ou_limite > 0, 'promoção só para quem consentiu', camp);
    await rpc(admin.c, 'ops_enviar_campanha', { p_titulo: 'De novo', p_mensagem: 'Outra promoção hoje', p_publico: 'PASSAGEIROS' });
    const r2 = await q(`select count(*)::int n from notificacoes where evento='PROMOCAO' and usuario_id=$1 and canal='PUSH'`, [sim.id]);
    check(r2[0].n === 1, 'no máximo 1 push de promoção por dia por pessoa', r2[0].n);
    check(await erroDe(rpc(sim.c, 'salvar_preferencia_notificacao', { p_evento: 'SEGURANCA', p_ativo: false })) === 'NOTIFICACAO_ESSENCIAL', 'avisos essenciais não podem ser desligados');
  });

  await secao('JORNADA PONTA A PONTA E CENÁRIOS DE FALHA', async () => {
    await offline(M1);
    // indicação: A indica B
    const A = await aprovarMotorista(await novoUsuario('Ana Indicadora', { motorista: true }));
    await offline(A);
    const B = await aprovarMotorista(await novoUsuario('Bruno Indicado', { motorista: true, codigo: A.codigo }));
    const P = await novoUsuario('Paula Passageira');
    // 1) pedido → matching → motorista → corrida
    const r = await pedir(P);
    const of = await ofertaDe(B);
    check(of && of.oferta, 'matching oferta a corrida ao motorista próximo');
    await rpc(B.c, 'aceitar_oferta', { p_oferta: of.oferta });
    await chegar(B, r.corrida);
    const pinErr = await rpc(B.c, 'iniciar_corrida', { p_corrida: r.corrida, p_pin: '0000' === await pinDe(r.corrida) ? '1111' : '0000' });
    check(pinErr.ok === false && pinErr.erro === 'PIN_INCORRETO' && (await q(`select status from corridas where id=$1`, [r.corrida]))[0].status === 'CHEGOU', 'PIN errado não inicia a corrida', pinErr);
    await rpc(B.c, 'iniciar_corrida', { p_corrida: r.corrida, p_pin: await pinDe(r.corrida) });
    await q(`update corridas set iniciada_em = now() - interval '15 minutes' where id=$1`, [r.corrida]);
    await trilha(r.corrida, B);
    const fin = await rpc(B.c, 'finalizar_corrida', { p_corrida: r.corrida, p_km_app: null });
    // 2) pagamento falha → passageiro não pede outra → paga de novo
    await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'falha-' + fin.pagamento.id, p_tipo: 'PAGAMENTO_FALHOU', p_payload: JSON.stringify({ pagamento_id: fin.pagamento.id, motivo: 'cartão recusado' }) });
    check((await q(`select status from pagamentos where id=$1`, [fin.pagamento.id]))[0].status === 'FALHOU', 'falha de pagamento registrada');
    check(await erroDe(pedir(P)) === 'PAGAMENTO_EM_ABERTO', 'com cobrança falha, passageiro paga antes de pedir outra');
    const novo = await rpc(P.c, 'pagar_novamente', { p_pagamento: fin.pagamento.id, p_metodo: 'PIX' });
    // 3) falha no processamento do webhook (payload quebrado) → nada é gravado → reenvio funciona
    const quebrado = await erroDe(rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'ok-1', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify({ pagamento_id: novo.id, valor: 'abc' }) }));
    check(quebrado !== null && (await q(`select count(*)::int n from webhooks_recebidos where evento_id='ok-1'`))[0].n === 0, 'erro no processamento não marca o evento como recebido (o gateway reenvia)', quebrado);
    await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'ok-1', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify({ pagamento_id: novo.id, gateway_ref: 'g1', valor: novo.valor }) });
    const dup = await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'ok-1', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify({ pagamento_id: novo.id, gateway_ref: 'g1', valor: novo.valor }) });
    check(dup.duplicado === true, 'reenvio do mesmo webhook depois de processado é ignorado');
    const c = (await q(`select status, preco_final from corridas where id=$1`, [r.corrida]))[0];
    check(c.status === 'PAGA', 'corrida paga após nova tentativa');
    // 4) comissão + indicação + carteira
    const preco = Number(c.preco_final);
    const recB = Number((await q(`select valor from recebiveis where corrida_id=$1 and tipo='CORRIDA'`, [r.corrida]))[0].valor);
    const gA = Number((await q(`select valor from ganhos_indicacao where corrida_id=$1 and beneficiario_id=$2`, [r.corrida, A.id]))[0].valor);
    const liq = (await q(`select l.valor, ct.tipo from lancamentos_ledger l join contas_ledger ct on ct.id=l.conta_id join transacoes_ledger t on t.id=l.transacao_id
                          where t.chave_idempotencia=$1 and ct.tipo='PLATAFORMA_RECEITA'`, ['LIQ:' + r.corrida]))[0];
    check(Math.abs(recB - preco * 0.8) < 0.011 && Math.abs(gA - preco * 0.03) < 0.011 && Math.abs(Number(liq.valor) - (preco - recB - gA)) < 0.011,
      'divisão: motorista 80%, indicador 3%, plataforma o restante (sem 2º/3º nível)', { preco, recB, gA, plat: liq.valor });
    // 5) avaliação dos dois lados
    await rpc(P.c, 'avaliar_corrida', { p_corrida: r.corrida, p_nota: 5, p_comentario: 'Ótimo' });
    await rpc(B.c, 'avaliar_corrida', { p_corrida: r.corrida, p_nota: 5 });
    check((await q(`select count(*)::int n from avaliacoes where corrida_id=$1`, [r.corrida]))[0].n === 2, 'passageiro e motorista avaliam');
    // 6) liberação D+N e repasse
    await q(`update configuracoes set valor='5' where chave='repasse_minimo'`);   // corrida de teste é curta
    await q(`update recebiveis set libera_em = now() - interval '1 minute' where corrida_id=$1`, [r.corrida]);
    await q(`select interno.job_liberar_saldos()`);
    const disp = await saldo(B.id, 'MOTORISTA_DISPONIVEL');
    check(Math.abs(disp - recB) < 0.01, 'ganho liberado após o prazo vai para o disponível');
    const rep = await rpc(B.c, 'solicitar_repasse', { p_valor: Math.floor(disp), p_chave_pix: 'bruno@pix', p_origem: 'GANHOS', p_chave_idempotencia: uuidv4() });
    await rpc(servidor, 'fin_concluir_repasse', { p_repasse: rep.id, p_sucesso: true, p_gateway_ref: 'pix-ok', p_motivo: null });
    check(Math.abs(await saldo(B.id, 'MOTORISTA_DISPONIVEL') - (disp - Math.floor(disp))) < 0.01, 'repasse PIX concluído debita o disponível');
    // 7) estorno de outra corrida
    const r2 = await pedir(P);
    const fin2 = await correrAteFinalizar(P, B, r2.corrida);
    await confirmarWebhook(fin2.pagamento);
    await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: r2.corrida, p_motivo: 'Cobrança indevida comprovada' });
    const g2 = await q(`select status from ganhos_indicacao where corrida_id=$1`, [r2.corrida]);
    const rc2 = await q(`select status from recebiveis where corrida_id=$1`, [r2.corrida]);
    check(g2.every(g => g.status === 'ESTORNADO') && rc2[0].status === 'ESTORNADO', 'estorno desfaz ganho do motorista e bônus de indicação');
    check((await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: r2.corrida, p_motivo: 'de novo' })).repetido === true, 'estorno duplicado não estorna duas vezes');
    // 8) queda: motorista some no caminho → sistema volta a buscar
    const r3 = await pedir(P);
    const of3 = await ofertaDe(B);
    await rpc(B.c, 'aceitar_oferta', { p_oferta: of3.oferta });
    await q(`update motorista_presenca set atualizado_em = now() - interval '6 minutes' where motorista_id=$1`, [B.id]);
    await q(`update corridas set aceita_em = now() - interval '6 minutes' where id=$1`, [r3.corrida]);
    await q(`select interno.job_corridas_travadas()`);
    const c3 = (await q(`select status, motorista_id from corridas where id=$1`, [r3.corrida]))[0];
    check(['BUSCANDO', 'SEM_MOTORISTA'].includes(c3.status) && c3.motorista_id === null, 'motorista sem sinal: corrida volta para a busca sem custo', c3);
    await rpc(P.c, 'cancelar_corrida', { p_corrida: r3.corrida, p_motivo: 'fim do teste' });
    check((await q(`select count(*)::int n from pagamentos where corrida_id=$1`, [r3.corrida]))[0].n === 0, 'cancelar antes de ter motorista não cobra nada');
    await online(M1);
  });

  await secao('CORREÇÕES DA AUDITORIA DA ETAPA 2 (1 teste por achado)', async () => {
    const SA = await novoUsuario('Super Admin'); await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'SUPER_ADMIN')`, [SA.id]);
    // retenção: só SUPER_ADMIN, com piso legal; nem configurando direto no banco o job apaga antes do piso
    check(await erroDe(rpc(admin.c, 'admin_salvar_config', { p_chave: 'retencao_auditoria_dias', p_valor: '0' })) === 'SEM_PERMISSAO', 'ADMIN não mexe nos prazos de retenção');
    check(await erroDe(rpc(SA.c, 'admin_salvar_config', { p_chave: 'retencao_auditoria_dias', p_valor: '0' })) === 'VALOR_ABAIXO_DO_MINIMO_LEGAL', 'nem o SUPER_ADMIN reduz abaixo do mínimo legal');
    const audAntes = (await q(`select count(*)::int n from auditoria`))[0].n;
    await q(`update configuracoes set valor='0' where chave='retencao_auditoria_dias'`); await q(`select interno.job_retencao()`);
    check((await q(`select count(*)::int n from auditoria`))[0].n >= audAntes, 'job de retenção respeita o piso mesmo com configuração zerada');
    await q(`update configuracoes set valor='1825' where chave='retencao_auditoria_dias'`);
    // HTML em nome de região/cidade é recusado no banco
    check(await erroDe(rpc(admin.c, 'ops_salvar_regiao', { p: JSON.stringify({ cidade_id: CID, nome: '<img src=x onerror=alert(1)>', centro_lat: O.lat, centro_lng: O.lng, raio_km: 1, tipo: 'BAIRRO' }) })) === 'TEXTO_INVALIDO', 'nome com HTML é recusado (proteção contra XSS no painel)');
    // assistente do admin: SUPORTE não vê números financeiros
    const sup = await novoUsuario('Suporte Só'); await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'SUPORTE')`, [sup.id]);
    const rs = await rpc(sup.c, 'assistente_admin', { p_pergunta: 'Qual foi a receita da semana?' });
    check(rs.dados_suficientes === false && !/R\$/.test(rs.resposta), 'assistente não mostra receita para SUPORTE', rs.resposta);
    // conta de equipe bloqueada perde o acesso
    await q(`update perfis set status='BLOQUEADO' where id=$1`, [sup.id]);
    check(/^CONTA_BLOQUEADO/.test(await erroDe(rpc(sup.c, 'seguranca_painel', {})) || '') , 'equipe com conta bloqueada não usa as funções de staff');
    check((await sup.c.query(`select interno.eh_staff() s`).catch(() => ({ rows: [{ s: 'erro' }] }))).rows[0].s !== true, 'RLS deixa de tratar a conta bloqueada como equipe');
    // passageiro não vê quais motoristas recusaram
    check((await erroDe(P1.c.query(`select motoristas_excluidos from corridas limit 1`))) !== null, 'coluna motoristas_excluidos não é visível para o app');
    // emergência repetida não duplica incidente
    const re = await pedir(P1); const ofe = await ofertaDe(M1); await rpc(M1.c, 'aceitar_oferta', { p_oferta: ofe.oferta });
    const e1 = await rpc(P1.c, 'acionar_emergencia', { p_corrida: re.corrida }); const e2 = await rpc(P1.c, 'acionar_emergencia', { p_corrida: re.corrida });
    check(e1 === e2, 'toque repetido no botão de emergência não abre outro incidente');
    await rpc(P1.c, 'cancelar_corrida', { p_corrida: re.corrida, p_motivo: 'teste' }).catch(() => {});

    // ---- dinheiro ----
    const W = await novoUsuario('Carteira Teste');
    const r0 = await rpc(W.c, 'recarregar_carteira', { p_valor: 100, p_metodo: 'PIX', p_chave_idempotencia: 'w-recarga-0' }); await confirmarWebhook(r0);
    const r1 = await rpc(W.c, 'recarregar_carteira', { p_valor: 100, p_metodo: 'PIX', p_chave_idempotencia: 'w-recarga-1' });
    check(await erroDe(rpc(W.c, 'pagar_novamente', { p_pagamento: r1.pagamento, p_metodo: 'CARTEIRA' })) === 'METODO_INVALIDO_PARA_ESTE_PAGAMENTO' && await saldo(W.id, 'PASSAGEIRO_CARTEIRA') === 100,
      'créditos não pagam recarga de créditos (não se cria dinheiro do nada)');
    const plano = (await q(`select id, preco_mensal from planos_assinatura where ativo limit 1`))[0];
    const gwAntes = await saldoPlat('GATEWAY_RECEBIVEIS');
    const a1 = await rpc(W.c, 'assinar_plano', { p_plano: plano.id, p_metodo: 'PIX' });
    await rpc(W.c, 'assinar_plano', { p_plano: plano.id, p_metodo: 'CARTEIRA' });
    check(Math.abs(await saldo(W.id, 'PASSAGEIRO_CARTEIRA') - (100 - Number(plano.preco_mensal))) < 0.01 && Math.abs(await saldoPlat('GATEWAY_RECEBIVEIS') - gwAntes) < 0.01
      && (await q(`select status from pagamentos where id=$1`, [a1.pagamento]))[0].status === 'CANCELADO', 'trocar PIX por créditos no Mobi+ cobra dos créditos e cancela a cobrança PIX (sem assinatura grátis)');
    await rpc(W.c, 'cancelar_assinatura');
    // renovação: período em que o mês se repete não colide
    await q(`update assinaturas set status='ATIVA', renova_em = date_trunc('month', now()) + interval '20 hours' where usuario_id=$1`, [W.id]);
    const ren = (await q(`select interno.job_assinaturas() r`))[0].r;
    check(ren.renovacoes_geradas >= 1, 'renovação gerada mesmo quando cai no mesmo mês da cobrança anterior', ren);
    // pagamento substituído e confirmado depois: não quebra o webhook, vai para devolução
    const X = await novoUsuario('Pagou Duas Vezes');
    const rx = await pedir(X); const finx = await correrAteFinalizar(X, M1, rx.corrida);
    await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'f-' + finx.pagamento.id, p_tipo: 'PAGAMENTO_FALHOU', p_payload: JSON.stringify({ pagamento_id: finx.pagamento.id, motivo: 'x' }) });
    const nx = await rpc(X.c, 'pagar_novamente', { p_pagamento: finx.pagamento.id, p_metodo: 'PIX' });
    await confirmarWebhook(nx);
    const tarde = await confirmarWebhook(finx.pagamento, 'tarde-' + finx.pagamento.id);
    check(tarde.erro === 'PAGAMENTO_SUBSTITUIDO_DEVOLVER' && (await q(`select count(*)::int n from webhooks_recebidos where evento_id=$1`, ['tarde-' + finx.pagamento.id]))[0].n === 1,
      'confirmação atrasada de cobrança substituída fica registrada para devolução (webhook não entra em loop)', tarde);
    check((await q(`select count(*)::int n from transacoes_ledger where chave_idempotencia=$1`, ['LIQ:' + rx.corrida]))[0].n === 1, 'corrida liquidada uma única vez');
    // reembolso em créditos: idempotente e nunca depois de estorno
    const k = uuidv4();
    await Promise.all([rpc(admin.c, 'fin_reembolsar_em_creditos', { p_corrida: rx.corrida, p_valor: 3, p_motivo: 'Demora na chegada', p_chave: k }),
      rpc(await conectar(admin.id), 'fin_reembolsar_em_creditos', { p_corrida: rx.corrida, p_valor: 3, p_motivo: 'Demora na chegada', p_chave: k })]);
    check(await saldo(X.id, 'PASSAGEIRO_CARTEIRA') === 3, 'mesmo pedido de reembolso repetido (em paralelo) credita uma vez só');
    await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: rx.corrida, p_motivo: 'Cobrança indevida' });
    check(await erroDe(rpc(admin.c, 'fin_reembolsar_em_creditos', { p_corrida: rx.corrida, p_valor: 5, p_motivo: 'Mais um reembolso' })) === 'CORRIDA_JA_ESTORNADA', 'corrida estornada não recebe crédito extra');
    // painel do dono continua fechando depois do estorno
    const ini = new Date(Date.now() - 864e5).toISOString(), fim = new Date(Date.now() + 864e5).toISOString();
    const dd = await rpc(admin.c, 'dono_dashboard', { p_inicio: ini, p_fim: fim });
    check(dd.financeiro.conferencia.ok === true && Number(dd.financeiro.corridas_estornadas_valor) > 0, 'painel do dono fecha a conta com corridas estornadas', dd.financeiro);
    // empresa: limite sob concorrência e estorno depois da fatura
    const G = await novoUsuario('Gestor Concorrência');
    const emp = await rpc(G.c, 'empresa_cadastrar', { p_razao: 'Corre Ltda', p_fantasia: 'Corre', p_cnpj: cnpj(), p_cidade: CID, p_email_financeiro: 'f@corre.com' });
    await rpc(admin.c, 'fin_aprovar_empresa', { p_empresa: emp, p_aprovar: true, p_limite: 40 });
    const funcs = [];
    for (let i = 0; i < 3; i++) { const f = await novoUsuario('Func ' + i); const c = await rpc(G.c, 'empresa_adicionar_membro', { p_empresa: emp, p_contato: f.id + '@teste.com' });
      await rpc(f.c, 'responder_convite_empresa', { p_convite: c.convite, p_aceitar: true }); funcs.push(f); }
    const tent = await Promise.allSettled(funcs.map(async (f) => rpc(await conectar(f.id), 'solicitar_corrida_empresa', { p_empresa: emp, p_chave_idempotencia: uuidv4(), p_cidade: CID, p_categoria: 'ECONOMICO',
      p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'A', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'B' })));
    const aceitas = tent.filter((t) => t.status === 'fulfilled').length;
    check(aceitas === 1, 'limite de crédito da empresa vale com pedidos simultâneos (R$ 40 → só 1 corrida de ~R$ 21)', tent.map((t) => t.status === 'fulfilled' ? 'ok' : t.reason.message));
    const rc = tent.findIndex((t) => t.status === 'fulfilled');
    const corridaEmp = tent[rc].value.corrida;
    await correrAteFinalizar(funcs[rc], M1, corridaEmp);
    const fat = await rpc(admin.c, 'fin_fechar_fatura', { p_empresa: emp });
    await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: corridaEmp, p_motivo: 'Corrida corporativa indevida' });
    const fv = (await q(`select valor, status from empresa_faturas where id=$1`, [fat]))[0];
    check(Number(fv.valor) === 0 && fv.status === 'PAGA' && Math.abs(await saldo(emp, 'EMPRESA_A_RECEBER')) < 0.01, 'estorno depois do fechamento abate a fatura (empresa não paga corrida estornada)', fv);
    // LGPD: exportação e exclusão cobrem as funções novas
    const L = await novoUsuario('Titular Novo');
    await rpc(L.c, 'salvar_local_favorito', { p_nome: 'Casa', p_endereco: 'Rua das Flores 123', p_lat: O.lat, p_lng: O.lng });
    await rpc(L.c, 'agendar_corrida', { p_chave_idempotencia: uuidv4(), p_cidade: CID, p_categoria: 'ECONOMICO', p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Casa', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Trabalho', p_metodo: 'PIX', p_agendada_para: new Date(Date.now() + 3 * 3600e3).toISOString() });
    const ex = await rpc(L.c, 'meus_dados_exportar');
    check(ex.locais_favoritos.length === 1 && ex.corridas_agendadas.length === 1 && 'empresas' in ex && 'perguntas_ao_assistente' in ex, 'exportação inclui favoritos, agendadas, empresas, assistente');
    await q(`select interno.anonimizar_usuario($1)`, [L.id]);
    const sobra = (await q(`select (select count(*) from locais_favoritos where usuario_id=$1)::int f, (select count(*) from corridas_agendadas where passageiro_id=$1 and (status='AGENDADA' or origem_endereco is not null))::int a`, [L.id]))[0];
    check(sobra.f === 0 && sobra.a === 0, 'anonimização remove favoritos e endereços/agendamentos', sobra);
  });

  await secao('LEDGER CONTINUA FECHANDO EM ZERO', async () => {
    const tot = (await q(`select coalesce(sum(valor),0) s from lancamentos_ledger`))[0].s;
    check(Number(tot) === 0, 'soma de todo o ledger = 0,00 depois de empresas, wallet, cupons e assinaturas', tot);
    const sal = await q(`select c.id from contas_ledger c left join saldos s on s.conta_id=c.id
                         where coalesce(s.saldo,0) <> coalesce((select sum(valor) from lancamentos_ledger l where l.conta_id=c.id),0)`);
    check(sal.length === 0, 'saldos materializados batem com o ledger');
    const neg = await q(`select count(*)::int n from saldos s join contas_ledger c on c.id=s.conta_id where c.tipo='PASSAGEIRO_CARTEIRA' and s.saldo < 0`);
    check(neg[0].n === 0, 'nenhuma carteira de passageiro negativa');
  });

  // ---------- relatório ----------
  for (const [s, n] of resultados) console.log(s ? `  ${s} ${n}` : n);
  console.log(`\n=========================================\n  ${ok} OK   ·   ${falhas} FALHA(S)\n=========================================`);
  for (const c of conexoes) await c.end().catch(() => {});
  process.exit(falhas ? 1 : 0);
})().catch(async e => { console.error('FALHA GERAL:', e); process.exit(2); });
