#!/bin/bash
# sobe o PostgreSQL de teste local (se não estiver rodando)
if ! pg_isready -h /var/tmp/pgtest -p 5433 >/dev/null 2>&1; then
  rm -f /var/tmp/pgtest/data/postmaster.pid
  su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D /var/tmp/pgtest/data -o '-p 5433 -k /var/tmp/pgtest' -l /var/tmp/pgtest/pg.log start" >/dev/null
  sleep 2
fi
