// ============================================================
// TESTES DAS EDGE FUNCTIONS + API REAL (PostgREST, o mesmo motor do Supabase)
// Sobe o PostgREST apontando para o banco de teste e exercita:
//   webhook (assinatura, replay, duplicado, conteúdo inválido, falha temporária),
//   push (VAPID, fila, aparelho removido), assistente (trava de números inventados),
//   e as permissões da API vistas "de fora" (anon / logado / servidor).
// Uso: node --experimental-strip-types supabase/tests/testes_funcoes.mjs   (via rodar_funcoes.sh)
// ============================================================
import { spawn } from 'node:child_process';
import { createHmac, randomUUID, webcrypto } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import pg from 'pg';
import { verificarAssinatura, hmacSha256Hex, compararSeguro } from '../functions/_shared/seguranca.ts';
import { tratarWebhook } from '../functions/_shared/webhook.ts';
import { criarRpc } from '../functions/_shared/rpc.ts';
import { jwtVapid, b64url, deB64url, enviarToque } from '../functions/_shared/push.ts';
import { processarFilaPush } from '../functions/_shared/enviador.ts';
import { numerosDe, textoSeguro } from '../functions/_shared/assistente.ts';
import { tratarCobranca, gatewaySimulado } from '../functions/_shared/cobranca.ts';

let ok = 0, falhas = 0;
const linhas = [];
const check = (c, nome, extra) => { if (c) { ok++; linhas.push('  ✔ ' + nome); } else { falhas++; linhas.push('  ✘ ' + nome + (extra !== undefined ? '  →  ' + JSON.stringify(extra) : '')); } };
const secao = async (nome, fn) => { linhas.push('\n■ ' + nome); try { await fn(); } catch (e) { falhas++; linhas.push('  ✘ ERRO INESPERADO: ' + (e.stack || e)); } };

const SEGREDO_JWT = 'segredo-de-teste-com-mais-de-32-caracteres!!';
const PORTA = 3999, URL_API = `http://127.0.0.1:${PORTA}`;
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
function jwt(claims) {
  const cab = b64({ alg: 'HS256', typ: 'JWT' }), corpo = b64({ exp: Math.floor(Date.now() / 1000) + 3600, ...claims });
  return `${cab}.${corpo}.${createHmac('sha256', SEGREDO_JWT).update(`${cab}.${corpo}`).digest('base64url')}`;
}
const ANON = jwt({ role: 'anon' }), SERVICO = jwt({ role: 'service_role' });
const db = new pg.Client(); await db.connect();
const q = async (s, p) => (await db.query(s, p)).rows;

// ---------- sobe o PostgREST ----------
writeFileSync('/tmp/postgrest_teste.conf', [
  `db-uri = "postgres://${process.env.PGUSER}@/${process.env.PGDATABASE}?host=${process.env.PGHOST}&port=${process.env.PGPORT}"`,
  `db-schemas = "public"`, `db-anon-role = "anon"`, `jwt-secret = "${SEGREDO_JWT}"`, `server-port = ${PORTA}`, `db-pool = 10`].join('\n'));
const prest = spawn(process.env.POSTGREST || '/tmp/claude-0/postgrest', ['/tmp/postgrest_teste.conf'], { stdio: 'ignore' });
for (let i = 0; i < 50; i++) { try { if ((await fetch(URL_API + '/')).status < 500) break; } catch {} await new Promise((r) => setTimeout(r, 200)); }

// "Supabase de bolso": o mesmo caminho /rest/v1 do Supabase, repassado ao PostgREST
import http from 'node:http';
const PROXY = 3998;
const proxy = http.createServer((req, res) => {
  const alvo = req.url.replace(/^\/rest\/v1/, '');
  const p2 = http.request({ host: '127.0.0.1', port: PORTA, path: alvo, method: req.method, headers: { ...req.headers, host: `127.0.0.1:${PORTA}` } }, (r2) => {
    res.writeHead(r2.statusCode, r2.headers); r2.pipe(res);
  });
  p2.on('error', () => { res.writeHead(502); res.end(); });
  req.pipe(p2);
}).listen(PROXY);
const rest = (token) => criarRpc(`http://127.0.0.1:${PROXY}`, ANON, token);
async function usuario(nome) {
  const id = randomUUID();
  await q(`insert into auth.users (id) values ($1)`, [id]);
  const t = jwt({ role: 'authenticated', sub: id });
  const cid = (await q(`select id from cidades where slug='piloto'`))[0].id;
  const n = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10));
  let s = n.reduce((a, d, i) => a + d * (10 - i), 0); let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0; n.push(d1);
  s = n.reduce((a, d, i) => a + d * (11 - i), 0); let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0; n.push(d2);
  await rest(t)('completar_cadastro', { p_nome: nome, p_telefone: '2198' + String(Math.random()).slice(2, 9), p_cpf: n.join(''), p_email: id + '@t.com', p_cidade: cid });
  return { id, t, rpc: rest(t) };
}
const assinar = async (segredo, corpo, ts) => ({ 'x-timestamp': String(ts), 'x-assinatura': await hmacSha256Hex(segredo, `${ts}.${corpo}`) });
const agora = () => Math.floor(Date.now() / 1000);

await secao('API VISTA DE FORA (PostgREST): PERMISSÕES', async () => {
  const u = await usuario('Usuário API');
  const negar = async (p) => { try { await p; return null; } catch (e) { return e; } };
  const e1 = await negar(rest(ANON)('executar_jobs', { p_qual: 'diario' }));
  check(e1 && [401, 403].includes(e1.status), 'anônimo não executa jobs', e1 && e1.status);
  const e2 = await negar(u.rpc('processar_webhook', { p_gateway: 'GW', p_evento_id: 'x', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: {} }));
  check(e2 && [401, 403].includes(e2.status), 'usuário logado não chama o webhook direto', e2 && e2.status);
  const r = await fetch(`${URL_API}/perfis?select=cpf`, { headers: { apikey: ANON, Authorization: `Bearer ${u.t}` } });
  check(r.status === 401 || r.status === 403, 'coluna CPF não sai pela API nem para o dono', r.status);
  const r2 = await fetch(`${URL_API}/perfis?select=nome`, { headers: { apikey: ANON, Authorization: `Bearer ${u.t}` } });
  const vis = await r2.json();
  check(r2.status === 200 && vis.length === 1, 'usuário só enxerga o próprio perfil (RLS)', vis.length);
  const r3 = await fetch(`${URL_API}/lancamentos_ledger?select=valor`, { headers: { apikey: ANON, Authorization: `Bearer ${u.t}` } });
  check(r3.status === 401 || r3.status === 403 || (await r3.json()).length === 0, 'ledger não é exposto aos apps');
  const r4 = await fetch(`${URL_API}/rpc/ver_corrida_compartilhada`, { method: 'POST', headers: { apikey: ANON, Authorization: `Bearer ${ANON}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_codigo: 'inexistente' }) });
  check(r4.status !== 401 && r4.status !== 403, 'link de acompanhamento funciona sem login (função pública controlada)', r4.status);
  const r5 = await fetch(`${URL_API}/rpc/minha_carteira`, { method: 'POST', headers: { apikey: ANON, Authorization: `Bearer ${ANON}`, 'Content-Type': 'application/json' }, body: '{}' });
  check(r5.status === 401 || r5.status === 403, 'anônimo não chama funções de usuário', r5.status);
});

await secao('WEBHOOK DE PAGAMENTO (Edge Function)', async () => {
  const SEG = 'segredo-do-gateway';
  const servidor = rest(SERVICO);
  const P = await usuario('Pagador Webhook');
  const rc = await P.rpc('recarregar_carteira', { p_valor: 50, p_metodo: 'PIX', p_chave_idempotencia: 'rec-webhook-1' });
  const corpo = JSON.stringify({ evento_id: 'evt-w1', tipo: 'PAGAMENTO_CONFIRMADO', pagamento_id: rc.pagamento, valor: 50, gateway_ref: 'gw-1' });
  const chamar = async (c, cab, extra = {}) => tratarWebhook({ gateway: 'generico', headers: new Headers({ ...cab, 'x-real-ip': '203.0.113.9' }), corpoCru: c, agoraSeg: agora(), segredo: SEG, rpc: servidor, ...extra });

  let r = await chamar(corpo, { 'x-timestamp': String(agora()), 'x-assinatura': 'abc' });
  check(r.status === 401, 'assinatura errada → 401', r);
  const sinal = await q(`select count(*)::int n from sinais_fraude where tipo='WEBHOOK_ASSINATURA_INVALIDA'`);
  check(sinal[0].n >= 1, 'tentativa com assinatura inválida vira sinal de risco');
  r = await chamar(corpo, await assinar(SEG, corpo, agora() - 3600));
  check(r.status === 401 && r.corpo.erro === 'FORA_DA_JANELA', 'webhook antigo reenviado (replay) → 401', r);
  r = await chamar(corpo, {});
  check(r.status === 401 && r.corpo.erro === 'SEM_ASSINATURA', 'sem assinatura → 401');
  r = await tratarWebhook({ gateway: 'generico', headers: new Headers(await assinar(SEG, corpo, agora())), corpoCru: corpo, agoraSeg: agora(), segredo: undefined, rpc: servidor });
  check(r.status === 500 && r.corpo.erro === 'SEGREDO_NAO_CONFIGURADO', 'sem segredo configurado, recusa tudo (fecha por padrão)');
  const ruim = JSON.stringify({ evento_id: 'evt-ruim', tipo: 'PAGAMENTO_CONFIRMADO', pagamento_id: 'nao-e-uuid', valor: 50 });
  r = await chamar(ruim, await assinar(SEG, ruim, agora()));
  check(r.status === 400 && r.corpo.erro === 'PAGAMENTO_ID_INVALIDO', 'conteúdo inválido → 400 (não reenviar)', r);
  const centavos = JSON.stringify({ evento_id: 'evt-c', tipo: 'PAGAMENTO_CONFIRMADO', pagamento_id: rc.pagamento, valor: 50.001 });
  r = await chamar(centavos, await assinar(SEG, centavos, agora()));
  check(r.status === 400, 'valor com mais de 2 casas é recusado');
  // falha temporária (banco fora): 500 e NADA gravado → o reenvio processa
  const rpcFora = async (fn, a) => { if (fn === 'processar_webhook') throw new TypeError('fetch failed'); return servidor(fn, a); };
  r = await chamar(corpo, await assinar(SEG, corpo, agora()), { rpc: rpcFora });
  check(r.status === 500 && (await q(`select count(*)::int n from webhooks_recebidos where evento_id='evt-w1'`))[0].n === 0, 'banco fora → 500, evento não marcado (gateway reenvia)', r);
  r = await chamar(corpo, await assinar(SEG, corpo, agora()));
  check(r.status === 200 && r.corpo.resultado.status === 'CONFIRMADO', 'reenvio com tudo certo → pagamento confirmado', r);
  const saldo = (await q(`select interno.saldo($1,'PASSAGEIRO_CARTEIRA') s`, [P.id]))[0].s;
  check(Number(saldo) === 50, 'crédito entrou uma vez na carteira', saldo);
  r = await chamar(corpo, await assinar(SEG, corpo, agora()));
  check(r.status === 200 && r.corpo.resultado.duplicado === true && Number((await q(`select interno.saldo($1,'PASSAGEIRO_CARTEIRA') s`, [P.id]))[0].s) === 50, 'mesmo evento de novo → 200 duplicado, sem crédito em dobro');
  // valor divergente: 200 (não adianta reenviar) + sinal de fraude
  const rc2 = await P.rpc('recarregar_carteira', { p_valor: 30, p_metodo: 'PIX', p_chave_idempotencia: 'rec-webhook-2' });
  const div = JSON.stringify({ evento_id: 'evt-div', tipo: 'PAGAMENTO_CONFIRMADO', pagamento_id: rc2.pagamento, valor: 3 });
  r = await chamar(div, await assinar(SEG, div, agora()));
  check(r.status === 200 && r.corpo.resultado.erro === 'VALOR_DIVERGENTE', 'valor diferente do cobrado → não confirma e registra sinal', r);
  const tent = await q(`select count(*)::int n, count(*) filter (where not assinatura_valida)::int ruins from webhook_tentativas`);
  check(tent[0].n >= 8 && tent[0].ruins >= 3, 'toda tentativa fica registrada (status, IP, assinatura, duração)', tent[0]);
  check(compararSeguro('abc', 'abc') && !compararSeguro('abc', 'abd') && !compararSeguro('abc', 'ab'), 'comparação de assinatura em tempo constante');
  const v = await verificarAssinatura({ segredo: 'x', corpo: '{}', timestamp: String(agora()), assinatura: 'sha256=' + await hmacSha256Hex('x', `${agora()}.{}`), agoraSeg: agora() });
  check(v.ok, 'aceita o prefixo "sha256=" usado por vários gateways');
});

await secao('PUSH (Web Push com VAPID, sem conteúdo)', async () => {
  const par = await webcrypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const pubRaw = new Uint8Array(await webcrypto.subtle.exportKey('raw', par.publicKey));
  const priv = (await webcrypto.subtle.exportKey('jwk', par.privateKey)).d;
  const vapid = { publica: b64url(pubRaw), privada: priv, contato: 'mailto:ops@exemplo.com' };
  const t = await jwtVapid('https://push.exemplo.com/abc', vapid, agora());
  const [c, p, s] = t.split('.');
  const valido = await webcrypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, par.publicKey, deB64url(s), new TextEncoder().encode(`${c}.${p}`));
  const claims = JSON.parse(Buffer.from(p, 'base64url').toString());
  check(valido && claims.aud === 'https://push.exemplo.com' && claims.sub.startsWith('mailto:'), 'JWT VAPID assinado (ES256) e verificável pela chave pública');
  let cab;
  await enviarToque('https://push.exemplo.com/abc', vapid, async (_u, init) => { cab = init.headers; return new Response(null, { status: 201 }); });
  check(cab.Authorization.startsWith('vapid t=') && cab['Content-Length'] === '0', 'push vai sem conteúdo (nenhum dado pessoal no servidor de push)');

  const U = await usuario('Usuário Push');
  await U.rpc('registrar_push', { p_endpoint: 'https://push.exemplo.com/aparelho-1', p_p256dh: 'x', p_auth: 'y', p_navegador: 'teste' });
  await U.rpc('registrar_push', { p_endpoint: 'https://push.exemplo.com/aparelho-velho', p_p256dh: 'x', p_auth: 'y', p_navegador: 'teste' });
  await q(`select interno.notificar($1,'CORRIDA','Motorista a caminho','Chega em 4 min')`, [U.id]);
  await q(`select interno.notificar($1,'CORRIDA','Motorista chegou','Placa ABC')`, [U.id]);
  const tocados = [];
  const r = await processarFilaPush(rest(SERVICO), async (endpoint) => { tocados.push(endpoint); return endpoint.endsWith('velho') ? { ok: false, remover: true, status: 410 } : { ok: true, remover: false, status: 201 }; });
  check(tocados.filter((e) => e.endsWith('aparelho-1')).length === 1, '2 notificações na fila → 1 toque por aparelho (sem spam)', tocados);
  check(r.removidos === 1 && (await q(`select count(*)::int n from push_inscricoes where usuario_id=$1`, [U.id]))[0].n === 1, 'aparelho desinstalado (410) sai da lista', r);
  const st = await q(`select status from notificacoes where usuario_id=$1 and canal='PUSH' and titulo like 'Motorista%'`, [U.id]);
  check(st.length === 2 && st.every((x) => x.status === 'ENVIADA'), 'fila marcada como enviada', st);
  const lista = await U.rpc('minhas_notificacoes', { p_limite: 10 });
  check(lista.length >= 2 && lista[0].titulo, 'app busca o texto pela API depois do toque');
  await q(`update notificacoes set status='ENVIANDO', criado_em = now() - interval '10 minutes' where usuario_id=$1 and canal='PUSH'`, [U.id]);
  const rec = await rest(SERVICO)('notificacoes_para_enviar', { p_canal: 'PUSH', p_limite: 10 });
  check(rec.length === 2, 'enviador caiu no meio: o que ficou "ENVIANDO" volta para a fila', rec.length);
});

await secao('ASSISTENTE COM MODELO DE LINGUAGEM (trava de números)', async () => {
  check(JSON.stringify(numerosDe('Você faturou R$ 1.234,56 em 3 corridas; espera 4–7 min; +32%')) === JSON.stringify([1234.56, 3, 4, 7, 32]), 'lê números no formato brasileiro');
  const fatos = { intencao: 'FATURAMENTO', resposta: 'Você faturou R$ 17,18 hoje em 1 corrida(s).', dados_suficientes: true, dados: { total: 17.18, corridas: 1 } };
  check(textoSeguro(fatos, 'Hoje você fez 1 corrida e faturou R$ 17,18.').usouModelo === true, 'reescrita com os mesmos números é aceita');
  const inv = textoSeguro(fatos, 'Você faturou R$ 17,18 e amanhã deve faturar R$ 250,00.');
  check(!inv.usouModelo && inv.texto === fatos.resposta, 'número inventado → descarta o modelo e usa a resposta do banco', inv.motivo);
  check(!textoSeguro({ ...fatos, dados_suficientes: false }, 'Você faturou R$ 17,18').usouModelo, 'sem dados suficientes, o modelo não fala');
  check(!textoSeguro(fatos, 'Veja em https://golpe.com').usouModelo, 'links na resposta do modelo são bloqueados');
});


await secao('COBRANÇA NO GATEWAY (criar-cobranca)', async () => {
  const P = await usuario('Pagadora Cobrança'); const O2 = await usuario('Outra Pessoa');
  const rc = await P.rpc('recarregar_carteira', { p_valor: 40, p_metodo: 'PIX', p_chave_idempotencia: 'cobranca-teste-1' });
  const base = { rpcServidor: rest(SERVICO), gateway: gatewaySimulado, producao: false };
  let r = await tratarCobranca({ ...base, pagamentoId: rc.pagamento, rpcUsuario: O2.rpc });
  check(r.status === 404, 'ninguém gera cobrança de pagamento alheio', r);
  r = await tratarCobranca({ ...base, pagamentoId: rc.pagamento, rpcUsuario: P.rpc, producao: true });
  check(r.status === 503 && r.corpo.erro === 'SIMULADOR_PROIBIDO_EM_PRODUCAO', 'simulador de cobrança recusado em produção');
  r = await tratarCobranca({ ...base, pagamentoId: rc.pagamento, rpcUsuario: P.rpc });
  check(r.status === 200 && /SIMULADO/.test(r.corpo.cobranca.pix_copia_cola), 'cobrança PIX criada e gravada para o pagador', r);
  const r2 = await tratarCobranca({ ...base, pagamentoId: rc.pagamento, rpcUsuario: P.rpc });
  check(r2.corpo.repetido === true, 'pedir de novo devolve a mesma cobrança (não cria outra no gateway)');
  const c = await P.rpc('minha_cobranca', { p_pagamento: rc.pagamento });
  check(c.status === 'PENDENTE' && c.cobranca.gateway === 'simulado', 'criar cobrança NÃO confirma o pagamento (só o webhook confirma)', c);
  const negar = async (pr) => { try { await pr; return null; } catch (e) { return e; } };
  const e = await negar(P.rpc('registrar_cobranca', { p_pagamento: rc.pagamento, p_gateway: 'x', p_gateway_ref: 'x', p_dados: {} }));
  check(e && [401, 403].includes(e.status), 'app não grava cobrança direto (só o servidor)', e && e.status);
});

prest.kill();
proxy.close();
await db.end();
console.log(linhas.join('\n'));
console.log(`\n=========================================\n  FUNÇÕES: ${ok} OK   ·   ${falhas} FALHA(S)\n=========================================`);
process.exit(falhas ? 1 : 0);
