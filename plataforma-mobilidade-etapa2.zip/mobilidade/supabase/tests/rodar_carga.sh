#!/bin/bash
# Banco limpo + teste de carga. Ex.: MOTORISTAS=60 PASSAGEIROS=150 POOL=40 ./supabase/tests/rodar_carga.sh
set -e
DB=${PGDATABASE:-mob_carga}
dropdb --if-exists --force "$DB" >/dev/null 2>&1 || true
createdb "$DB"
for f in supabase/tests/shim_supabase.sql supabase/migrations/0*.sql supabase/seed.sql; do
  psql -d "$DB" -v ON_ERROR_STOP=1 -q --single-transaction -f "$f" >/dev/null 2>&1 || { echo "ERRO aplicando $f"; exit 1; }
done
PGDATABASE="$DB" node supabase/tests/teste_carga.js
