#!/bin/bash
# Banco limpo + PostgREST + testes das Edge Functions
set -e
DB=${PGDATABASE:-mob_funcoes}
dropdb --if-exists --force "$DB" >/dev/null 2>&1 || true
createdb "$DB"
for f in supabase/tests/shim_supabase.sql supabase/migrations/0*.sql supabase/seed.sql; do
  psql -d "$DB" -v ON_ERROR_STOP=1 -q --single-transaction -f "$f" >/dev/null 2>&1 || { echo "ERRO aplicando $f"; exit 1; }
done
PGDATABASE="$DB" node --experimental-strip-types --no-warnings supabase/tests/testes_funcoes.mjs
