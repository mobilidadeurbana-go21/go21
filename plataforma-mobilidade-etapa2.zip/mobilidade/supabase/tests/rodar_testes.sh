#!/bin/bash
# Cria um banco limpo, aplica tudo e roda os testes (Etapa 1 e Etapa 2).
# Uso: ./supabase/tests/rodar_testes.sh            → as duas suítes
#      ./supabase/tests/rodar_testes.sh etapa2     → só a Etapa 2
set -e
DB=${PGDATABASE:-mob_teste}
preparar() {
  dropdb --if-exists --force "$DB" >/dev/null 2>&1 || true
  createdb "$DB"
  for f in supabase/tests/shim_supabase.sql supabase/migrations/0*.sql supabase/seed.sql; do
    # cada migration numa transação, como o Supabase faz
    psql -d "$DB" -v ON_ERROR_STOP=1 -q --single-transaction -f "$f" >/dev/null 2>&1 || { echo "ERRO aplicando $f"; psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f" 2>&1 | grep -i error | head; exit 1; }
  done
}
RC=0
if [ "$1" != "etapa2" ]; then
  preparar; echo "### ETAPA 1"; PGDATABASE="$DB" node supabase/tests/testes.js || RC=1
fi
preparar; echo "### ETAPA 2"; PGDATABASE="$DB" node supabase/tests/testes_etapa2.js || RC=1
exit $RC
