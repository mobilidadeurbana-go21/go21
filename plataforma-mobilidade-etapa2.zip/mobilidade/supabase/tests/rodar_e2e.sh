#!/bin/bash
# Gera o site, cria banco limpo e roda o teste de ponta a ponta clicando nas telas.
set -e
node apps/build.js >/dev/null
DB=${PGDATABASE:-mob_e2e}
dropdb --if-exists --force "$DB" >/dev/null 2>&1 || true
createdb "$DB"
for f in supabase/tests/shim_supabase.sql supabase/migrations/0*.sql supabase/seed.sql; do
  psql -d "$DB" -v ON_ERROR_STOP=1 -q --single-transaction -f "$f" >/dev/null 2>&1 || { echo "ERRO aplicando $f"; exit 1; }
done
PGDATABASE="$DB" node supabase/tests/e2e_telas.mjs
