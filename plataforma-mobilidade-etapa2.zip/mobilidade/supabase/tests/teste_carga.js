// ============================================================
// TESTE DE CARGA E CONCORRÊNCIA (PostgreSQL real)
// Simula o que o PostgREST/Supabase faz: cada requisição é uma transação com
// SET LOCAL role + claims do JWT, num pool de conexões compartilhado.
//
// Cenário (ajustável por variáveis de ambiente):
//   MOTORISTAS=60 PASSAGEIROS=150 POOL=40
//   1) pico: todos os passageiros pedem corrida ao mesmo tempo
//   2) motoristas aceitam, chegam, iniciam e finalizam em paralelo
//   3) gateway manda cada confirmação 3x (duplicada) em paralelo
//   4) rajada de GPS (atualizar_localizacao) e de radar
//   5) jobs (matching, segurança, liberação) rodando no meio da carga
// No fim confere as invariantes: 1 liquidação por corrida, ledger = 0,
// nenhuma oferta dupla, nenhum motorista em 2 corridas, sem carteira negativa.
//
// Uso: PGHOST=... PGPORT=... PGUSER=... PGDATABASE=... node supabase/tests/teste_carga.js
// (rodar num banco preparado por rodar_testes.sh — ex.: ./supabase/tests/rodar_carga.sh)
// ============================================================
const { Pool, Client } = require('pg');
const crypto = require('crypto');

const N_MOT = +(process.env.MOTORISTAS || 60);
const N_PAS = +(process.env.PASSAGEIROS || 150);
const POOL = +(process.env.POOL || 40);
const pool = new Pool({ max: POOL });

const lat = {};           // latências por função
const erros = {};
function medir(fn, ms) { (lat[fn] = lat[fn] || []).push(ms); }
function errar(fn, msg) { const k = fn + ': ' + msg; erros[k] = (erros[k] || 0) + 1; }

async function rpc(uid, fn, args = {}, papel = 'authenticated') {
  const ks = Object.keys(args);
  const c = await pool.connect();
  const t0 = process.hrtime.bigint();
  try {
    await c.query('begin');
    await c.query(`select set_config('request.jwt.claim.sub', $1, true), set_config('request.jwt.claim.role', $2, true)`, [uid || '', papel]);
    await c.query(`set local role ${papel}`);
    const r = await c.query(`select public.${fn}(${ks.map((k, i) => `${k} => $${i + 1}`).join(', ')}) as r`, ks.map(k => args[k]));
    await c.query('commit');
    medir(fn, Number(process.hrtime.bigint() - t0) / 1e6);
    return r.rows[0].r;
  } catch (e) {
    await c.query('rollback').catch(() => {});
    medir(fn, Number(process.hrtime.bigint() - t0) / 1e6);
    errar(fn, e.message);
    throw e;
  } finally { c.release(); }
}
const q = async (sql, p) => (await pool.query(sql, p)).rows;
const uuid = () => crypto.randomUUID();
function cpf() {
  const n = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10));
  let s = n.reduce((a, d, i) => a + d * (10 - i), 0); let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0; n.push(d1);
  s = n.reduce((a, d, i) => a + d * (11 - i), 0); let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0; n.push(d2);
  return n.join('');
}
let telSeq = 700000000;
const tel = () => '219' + String(telSeq++).slice(-8);
const O = { lat: -22.9068, lng: -43.1729 }, D = { lat: -22.9500, lng: -43.2100 };
const rnd = (a) => (Math.random() - 0.5) * a;
const pct = (arr, p) => { if (!arr || !arr.length) return 0; const s = [...arr].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p / 100 * s.length))]; };
const dorme = (ms) => new Promise(r => setTimeout(r, ms));
// executa tarefas com concorrência limitada
async function emParalelo(itens, fn, conc = POOL) {
  const res = []; let i = 0;
  await Promise.all(Array.from({ length: Math.min(conc, itens.length) }, async () => {
    while (i < itens.length) { const k = i++; res[k] = await fn(itens[k], k).catch(e => ({ erro: e.message })); }
  }));
  return res;
}

(async () => {
  const t0 = Date.now();
  const CID = (await q(`select id from cidades where slug='piloto'`))[0].id;
  await q(`update configuracoes set valor='0' where chave in ('indicacao_min_corridas_indicado','corrida_valida_min_minutos')`);
  // limites anti-abuso por usuário continuam valendo; aqui cada ator faz poucas ações
  const adminId = uuid();
  await q(`insert into auth.users (id) values ($1)`, [adminId]);
  await rpc(adminId, 'completar_cadastro', { p_nome: 'Admin Carga', p_telefone: tel(), p_cpf: cpf(), p_email: 'carga@teste.com', p_cidade: CID });
  await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'ADMIN'),($1,'OPERACOES') on conflict do nothing`, [adminId]);

  async function novo(nome, motorista) {
    const id = uuid();
    await q(`insert into auth.users (id) values ($1)`, [id]);
    await rpc(id, 'completar_cadastro', { p_nome: nome, p_telefone: tel(), p_cpf: cpf(), p_email: id + '@t.com', p_cidade: CID,
      p_quer_ser_motorista: motorista, p_dispositivo: 'd-' + id });
    return id;
  }
  console.log(`Preparando ${N_MOT} motoristas e ${N_PAS} passageiros (pool ${POOL})...`);
  const motoristas = await emParalelo(Array.from({ length: N_MOT }, (_, i) => i), async (i) => {
    const id = await novo('Motorista ' + i, true);
    await rpc(id, 'motorista_salvar_dados', { p_cnh_numero: '1234567890' + (i % 10), p_cnh_categoria: 'B', p_cnh_validade: '2030-01-01', p_cnh_ear: true, p_data_nascimento: '1985-05-05' });
    const v = (await rpc(id, 'motorista_cadastrar_veiculo', { p_marca: 'Fiat', p_modelo: 'Argo', p_ano: 2022, p_placa: 'CRG' + (i % 10) + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(i / 10) % 26] + String(Math.floor(i / 260) % 100).padStart(2, '0'),
      p_cor: 'Branco', p_capacidade: 4, p_acessivel: false, p_categorias: '{ECONOMICO}' })).veiculo;
    for (const t of ['CNH', 'SELFIE', 'ANTECEDENTES']) {
      const d = await rpc(id, 'motorista_enviar_documento', { p_dono_tipo: 'MOTORISTA', p_dono: id, p_tipo: t, p_arquivo_path: `${id}/${t}.jpg`, p_numero: null, p_validade: t === 'CNH' ? '2030-01-01' : null });
      await rpc(adminId, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    for (const t of ['CRLV', 'SEGURO']) {
      const d = await rpc(id, 'motorista_enviar_documento', { p_dono_tipo: 'VEICULO', p_dono: v, p_tipo: t, p_arquivo_path: `${id}/${t}.pdf`, p_numero: null, p_validade: '2030-01-01' });
      await rpc(adminId, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    await rpc(adminId, 'ops_analisar_veiculo', { p_veiculo: v, p_aprovado: true, p_categorias: '{ECONOMICO}' });
    await rpc(adminId, 'ops_alterar_status_motorista', { p_motorista: id, p_status: 'ATIVO', p_motivo: 'carga' });
    await rpc(id, 'ficar_online', { p_lat: O.lat + rnd(0.04), p_lng: O.lng + rnd(0.04) });
    return id;
  }, 10);
  const passageiros = await emParalelo(Array.from({ length: N_PAS }, (_, i) => i), (i) => novo('Passageiro ' + i, false), 20);
  const okMot = motoristas.filter(m => typeof m === 'string'), okPas = passageiros.filter(p => typeof p === 'string');
  console.log(`Preparado em ${((Date.now() - t0) / 1000).toFixed(1)} s: ${okMot.length} motoristas online, ${okPas.length} passageiros.\n`);
  for (const k of Object.keys(lat)) delete lat[k];           // mede só a fase de carga
  for (const k of Object.keys(erros)) delete erros[k];

  // ---------- 1) PICO DE PEDIDOS ----------
  const tPico = Date.now();
  const pedidos = await emParalelo(okPas, async (p) => {
    const chave = uuid();
    const args = { p_chave_idempotencia: chave, p_cidade: CID, p_categoria: 'ECONOMICO', p_o_lat: O.lat + rnd(0.03), p_o_lng: O.lng + rnd(0.03), p_o_endereco: 'O',
      p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'D', p_metodo: 'PIX' };
    // clique duplo de metade dos passageiros: mesma chave em paralelo
    const [r] = await Promise.all([rpc(p, 'solicitar_corrida', args), Math.random() < 0.5 ? rpc(p, 'solicitar_corrida', args).catch(() => null) : null]);
    return { p, corrida: r.corrida };
  }, POOL);
  const durPico = (Date.now() - tPico) / 1000;
  const corridasCriadas = pedidos.filter(x => x.corrida);
  const duplicadas = (await q(`select count(*)::int n from (select passageiro_id, chave_idempotencia from corridas group by 1,2 having count(*) > 1) x`))[0].n;

  // ---------- 2) MOTORISTAS TRABALHANDO EM PARALELO + JOBS NO MEIO ----------
  let jobsRodando = true;
  const jobs = (async () => {
    while (jobsRodando) {
      await rpc(null, 'executar_jobs', { p_qual: 'rapido' }, 'service_role').catch(() => {});
      await dorme(300);
    }
  })();
  const finalizadas = [];
  const tTrab = Date.now();
  await emParalelo(okMot, async (m) => {
    for (let rodada = 0; rodada < 6; rodada++) {
      const of = await rpc(m, 'minha_oferta').catch(() => null);
      if (!of || !of.oferta) { await dorme(150); continue; }
      const ac = await rpc(m, 'aceitar_oferta', { p_oferta: of.oferta }).catch(() => null);
      if (!ac) continue;
      const corrida = (of.corrida && of.corrida.id) || (await q(`select corrida_id from ofertas where id=$1`, [of.oferta]))[0].corrida_id;
      const c = (await q(`select origem_lat, origem_lng from corridas where id=$1`, [corrida]))[0];
      await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m, c.origem_lat, c.origem_lng]);
      // rajada de GPS concorrente com o fluxo
      await Promise.all([
        rpc(m, 'cheguei', { p_corrida: corrida }),
        rpc(m, 'atualizar_localizacao', { p_lat: c.origem_lat, p_lng: c.origem_lng, p_rumo: 0, p_velocidade_kmh: 0 }).catch(() => null)]);
      const pin = (await q(`select pin from corrida_segredos where corrida_id=$1`, [corrida]))[0].pin;
      await rpc(m, 'iniciar_corrida', { p_corrida: corrida, p_pin: pin });
      await q(`update corridas set iniciada_em = now() - interval '12 minutes' where id=$1`, [corrida]);
      const pts = [[c.origem_lat, c.origem_lng], [-22.92, -43.185], [-22.935, -43.197], [D.lat, D.lng]];
      for (let i = 0; i < pts.length; i++)
        await q(`insert into corrida_trilha (corrida_id, registrado_em, lat, lng, velocidade_kmh) values ($1, now() - make_interval(secs => $2), $3, $4, 30)`,
          [corrida, (pts.length - 1 - i) * 180, pts[i][0], pts[i][1]]);
      await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m, D.lat, D.lng]);
      const fin = await rpc(m, 'finalizar_corrida', { p_corrida: corrida, p_km_app: null });
      finalizadas.push(fin);
      await rpc(m, 'radar').catch(() => null);
      await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m, O.lat + rnd(0.04), O.lng + rnd(0.04)]);
    }
  }, POOL);
  jobsRodando = false; await jobs;
  const durTrab = (Date.now() - tTrab) / 1000;

  // ---------- 3) WEBHOOKS DUPLICADOS EM PARALELO ----------
  const tWh = Date.now();
  const whs = [];
  for (const f of finalizadas) {
    if (!f || !f.pagamento || f.pagamento.status !== 'PENDENTE') continue;
    const payload = JSON.stringify({ pagamento_id: f.pagamento.id, gateway_ref: 'gw-' + f.pagamento.id, valor: f.pagamento.valor });
    for (let k = 0; k < 3; k++) whs.push({ ev: 'evt-' + f.pagamento.id + (k === 2 ? '-reenvio' : ''), payload });   // 2 iguais + 1 com outro id
  }
  await emParalelo(whs.sort(() => Math.random() - 0.5), (w) =>
    rpc(null, 'processar_webhook', { p_gateway: 'GW', p_evento_id: w.ev, p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: w.payload }, 'service_role'), POOL);
  const durWh = (Date.now() - tWh) / 1000;
  await rpc(null, 'executar_jobs', { p_qual: 'horario' }, 'service_role');

  // ---------- INVARIANTES ----------
  const inv = {};
  inv.corridas_pedidas = okPas.length;
  inv.corridas_criadas = (await q(`select count(distinct passageiro_id)::int n from corridas`))[0].n;
  inv.clique_duplo_sem_erro = corridasCriadas.length === okPas.length;
  inv.chave_duplicada = duplicadas;
  inv.finalizadas = finalizadas.length;
  inv.pagas = (await q(`select count(*)::int n from corridas where status='PAGA'`))[0].n;
  inv.liquidacao_dupla = (await q(`select count(*)::int n from (select referencia from transacoes_ledger where tipo='LIQUIDACAO_CORRIDA' group by 1 having count(*)>1) x`))[0].n;
  inv.ledger_soma = Number((await q(`select coalesce(sum(valor),0) s from lancamentos_ledger`))[0].s);
  inv.tx_desbalanceada = (await q(`select count(*)::int n from (select transacao_id from lancamentos_ledger group by 1 having sum(valor)<>0) x`))[0].n;
  inv.saldo_divergente = (await q(`select count(*)::int n from contas_ledger c left join saldos s on s.conta_id=c.id
                          where coalesce(s.saldo,0) <> coalesce((select sum(valor) from lancamentos_ledger l where l.conta_id=c.id),0)`))[0].n;
  inv.motorista_em_2_corridas = (await q(`select count(*)::int n from (select motorista_id from corridas where status in ('A_CAMINHO','CHEGOU','EM_CURSO') group by 1 having count(*)>1) x`))[0].n;
  inv.oferta_aceita_dupla = (await q(`select count(*)::int n from (select corrida_id from ofertas where status='ACEITA' group by 1 having count(*)>1) x`))[0].n;
  inv.webhooks_duplicados_ignorados = (await q(`select count(*)::int n from webhooks_recebidos`))[0].n;
  inv.carteira_negativa = (await q(`select count(*)::int n from saldos s join contas_ledger c on c.id=s.conta_id where c.tipo='PASSAGEIRO_CARTEIRA' and s.saldo<0`))[0].n;
  inv.jobs_com_erro = (await q(`select count(*)::int n from jobs_execucoes where not ok`))[0].n;

  console.log('FASES');
  console.log(`  pico de pedidos:     ${okPas.length} passageiros (metade com clique duplo) em ${durPico.toFixed(2)} s`);
  console.log(`  motoristas rodando:  ${finalizadas.length} corridas completas em ${durTrab.toFixed(1)} s (jobs a cada 300 ms no meio)`);
  console.log(`  webhooks:            ${whs.length} chamadas (cada pagamento 3x) em ${durWh.toFixed(2)} s`);
  console.log('\nLATÊNCIA POR FUNÇÃO (ms)          n      p50     p95     p99     máx');
  for (const [fn, a] of Object.entries(lat).sort((x, y) => y[1].length - x[1].length))
    console.log(`  ${fn.padEnd(28)} ${String(a.length).padStart(6)} ${pct(a, 50).toFixed(1).padStart(8)} ${pct(a, 95).toFixed(1).padStart(7)} ${pct(a, 99).toFixed(1).padStart(7)} ${Math.max(...a).toFixed(1).padStart(8)}`);
  console.log('\nERROS DE NEGÓCIO/CONCORRÊNCIA DURANTE A CARGA (esperados: disputa de oferta, limite, etc.)');
  const errosOrd = Object.entries(erros).sort((a, b) => b[1] - a[1]);
  if (!errosOrd.length) console.log('  nenhum');
  for (const [k, n] of errosOrd.slice(0, 15)) console.log(`  ${String(n).padStart(5)}× ${k}`);
  console.log('\nINVARIANTES');
  let falhas = 0;
  const regra = { clique_duplo_sem_erro: true, chave_duplicada: 0, liquidacao_dupla: 0, ledger_soma: 0, tx_desbalanceada: 0, saldo_divergente: 0, motorista_em_2_corridas: 0, oferta_aceita_dupla: 0, carteira_negativa: 0, jobs_com_erro: 0 };
  for (const [k, v] of Object.entries(inv)) {
    const ok = !(k in regra) || v === regra[k];
    if (!ok) falhas++;
    console.log(`  ${ok ? '✔' : '✘'} ${k.padEnd(30)} ${v}`);
  }
  const extra = inv.corridas_criadas === okPas.length && inv.pagas === inv.finalizadas;
  if (!extra) falhas++;
  console.log(`  ${extra ? '✔' : '✘'} todo pedido virou corrida e toda finalizada foi paga uma vez`);
  console.log(`\n=========================================\n  CARGA: ${falhas ? falhas + ' INVARIANTE(S) VIOLADA(S)' : 'todas as invariantes OK'}\n=========================================`);
  await pool.end();
  process.exit(falhas ? 1 : 0);
})().catch(async e => { console.error('FALHA GERAL:', e); process.exit(2); });
