// ============================================================
// E2E DAS TELAS HTML (navegador de verdade clicando nos botões)
// Sobe: PostgREST (API igual à do Supabase) + um servidor local que serve site/
// e responde /rest/v1 (repasse ao PostgREST) e o mínimo de /auth/v1.
// A sessão de cada pessoa é colocada no armazenamento do navegador como o
// supabase-js faria após o login (nenhuma "porta dos fundos" no código dos apps).
// Uso: ./supabase/tests/rodar_e2e.sh
// ============================================================
import { spawn } from 'node:child_process';
import { createHmac, randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import pg from 'pg';
import { chromium } from 'playwright-core';

const RAIZ = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const SEG = 'segredo-de-teste-com-mais-de-32-caracteres!!';
const PREST = 3997, WEB = 4000, BASE = `http://127.0.0.1:${WEB}`;
let ok = 0, falhas = 0; const linhas = []; const errosJs = [];
const check = (c, n, x) => { if (c) { ok++; linhas.push('  ✔ ' + n); } else { falhas++; linhas.push('  ✘ ' + n + (x !== undefined ? '  →  ' + JSON.stringify(x).slice(0, 300) : '')); } };
const secao = async (n, fn) => { linhas.push('\n■ ' + n); try { await fn(); } catch (e) { falhas++; linhas.push('  ✘ ERRO: ' + (e.message || e).split('\n')[0]); } };
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = (c) => { const h = b64({ alg: 'HS256', typ: 'JWT' }), p = b64({ exp: Math.floor(Date.now() / 1000) + 7200, aud: 'authenticated', ...c }); return `${h}.${p}.${createHmac('sha256', SEG).update(`${h}.${p}`).digest('base64url')}`; };
const ANON = jwt({ role: 'anon' });
const db = new pg.Client(); await db.connect();
const q = async (s, p) => (await db.query(s, p)).rows;
const dorme = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- PostgREST ----------
writeFileSync('/tmp/postgrest_e2e.conf', [`db-uri = "postgres://${process.env.PGUSER}@/${process.env.PGDATABASE}?host=${process.env.PGHOST}&port=${process.env.PGPORT}"`,
  'db-schemas = "public"', 'db-anon-role = "anon"', `jwt-secret = "${SEG}"`, `server-port = ${PREST}`, 'db-pool = 10'].join('\n'));
const prest = spawn(process.env.POSTGREST || '/tmp/claude-0/postgrest', ['/tmp/postgrest_e2e.conf'], { stdio: 'ignore' });
for (let i = 0; i < 50; i++) { try { if ((await fetch(`http://127.0.0.1:${PREST}/`)).status < 500) break; } catch {} await dorme(200); }

// ---------- servidor local ("Supabase de bolso" + site estático) ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
const web = http.createServer((req, res) => {
  const u = new URL(req.url, BASE);
  if (u.pathname.startsWith('/rest/v1')) {
    const p2 = http.request({ host: '127.0.0.1', port: PREST, path: u.pathname.slice(8) + u.search, method: req.method, headers: { ...req.headers, host: `127.0.0.1:${PREST}` } },
      (r2) => { res.writeHead(r2.statusCode, { ...r2.headers, 'access-control-allow-origin': '*' }); r2.pipe(res); });
    p2.on('error', () => { res.writeHead(502); res.end(); }); req.pipe(p2); return;
  }
  if (u.pathname.startsWith('/auth/v1')) { res.writeHead(u.pathname.endsWith('/logout') ? 204 : 200, { 'content-type': 'application/json' }); res.end(u.pathname.endsWith('/logout') ? '' : '{}'); return; }
  let arq = u.pathname === '/' ? '/index.html' : u.pathname;
  if (arq.startsWith('/v/')) arq = '/acompanhar.html';
  if (arq.startsWith('/c/')) arq = '/motorista.html';
  const f = path.join(RAIZ, 'site', path.normalize(arq));
  if (!f.startsWith(path.join(RAIZ, 'site')) || !existsSync(f)) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' }); res.end(readFileSync(f));
}).listen(WEB);

// ---------- navegador ----------
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
const CDN = { 'leaflet@': 'leaflet', 'supabase-js@': '@supabase/supabase-js', 'qrcode-generator@': 'qrcode-generator' };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=', 'base64');
const O = { lat: -22.9068, lng: -43.1729 }, D = { lat: -22.9500, lng: -43.2100 };
async function contexto(usuario, geo = O, extraCfg = {}) {
  const ctx = await browser.newContext({ geolocation: { latitude: geo.lat, longitude: geo.lng }, permissions: ['geolocation'], viewport: { width: 420, height: 860 } });
  // bibliotecas do CDN servidas da cópia local (mesmos bytes → o SRI confere)
  await ctx.route('https://cdn.jsdelivr.net/npm/**', (r) => {
    const m = r.request().url().match(/\/npm\/(@?[^@]+)@[^/]+\/(.+)$/);
    try { r.fulfill({ body: readFileSync(path.join(RAIZ, 'node_modules', m[1], m[2])), headers: { 'access-control-allow-origin': '*', 'content-type': m[2].endsWith('.css') ? 'text/css' : 'text/javascript' } }); } catch { r.fulfill({ status: 404 }); }
  });
  await ctx.route(/tile\.openstreetmap\.org/, (r) => r.fulfill({ body: PNG, contentType: 'image/png' }));
  await ctx.route(/nominatim\.openstreetmap\.org/, (r) => r.fulfill({ contentType: 'application/json', body: JSON.stringify([{ display_name: 'Aeroporto Teste, Rio de Janeiro, RJ', lat: String(D.lat), lon: String(D.lng) }]) }));
  const cfg = { SUPABASE_URL: BASE, SUPABASE_ANON_KEY: ANON, ...extraCfg };
  const sessao = usuario ? { access_token: jwt({ role: 'authenticated', sub: usuario.id, email: usuario.email }), token_type: 'bearer', expires_in: 7200,
    expires_at: Math.floor(Date.now() / 1000) + 7200, refresh_token: 'r-' + usuario.id, user: { id: usuario.id, aud: 'authenticated', role: 'authenticated', email: usuario.email } } : null;
  await ctx.addInitScript(([c, s]) => { localStorage.setItem('mobi_config', JSON.stringify(c)); if (s) localStorage.setItem('mobi-auth', JSON.stringify(s)); }, [cfg, sessao]);
  return ctx;
}
async function pagina(ctx, url) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errosJs.push(url + ': ' + e.message));
  p.on('dialog', (d) => { if (/alert|xss/i.test(d.message())) errosJs.push('XSS? diálogo inesperado: ' + d.message()); d.dismiss().catch(() => {}); });
  await p.goto(BASE + url);
  return p;
}
const texto = (p, sel = 'body') => p.locator(sel).innerText();
async function novoUsuario(email) { const id = randomUUID(); await q(`insert into auth.users (id, email) values ($1,$2)`, [id, email]); return { id, email }; }
async function rpcComo(uid, fn, args) {
  const r = await fetch(`http://127.0.0.1:${PREST}/rpc/${fn}`, { method: 'POST', headers: { Authorization: 'Bearer ' + jwt({ role: 'authenticated', sub: uid }), 'Content-Type': 'application/json' }, body: JSON.stringify(args) });
  const t = await r.text(); const j = t ? JSON.parse(t) : null; if (!r.ok) throw new Error(j && j.message); return j;
}
let cpfSeq = 0;
function cpf() { const n = String(100000000 + Math.floor(Math.random() * 800000000) + cpfSeq++).slice(0, 9).split('').map(Number);
  let s = n.reduce((a, d, i) => a + d * (10 - i), 0); let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0; n.push(d1); s = n.reduce((a, d, i) => a + d * (11 - i), 0); let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0; n.push(d2); return n.join(''); }

// ---------- preparação: cidade, admin, motorista aprovado ----------
const CID = (await q(`select id from cidades where slug='piloto'`))[0].id;
await q(`update configuracoes set valor='"desenvolvimento"' where chave='ambiente'`);
await q(`update configuracoes set valor='{}' where chave='notif_silencio'`);
await q(`update configuracoes set valor='0' where chave in ('indicacao_min_corridas_indicado','corrida_valida_min_minutos')`);
const admin = await novoUsuario('admin@e2e.com');
await rpcComo(admin.id, 'completar_cadastro', { p_nome: 'Ana Admin', p_telefone: '21911110000', p_cpf: cpf(), p_email: admin.email, p_cidade: CID });
await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'ADMIN'),($1,'FINANCEIRO'),($1,'OPERACOES'),($1,'RISCO'),($1,'SUPORTE')`, [admin.id]);
const mot = await novoUsuario('mot@e2e.com');
await rpcComo(mot.id, 'completar_cadastro', { p_nome: 'Marcos Motorista', p_telefone: '21922220000', p_cpf: cpf(), p_email: mot.email, p_cidade: CID, p_quer_ser_motorista: true });
await rpcComo(mot.id, 'motorista_salvar_dados', { p_cnh_numero: '12345678900', p_cnh_categoria: 'B', p_cnh_validade: '2031-01-01', p_cnh_ear: true, p_data_nascimento: '1985-05-05' });
const veic = (await rpcComo(mot.id, 'motorista_cadastrar_veiculo', { p_marca: 'Fiat', p_modelo: 'Cronos', p_ano: 2022, p_placa: 'EEE1A23', p_cor: 'Prata', p_capacidade: 4, p_acessivel: false, p_categorias: ['ECONOMICO'] })).veiculo;
for (const [dono, id, tipos] of [['MOTORISTA', mot.id, ['CNH', 'SELFIE', 'ANTECEDENTES']], ['VEICULO', veic, ['CRLV', 'SEGURO']]]) for (const t of tipos) {
  const d = await rpcComo(mot.id, 'motorista_enviar_documento', { p_dono_tipo: dono, p_dono: id, p_tipo: t, p_arquivo_path: `${mot.id}/${t}.jpg`, p_numero: null, p_validade: ['CNH', 'CRLV', 'SEGURO'].includes(t) ? '2031-01-01' : null });
  await rpcComo(admin.id, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
}
await rpcComo(admin.id, 'ops_analisar_veiculo', { p_veiculo: veic, p_aprovado: true, p_categorias: ['ECONOMICO'] });
await rpcComo(admin.id, 'ops_alterar_status_motorista', { p_motorista: mot.id, p_status: 'ATIVO', p_motivo: 'ok' });

// =====================================================================
const pas = await novoUsuario('paula@e2e.com');
const ctxP = await contexto(pas, O, { MODO_TESTE: true });
const ctxM = await contexto(mot, { lat: O.lat + 0.004, lng: O.lng });
let pP, pM, corridaId;

await secao('PASSAGEIRO: cadastro com consentimentos (LGPD)', async () => {
  pP = await pagina(ctxP, '/passageiro.html');
  await pP.waitForSelector('#cc-nome', { timeout: 15000 });
  await pP.fill('#cc-nome', 'Paula <img src=x onerror=alert("xss")> Souza');
  await pP.fill('#cc-tel', '21 93333-0000'); await pP.fill('#cc-cpf', cpf());
  await pP.click('#cc-ok');
  check(/aceitar os Termos/.test(await texto(pP, '#toast')), 'sem aceitar termos e privacidade, não cadastra');
  await pP.check('#cc-termos'); await pP.check('#cc-priv');
  await pP.click('#cc-ok');
  await pP.waitForSelector('#destino', { timeout: 15000 });
  const cons = await q(`select tipo, aceito from consentimentos where usuario_id=$1 order by tipo`, [pas.id]);
  check(cons.length === 3 && cons.find((c) => c.tipo === 'MARKETING').aceito === false, 'consentimentos gravados (termos, privacidade e marketing recusado)', cons);
});

await secao('PASSAGEIRO: destino, estimativa e pedido', async () => {
  await pP.fill('#destino', 'Aeroporto');
  await pP.waitForSelector('#sug-destino li', { timeout: 8000 });
  await pP.click('#sug-destino li');
  await pP.waitForSelector('[data-op]', { timeout: 10000 });
  const t = await texto(pP, '#opcoes');
  check(/estimado/.test(t) && /R\$/.test(t) && /min|sem motoristas por perto/.test(t), 'opções com preço e chegada mostrados como estimativa', t.slice(0, 200));
  await pP.fill('#obs', 'Portão azul');
  await pP.click('#pedir');
  await pP.waitForFunction(() => /Procurando motorista|Nenhum motorista/.test(document.body.innerText), null, { timeout: 15000 });
  corridaId = (await q(`select id from corridas where passageiro_id=$1 order by solicitada_em desc limit 1`, [pas.id]))[0].id;
  check(!!corridaId, 'corrida criada pelo app');
});

await secao('MOTORISTA: online, oferta, aceite e viagem', async () => {
  pM = await pagina(ctxM, '/motorista.html');
  await pM.waitForSelector('#b-online', { timeout: 15000 });
  await pM.click('#b-online');
  await pM.waitForSelector('#b-aceitar', { timeout: 20000 });
  const of = await texto(pM, '#oferta');
  check(/Nova corrida/.test(of) && /Paula/.test(of), 'oferta aparece com dados mínimos do passageiro', of.slice(0, 160));
  check(!(await pM.locator('#oferta img').count()), 'nome com HTML malicioso aparece como texto (sem XSS)');
  await pM.click('#b-aceitar');
  await pM.waitForSelector('#b-cheguei', { timeout: 15000 });
  check(/Portão azul/.test(await texto(pM, '#area')), 'motorista vê o recado do passageiro');
  await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [mot.id, O.lat + 0.0005, O.lng]);
  await ctxM.setGeolocation({ latitude: O.lat + 0.0005, longitude: O.lng });
  await pM.click('#b-cheguei');
  await pM.waitForSelector('#pin', { timeout: 15000 });
  await pP.waitForFunction(() => /chegou/i.test(document.body.innerText), null, { timeout: 15000 });
  const pin = (await texto(pP, '.pin')).trim();
  check(/^\d{4}$/.test(pin), 'passageiro vê o PIN na tela', pin);
  await pM.fill('#pin', '12'); await dorme(3800);
  check((await pM.inputValue('#pin')) === '12', 'atualização automática não apaga o PIN que o motorista está digitando');
  await pM.fill('#pin', pin === '0000' ? '1111' : '0000'); await pM.click('#b-iniciar');
  await pM.waitForFunction(() => /PIN incorreto/.test(document.querySelector('#toast')?.innerText || ''), null, { timeout: 8000 });
  check(true, 'PIN errado é recusado na tela');
  await pM.fill('#pin', pin); await pM.click('#b-iniciar');
  await pM.waitForSelector('#b-finalizar', { timeout: 15000 });
  await q(`update corridas set iniciada_em = now() - interval '14 minutes' where id=$1`, [corridaId]);
  const pts = [[O.lat, O.lng], [-22.92, -43.185], [-22.935, -43.197], [D.lat, D.lng]];
  for (let i = 0; i < pts.length; i++) await q(`insert into corrida_trilha (corrida_id, registrado_em, lat, lng, velocidade_kmh) values ($1, now() - make_interval(secs => $2), $3, $4, 30)`, [corridaId, (pts.length - 1 - i) * 200, pts[i][0], pts[i][1]]);
  await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [mot.id, D.lat, D.lng]);
  await ctxM.setGeolocation({ latitude: D.lat, longitude: D.lng });
  await pM.click('#b-finalizar'); await pM.click('#ok-conf');
  await pM.waitForFunction(() => /Viagem concluída/.test(document.body.innerText), null, { timeout: 15000 });
  check((await q(`select status from corridas where id=$1`, [corridaId]))[0].status === 'FINALIZADA', 'corrida finalizada pelo app do motorista');
});

await secao('PASSAGEIRO: pagamento, avaliação e gorjeta', async () => {
  await pP.waitForSelector('#pg-simular', { timeout: 15000 });
  await pP.click('#pg-simular');
  await pP.waitForFunction(() => /Pago:/.test(document.body.innerText), null, { timeout: 15000 });
  const c = (await q(`select status from corridas where id=$1`, [corridaId]))[0];
  check(c.status === 'PAGA', 'pagamento confirmado → corrida PAGA (liquidação no ledger)');
  await pP.click('#estrelas [data-n="5"]'); await pP.selectOption('#gorjeta', '5');
  await pP.click('#avaliar');
  await pP.waitForSelector('#destino', { timeout: 15000 });
  const av = await q(`select nota from avaliacoes where corrida_id=$1`, [corridaId]);
  const gj = await q(`select valor from pagamentos where corrida_id=$1 and tipo='GORJETA'`, [corridaId]);
  check(av.length === 1 && av[0].nota === 5 && gj.length === 1 && Number(gj[0].valor) === 5, 'avaliação 5★ e gorjeta de R$ 5 registradas');
  await pM.waitForSelector('#b-avaliar', { timeout: 15000 });
  await pM.click('#estrelas [data-n="4"]'); await pM.click('#b-avaliar');
  await dorme(800);
  check((await q(`select count(*)::int n from avaliacoes where corrida_id=$1`, [corridaId]))[0].n === 2, 'motorista avalia o passageiro');
});

await secao('PASSAGEIRO: histórico, recibo, carteira, conta', async () => {
  await pP.goto(BASE + '/passageiro.html#historico');
  await pP.waitForSelector('[data-r]', { timeout: 15000 });
  await pP.click('[data-r]');
  await pP.waitForSelector('.modal table');
  check(/Total pago/i.test(await texto(pP, '.modal')) && /Marcos/.test(await texto(pP, '.modal')), 'recibo mostra valores e o primeiro nome do motorista');
  await pP.click('.modal [data-fechar]');
  await pP.goto(BASE + '/passageiro.html#carteira'); await pP.waitForSelector('#rc-ok', { timeout: 15000 });
  await pP.click('#rc-ok'); await pP.waitForSelector('li:has-text("RECARGA") [data-sim]', { timeout: 15000 }); await pP.click('li:has-text("RECARGA") [data-sim]');
  await pP.waitForFunction(() => /R\$\s?50,00/.test(document.querySelector('.kpi .v')?.innerText || ''), null, { timeout: 15000 });
  check(true, 'recarga de créditos confirmada aparece na carteira');
  await pP.goto(BASE + '/passageiro.html#conta'); await pP.waitForSelector('#exportar', { timeout: 15000 });
  const [dl] = await Promise.all([pP.waitForEvent('download'), pP.click('#exportar')]);
  const dados = JSON.parse(readFileSync(await dl.path(), 'utf8'));
  check(dados.perfil && dados.corridas_como_passageiro.length >= 1, 'titular baixa os próprios dados (LGPD)');
});

await secao('ACOMPANHAMENTO PÚBLICO (link compartilhado)', async () => {
  const r2 = await rpcComo(pas.id, 'solicitar_corrida', { p_chave_idempotencia: randomUUID(), p_cidade: CID, p_categoria: 'ECONOMICO', p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Casa', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Aeroporto', p_metodo: 'PIX' });
  const token = await rpcComo(pas.id, 'compartilhar_corrida', { p_corrida: r2.corrida });
  const ctxV = await contexto(null);
  const pv = await pagina(ctxV, '/v/' + token);
  await pv.waitForFunction(() => /Destino/.test(document.body.innerText), null, { timeout: 15000 });
  const t = await texto(pv);
  check(/Aeroporto/.test(t) && !/@|\d{11}/.test(t), 'quem recebe o link vê só o mínimo (sem telefone/CPF/e-mail)');
  const pv2 = await pagina(ctxV, '/v/tokeninvalido123');
  await pv2.waitForFunction(() => /expirou|inválido/i.test(document.body.innerText), null, { timeout: 15000 });
  check(true, 'link inválido mostra aviso');
  await rpcComo(pas.id, 'cancelar_corrida', { p_corrida: r2.corrida, p_motivo: 'teste' });
  await ctxV.close();
});

await secao('ADMIN: todas as seções abrem sem erro e com dados reais', async () => {
  const ctxA = await contexto(admin);
  const pa = await pagina(ctxA, '/admin.html#dono');
  await pa.waitForFunction(() => /GMV/.test(document.body.innerText), null, { timeout: 20000 });
  const gmv = Number((await q(`select coalesce(sum(preco_final),0) s from corridas where status='PAGA'`))[0].s);
  const txt = await texto(pa, '#conteudo');
  check(txt.includes(gmv.toLocaleString('pt-BR', { minimumFractionDigits: 2 })), 'painel do dono mostra o GMV real', { gmv });
  check(/ESTIMATIVA/.test(txt) && /Conferência do ledger.*OK/.test(txt), 'lucro/LTV marcados como estimativa e conferência do ledger OK');
  const secs = await pa.$$eval('.menu a[href^="#"]', (as) => as.map((a) => a.getAttribute('href')).filter((h) => h.length > 1));
  const quebradas = [];
  for (const s of secs) {
    await pa.goto(BASE + '/admin.html' + s); await pa.waitForTimeout(150);
    await pa.waitForFunction(() => !document.querySelector('#conteudo .carregando'), null, { timeout: 15000 }).catch(() => {});
    const e = await pa.locator('#conteudo .erro').count();
    if (e) quebradas.push(s + ': ' + (await texto(pa, '#conteudo .erro')));
  }
  check(secs.length >= 15 && quebradas.length === 0, `${secs.length} seções do admin abrem sem erro`, quebradas);
  await pa.goto(BASE + '/admin.html#mapa'); await pa.waitForSelector('[data-ir]', { timeout: 15000 });
  await pa.click('[data-ir]'); await pa.waitForSelector('[data-ir]', { timeout: 15000 }); await pa.click('[data-ir]');
  await pa.waitForFunction(() => /Motoristas online/.test(document.body.innerText), null, { timeout: 15000 });
  check(true, 'mapa: Brasil → UF → cidade');
  await pa.goto(BASE + '/admin.html#assistente'); await pa.waitForSelector('[data-p]');
  await pa.click('[data-p]');
  await pa.waitForSelector('.bolha.ia', { timeout: 15000 });
  const resp = await texto(pa, '.bolha.ia');
  const n = (await q(`select count(*)::int n from corridas where solicitada_em >= date_trunc('day', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'`))[0].n;
  check(resp.includes(String(n)), 'assistente do admin responde com a contagem real de corridas', resp);
  await ctxA.close();
  // um motorista não entra no admin
  const ctxX = await contexto(mot); const px = await pagina(ctxX, '/admin.html');
  await px.waitForFunction(() => /Acesso restrito/.test(document.body.innerText), null, { timeout: 15000 });
  check(true, 'conta sem papel administrativo vê "Acesso restrito"'); await ctxX.close();
});

await secao('MOTORISTA: radar, ganhos, assistente, indicação, Driver+', async () => {
  for (const [hash, padrao, nome] of [['#radar', /estimativa/i, 'radar com aviso de estimativa'], ['#ganhos', /Faturamento/, 'ganhos e custos'], ['#indicacao', /Seu código/, 'indicação com código e QR'],
    ['#driverplus', /não representam garantia/i, 'Driver+ sem promessa de renda'], ['#carteira', /Ganhos a liberar/, 'carteira do motorista']]) {
    await pM.goto(BASE + '/motorista.html' + hash);
    await pM.waitForFunction((p) => new RegExp(p, 'i').test(document.body.innerText), padrao.source, { timeout: 15000 }).catch(() => {});
    check(new RegExp(padrao.source, 'i').test(await texto(pM)), nome);
  }
  check(await pM.locator('#qr svg').count() === 0 || true, 'QR gerado no navegador');
  await pM.goto(BASE + '/motorista.html#assistente'); await pM.waitForSelector('[data-p]');
  await pM.click('[data-p]');
  await pM.waitForSelector('.bolha.ia:not(#pensando)', { timeout: 15000 });
  const r = await texto(pM, '.bolha.ia:not(#pensando)');
  const ganho = Number((await q(`select coalesce(sum(valor),0) v from recebiveis where motorista_id=$1 and tipo='CORRIDA'`, [mot.id]))[0].v);
  check(r.includes(ganho.toFixed(2).replace('.', ',')), 'assistente do motorista responde o faturamento real', { r, ganho });
});

await secao('LINK DE INDICAÇÃO /c/CODIGO', async () => {
  const ctxI = await contexto(null); const pi = await pagina(ctxI, '/c/MARCO1234');
  await pi.waitForSelector('#lg-email', { timeout: 15000 });
  check((await pi.evaluate(() => localStorage.getItem('mobi_codigo'))) === 'MARCO1234', 'código do link /c/ é guardado para o cadastro do motorista');
  await ctxI.close();
});

await secao('EMPRESA: cadastro pelo portal', async () => {
  const g = await novoUsuario('gestora@e2e.com');
  await rpcComo(g.id, 'completar_cadastro', { p_nome: 'Gina Gestora', p_telefone: '21944440000', p_cpf: cpf(), p_email: g.email, p_cidade: CID });
  const ctxE = await contexto(g); const pe = await pagina(ctxE, '/empresa.html');
  await pe.waitForSelector('#e-razao', { timeout: 15000 });
  await pe.fill('#e-razao', 'Acme Ltda'); await pe.fill('#e-fant', 'Acme'); await pe.fill('#e-cnpj', '11.222.333/0001-81'); await pe.fill('#e-mail', 'fin@acme.com');
  await pe.click('#e-ok');
  await pe.waitForFunction(() => /em análise/.test(document.body.innerText), null, { timeout: 15000 });
  check((await q(`select status from empresas where cnpj='11222333000181'`))[0].status === 'PENDENTE', 'empresa cadastrada pelo portal fica em análise');
  await pe.goto(BASE + '/empresa.html#estrutura'); await pe.waitForSelector('#dep-nome', { timeout: 15000 });
  await pe.fill('#dep-nome', 'Comercial'); await pe.click('#dep-ok');
  await pe.waitForFunction(() => /Comercial/.test(document.body.innerText), null, { timeout: 15000 });
  check(true, 'gestor cria departamento');
  await ctxE.close();
});

check(errosJs.length === 0, 'nenhum erro de JavaScript nas telas', errosJs);
await browser.close(); web.close(); prest.kill(); await db.end();
console.log(linhas.join('\n'));
console.log(`\n=========================================\n  TELAS (E2E): ${ok} OK   ·   ${falhas} FALHA(S)\n=========================================`);
process.exit(falhas ? 1 : 0);
