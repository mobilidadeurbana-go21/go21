-- ============================================================
-- SHIM DO SUPABASE — SÓ PARA TESTES LOCAIS
-- Reproduz o mínimo do ambiente Supabase (auth.uid(), papéis
-- anon/authenticated/service_role e a publicação do realtime)
-- num PostgreSQL puro. NÃO rodar no Supabase.
-- ============================================================
do $$ begin
  if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if;
  if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin bypassrls; end if;
end $$;

create schema if not exists auth;
create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text,
  phone text,
  email_confirmed_at timestamptz,   -- como no Supabase: preenchido quando o contato é confirmado
  phone_confirmed_at timestamptz,
  created_at timestamptz default now()
);
-- mesmas definições do Supabase: aceitam o formato antigo (claim.sub) e o do PostgREST 10+ (claims em JSON)
create or replace function auth.uid() returns uuid language sql stable as $$
  select coalesce(nullif(current_setting('request.jwt.claim.sub', true), ''),
                  (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub'))::uuid
$$;
create or replace function auth.role() returns text language sql stable as $$
  select coalesce(nullif(current_setting('request.jwt.claim.role', true), ''),
                  (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role'), 'anon')
$$;
grant usage on schema auth to anon, authenticated, service_role;
grant execute on all functions in schema auth to anon, authenticated, service_role;

do $$ begin
  if not exists (select 1 from pg_publication where pubname='supabase_realtime') then
    create publication supabase_realtime;
  end if;
end $$;

-- Permissões padrão do Supabase: tudo que for criado em public nasce liberado para anon/authenticated.
-- Os testes rodam com isso ligado para provar que as migrations fecham o acesso sozinhas.
grant usage on schema public to anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;
