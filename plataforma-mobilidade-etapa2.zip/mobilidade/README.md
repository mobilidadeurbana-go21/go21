# Plataforma de Mobilidade — Etapas 1 e 2

Banco (Supabase/PostgreSQL) com **todas as regras de negócio**, Edge Functions (webhook de pagamento, cobrança, push, assistente) e **apps em HTML de arquivo único** (passageiro, motorista, empresa, administração e acompanhamento público).

```
supabase/migrations/   0001 → 0015 (rodar nesta ordem; inclui 0010_00 antes da 0010)
supabase/functions/    webhook-pagamento · criar-cobranca · enviar-notificacoes · assistente · jobs
supabase/tests/        testes do banco, das funções, de carga e E2E clicando nas telas
apps/src/              fonte das telas (edite aqui)  →  node apps/build.js  →  site/ (publicar)
docs/                  arquitetura, módulos, auditorias, IA, integrações, operação, relatório da Etapa 2
```

**Princípio:** o app nunca grava tabela. Tudo passa por funções do banco que conferem permissão, saldo, limites, antifraude e auditoria. O app só mostra e chama.

---

## Instalação passo a passo

### 1. Projeto Supabase (novo, só para a mobilidade)
1. Em supabase.com → **New project**. Região: São Paulo. Guarde a senha do banco num cofre.
2. **Database → Extensions**: ligue `pg_cron` e `pg_net`.
3. **Authentication → Providers**: e-mail ligado com **Confirm email** ligado (convites de empresa só valem para contato confirmado). Para login por SMS, configure um provedor de SMS (ver `docs/INTEGRACOES.md`).
4. **Authentication → URL Configuration**: Site URL = seu domínio (ex.: `https://app.seudominio.com.br`).

### 2. Migrations (SQL Editor, uma de cada vez, na ordem)
`0001_base` → `0002_cadastros` → `0003_corridas` → `0004_financeiro` → `0005_risco_paineis_seguranca` → `0006_admin_lgpd_observabilidade` → `0007_inteligencia_radar` → `0008_rentabilidade_assistentes` → `0009_seguranca_risco_indicacao` → **`0010_00_enum_empresa`** → `0010_ecossistema` → `0011_categorias_dono_analytics` → `0012_correcoes_carga` → `0013_push_web` → `0014_ajustes_telas` → `0015_correcoes_auditoria_etapa2` → `seed.sql` (cidade de exemplo — troque pelos dados reais).

Cada arquivo deve terminar sem erro. Avisos (NOTICE) são normais. Se usar a CLI: `supabase db push` aplica tudo na ordem.

### 3. Agendamentos
Se o `pg_cron` estava ligado antes das migrations, os jobs do banco já ficaram agendados (matching a cada minuto, inteligência a cada 5 min, horário e diário). Confira em **Database → Cron Jobs**. Se não aparecerem, rode de novo a migration `0005` (o trecho do cron é idempotente).

O envio de push precisa chamar a Edge Function a cada minuto. No SQL Editor:
```sql
select cron.schedule('mob_push', '* * * * *', $$
  select net.http_post(url := 'https://SEU-PROJETO.supabase.co/functions/v1/enviar-notificacoes',
                       headers := jsonb_build_object('x-segredo-cron', 'MESMO_VALOR_DO_CRON_SEGREDO'));
$$);
```

### 4. Edge Functions
Instale a CLI do Supabase e, na pasta do projeto:
```bash
supabase link --project-ref SEU-PROJETO
supabase secrets set CRON_SEGREDO=<gere 32+ caracteres aleatórios> APP_ORIGEM=https://app.seudominio.com.br \
  AMBIENTE=producao GATEWAY=<nome do adaptador do seu gateway> WEBHOOK_SEGREDO_GENERICO=<segredo do webhook> \
  VAPID_PUBLICA=<...> VAPID_PRIVADA=<...> VAPID_CONTATO=mailto:suporte@seudominio.com.br
supabase functions deploy webhook-pagamento --no-verify-jwt
supabase functions deploy enviar-notificacoes --no-verify-jwt
supabase functions deploy jobs --no-verify-jwt
supabase functions deploy criar-cobranca
supabase functions deploy assistente
```
- Chaves VAPID: `npx web-push generate-vapid-keys` (uma vez).
- Assistente com linguagem natural (opcional): `ASSISTENTE_LLM_CHAVE` e `ASSISTENTE_MODELO`. Sem eles, o assistente responde direto do banco (já completo).
- **Gateway de pagamento:** o adaptador real precisa ser escrito com a API do gateway contratado (modelo em `supabase/functions/_shared/cobranca.ts` e `docs/INTEGRACOES.md`). Até lá, homologação usa `GATEWAY=simulado` com `AMBIENTE=homologacao` — **o simulador é recusado em produção.**

### 5. Seu usuário de dono (SUPER_ADMIN)
1. Abra `passageiro.html` publicado, crie a conta e complete o cadastro.
2. No SQL Editor: `insert into usuario_papeis (usuario_id, papel) select id, 'SUPER_ADMIN' from perfis where email = 'seu@email.com';`
3. Os demais papéis (ADMIN, FINANCEIRO, OPERACOES, RISCO, SUPORTE) você concede pela tela **admin → Equipe e papéis**.

### 6. Telas (Vercel)
1. Copie `apps/config.exemplo.json` para `apps/config.json` e preencha (URL e chave **anon** do projeto: Supabase → Settings → API). Nunca coloque a chave `service_role` aqui (o build descarta qualquer chave com nome de segredo, mas não confie nisso).
2. `npm install` e `npm run build:producao` → gera `site/` com as páginas, `vercel.json` (rotas `/c/CODIGO` e `/v/TOKEN`, cabeçalhos de segurança e CSP calculada a partir da sua configuração).
3. Na Vercel: **New Project → importar o repositório**, Root Directory = `site`, sem comando de build (ou use `npm run build:producao` com Output Directory `site`).
4. Endereços: `/passageiro.html`, `/motorista.html`, `/empresa.html`, `/admin.html`, `/v/<token>` (acompanhamento), `/c/<código>` (indicação de motorista).

### 7. Cidade, tarifas e categorias
Na tela **admin → Cidades e tarifas**: dados da cidade, raio, documentos exigidos, regulamentação municipal, tarifas por categoria. Categorias especiais (Familiar, Acessível, Aeroporto…) só aparecem para motoristas que cumprem os requisitos verificados pela operação. Cidade nova nasce **inativa**.

### 8. Ambiente
O banco nasce em **produção** (simulador de pagamento fechado). Para homologação: `admin_salvar_config('ambiente', '"homologacao"')` (só SUPER_ADMIN) e, nas telas, `MODO_TESTE: true`.

### 9. Antes de abrir ao público
Siga a lista "Próximos passos para lançamento" em `docs/RELATORIO_ETAPA2.md` (gateway real, SMS, provedor de mapas, revisão jurídica, backup testado, alarmes).

---

## Testes (para quem desenvolve)
Precisa de PostgreSQL 15+ local, Node 22, PostgREST 12 (para funções/E2E) e Chromium (E2E).
```bash
npm install
npm test                 # banco: Etapa 1 (156) + Etapa 2 (189)
npm run test:funcoes     # Edge Functions contra a API real (PostgREST): 40
npm run test:e2e         # navegador clicando nas telas: 36
MOTORISTAS=120 PASSAGEIROS=400 POOL=80 npm run test:carga   # carga e concorrência com invariantes
```
Variáveis: `PGHOST`, `PGPORT`, `PGUSER` (e `POSTGREST`/`CHROME` para os caminhos dos binários).
