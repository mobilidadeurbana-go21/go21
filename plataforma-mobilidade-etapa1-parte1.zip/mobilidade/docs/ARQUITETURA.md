# Arquitetura da Plataforma de Mobilidade — Etapa 1

> Documento vivo. Toda mudança estrutural entra aqui **antes** de ir para o código.

## 1. Princípios

1. **O banco é a fonte da verdade e o guardião das regras.** Toda regra de dinheiro, estado de corrida e permissão mora no PostgreSQL, em funções testadas. Os apps (passageiro, motorista, admin) só *pedem*; o banco decide. Isso impede que um app adulterado burle regras.
2. **Ninguém escreve direto nas tabelas.** Os apps só leem (com RLS) e chamam funções (`rpc`). Toda escrita passa por funções `SECURITY DEFINER` que validam quem é o usuário, o papel e a regra de negócio.
3. **Dinheiro é contabilidade, não um campo "saldo".** Ledger de partidas dobradas, imutável. Corrigir = lançar o contrário. O banco recusa qualquer transação que não feche em zero.
4. **Tudo idempotente.** Pedido de corrida, pagamento, webhook, saque e estorno podem chegar repetidos sem duplicar nada.
5. **Nada fixo no código.** Comissão, tarifas, raios de busca, carências e limites ficam em tabelas configuráveis (global → cidade → categoria → motorista → horário/campanha).
6. **Antifraude sinaliza e segura valor; quem pune é uma pessoa.** Nenhum bloqueio automático de conta.
7. **Segurança pergunta, não presume.** "Detectamos uma alteração inesperada. Está tudo bem?"

## 2. Stack

| Camada | Escolha | Por quê | Quando trocar/evoluir |
|---|---|---|---|
| Banco | **PostgreSQL (Supabase)** | ACID para dinheiro, RLS por usuário, funções transacionais, réplica de leitura | Nunca sai; ganha réplicas e particionamento (§7) |
| API | **PostgREST do Supabase** (RPC + leitura com RLS) | Zero servidor para manter no início; cada função vira endpoint `POST /rest/v1/rpc/<nome>` | Partes quentes (matching, GPS) migram para serviço dedicado (§7) |
| Autenticação | **Supabase Auth** (telefone por SMS + e-mail) | Sessão JWT, recuperação, logout, bloqueio de força bruta | Adicionar MFA para staff (Etapa 2) |
| Tempo real | **Supabase Realtime** (`corridas`, `ofertas`, `notificacoes`) respeitando RLS | Atualização instantânea de status/oferta | GPS de alta frequência vai para canal *broadcast* (Etapa 2) |
| Arquivos | **Supabase Storage**, buckets privados `documentos` e `fotos`, pasta por usuário | Documentos sensíveis nunca públicos | — |
| Funções de servidor | **Supabase Edge Functions** (Deno) | Webhook do gateway, envio de push/SMS/e-mail, cobrança PIX/cartão | — |
| Jobs | **pg_cron** (`executar_jobs`) | Matching (10 s), liberação D+N (15 min), documentos e risco (diário) | Fila dedicada se o volume pedir |
| Frontend | **Apps web instaláveis (PWA)** hospedados na **Vercel** | Um código para Android/iPhone/desktop, publica pelo GitHub | App de loja (React Native/Expo) quando precisar de GPS em segundo plano contínuo |
| Mapas | Etapa 2: Google Maps Platform ou Mapbox (rota, ETA com trânsito, geocodificação) | O servidor já confere a rota informada (§4.2) | — |
| Pagamentos | Etapa 2: gateway brasileiro com PIX + cartão tokenizado (ex.: Mercado Pago, Pagar.me, Asaas) | **Nunca** guardamos número de cartão: só token do gateway | — |

## 3. Componentes

```
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ App Passageiro│  │ App Motorista │  │ Painel Admin  │   (PWA na Vercel)
└──────┬───────┘  └──────┬───────┘  └──────┬───────┘
       │ JWT (Supabase Auth)               │
       ▼                                   ▼
┌──────────────────────────────────────────────────────┐
│ Supabase: PostgREST (rpc + leitura c/ RLS) · Realtime │
├──────────────────────────────────────────────────────┤
│ PostgreSQL                                            │
│  public.*   → tabelas + funções chamáveis pelos apps  │
│  interno.*  → regras internas (não expostas)          │
│  pg_cron    → jobs                                    │
└───────────────┬──────────────────────────────────────┘
                │ service_role (só servidor)
┌───────────────▼──────────────┐
│ Edge Functions               │──► Gateway PIX/cartão (webhook)
│  webhook-pagamento           │──► FCM (push) · SMS · e-mail · WhatsApp
│  enviar-notificacoes         │
│  processar-repasses          │
└──────────────────────────────┘
```

## 4. Módulos e onde cada regra mora

Detalhe completo por módulo (o que, onde, dependências, banco, APIs, segurança, testes, como validar) em [`MODULOS.md`](MODULOS.md).

### 4.1 Corrida — máquina de estados
`SOLICITADA → BUSCANDO → A_CAMINHO → CHEGOU → EM_CURSO → FINALIZADA → PAGA`
desvios: `CANCELADA`, `SEM_MOTORISTA`; motorista cancela → volta para `BUSCANDO` (rematching).
Cada transição grava um evento imutável em `corrida_eventos` (SOLICITACAO, OFERTA_ENVIADA, ACEITE, DESLOCAMENTO, CHEGADA, EMBARQUE, FINALIZACAO, PAGAMENTO, AVALIACAO, REPASSE, cancelamentos, verificações de segurança).
Travas de banco: **1 corrida ativa por passageiro** e **1 por motorista** (índices únicos parciais), **1 oferta pendente por corrida e por motorista**.

### 4.2 Preço
`tarifa_base + km × preço_km + min × preço_min` (mínimo garantido, multiplicador com teto por categoria/cidade).
A rota que o app manda é **conferida**: menor que a linha reta ou absurdamente maior → o servidor estima sozinho.
**Preço previsível:** o passageiro paga o estimado, salvo se a corrida real passar da tolerância (20%, configurável).
**Km final só da trilha GPS gravada no servidor**, ignorando saltos impossíveis (>150 km/h) e com teto de 2× o estimado (acima disso cobra o estimado e retém o valor do motorista para análise).

### 4.3 Matching
Não é "o mais perto". Score em minutos equivalentes (menor vence), pesos por cidade:
ETA (distância × trânsito) + direção do motorista + qualidade (nota) + cancelamentos + taxa de aceite + risco − tempo ocioso; componentes `demanda_regiao` preparados.
Raio cresce automaticamente (3 → 5 → 8 → 12 km) até achar alguém. Oferta expira em 15 s. Recusa/expiração/cancelamento do motorista → próximo candidato na hora, com o relógio da busca zerado.

### 4.4 Financeiro (ledger)
Contas: `MOTORISTA_PENDENTE/DISPONIVEL`, `INDICACAO_PENDENTE/DISPONIVEL`, `PASSAGEIRO_CARTEIRA`, `PLATAFORMA_RECEITA`, `PLATAFORMA_PROMOCOES`, `INDICACAO_RETIDA`, `GATEWAY_RECEBIVEIS`, `REPASSES_EM_PROCESSAMENTO`, `REPASSES_PAGOS`.
Corrida de R$100 (regra padrão 20% / 3-2-1): gateway −100 · motorista +80 · indicador nível 1 +3 · nível 2 +2 · nível 3 +1 · plataforma +14. **Testado.**
Ganho do motorista: pendente → disponível em D+1; bônus de indicação em D+7; saque via PIX com trava de saldo.
Dinheiro em espécie: o motorista fica devendo só a comissão, descontada dos próximos ganhos.

## 5. Ambientes

| Ambiente | Supabase | Vercel | `configuracoes.ambiente` | Simulador de pagamento |
|---|---|---|---|---|
| Desenvolvimento | projeto `mob-dev` | preview | `desenvolvimento` | qualquer usuário |
| Homologação | projeto `mob-hml` (dados fictícios) | `hml.seudominio` | `homologacao` | só equipe |
| Produção | projeto `mob-prod` (plano pago, PITR ligado) | `seudominio` | `producao` | **não existe** (fechado por padrão) |

Migrations aplicadas na mesma ordem nos três (Supabase CLI: `supabase db push`). Nunca editar banco de produção à mão: toda mudança é migration nova, testada em dev e homologação.

## 6. Operação

- **Filas:** notificações usam fila no banco (`notificacoes`, status PENDENTE→ENVIANDO→ENVIADA/FALHOU, até 5 tentativas, `FOR UPDATE SKIP LOCKED` permite vários workers). Repasses: `repasses` com status. Matching: job + "empurrão" a cada consulta do passageiro.
- **Cache:** catálogos (cidades, categorias, tarifas) mudam pouco → cache no app (5 min) e na borda. Saldo nunca é cacheado (lê `saldos`, que é atualizado no mesmo commit do lançamento).
- **Logs:** `auditoria` (imutável: login, mudanças de status, comissões, pagamentos, estornos, decisões de risco, ações de suporte), `corrida_eventos` (imutável), logs do Supabase (API/Auth/Edge) exportados para ferramenta externa (Logflare/Datadog) na produção.
- **Monitoramento (alertas mínimos):** corridas `SEM_MOTORISTA`/hora por cidade; tempo médio de espera; webhooks não processados > 5 min; `notificacoes` FALHOU; incidentes CRÍTICOS abertos; sinais de fraude severidade ≥ 4; **soma do ledger ≠ 0** (nunca deveria acontecer); fila de repasses parada.
- **Backups:** Supabase Pro faz backup diário; **ligar PITR** (recuperação a qualquer instante) na produção. Exportação semanal criptografada para outro provedor (S3/GCS). Teste de restauração mensal em projeto separado.
- **Recuperação de falhas:** jobs idempotentes (podem rodar de novo sem efeito colateral); webhook repetido é ignorado; corrida travada é detectada por job (motorista sem GPS 5 min → nova busca; EM CURSO muito além do previsto → suporte assume e encerra com `suporte_finalizar_corrida`).

## 7. Escala: de 10 a 1 milhão+

| Fase | Usuários | O que muda |
|---|---|---|
| Piloto | 10–1.000 motoristas | Tudo como está. Supabase Pro. pg_cron. |
| Cidade cheia | 10 mil motoristas | Supabase compute maior; réplica de leitura para painéis/relatórios; GPS do motorista via Realtime *broadcast* (não grava toda posição no banco, só a trilha da corrida em andamento); índice espacial PostGIS/H3 no lugar da caixa lat/lng. |
| Multi-cidade | 100 mil | Particionar `corrida_eventos`, `corrida_trilha`, `lancamentos_ledger`, `auditoria`, `notificacoes` por mês; arquivar trilhas antigas; matching vira serviço dedicado (lendo presença em Redis/geo-índice) que chama a mesma função de aceite no banco; filas em serviço dedicado. |
| Nacional | 1 milhão+ | Banco por região (shard por cidade); ledger permanece central e serializado por conta; data warehouse (BigQuery/ClickHouse) para analytics. |

O desenho já facilita isso: regras isoladas em funções, chaves UUID, histórico append-only, nenhum estado no app.

## 8. Segurança e LGPD (resumo)

- RLS em **todas** as 41 tabelas; staff por papel (ADMIN, OPERACOES, FINANCEIRO, RISCO, SUPORTE, SUPER_ADMIN; EMPRESA preparado).
- Ninguém decide sobre o próprio registro (conflito de interesse bloqueado no banco).
- CPF nunca volta inteiro para o app; documentos em bucket privado; PIN fora da tabela que o motorista lê.
- IP de auditoria vem do proxy confiável.
- Limite de chamadas por usuário/ação. Erros de validação sensíveis são **devolvidos** (não lançados) para o limite contar e evitar varredura de CPF/telefone.
- LGPD: base legal = execução de contrato + segurança; aceite de termos versionado em `perfis`; direito de exclusão = anonimizar perfil mantendo registros financeiros/fiscais pelo prazo legal (função na Etapa 2); relatório de dados do titular (Etapa 2).
- **Antes de operar comercialmente:** validação jurídica (regulamentação municipal de transporte por app, tributação, LGPD, termos de uso, contrato com motoristas, programa de indicação).
