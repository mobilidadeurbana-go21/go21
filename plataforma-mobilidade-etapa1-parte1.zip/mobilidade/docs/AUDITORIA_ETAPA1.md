# Auditoria geral — Etapa 1, Parte 1 (base de dados e regras)

**Data:** 03/10/2026 · **Escopo:** banco, regras de negócio, segurança, financeiro e testes. Os apps (passageiro, motorista e admin) e as integrações reais (gateway de pagamento, mapas, push/SMS) ficam para a Parte 2 e a Etapa 2.

## 1. O que foi implementado

| Área | Situação |
|---|---|
| Arquitetura documentada (stack, ambientes, filas, cache, logs, monitoramento, backups, recuperação, escala 10 → 1M) | ✅ `docs/ARQUITETURA.md` |
| Usuários, papéis (passageiro, motorista, admin + empresa, suporte, financeiro, operações, risco, super admin), cadastro, acesso, proteção contra abuso | ✅ |
| Motorista: cadastro, CNH/EAR, documentos, selfie, veículo, CRLV, seguro, estados, compliance por cidade/categoria | ✅ |
| Veículo: categorias configuráveis por cidade (15 catalogadas; Econômico, Conforto e Premium ligadas) | ✅ |
| Passageiro: estimativa de preço e de chegada por categoria, pedido idempotente | ✅ |
| Corrida: ciclo completo, todos os eventos registrados e imutáveis | ✅ |
| Matching multi-critério, raio crescente, rematching automático | ✅ |
| Pagamentos: PIX, cartão, carteira, dinheiro, gorjeta, taxa de cancelamento, recarga, estorno, repagamento; idempotentes, com UUID único | ✅ (gateway real na Etapa 2) |
| Comissão configurável (20% e 3/2/1 por padrão) por cidade, categoria, motorista, horário, campanha e período | ✅ |
| Indicação em 3 níveis, com código, link, árvore, histórico, ganhos, status e antifraude | ✅ (QR Code gerado no app) |
| Carteira com ledger imutável de partidas dobradas, D+N, saque | ✅ |
| Motorista gerente financeiro (painel do dia/período) e motor de rentabilidade antes do aceite | ✅ |
| Segurança: PIN, compartilhamento, contatos, emergência, denúncia, incidentes, desvio/parada/duração → "Está tudo bem?" | ✅ |
| Antifraude: detecção → análise → validação humana → ação; sem bloqueio automático | ✅ |
| Cidades, compliance, auditoria, notificações (fila), painel admin com filtros | ✅ |
| Permissões: RLS em 41 tabelas, escrita só por funções | ✅ |

**Números:** 41 tabelas, 111 funções (52 de API: 48 para os apps e 4 só para o servidor), 5 migrations e o seed.

## 2. O que foi testado

**156 verificações automáticas, todas passando, em 4 rodadas seguidas.** Rodam num PostgreSQL de verdade, com cada ator na própria conexão e com o mesmo papel que teria no Supabase. Os testes de concorrência usam conexões simultâneas reais:

- 2 pedidos simultâneos do mesmo passageiro geram 1 corrida.
- 3 envios com a mesma chave geram 1 corrida.
- Aceite e cancelamento ao mesmo tempo terminam em estado coerente.
- Dois motoristas disputando uma oferta: só o dono aceita.
- 4 webhooks simultâneos geram 1 liquidação.
- 3 saques simultâneos não passam do saldo.
- 2 gorjetas simultâneas pela carteira: só uma é debitada.
- Integridade final: a soma de todo o ledger dá R$ 0,00, nenhuma transação está desbalanceada e os saldos batem com os lançamentos.

As migrations podem ser reaplicadas por cima de um banco com dados sem erro.

## 3. Problemas encontrados

**Pelos testes (2):**
1. A conferência de partidas dobradas no commit dava erro de permissão para o servidor. Para usuário comum ela passava sem conferir nada, porque o RLS escondia as linhas.
2. A busca de motorista ficava presa no raio de 3 km quando não havia ninguém perto.

**Pela revisão independente (19, 13 deles provados com exploit):**

| # | Gravidade | Problema |
|---|---|---|
| 1 | CRÍTICO | Passageiro marcava a própria corrida como paga pelo simulador, que só fechava com a palavra exata "producao" |
| 2 | ALTO | Motorista lia o PIN direto na tabela de corridas (e pelo realtime) |
| 3 | ALTO | GPS falso em zigue-zague inflava o preço (de R$ 21 para R$ 134) |
| 4 | ALTO | Motorista respondia "tudo bem" pela passageira; finalizar a corrida apagava a pergunta aberta |
| 5 | ALTO | Corrida não paga não impedia pedir outra; cobrança que falhava não tinha como ser paga |
| 6 | MÉDIO | Estorno de corrida com bônus retido já decidido vazava dinheiro |
| 7 | MÉDIO | Sinais de risco se perdiam quando a operação dava erro (rollback) |
| 8 | MÉDIO | Dava para descobrir quais CPFs estavam cadastrados, porque o limite não contava as tentativas com erro |
| 9 | MÉDIO | Motorista marcava "cheguei" a 29 km e cobrava taxa de não comparecimento; passageiro pagava taxa com o motorista parado |
| 10 | MÉDIO | Depois de cancelamento do motorista, a corrida virava "sem motorista" na hora |
| 11 | MÉDIO | Motorista ativo alterava a própria validade da CNH e o EAR |
| 12 | MÉDIO | A carteira podia ser gasta duas vezes em paralelo |
| 13 | MÉDIO | Membro da equipe podia aprovar o próprio cadastro ou bônus |
| 14 | MÉDIO | IP da auditoria era falsificável pelo cliente |
| 15 | BAIXO | Jobs podiam ser chamados pelos apps |
| 16 | BAIXO | Passageiro via dados internos nos eventos (score, divisão do dinheiro) |
| 17 | BAIXO | Corridas podiam ficar travadas para sempre (app do motorista morre) |
| 18 | BAIXO | Arredondamento da indicação podia deixar a plataforma R$ 0,01 negativa |
| 19 | BAIXO | Regra de comissão que vira a meia-noite (22h às 2h) nunca valia |

## 4. Problemas corrigidos

**Todos os 21.** Cada correção tem pelo menos um teste próprio (seção "CORREÇÕES DA REVISÃO INDEPENDENTE" nos testes), exceto os itens 7 e 8, que estão cobertos nos testes de placa duplicada, de autoindicação e de limite de cadastro.

## 5. Riscos restantes (conhecidos e assumidos)

1. **Versão do PostgreSQL:** testado no PostgreSQL 16; o Supabase usa 15 ou 17. Não achei nenhum recurso exclusivo do 16, mas é preciso aplicar primeiro num projeto de desenvolvimento do Supabase. A política de Storage só roda no Supabase; se falhar, os buckets são criados pelo painel.
2. **Limite de chamadas:** só conta chamadas que terminam. Os pontos sensíveis (cadastro, placa, indicação) já devolvem o erro em vez de lançar. Para o resto, colocar limite por IP na borda (Cloudflare/WAF) antes de abrir ao público.
3. **Gateway de pagamento não integrado:** o webhook está pronto e idempotente, mas a Edge Function que recebe o webhook precisa conferir a assinatura (HMAC) do gateway. Isso é obrigatório antes de produção.
4. **PIX pago depois de a cobrança ser substituída:** o sistema gera um sinal, mas o estorno é manual.
5. **Dívida do motorista em dinheiro sem teto:** recomendação para a Etapa 2 é limitar a dívida e, passado o limite, bloquear corridas em dinheiro.
6. **Notificações** ficam na fila mas ainda não são enviadas (push/SMS/e-mail na Etapa 2).
7. **ETA sem trânsito real** (usa velocidade média); a integração de mapas fica para a Etapa 2.
8. **Pesos do matching** foram chutados com bom senso e precisam ser calibrados com dados reais do piloto.
9. **LGPD:** faltam a anonimização (direito de exclusão), o relatório de dados do titular e a criptografia do CPF em repouso (Supabase Vault).
10. **Jurídico:** regulamentação municipal, tributos, termos de uso, contrato do motorista e o **programa de indicação em 3 níveis** precisam de parecer de advogado antes de operar. O bônus é ligado a corrida real e sai da taxa da plataforma, o que ajuda, mas a validação jurídica é obrigatória.
11. **Estorno parcial** não existe (só total).

## 6. Preparado para a Etapa 2

- **Categorias** Moto, 7 lugares, Acessível, Familiar, Aeroporto, Intermunicipal, Agendada, Compartilhada, Corporativa, Eventos, Terminal e Viagens já estão catalogadas; basta ligar e configurar a tarifa por cidade.
- **Cupons:** a estrutura está pronta (falta aplicar no pedido).
- **Campanhas, promoções e comissões** por horário, período ou motorista já funcionam pela tabela de regras.
- **Papéis** EMPRESA, SUPORTE, FINANCEIRO, OPERAÇÕES e RISCO já existem no banco.
- **Matching** já tem o componente "demanda da região" (peso 0) pronto para a inteligência de demanda.
- **Notificações** já estão em fila multicanal, inclusive WhatsApp.
- **Detecção de segurança** tem pontos de extensão para a IA de segurança avançada.
- **Escala:** o plano está documentado (PostGIS/H3, particionamento, serviço de matching dedicado, réplicas).
