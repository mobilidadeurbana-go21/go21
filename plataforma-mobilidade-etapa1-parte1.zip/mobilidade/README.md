# Plataforma de Mobilidade — Etapa 1 (Parte 1: banco e regras)

Base real da plataforma: usuários, motoristas, veículos, corridas, matching, pagamentos, carteira, comissões, indicação, segurança, antifraude, cidades, compliance, notificações, auditoria e painel admin. Tudo roda dentro do banco (Supabase/PostgreSQL), com **156 testes automáticos passando**.

```
docs/
  ARQUITETURA.md        ← stack, ambientes, operação, escala de 10 a 1 milhão+
  MODULOS.md            ← ficha de cada módulo (o que, onde, banco, APIs, segurança, testes)
  AUDITORIA_ETAPA1.md   ← o que foi feito, testado, corrigido e os riscos restantes
supabase/
  migrations/           ← 0001 a 0005, rodar NESSA ORDEM
  seed.sql              ← cidade piloto de EXEMPLO + regra de comissão 20% (3/2/1)
  tests/                ← testes de ponta a ponta (rodam fora do Supabase)
```

---

## Como instalar no Supabase (clique a clique)

> Use um **projeto Supabase NOVO, só para a plataforma de mobilidade**. Não use o projeto da Plenart.

### 1. Criar o projeto
1. Entre em **supabase.com** e clique em **New project**.
2. Dê um nome, por exemplo `mobilidade-dev`.
3. Crie uma senha forte para o banco e **guarde essa senha**.
4. Escolha a região **South America (São Paulo)**.
5. Clique em **Create new project** e espere uns 2 minutos.

### 2. Ligar o agendador de tarefas (pg_cron)
1. No menu da esquerda, clique em **Database**.
2. Clique em **Extensions**.
3. Procure **pg_cron** e ligue a chave.

### 3. Rodar as migrations (uma de cada vez, na ordem)
1. No menu da esquerda, clique em **SQL Editor** e depois em **+ New query**.
2. Abra o arquivo `supabase/migrations/0001_base.sql`, copie tudo, cole e clique em **RUN**.
3. Tem que aparecer **Success**.
4. Repita o mesmo (nova query, colar, RUN) com:
   - `0002_cadastros.sql`
   - `0003_corridas.sql`
   - `0004_financeiro.sql`
   - `0005_risco_paineis_seguranca.sql`
   - `seed.sql`

Se alguma der erro, **pare** e me mande o print da mensagem. Pode rodar de novo sem medo, porque elas não apagam nada.

### 4. Criar os arquivos de documentos (se a migration 0005 avisar)
Se a 0005 mostrar o aviso "Storage não configurado por SQL", crie os buckets à mão:
1. No menu da esquerda, clique em **Storage** e depois em **New bucket**.
2. Crie um bucket chamado `documentos`, com **Public bucket desligado**.
3. Crie outro chamado `fotos`, também com **Public bucket desligado**.

### 5. Criar o seu usuário de dono (SUPER_ADMIN)
1. No menu da esquerda, clique em **Authentication**, depois em **Users** e em **Add user**, e crie com o seu e-mail.
2. Copie o **UID** do usuário criado.
3. No **SQL Editor**, rode trocando pelo seu UID:
   ```sql
   insert into usuario_papeis (usuario_id, papel) values ('COLE-SEU-UID-AQUI', 'SUPER_ADMIN');
   ```

### 6. Ajustar a cidade e as tarifas
O seed cria uma "Cidade Piloto (EXEMPLO)". Antes de testar com gente de verdade, troque nome, coordenadas e tarifas na tabela `cidades` e em `cidade_categorias` pelo **Table Editor**.

### 7. Ambiente
O projeto nasce como `desenvolvimento`, que deixa simular pagamento. No projeto de **produção**, rode:
```sql
update configuracoes set valor = '"producao"' where chave = 'ambiente';
```

---

## Testes (para quem desenvolve)

Precisa de PostgreSQL local e Node.js:
```bash
npm install
PGHOST=localhost PGPORT=5432 PGUSER=postgres ./supabase/tests/rodar_testes.sh
```
O script cria um banco limpo, aplica tudo e roda as 156 verificações.

## Próximos passos
- **Parte 2 da Etapa 1:** apps de passageiro e de motorista e o painel admin, ligados a este banco.
- **Etapa 2:** gateway de pagamento real (PIX/cartão), mapas com trânsito, envio de push/SMS e o resto listado em `docs/AUDITORIA_ETAPA1.md`.
