-- ============================================================
-- 0003 — CORRIDAS: presença do motorista, preço, matching,
--        ciclo completo da corrida, rematching, segurança
-- ============================================================

do $$ begin
  create type status_corrida as enum ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO','FINALIZADA','PAGA','CANCELADA','SEM_MOTORISTA');
exception when duplicate_object then null; end $$;
do $$ begin
  create type status_oferta as enum ('PENDENTE','ACEITA','RECUSADA','EXPIRADA','CANCELADA');
exception when duplicate_object then null; end $$;
do $$ begin
  create type metodo_pagamento as enum ('PIX','CARTAO','CARTEIRA','DINHEIRO');
exception when duplicate_object then null; end $$;

-- ---------- PRESENÇA DO MOTORISTA (1 linha por motorista, atualizada sempre) ----------
create table if not exists motorista_presenca (
  motorista_id uuid primary key references motoristas(id) on delete cascade,
  online boolean not null default false,
  disponivel boolean not null default false,       -- online e sem corrida
  cidade_id uuid references cidades(id),
  categorias text[] not null default '{}',          -- liberadas pelo compliance ao ficar online
  lat float8, lng float8,
  rumo float8,                                      -- direção em graus
  velocidade_kmh float8,
  atualizado_em timestamptz,
  disponivel_desde timestamptz,                     -- para medir tempo ocioso
  sessao_id uuid
);
create index if not exists presenca_busca_idx on motorista_presenca (cidade_id, lat, lng) where online and disponivel;

create table if not exists sessoes_online (
  id uuid primary key default gen_random_uuid(),
  motorista_id uuid not null references motoristas(id) on delete cascade,
  inicio timestamptz not null default now(),
  fim timestamptz
);
create index if not exists sessoes_motorista_idx on sessoes_online (motorista_id, inicio desc);

-- ---------- CORRIDA ----------
create table if not exists corridas (
  id uuid primary key default gen_random_uuid(),
  chave_idempotencia text not null,
  passageiro_id uuid not null references perfis(id),
  motorista_id uuid references motoristas(id),
  veiculo_id uuid references veiculos(id),
  cidade_id uuid not null references cidades(id),
  categoria text not null references categorias(codigo),
  status status_corrida not null default 'SOLICITADA',
  passageiros int not null default 1,
  origem_lat float8 not null, origem_lng float8 not null, origem_endereco text,
  destino_lat float8 not null, destino_lng float8 not null, destino_endereco text,
  distancia_estimada_km numeric(8,2) not null,
  duracao_estimada_min numeric(8,1) not null,
  multiplicador numeric(4,2) not null default 1,
  preco_estimado numeric(10,2) not null,
  preco_final numeric(10,2),
  distancia_real_km numeric(8,2),
  duracao_real_min numeric(8,1),
  metodo_pagamento metodo_pagamento not null,
  cupom_codigo text,
  desconto numeric(10,2) not null default 0,
  tentativas_matching int not null default 0,
  busca_iniciada_em timestamptz not null default now(),   -- zera no rematching
  motoristas_excluidos uuid[] not null default '{}',
  cancelado_por text check (cancelado_por in ('PASSAGEIRO','MOTORISTA','SISTEMA','SUPORTE')),
  motivo_cancelamento text,
  taxa_cancelamento numeric(10,2),
  solicitada_em timestamptz not null default now(),
  aceita_em timestamptz,
  chegou_em timestamptz,
  iniciada_em timestamptz,
  finalizada_em timestamptz,
  paga_em timestamptz,
  cancelada_em timestamptz,
  versao int not null default 1,
  unique (passageiro_id, chave_idempotencia)
);
create index if not exists corridas_passageiro_idx on corridas (passageiro_id, solicitada_em desc);
create index if not exists corridas_motorista_idx on corridas (motorista_id, solicitada_em desc);
create index if not exists corridas_cidade_data_idx on corridas (cidade_id, solicitada_em desc);
create index if not exists corridas_status_idx on corridas (status) where status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO');

-- PIN do embarque fica numa tabela que NENHUM app lê direto (só pelas funções):
-- o motorista não pode descobrir o PIN, senão a proteção "carro errado" não vale nada.
create table if not exists corrida_segredos (
  corrida_id uuid primary key references corridas(id),
  pin char(4) not null,
  pin_tentativas int not null default 0
);

-- trava de banco: 1 corrida ativa por passageiro e por motorista (protege contra corrida dupla/concorrência)
create unique index if not exists uma_corrida_ativa_passageiro on corridas (passageiro_id)
  where status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO');
create unique index if not exists uma_corrida_ativa_motorista on corridas (motorista_id)
  where status in ('A_CAMINHO','CHEGOU','EM_CURSO');

-- ---------- EVENTOS DA CORRIDA (histórico completo, imutável) ----------
create table if not exists corrida_eventos (
  id bigint generated always as identity primary key,
  corrida_id uuid not null references corridas(id),
  tipo text not null,
  status_de status_corrida,
  status_para status_corrida,
  ator_id uuid,
  dados jsonb not null default '{}',
  criado_em timestamptz not null default clock_timestamp()
);
create index if not exists corrida_eventos_idx on corrida_eventos (corrida_id, id);
drop trigger if exists corrida_eventos_imutavel on corrida_eventos;
create trigger corrida_eventos_imutavel before update or delete on corrida_eventos
  for each row execute function interno.trg_imutavel();

create or replace function interno.evento(p_corrida uuid, p_tipo text, p_de status_corrida, p_para status_corrida, p_dados jsonb default '{}')
returns void language sql security definer set search_path = public, pg_temp as $$
  insert into corrida_eventos (corrida_id, tipo, status_de, status_para, ator_id, dados)
  values (p_corrida, p_tipo, p_de, p_para, auth.uid(), coalesce(p_dados, '{}'))
$$;

-- ---------- OFERTAS (matching) ----------
create table if not exists ofertas (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid not null references corridas(id),
  motorista_id uuid not null references motoristas(id),
  status status_oferta not null default 'PENDENTE',
  score numeric(10,3),
  componentes jsonb,                 -- por que esse motorista foi escolhido
  distancia_embarque_km numeric(8,2),
  eta_embarque_min numeric(8,1),
  rentabilidade jsonb,               -- o que o motorista vê antes de aceitar
  ofertada_em timestamptz not null default now(),
  expira_em timestamptz not null,
  respondida_em timestamptz
);
create index if not exists ofertas_corrida_idx on ofertas (corrida_id, ofertada_em);
create index if not exists ofertas_motorista_idx on ofertas (motorista_id, ofertada_em desc);
create unique index if not exists uma_oferta_pendente_corrida on ofertas (corrida_id) where status = 'PENDENTE';
create unique index if not exists uma_oferta_pendente_motorista on ofertas (motorista_id) where status = 'PENDENTE';

-- ---------- AVALIAÇÕES ----------
create table if not exists avaliacoes (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid not null references corridas(id),
  avaliador_id uuid not null,
  avaliado_id uuid not null,
  papel_avaliador text not null check (papel_avaliador in ('PASSAGEIRO','MOTORISTA')),
  nota int not null check (nota between 1 and 5),
  comentario text,
  tags text[],
  criado_em timestamptz not null default now(),
  unique (corrida_id, avaliador_id)
);

-- ---------- SEGURANÇA ----------
create table if not exists corrida_trilha (
  corrida_id uuid not null references corridas(id),
  registrado_em timestamptz not null default clock_timestamp(),
  lat float8 not null, lng float8 not null,
  velocidade_kmh float8,
  primary key (corrida_id, registrado_em)
);

create table if not exists corrida_compartilhamentos (
  token text primary key,
  corrida_id uuid not null references corridas(id),
  criado_por uuid not null,
  expira_em timestamptz not null,
  criado_em timestamptz not null default now()
);

create table if not exists incidentes (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid references corridas(id),
  reportado_por uuid,
  tipo text not null check (tipo in ('EMERGENCIA','DENUNCIA','ACIDENTE','ASSEDIO','OBJETO_PERDIDO','COBRANCA','OUTRO','ALERTA_AUTOMATICO')),
  gravidade text not null default 'MEDIA' check (gravidade in ('BAIXA','MEDIA','ALTA','CRITICA')),
  descricao text,
  lat float8, lng float8,
  status text not null default 'ABERTO' check (status in ('ABERTO','EM_ATENDIMENTO','RESOLVIDO','ARQUIVADO')),
  responsavel_id uuid,
  resolucao text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists incidentes_status_idx on incidentes (status, gravidade, criado_em);
drop trigger if exists incidentes_auditar on incidentes;
create trigger incidentes_auditar after insert or update on incidentes
  for each row execute function interno.trg_auditar();

create table if not exists verificacoes_seguranca (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid not null references corridas(id),
  tipo text not null check (tipo in ('DESVIO','PARADA','DURACAO','COMPORTAMENTO')),
  mensagem text not null default 'Detectamos uma alteração inesperada. Está tudo bem?',
  dados jsonb,
  status text not null default 'AGUARDANDO' check (status in ('AGUARDANDO','TUDO_BEM','PRECISA_AJUDA','SEM_RESPOSTA')),
  respondido_por uuid,
  respondida_em timestamptz,
  criada_em timestamptz not null default now()
);
create unique index if not exists uma_verificacao_aberta on verificacoes_seguranca (corrida_id, tipo) where status = 'AGUARDANDO';

-- ============================================================
-- PREÇO
-- ============================================================

-- rota informada pelo app (mapa) é conferida: não pode ser menor que a linha reta
-- nem absurdamente maior. Se vier estranha, o servidor estima sozinho.
create or replace function interno.rota_saneada(o_lat float8, o_lng float8, d_lat float8, d_lng float8, p_km numeric, p_min numeric,
  out km numeric, out minutos numeric)
language plpgsql stable as $$
declare v_linha numeric := interno.distancia_km(o_lat, o_lng, d_lat, d_lng);
        v_vel numeric := interno.cfg_num('velocidade_media_kmh', 25);
begin
  if p_km is not null and p_km >= v_linha * 0.95 and p_km <= greatest(v_linha * 3, 1) then
    km := p_km;
  else
    km := v_linha * interno.cfg_num('fator_rota', 1.3);
  end if;
  km := greatest(round(km, 2), 0.1);
  if p_min is not null and p_min >= km / 120 * 60 and p_min <= greatest(km / 5 * 60, 5) then
    minutos := p_min;
  else
    minutos := km / v_vel * 60;
  end if;
  minutos := greatest(round(minutos, 1), 1);
end $$;

create or replace function interno.calcular_preco(p_cidade uuid, p_categoria text, p_km numeric, p_min numeric, p_mult numeric default 1)
returns numeric language sql stable as $$
  select round(greatest(cc.tarifa_minima,
           cc.tarifa_base + cc.preco_km * p_km + cc.preco_minuto * p_min) * least(greatest(p_mult, 1), cc.multiplicador_maximo), 2)
  from cidade_categorias cc where cc.cidade_id = p_cidade and cc.categoria = p_categoria
$$;

-- ============================================================
-- MATCHING — não é só "o mais perto"
-- ============================================================
-- score = minutos "equivalentes" (quanto MENOR, melhor):
--   ETA até o embarque (distância x fator de trânsito)
-- + penalidade de direção (motorista indo para o lado oposto)
-- − bônus de tempo ocioso (quem está parado há mais tempo ganha a vez)
-- + penalidade de qualidade (nota baixa)
-- + penalidade de cancelamentos
-- + penalidade de baixa taxa de aceite
-- + penalidade de risco (sinais de fraude/segurança em aberto)
-- + componentes preparados para demanda/região (peso 0 por enquanto)
-- Pesos ajustáveis por cidade em cidades.regras -> 'matching'.

create or replace function interno.peso(p_cidade uuid, p_chave text, p_padrao numeric) returns numeric
language sql stable as $$
  select coalesce((select (regras -> 'matching' ->> p_chave)::numeric from cidades where id = p_cidade), p_padrao)
$$;

create or replace function interno.candidatos(p_corrida uuid, p_raio_km numeric, p_limite int default 5)
returns table (motorista_id uuid, veiculo_id uuid, distancia_km numeric, eta_min numeric, score numeric, componentes jsonb)
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare c corridas; v_vel numeric; v_fator numeric; v_dlat float8; v_dlng float8;
begin
  select * into c from corridas where id = p_corrida;
  v_vel := interno.cfg_num('velocidade_media_kmh', 25);
  v_fator := interno.peso(c.cidade_id, 'fator_transito', 1.0) * interno.cfg_num('fator_rota', 1.3);
  v_dlat := p_raio_km / 111.0;
  v_dlng := p_raio_km / (111.0 * greatest(cos(radians(c.origem_lat)), 0.01));

  return query
  with base as (
    select p.motorista_id, m.veiculo_ativo_id as veiculo_id,
           interno.distancia_km(p.lat, p.lng, c.origem_lat, c.origem_lng)::numeric as dist,
           p.rumo, p.velocidade_kmh, p.lat, p.lng, p.disponivel_desde,
           m.avaliacao_media, m.total_corridas, m.total_cancelamentos, m.ofertas_recebidas, m.ofertas_aceitas
    from motorista_presenca p
    join motoristas m on m.id = p.motorista_id and m.status = 'ATIVO'
    join veiculos v on v.id = m.veiculo_ativo_id and v.capacidade >= c.passageiros
    join perfis pf on pf.id = p.motorista_id and pf.status = 'ATIVO'
    where p.online and p.disponivel
      and p.cidade_id = c.cidade_id
      and c.categoria = any(p.categorias)
      and p.atualizado_em > now() - interval '2 minutes'
      and p.lat between c.origem_lat - v_dlat and c.origem_lat + v_dlat
      and p.lng between c.origem_lng - v_dlng and c.origem_lng + v_dlng
      and not (p.motorista_id = any(c.motoristas_excluidos))
      and p.motorista_id <> c.passageiro_id
      and not exists (select 1 from ofertas o where o.motorista_id = p.motorista_id and o.status = 'PENDENTE')
  ), calc as (
    select b.*,
      round(b.dist * v_fator / v_vel * 60, 2) as eta,
      case when b.rumo is not null and coalesce(b.velocidade_kmh, 0) >= 10 then
        abs(mod((b.rumo - interno.rumo(b.lat, b.lng, c.origem_lat, c.origem_lng) + 540)::numeric, 360) - 180)
      else 0 end as angulo,
      least(extract(epoch from now() - coalesce(b.disponivel_desde, now())) / 60, 30) as ocioso_min,
      (select count(*) from sinais_fraude s where s.entidade_tipo = 'USUARIO' and s.entidade_id = b.motorista_id::text
         and s.status in ('ABERTO','EM_ANALISE') and s.severidade >= 3) as riscos
    from base b where b.dist <= p_raio_km
  ), pontos as (
    select k.*,
      jsonb_build_object(
        'eta_min', k.eta,
        'direcao', round(k.angulo / 180 * interno.peso(c.cidade_id, 'peso_direcao', 4), 2),
        'ocioso', round(-k.ocioso_min * interno.peso(c.cidade_id, 'peso_ocioso', 0.1), 2),
        'qualidade', round((5 - k.avaliacao_media) * interno.peso(c.cidade_id, 'peso_qualidade', 2), 2),
        'cancelamentos', round(k.total_cancelamentos::numeric / greatest(k.total_corridas + k.total_cancelamentos, 10)
                               * interno.peso(c.cidade_id, 'peso_cancelamento', 10), 2),
        'aceite', round((1 - k.ofertas_aceitas::numeric / greatest(k.ofertas_recebidas, 10))
                        * interno.peso(c.cidade_id, 'peso_aceite', 2), 2),
        'risco', round(k.riscos * interno.peso(c.cidade_id, 'peso_risco', 5), 2),
        'demanda_regiao', 0
      ) as comp
    from calc k
  )
  select pt.motorista_id, pt.veiculo_id, round(pt.dist, 2), pt.eta,
         round((select sum(value::numeric) from jsonb_each_text(pt.comp)), 3) as score,
         pt.comp
  from pontos pt
  order by 5 asc, pt.dist asc
  limit p_limite;
end $$;

-- envia a corrida para o melhor motorista disponível (1 oferta por vez)
create or replace function interno.buscar_motorista(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare
  c corridas; cand record; v_oferta uuid; v_raios jsonb; v_raio numeric; v_exp int; v_i int;
  v_max int; v_tempo int; v_expiradas uuid[];
begin
  select * into c from corridas where id = p_corrida for update;
  if c.status not in ('SOLICITADA','BUSCANDO') then return jsonb_build_object('status', c.status); end if;

  -- oferta ainda válida? não faz nada
  if exists (select 1 from ofertas where corrida_id = p_corrida and status = 'PENDENTE' and expira_em > now()) then
    return jsonb_build_object('status', c.status, 'aguardando_resposta', true);
  end if;

  -- ofertas vencidas: motorista não respondeu -> sai da lista desta corrida
  with exp as (
    update ofertas set status = 'EXPIRADA', respondida_em = now()
    where corrida_id = p_corrida and status = 'PENDENTE' and expira_em <= now()
    returning motorista_id)
  select array_agg(motorista_id) into v_expiradas from exp;
  if v_expiradas is not null then
    update corridas set motoristas_excluidos = motoristas_excluidos || v_expiradas where id = p_corrida
    returning * into c;
    perform interno.evento(p_corrida, 'OFERTA_EXPIRADA', c.status, c.status, jsonb_build_object('motoristas', v_expiradas));
  end if;

  v_max := interno.regra_num(c.cidade_id, 'matching_max_tentativas', 8);
  v_tempo := interno.regra_num(c.cidade_id, 'matching_tempo_max_segundos', 240);
  if c.tentativas_matching >= v_max or now() - c.busca_iniciada_em > make_interval(secs => v_tempo) then
    update corridas set status = 'SEM_MOTORISTA', versao = versao + 1 where id = p_corrida;
    perform interno.evento(p_corrida, 'SEM_MOTORISTA', c.status, 'SEM_MOTORISTA',
      jsonb_build_object('tentativas', c.tentativas_matching));
    perform interno.notificar(c.passageiro_id, 'CORRIDA', 'Nenhum motorista disponível',
      'Não encontramos motorista agora. Tente novamente em instantes.', jsonb_build_object('corrida', c.id));
    return jsonb_build_object('status', 'SEM_MOTORISTA');
  end if;

  v_raios := coalesce((select regras -> 'matching_raios_km' from cidades where id = c.cidade_id), interno.cfg('matching_raios_km'), '[3,5,8]');
  v_exp := interno.regra_num(c.cidade_id, 'oferta_expira_segundos', 15);

  -- começa no raio da tentativa atual e AMPLIA na hora se não houver ninguém perto
  for v_i in least(c.tentativas_matching, jsonb_array_length(v_raios) - 1) .. jsonb_array_length(v_raios) - 1 loop
    v_raio := (v_raios ->> v_i)::numeric;
    for cand in select * from interno.candidatos(p_corrida, v_raio, 5) loop
      begin
        insert into ofertas (corrida_id, motorista_id, score, componentes, distancia_embarque_km, eta_embarque_min, rentabilidade, expira_em)
        values (p_corrida, cand.motorista_id, cand.score, cand.componentes, cand.distancia_km, cand.eta_min,
                interno.rentabilidade(cand.motorista_id, c.cidade_id, c.categoria, c.preco_estimado,
                                      c.distancia_estimada_km, c.duracao_estimada_min, cand.distancia_km, cand.eta_min),
                now() + make_interval(secs => v_exp))
        returning id into v_oferta;
        exit;
      exception when unique_violation then
        continue;   -- esse motorista recebeu outra oferta no mesmo instante: tenta o próximo
      end;
    end loop;
    exit when v_oferta is not null;
  end loop;

  if v_oferta is null then
    update corridas set status = 'BUSCANDO' where id = p_corrida and status = 'SOLICITADA';
    return jsonb_build_object('status', 'BUSCANDO', 'candidatos', 0, 'raio_km', v_raio);
  end if;

  update corridas set status = 'BUSCANDO', tentativas_matching = tentativas_matching + 1 where id = p_corrida;
  update motoristas set ofertas_recebidas = ofertas_recebidas + 1 where id = cand.motorista_id;
  perform interno.evento(p_corrida, 'OFERTA_ENVIADA', c.status, 'BUSCANDO',
    jsonb_build_object('oferta', v_oferta, 'motorista', cand.motorista_id, 'score', cand.score, 'componentes', cand.componentes, 'raio_km', v_raio));
  perform interno.notificar(cand.motorista_id, 'CORRIDA', 'Nova corrida',
    'R$ ' || to_char(c.preco_estimado, 'FM999990D00') || ' · ' || c.distancia_estimada_km || ' km', jsonb_build_object('oferta', v_oferta));
  return jsonb_build_object('status', 'BUSCANDO', 'oferta', v_oferta, 'motorista', cand.motorista_id);
end $$;

-- job (a cada poucos segundos): vence ofertas e reprocessa corridas buscando
create or replace function interno.job_matching() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n int := 0;
begin
  for r in select id from corridas where status in ('SOLICITADA','BUSCANDO') order by solicitada_em limit 500 loop
    begin
      perform interno.buscar_motorista(r.id);
      n := n + 1;
    exception when others then
      raise warning 'job_matching corrida %: %', r.id, sqlerrm;
    end;
  end loop;
  return n;
end $$;

-- ============================================================
-- RPC — MOTORISTA: online, localização, ofertas
-- ============================================================

create or replace function public.ficar_online(p_lat float8, p_lng float8) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_cats text[]; v_sessao uuid; m motoristas;
begin
  perform interno.limitar('online', 20, 60);
  select * into m from motoristas where id = v_uid;
  v_cats := interno.categorias_liberadas(v_uid);
  if cardinality(v_cats) = 0 then
    perform interno.erro('PENDENCIAS_DE_COMPLIANCE', array_to_string(interno.pendencias_motorista(v_uid), ','));
  end if;
  select sessao_id into v_sessao from motorista_presenca where motorista_id = v_uid and online;
  if v_sessao is null then
    insert into sessoes_online (motorista_id) values (v_uid) returning id into v_sessao;
  end if;
  insert into motorista_presenca as mp (motorista_id, online, disponivel, cidade_id, categorias, lat, lng, atualizado_em, disponivel_desde, sessao_id)
  values (v_uid, true, true, m.cidade_id, v_cats, p_lat, p_lng, now(), now(), v_sessao)
  on conflict (motorista_id) do update set online = true, cidade_id = excluded.cidade_id, categorias = excluded.categorias,
    lat = excluded.lat, lng = excluded.lng, atualizado_em = now(), sessao_id = v_sessao,
    disponivel = not exists (select 1 from corridas where motorista_id = v_uid and status in ('A_CAMINHO','CHEGOU','EM_CURSO')),
    disponivel_desde = case when mp.disponivel then mp.disponivel_desde else now() end;
  return jsonb_build_object('online', true, 'categorias', v_cats);
end $$;

create or replace function public.ficar_offline() returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}');
begin
  update sessoes_online set fim = now()
  where id = (select sessao_id from motorista_presenca where motorista_id = v_uid) and fim is null;
  update motorista_presenca set online = false, disponivel = false, sessao_id = null where motorista_id = v_uid;
  -- oferta em aberto volta para o matching
  update ofertas set status = 'RECUSADA', respondida_em = now() where motorista_id = v_uid and status = 'PENDENTE';
end $$;

create or replace function public.atualizar_localizacao(p_lat float8, p_lng float8, p_rumo float8 default null, p_velocidade_kmh float8 default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); p motorista_presenca; v_kmh float8; v_corrida uuid;
begin
  perform interno.limitar('gps', 120, 60);
  if p_lat not between -90 and 90 or p_lng not between -180 and 180 then perform interno.erro('COORDENADA_INVALIDA'); end if;
  select * into p from motorista_presenca where motorista_id = v_uid;
  if not found or not p.online then perform interno.erro('MOTORISTA_OFFLINE'); end if;

  -- GPS impossível (teletransporte) -> sinal de risco, sem bloquear
  if p.lat is not null and p.atualizado_em is not null and now() > p.atualizado_em then
    v_kmh := interno.distancia_km(p.lat, p.lng, p_lat, p_lng) / greatest(extract(epoch from now() - p.atualizado_em) / 3600, 1.0/3600);
    if v_kmh > 250 and interno.distancia_km(p.lat, p.lng, p_lat, p_lng) > 2 then
      perform interno.registrar_sinal('USUARIO', v_uid::text, 'GPS_INCONSISTENTE', 2,
        jsonb_build_object('de', jsonb_build_array(p.lat, p.lng), 'para', jsonb_build_array(p_lat, p_lng), 'kmh', round(v_kmh::numeric)));
    end if;
  end if;

  update motorista_presenca set lat = p_lat, lng = p_lng, rumo = p_rumo, velocidade_kmh = p_velocidade_kmh, atualizado_em = now()
  where motorista_id = v_uid;

  select id into v_corrida from corridas where motorista_id = v_uid and status = 'EM_CURSO';
  if v_corrida is not null then
    insert into corrida_trilha (corrida_id, lat, lng, velocidade_kmh) values (v_corrida, p_lat, p_lng, p_velocidade_kmh)
    on conflict do nothing;
    perform interno.verificar_anomalias(v_corrida);
  end if;
end $$;

create or replace function public.minha_oferta() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'oferta', o.id, 'expira_em', o.expira_em,
    'segundos_restantes', greatest(0, extract(epoch from o.expira_em - now())::int),
    'corrida', jsonb_build_object('id', c.id, 'categoria', c.categoria,
       'origem', jsonb_build_object('lat', c.origem_lat, 'lng', c.origem_lng, 'endereco', c.origem_endereco),
       'destino', jsonb_build_object('lat', c.destino_lat, 'lng', c.destino_lng, 'endereco', c.destino_endereco),
       'valor', c.preco_estimado, 'distancia_km', c.distancia_estimada_km, 'duracao_min', c.duracao_estimada_min,
       'pagamento', c.metodo_pagamento,
       'passageiro', (select split_part(nome, ' ', 1) from perfis where id = c.passageiro_id),
       'nota_passageiro', (select round(avg(nota), 2) from avaliacoes where avaliado_id = c.passageiro_id)),
    'embarque_km', o.distancia_embarque_km, 'embarque_min', o.eta_embarque_min,
    'rentabilidade', o.rentabilidade)
  from ofertas o join corridas c on c.id = o.corrida_id
  where o.motorista_id = auth.uid() and o.status = 'PENDENTE' and o.expira_em > now()
  limit 1
$$;

create or replace function public.aceitar_oferta(p_oferta uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); o ofertas; c corridas; v_pend text[]; pr motorista_presenca;
begin
  perform interno.limitar('aceitar', 30, 60);
  select corrida_id into c.id from ofertas where id = p_oferta;
  if c.id is null then perform interno.erro('OFERTA_NAO_ENCONTRADA'); end if;

  -- ordem de travas sempre: corrida -> oferta (evita deadlock com cancelamento)
  select * into c from corridas where id = c.id for update;
  select * into o from ofertas where id = p_oferta for update;

  if o.motorista_id <> v_uid then perform interno.erro('SEM_PERMISSAO'); end if;
  if o.status = 'ACEITA' and c.motorista_id = v_uid then
    return jsonb_build_object('ok', true, 'corrida', c.id, 'status', c.status, 'repetido', true);   -- clique duplo
  end if;
  if o.status <> 'PENDENTE' then
    return jsonb_build_object('ok', false, 'erro', 'OFERTA_NAO_DISPONIVEL', 'status_oferta', o.status);
  end if;
  if c.status <> 'BUSCANDO' or c.motorista_id is not null then
    update ofertas set status = 'CANCELADA', respondida_em = now() where id = p_oferta;
    return jsonb_build_object('ok', false, 'erro', 'CORRIDA_INDISPONIVEL', 'status_corrida', c.status);
  end if;
  if o.expira_em < now() then
    update ofertas set status = 'EXPIRADA', respondida_em = now() where id = p_oferta;
    update corridas set motoristas_excluidos = motoristas_excluidos || v_uid where id = c.id;
    perform interno.buscar_motorista(c.id);
    return jsonb_build_object('ok', false, 'erro', 'OFERTA_EXPIRADA');
  end if;

  select * into pr from motorista_presenca where motorista_id = v_uid for update;
  if not coalesce(pr.online, false) or not pr.disponivel then
    update ofertas set status = 'RECUSADA', respondida_em = now() where id = p_oferta;
    update corridas set motoristas_excluidos = motoristas_excluidos || v_uid where id = c.id;
    perform interno.buscar_motorista(c.id);
    return jsonb_build_object('ok', false, 'erro', 'MOTORISTA_INDISPONIVEL');
  end if;

  v_pend := interno.pendencias_motorista(v_uid, c.categoria);
  if cardinality(v_pend) > 0 then
    update ofertas set status = 'RECUSADA', respondida_em = now() where id = p_oferta;
    update corridas set motoristas_excluidos = motoristas_excluidos || v_uid where id = c.id;
    perform interno.buscar_motorista(c.id);
    return jsonb_build_object('ok', false, 'erro', 'PENDENCIAS_DE_COMPLIANCE', 'pendencias', to_jsonb(v_pend));
  end if;

  update corridas set motorista_id = v_uid,
    veiculo_id = (select veiculo_ativo_id from motoristas where id = v_uid),
    status = 'A_CAMINHO', aceita_em = now(), versao = versao + 1
  where id = c.id;
  update ofertas set status = 'ACEITA', respondida_em = now() where id = p_oferta;
  update motoristas set ofertas_aceitas = ofertas_aceitas + 1 where id = v_uid;
  update motorista_presenca set disponivel = false where motorista_id = v_uid;

  perform interno.evento(c.id, 'ACEITE', 'BUSCANDO', 'A_CAMINHO', jsonb_build_object('oferta', p_oferta, 'motorista', v_uid));
  perform interno.evento(c.id, 'DESLOCAMENTO', 'A_CAMINHO', 'A_CAMINHO', jsonb_build_object('eta_min', o.eta_embarque_min));
  perform interno.notificar(c.passageiro_id, 'MOTORISTA_A_CAMINHO', 'Motorista a caminho',
    (select split_part(p.nome, ' ', 1) || ' · ' || v.modelo || ' ' || v.cor || ' · ' || v.placa
     from perfis p join motoristas m on m.id = p.id join veiculos v on v.id = m.veiculo_ativo_id where p.id = v_uid),
    jsonb_build_object('corrida', c.id));
  return jsonb_build_object('ok', true, 'corrida', c.id, 'status', 'A_CAMINHO');
end $$;

create or replace function public.recusar_oferta(p_oferta uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); o ofertas; v_corrida uuid;
begin
  select corrida_id into v_corrida from ofertas where id = p_oferta and motorista_id = v_uid;
  if v_corrida is null then perform interno.erro('OFERTA_NAO_ENCONTRADA'); end if;
  perform 1 from corridas where id = v_corrida for update;
  select * into o from ofertas where id = p_oferta for update;
  if o.status <> 'PENDENTE' then return jsonb_build_object('ok', true, 'status_oferta', o.status); end if;
  update ofertas set status = 'RECUSADA', respondida_em = now() where id = p_oferta;
  update corridas set motoristas_excluidos = motoristas_excluidos || v_uid where id = v_corrida;
  perform interno.evento(v_corrida, 'OFERTA_RECUSADA', null, null, jsonb_build_object('motorista', v_uid));
  perform interno.buscar_motorista(v_corrida);   -- já procura o próximo
  return jsonb_build_object('ok', true);
end $$;

-- ============================================================
-- RPC — PASSAGEIRO: estimar e pedir
-- ============================================================

create or replace function public.estimar_corrida(p_cidade uuid, p_o_lat float8, p_o_lng float8, p_d_lat float8, p_d_lng float8,
  p_rota_km numeric default null, p_rota_min numeric default null)
returns jsonb language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare r record; v_vel numeric := interno.cfg_num('velocidade_media_kmh', 25); v_out jsonb := '[]';
        v_eta numeric; v_cid cidades;
begin
  select * into v_cid from cidades where id = p_cidade and ativa;
  if not found then perform interno.erro('CIDADE_NAO_ATENDIDA'); end if;
  if interno.distancia_km(v_cid.centro_lat, v_cid.centro_lng, p_o_lat, p_o_lng) > v_cid.raio_atendimento_km then
    perform interno.erro('FORA_DA_AREA_DE_ATENDIMENTO');
  end if;
  select * into r from interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  for r in
    select cc.categoria, cat.nome, cat.descricao, cat.capacidade_padrao, cat.ordem, s.km, s.minutos,
           interno.calcular_preco(p_cidade, cc.categoria, s.km, s.minutos) as preco
    from cidade_categorias cc
    join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
    cross join interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min) s
    where cc.cidade_id = p_cidade and cc.habilitada
    order by cat.ordem
  loop
    select round(min(interno.distancia_km(p.lat, p.lng, p_o_lat, p_o_lng))::numeric * interno.cfg_num('fator_rota', 1.3) / v_vel * 60, 0)
      into v_eta
    from motorista_presenca p
    where p.online and p.disponivel and p.cidade_id = p_cidade and r.categoria = any(p.categorias)
      and p.atualizado_em > now() - interval '2 minutes'
      and p.lat between p_o_lat - 0.11 and p_o_lat + 0.11 and p.lng between p_o_lng - 0.12 and p_o_lng + 0.12;
    v_out := v_out || jsonb_build_object('categoria', r.categoria, 'nome', r.nome, 'descricao', r.descricao,
      'capacidade', r.capacidade_padrao, 'preco', r.preco, 'distancia_km', r.km, 'duracao_min', r.minutos,
      'chegada_min', greatest(v_eta, 1), 'disponivel', v_eta is not null);
  end loop;
  return v_out;
end $$;

create or replace function public.solicitar_corrida(
  p_chave_idempotencia text, p_cidade uuid, p_categoria text,
  p_o_lat float8, p_o_lng float8, p_o_endereco text,
  p_d_lat float8, p_d_lng float8, p_d_endereco text,
  p_metodo metodo_pagamento, p_rota_km numeric default null, p_rota_min numeric default null,
  p_passageiros int default 1)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_rota record; v_preco numeric; pf perfis; v_match jsonb;
begin
  if coalesce(length(p_chave_idempotencia), 0) < 8 then perform interno.erro('CHAVE_IDEMPOTENCIA_OBRIGATORIA'); end if;

  -- mesmo pedido repetido (internet caiu, clique duplo): devolve a mesma corrida
  select * into c from corridas where passageiro_id = v_uid and chave_idempotencia = p_chave_idempotencia;
  if found then return jsonb_build_object('corrida', c.id, 'status', c.status, 'repetido', true); end if;

  perform interno.limitar('solicitar', 6, 60);
  select * into pf from perfis where id = v_uid;
  if not found then perform interno.erro('CADASTRO_INCOMPLETO'); end if;
  if pf.status <> 'ATIVO' then perform interno.erro('CONTA_' || pf.status::text); end if;
  if not exists (select 1 from cidade_categorias cc join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
                 where cc.cidade_id = p_cidade and cc.categoria = p_categoria and cc.habilitada) then
    perform interno.erro('CATEGORIA_INDISPONIVEL');
  end if;
  if exists (select 1 from corridas where passageiro_id = v_uid and status in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU','EM_CURSO')) then
    perform interno.erro('JA_EXISTE_CORRIDA_ATIVA');
  end if;
  -- corrida anterior sem pagar (PIX pendente há muito tempo ou cobrança que falhou): paga antes de pedir outra
  if exists (select 1 from pagamentos pg where pg.pagador_id = v_uid and pg.tipo in ('CORRIDA','TAXA_CANCELAMENTO')
             and ((pg.status = 'PENDENTE' and pg.criado_em < now() - make_interval(mins => interno.cfg_num('divida_bloqueio_minutos', 30)::int))
               or (pg.status = 'FALHOU' and not exists (select 1 from pagamentos p2 where p2.corrida_id = pg.corrida_id and p2.tipo = pg.tipo
                                                         and p2.status in ('PENDENTE','CONFIRMADO','AUTORIZADO'))))) then
    perform interno.erro('PAGAMENTO_EM_ABERTO');
  end if;
  if p_metodo = 'DINHEIRO' and not coalesce((select (regras ->> 'aceita_dinheiro')::boolean from cidades where id = p_cidade), false) then
    perform interno.erro('DINHEIRO_NAO_PERMITIDO_NA_CIDADE');
  end if;
  if p_passageiros not between 1 and 8 then perform interno.erro('PASSAGEIROS_INVALIDO'); end if;

  -- valida área (mesma regra da estimativa)
  perform public.estimar_corrida(p_cidade, p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);

  select * into v_rota from interno.rota_saneada(p_o_lat, p_o_lng, p_d_lat, p_d_lng, p_rota_km, p_rota_min);
  if v_rota.km < 0.3 then perform interno.erro('DESTINO_MUITO_PROXIMO'); end if;
  v_preco := interno.calcular_preco(p_cidade, p_categoria, v_rota.km, v_rota.minutos);

  begin
    insert into corridas (chave_idempotencia, passageiro_id, cidade_id, categoria, passageiros,
      origem_lat, origem_lng, origem_endereco, destino_lat, destino_lng, destino_endereco,
      distancia_estimada_km, duracao_estimada_min, preco_estimado, metodo_pagamento)
    values (p_chave_idempotencia, v_uid, p_cidade, p_categoria, p_passageiros,
      p_o_lat, p_o_lng, left(p_o_endereco, 300), p_d_lat, p_d_lng, left(p_d_endereco, 300),
      v_rota.km, v_rota.minutos, v_preco, p_metodo)
    returning * into c;
    insert into corrida_segredos (corrida_id, pin) values (c.id, lpad((floor(random() * 10000))::int::text, 4, '0'));
  exception when unique_violation then
    -- corrida simultânea do mesmo passageiro: o índice único segura
    select * into c from corridas where passageiro_id = v_uid and chave_idempotencia = p_chave_idempotencia;
    if found then return jsonb_build_object('corrida', c.id, 'status', c.status, 'repetido', true); end if;
    perform interno.erro('JA_EXISTE_CORRIDA_ATIVA');
  end;

  perform interno.evento(c.id, 'SOLICITACAO', null, 'SOLICITADA',
    jsonb_build_object('preco', v_preco, 'km', v_rota.km, 'min', v_rota.minutos, 'categoria', p_categoria, 'metodo', p_metodo));
  v_match := interno.buscar_motorista(c.id);
  return jsonb_build_object('corrida', c.id, 'status', v_match ->> 'status', 'preco_estimado', v_preco,
    'pin', (select pin from corrida_segredos where corrida_id = c.id));
end $$;

-- o app do passageiro chama a cada poucos segundos; também empurra o matching
create or replace function public.acompanhar_corrida(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_mot jsonb; pr motorista_presenca;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (c.passageiro_id <> v_uid and c.motorista_id is distinct from v_uid and not interno.eh_staff()) then
    perform interno.erro('CORRIDA_NAO_ENCONTRADA');
  end if;
  if c.status in ('SOLICITADA','BUSCANDO') then
    perform interno.buscar_motorista(p_corrida);
    select * into c from corridas where id = p_corrida;
  end if;
  if c.motorista_id is not null then
    select * into pr from motorista_presenca where motorista_id = c.motorista_id;
    select jsonb_build_object('nome', split_part(p.nome, ' ', 1), 'foto', p.foto_path, 'nota', m.avaliacao_media,
             'veiculo', jsonb_build_object('modelo', v.marca || ' ' || v.modelo, 'cor', v.cor, 'placa', v.placa),
             'lat', case when c.status in ('A_CAMINHO','CHEGOU','EM_CURSO') then pr.lat end,
             'lng', case when c.status in ('A_CAMINHO','CHEGOU','EM_CURSO') then pr.lng end,
             'rumo', pr.rumo,
             'eta_min', case when c.status = 'A_CAMINHO' and pr.lat is not null then
                round((interno.distancia_km(pr.lat, pr.lng, c.origem_lat, c.origem_lng) * interno.cfg_num('fator_rota', 1.3)
                      / interno.cfg_num('velocidade_media_kmh', 25) * 60)::numeric, 0) end)
      into v_mot
    from perfis p join motoristas m on m.id = p.id left join veiculos v on v.id = c.veiculo_id
    where p.id = c.motorista_id;
  end if;
  return jsonb_build_object(
    'id', c.id, 'status', c.status, 'categoria', c.categoria,
    'origem', jsonb_build_object('lat', c.origem_lat, 'lng', c.origem_lng, 'endereco', c.origem_endereco),
    'destino', jsonb_build_object('lat', c.destino_lat, 'lng', c.destino_lng, 'endereco', c.destino_endereco),
    'preco_estimado', c.preco_estimado, 'preco_final', c.preco_final, 'metodo', c.metodo_pagamento,
    'pin', case when v_uid = c.passageiro_id then (select pin from corrida_segredos where corrida_id = c.id) end,
    'motorista', v_mot,
    'passageiro', case when v_uid = c.motorista_id then
        (select jsonb_build_object('nome', split_part(nome, ' ', 1)) from perfis where id = c.passageiro_id) end,
    'cancelado_por', c.cancelado_por, 'taxa_cancelamento', c.taxa_cancelamento,
    'verificacao', (select jsonb_build_object('id', id, 'mensagem', mensagem) from verificacoes_seguranca
                    where corrida_id = c.id and status = 'AGUARDANDO' order by criada_em desc limit 1),
    'pagamento', (select jsonb_build_object('id', id, 'status', status, 'valor', valor) from pagamentos
                  where corrida_id = c.id and tipo = 'CORRIDA' order by criado_em desc limit 1),
    'avaliou', exists (select 1 from avaliacoes where corrida_id = c.id and avaliador_id = v_uid)
  );
end $$;

-- ============================================================
-- RPC — CICLO DA CORRIDA (motorista)
-- ============================================================

create or replace function interno.travar_corrida_motorista(p_corrida uuid, p_uid uuid, p_status status_corrida[])
returns corridas language plpgsql as $$
declare c corridas;
begin
  select * into c from corridas where id = p_corrida for update;
  if not found or c.motorista_id is distinct from p_uid then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if not (c.status = any(p_status)) then perform interno.erro('STATUS_INVALIDO', c.status::text); end if;
  return c;
end $$;

create or replace function public.cheguei(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); c corridas; v_dist numeric;
begin
  select * into c from corridas where id = p_corrida and motorista_id = v_uid;
  if c.status = 'CHEGOU' then return jsonb_build_object('status', 'CHEGOU', 'repetido', true); end if;
  c := interno.travar_corrida_motorista(p_corrida, v_uid, '{A_CAMINHO}');
  select round(interno.distancia_km(lat, lng, c.origem_lat, c.origem_lng)::numeric * 1000) into v_dist
  from motorista_presenca where motorista_id = v_uid and atualizado_em > now() - interval '90 seconds';
  -- "cheguei" de longe abriria caminho para cobrar taxa de não comparecimento sem ir ao local
  if v_dist is null then perform interno.erro('GPS_DESATUALIZADO'); end if;
  if v_dist > interno.regra_num(c.cidade_id, 'chegada_raio_m', 300) then
    perform interno.erro('LONGE_DO_EMBARQUE', v_dist || ' m');
  end if;
  update corridas set status = 'CHEGOU', chegou_em = now(), versao = versao + 1 where id = p_corrida;
  perform interno.evento(p_corrida, 'CHEGADA', 'A_CAMINHO', 'CHEGOU', jsonb_build_object('distancia_embarque_m', v_dist));
  perform interno.notificar(c.passageiro_id, 'MOTORISTA_CHEGOU', 'Seu motorista chegou',
    'Confira a placa antes de entrar. Seu PIN é ' || (select pin from corrida_segredos where corrida_id = c.id) || '.', jsonb_build_object('corrida', c.id));
  return jsonb_build_object('status', 'CHEGOU', 'distancia_embarque_m', v_dist);
end $$;

create or replace function public.iniciar_corrida(p_corrida uuid, p_pin text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); c corridas; v_max int := interno.cfg_num('pin_max_tentativas', 5);
        sg corrida_segredos;
begin
  select * into c from corridas where id = p_corrida and motorista_id = v_uid;
  if c.status = 'EM_CURSO' then return jsonb_build_object('ok', true, 'status', 'EM_CURSO', 'repetido', true); end if;
  c := interno.travar_corrida_motorista(p_corrida, v_uid, '{CHEGOU}');
  select * into sg from corrida_segredos where corrida_id = p_corrida for update;
  if sg.pin_tentativas >= v_max then return jsonb_build_object('ok', false, 'erro', 'PIN_BLOQUEADO'); end if;
  if coalesce(p_pin, '') <> sg.pin then
    update corrida_segredos set pin_tentativas = pin_tentativas + 1 where corrida_id = p_corrida;
    perform interno.evento(p_corrida, 'PIN_INCORRETO', 'CHEGOU', 'CHEGOU', jsonb_build_object('tentativa', sg.pin_tentativas + 1));
    if sg.pin_tentativas + 1 >= v_max then
      perform interno.registrar_sinal('CORRIDA', p_corrida::text, 'PIN_TENTATIVAS', 3, jsonb_build_object('motorista', v_uid));
      perform interno.notificar(c.passageiro_id, 'SEGURANCA', 'Atenção ao embarque',
        'O PIN foi digitado errado várias vezes. Só entre no carro se a placa e o motorista conferirem.', jsonb_build_object('corrida', c.id));
    end if;
    return jsonb_build_object('ok', false, 'erro', 'PIN_INCORRETO', 'restantes', v_max - sg.pin_tentativas - 1);
  end if;
  update corridas set status = 'EM_CURSO', iniciada_em = now(), versao = versao + 1 where id = p_corrida;
  perform interno.evento(p_corrida, 'EMBARQUE', 'CHEGOU', 'EM_CURSO', '{}');
  return jsonb_build_object('ok', true, 'status', 'EM_CURSO');
end $$;

create or replace function public.finalizar_corrida(p_corrida uuid, p_km_app numeric default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); c corridas; v_km numeric; v_min numeric; v_trilha numeric;
        v_recalc numeric; v_final numeric; v_tol numeric; v_pag jsonb; pr motorista_presenca; v_teto numeric;
begin
  select * into c from corridas where id = p_corrida and motorista_id = v_uid;
  if c.status in ('FINALIZADA','PAGA') then
    return jsonb_build_object('status', c.status, 'preco_final', c.preco_final, 'repetido', true);
  end if;
  c := interno.travar_corrida_motorista(p_corrida, v_uid, '{EM_CURSO}');

  -- distância: SÓ a trilha GPS gravada no servidor (o valor do app fica só registrado).
  -- Trechos com velocidade impossível são ignorados e o total tem teto (anti GPS falso).
  select sum(d) into v_trilha from (
    select interno.distancia_km(lat, lng, prev_lat, prev_lng) as d,
           extract(epoch from registrado_em - prev_em) as seg
    from (select lat, lng, registrado_em, lag(lat) over w prev_lat, lag(lng) over w prev_lng, lag(registrado_em) over w prev_em
          from corrida_trilha where corrida_id = p_corrida window w as (order by registrado_em)) t
    where prev_lat is not null) x
  where x.d / greatest(x.seg / 3600, 1.0/3600) <= interno.cfg_num('velocidade_max_kmh', 150);
  select * into pr from motorista_presenca where motorista_id = v_uid;
  v_teto := c.distancia_estimada_km * interno.regra_num(c.cidade_id, 'teto_km_fator', 2);
  if v_trilha > v_teto then
    perform interno.registrar_sinal('CORRIDA', p_corrida::text, 'DISTANCIA_ACIMA_DO_TETO', 4,
      jsonb_build_object('trilha_km', round(v_trilha::numeric, 2), 'estimado_km', c.distancia_estimada_km, 'km_app', p_km_app));
    v_km := c.distancia_estimada_km;   -- cobra o estimado; o valor fica retido para análise (sinal severidade 4)
  else
    v_km := coalesce(nullif(round(v_trilha::numeric, 2), 0), c.distancia_estimada_km);
  end if;
  v_min := greatest(round((extract(epoch from now() - c.iniciada_em) / 60)::numeric, 1), 1);   -- relógio do servidor

  -- preço previsível: passageiro paga o estimado, salvo diferença real acima da tolerância
  v_recalc := interno.calcular_preco(c.cidade_id, c.categoria, v_km, v_min, c.multiplicador);
  v_tol := interno.regra_num(c.cidade_id, 'tolerancia_preco_pct', 20) / 100;
  v_final := case when v_recalc > c.preco_estimado * (1 + v_tol) then v_recalc else c.preco_estimado end;

  -- longe do destino ao finalizar? registra (não impede)
  if pr.lat is not null and interno.distancia_km(pr.lat, pr.lng, c.destino_lat, c.destino_lng) > 1 then
    perform interno.evento(p_corrida, 'FINALIZADA_LONGE_DO_DESTINO', 'EM_CURSO', 'EM_CURSO',
      jsonb_build_object('km_do_destino', round(interno.distancia_km(pr.lat, pr.lng, c.destino_lat, c.destino_lng)::numeric, 2)));
  end if;

  update corridas set status = 'FINALIZADA', finalizada_em = now(), distancia_real_km = v_km, duracao_real_min = v_min,
    preco_final = v_final, versao = versao + 1 where id = p_corrida;
  update motoristas set total_corridas = total_corridas + 1 where id = v_uid;
  update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = v_uid;

  perform interno.evento(p_corrida, 'FINALIZACAO', 'EM_CURSO', 'FINALIZADA',
    jsonb_build_object('km', v_km, 'min', v_min, 'preco_recalculado', v_recalc, 'preco_final', v_final, 'fonte_km',
      case when v_trilha > v_teto then 'ESTIMATIVA_TETO' when v_trilha > 0 then 'TRILHA' else 'ESTIMATIVA' end, 'km_app', p_km_app));

  v_pag := interno.cobrar_corrida(p_corrida);
  return jsonb_build_object('status', 'FINALIZADA', 'preco_final', v_final, 'pagamento', v_pag);
end $$;

-- ============================================================
-- CANCELAMENTO + REMATCHING AUTOMÁTICO
-- ============================================================
create or replace function public.cancelar_corrida(p_corrida uuid, p_motivo text default null) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_quem text; v_taxa numeric := 0; v_espera int;
        v_motorista uuid;
begin
  perform interno.limitar('cancelar', 10, 60);
  select * into c from corridas where id = p_corrida for update;
  if not found then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if c.status = 'CANCELADA' then return jsonb_build_object('status', 'CANCELADA', 'repetido', true); end if;

  if v_uid = c.passageiro_id then v_quem := 'PASSAGEIRO';
  elsif v_uid = c.motorista_id then v_quem := 'MOTORISTA';
  elsif interno.eh_staff() then v_quem := 'SUPORTE';
  else perform interno.erro('CORRIDA_NAO_ENCONTRADA');
  end if;

  update ofertas set status = 'CANCELADA', respondida_em = now() where corrida_id = p_corrida and status = 'PENDENTE';

  -- ---------- MOTORISTA cancela: corrida volta para a busca (rematching) ----------
  if v_quem = 'MOTORISTA' then
    if c.status not in ('A_CAMINHO','CHEGOU') then perform interno.erro('STATUS_INVALIDO', c.status::text); end if;

    -- passageiro não apareceu: espera mínima cumprida -> cancelamento por culpa do passageiro
    v_espera := interno.regra_num(c.cidade_id, 'espera_embarque_seg', 300);
    if p_motivo = 'PASSAGEIRO_NAO_APARECEU' and c.status = 'CHEGOU' and now() - c.chegou_em >= make_interval(secs => v_espera) then
      select taxa_cancelamento into v_taxa from cidade_categorias where cidade_id = c.cidade_id and categoria = c.categoria;
      update corridas set status = 'CANCELADA', cancelado_por = 'PASSAGEIRO', motivo_cancelamento = p_motivo,
        taxa_cancelamento = nullif(v_taxa, 0), cancelada_em = now(), versao = versao + 1 where id = p_corrida;
      update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = v_uid;
      perform interno.evento(p_corrida, 'CANCELAMENTO_NAO_COMPARECEU', c.status, 'CANCELADA', jsonb_build_object('taxa', v_taxa));
      if v_taxa > 0 then perform interno.cobrar_taxa_cancelamento(p_corrida); end if;
      perform interno.notificar(c.passageiro_id, 'CANCELAMENTO', 'Corrida cancelada', 'O motorista esperou e você não apareceu.', jsonb_build_object('corrida', c.id));
      return jsonb_build_object('status', 'CANCELADA', 'taxa', v_taxa);
    end if;

    update corridas set status = 'BUSCANDO', motorista_id = null, veiculo_id = null, aceita_em = null, chegou_em = null,
      motoristas_excluidos = motoristas_excluidos || v_uid, busca_iniciada_em = now(), tentativas_matching = 0, versao = versao + 1
    where id = p_corrida;
    update motoristas set total_cancelamentos = total_cancelamentos + 1 where id = v_uid;
    update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = v_uid;
    perform interno.evento(p_corrida, 'CANCELAMENTO_MOTORISTA', c.status, 'BUSCANDO', jsonb_build_object('motorista', v_uid, 'motivo', p_motivo));
    perform interno.evento(p_corrida, 'REMATCHING', 'BUSCANDO', 'BUSCANDO', '{}');
    perform interno.notificar(c.passageiro_id, 'CANCELAMENTO', 'Buscando outro motorista',
      'O motorista cancelou. Já estamos procurando outro para você, sem custo.', jsonb_build_object('corrida', c.id));
    perform interno.buscar_motorista(p_corrida);
    return jsonb_build_object('status', 'BUSCANDO', 'rematching', true);
  end if;

  -- ---------- PASSAGEIRO ou SUPORTE cancela ----------
  if c.status not in ('SOLICITADA','BUSCANDO','A_CAMINHO','CHEGOU') and v_quem = 'PASSAGEIRO' then
    perform interno.erro('STATUS_INVALIDO', c.status::text);
  end if;
  if c.status in ('FINALIZADA','PAGA','SEM_MOTORISTA') then perform interno.erro('STATUS_INVALIDO', c.status::text); end if;

  if v_quem = 'PASSAGEIRO' and c.status in ('A_CAMINHO','CHEGOU')
     and now() - c.aceita_em > make_interval(secs => interno.regra_num(c.cidade_id, 'carencia_cancelamento_seg', 120)) then
    -- só cobra se o motorista chegou ou se aproximou de verdade (não paga taxa por motorista parado)
    if c.status = 'CHEGOU' or exists (
         select 1 from motorista_presenca mp, ofertas o
         where mp.motorista_id = c.motorista_id and o.corrida_id = c.id and o.motorista_id = c.motorista_id and o.status = 'ACEITA'
           and mp.atualizado_em > now() - interval '2 minutes'
           and interno.distancia_km(mp.lat, mp.lng, c.origem_lat, c.origem_lng) < o.distancia_embarque_km * 0.8) then
      select taxa_cancelamento into v_taxa from cidade_categorias where cidade_id = c.cidade_id and categoria = c.categoria;
    else
      perform interno.evento(p_corrida, 'TAXA_DISPENSADA', c.status, c.status, jsonb_build_object('motivo', 'motorista não se aproximou'));
    end if;
  end if;

  v_motorista := c.motorista_id;
  update corridas set status = 'CANCELADA', cancelado_por = v_quem, motivo_cancelamento = p_motivo,
    taxa_cancelamento = nullif(v_taxa, 0), cancelada_em = now(), versao = versao + 1 where id = p_corrida;
  if v_motorista is not null then
    update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = v_motorista;
    perform interno.notificar(v_motorista, 'CANCELAMENTO', 'Corrida cancelada',
      'O passageiro cancelou.' || case when v_taxa > 0 then ' Você recebe a taxa de cancelamento.' else '' end, jsonb_build_object('corrida', c.id));
  end if;
  perform interno.evento(p_corrida, 'CANCELAMENTO_' || v_quem, c.status, 'CANCELADA', jsonb_build_object('motivo', p_motivo, 'taxa', v_taxa));
  if v_taxa > 0 then perform interno.cobrar_taxa_cancelamento(p_corrida); end if;
  return jsonb_build_object('status', 'CANCELADA', 'taxa', v_taxa);
end $$;

-- ============================================================
-- AVALIAÇÃO
-- ============================================================
create or replace function public.avaliar_corrida(p_corrida uuid, p_nota int, p_comentario text default null, p_tags text[] default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_avaliado uuid; v_papel text;
begin
  select * into c from corridas where id = p_corrida;
  if not found then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if c.status not in ('FINALIZADA','PAGA') then perform interno.erro('STATUS_INVALIDO'); end if;
  if c.finalizada_em < now() - interval '7 days' then perform interno.erro('PRAZO_AVALIACAO_ENCERRADO'); end if;
  if v_uid = c.passageiro_id then v_avaliado := c.motorista_id; v_papel := 'PASSAGEIRO';
  elsif v_uid = c.motorista_id then v_avaliado := c.passageiro_id; v_papel := 'MOTORISTA';
  else perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;

  insert into avaliacoes (corrida_id, avaliador_id, avaliado_id, papel_avaliador, nota, comentario, tags)
  values (p_corrida, v_uid, v_avaliado, v_papel, p_nota, left(p_comentario, 500), p_tags)
  on conflict (corrida_id, avaliador_id) do nothing;
  if not found then perform interno.erro('JA_AVALIADA'); end if;

  if v_papel = 'PASSAGEIRO' then
    update motoristas set
      avaliacao_media = round(((avaliacao_media * total_avaliacoes) + p_nota)::numeric / (total_avaliacoes + 1), 2),
      total_avaliacoes = total_avaliacoes + 1
    where id = v_avaliado;
  end if;
  perform interno.evento(p_corrida, 'AVALIACAO', c.status, c.status, jsonb_build_object('papel', v_papel, 'nota', p_nota));
  if p_nota <= 2 and p_comentario is not null then
    insert into incidentes (corrida_id, reportado_por, tipo, gravidade, descricao)
    values (p_corrida, v_uid, 'OUTRO', 'BAIXA', 'Avaliação baixa: ' || left(p_comentario, 500));
  end if;
end $$;

-- ============================================================
-- SEGURANÇA
-- ============================================================

create or replace function public.compartilhar_corrida(p_corrida uuid) returns text
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_token text;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (c.passageiro_id <> v_uid and c.motorista_id is distinct from v_uid) then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  v_token := interno.token();
  insert into corrida_compartilhamentos (token, corrida_id, criado_por, expira_em) values (v_token, p_corrida, v_uid, now() + interval '6 hours');
  return v_token;
end $$;

-- pública (sem login): quem recebeu o link acompanha a viagem, com dados mínimos
create or replace function public.ver_corrida_compartilhada(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare s corrida_compartilhamentos; c corridas; pr motorista_presenca;
begin
  select * into s from corrida_compartilhamentos where token = p_token and expira_em > now();
  if not found then return null; end if;
  select * into c from corridas where id = s.corrida_id;
  select * into pr from motorista_presenca where motorista_id = c.motorista_id;
  return jsonb_build_object('status', c.status,
    'passageiro', (select split_part(nome, ' ', 1) from perfis where id = c.passageiro_id),
    'motorista', (select split_part(nome, ' ', 1) from perfis where id = c.motorista_id),
    'veiculo', (select jsonb_build_object('modelo', marca || ' ' || modelo, 'cor', cor, 'placa', placa) from veiculos where id = c.veiculo_id),
    'destino', c.destino_endereco,
    'posicao', case when c.status in ('A_CAMINHO','CHEGOU','EM_CURSO') then jsonb_build_object('lat', pr.lat, 'lng', pr.lng, 'em', pr.atualizado_em) end);
end $$;

create or replace function public.acionar_emergencia(p_corrida uuid, p_lat float8 default null, p_lng float8 default null, p_descricao text default null)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; v_id uuid; r record; v_token text;
begin
  select * into c from corridas where id = p_corrida;
  if not found or (c.passageiro_id <> v_uid and c.motorista_id is distinct from v_uid) then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  insert into incidentes (corrida_id, reportado_por, tipo, gravidade, descricao, lat, lng)
  values (p_corrida, v_uid, 'EMERGENCIA', 'CRITICA', p_descricao, p_lat, p_lng) returning id into v_id;
  perform interno.evento(p_corrida, 'EMERGENCIA', c.status, c.status, jsonb_build_object('incidente', v_id, 'lat', p_lat, 'lng', p_lng));
  v_token := public.compartilhar_corrida(p_corrida);
  for r in select nome, telefone from contatos_confianca where usuario_id = v_uid loop
    perform interno.notificar(v_uid, 'SEGURANCA', 'Emergência acionada',
      'Alerta enviado para ' || r.nome, jsonb_build_object('para_telefone', r.telefone, 'link_token', v_token), '{SMS}');
  end loop;
  -- avisa toda a equipe de suporte
  for r in select usuario_id from usuario_papeis where papel = 'SUPORTE' and ativo loop
    perform interno.notificar(r.usuario_id, 'SEGURANCA', 'EMERGÊNCIA EM CORRIDA', 'Corrida ' || p_corrida, jsonb_build_object('incidente', v_id), '{PUSH,IN_APP}');
  end loop;
  return v_id;
end $$;

create or replace function public.registrar_denuncia(p_corrida uuid, p_tipo text, p_descricao text) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid;
begin
  perform interno.limitar('denuncia', 10, 3600);
  if p_corrida is not null and not exists (select 1 from corridas where id = p_corrida and (passageiro_id = v_uid or motorista_id = v_uid)) then
    perform interno.erro('CORRIDA_NAO_ENCONTRADA');
  end if;
  insert into incidentes (corrida_id, reportado_por, tipo, gravidade, descricao)
  values (p_corrida, v_uid, coalesce(p_tipo, 'DENUNCIA'),
          case when p_tipo in ('ASSEDIO','ACIDENTE') then 'ALTA' else 'MEDIA' end, left(p_descricao, 2000))
  returning id into v_id;
  return v_id;
end $$;

-- detecção de anomalias: PERGUNTA, não presume perigo
create or replace function interno.verificar_anomalias(p_corrida uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; v_ult corrida_trilha; v_parado boolean; v_desvio numeric; v_limite numeric; v_od numeric; v_tipo text; v_dados jsonb;
begin
  select * into c from corridas where id = p_corrida;
  if c.status <> 'EM_CURSO' then return; end if;
  select * into v_ult from corrida_trilha where corrida_id = p_corrida order by registrado_em desc limit 1;
  v_od := interno.distancia_km(c.origem_lat, c.origem_lng, c.destino_lat, c.destino_lng);

  -- duração anormal
  if now() - c.iniciada_em > make_interval(mins => (c.duracao_estimada_min * interno.cfg_num('seguranca_fator_duracao', 2))::int + 5) then
    v_tipo := 'DURACAO'; v_dados := jsonb_build_object('estimado_min', c.duracao_estimada_min,
      'decorrido_min', round((extract(epoch from now() - c.iniciada_em) / 60)::numeric));
  end if;

  -- parada inesperada: todos os pontos dos últimos N minutos a menos de 100 m e longe do destino
  if v_tipo is null and v_ult.lat is not null
     and interno.distancia_km(v_ult.lat, v_ult.lng, c.destino_lat, c.destino_lng) > 0.5 then
    select count(*) >= 3 and bool_and(interno.distancia_km(t.lat, t.lng, v_ult.lat, v_ult.lng) < 0.1)
      into v_parado
    from corrida_trilha t
    where t.corrida_id = p_corrida and t.registrado_em > now() - make_interval(mins => interno.cfg_num('seguranca_parada_minutos', 6)::int);
    if v_parado and exists (select 1 from corrida_trilha where corrida_id = p_corrida
                            and registrado_em <= now() - make_interval(mins => interno.cfg_num('seguranca_parada_minutos', 6)::int)) then
      v_tipo := 'PARADA'; v_dados := jsonb_build_object('lat', v_ult.lat, 'lng', v_ult.lng);
    end if;
  end if;

  -- desvio: o ponto atual "aumenta" muito o caminho origem -> destino
  if v_tipo is null and v_ult.lat is not null then
    v_desvio := interno.distancia_km(c.origem_lat, c.origem_lng, v_ult.lat, v_ult.lng)
              + interno.distancia_km(v_ult.lat, v_ult.lng, c.destino_lat, c.destino_lng) - v_od;
    v_limite := greatest(interno.cfg_num('seguranca_desvio_km', 2), v_od * 0.5);
    if v_desvio > v_limite then
      v_tipo := 'DESVIO'; v_dados := jsonb_build_object('desvio_km', round(v_desvio::numeric, 2), 'lat', v_ult.lat, 'lng', v_ult.lng);
    end if;
  end if;

  if v_tipo is not null then
    begin
      insert into verificacoes_seguranca (corrida_id, tipo, dados) values (p_corrida, v_tipo, v_dados);
      perform interno.evento(p_corrida, 'VERIFICACAO_SEGURANCA', 'EM_CURSO', 'EM_CURSO', jsonb_build_object('tipo', v_tipo) || v_dados);
      perform interno.notificar(c.passageiro_id, 'SEGURANCA', 'Está tudo bem?',
        'Detectamos uma alteração inesperada. Está tudo bem?', jsonb_build_object('corrida', c.id, 'tipo', v_tipo));
    exception when unique_violation then null;   -- já existe pergunta aberta desse tipo
    end;
  end if;
end $$;

create or replace function public.responder_verificacao(p_verificacao uuid, p_tudo_bem boolean) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v verificacoes_seguranca; c corridas;
begin
  select * into v from verificacoes_seguranca where id = p_verificacao for update;
  select * into c from corridas where id = v.corrida_id;
  -- só o passageiro responde: o motorista não pode dizer "tudo bem" por ele
  if not found or c.passageiro_id <> v_uid then perform interno.erro('NAO_ENCONTRADO'); end if;
  if v.status <> 'AGUARDANDO' then return; end if;
  update verificacoes_seguranca set status = case when p_tudo_bem then 'TUDO_BEM' else 'PRECISA_AJUDA' end,
    respondido_por = v_uid, respondida_em = now() where id = p_verificacao;
  if not p_tudo_bem then
    perform public.acionar_emergencia(v.corrida_id, (v.dados ->> 'lat')::float8, (v.dados ->> 'lng')::float8, 'Pediu ajuda após verificação: ' || v.tipo);
  end if;
end $$;

-- job: corridas que ficaram paradas num estado (ex.: app do motorista morreu)
create or replace function interno.job_corridas_travadas() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n int := 0;
begin
  -- A CAMINHO sem GPS do motorista há 5 min: volta para a busca, sem custo ao passageiro
  for r in select c.* from corridas c join motorista_presenca p on p.motorista_id = c.motorista_id
           where c.status = 'A_CAMINHO' and greatest(coalesce(p.atualizado_em, c.aceita_em), c.aceita_em) < now() - interval '5 minutes'
           for update of c skip locked loop
    update corridas set status = 'BUSCANDO', motorista_id = null, veiculo_id = null, aceita_em = null,
      motoristas_excluidos = motoristas_excluidos || r.motorista_id, busca_iniciada_em = now(), tentativas_matching = 0, versao = versao + 1
    where id = r.id;
    update motorista_presenca set disponivel = false, online = false where motorista_id = r.motorista_id;
    update motoristas set total_cancelamentos = total_cancelamentos + 1 where id = r.motorista_id;
    perform interno.evento(r.id, 'REMATCHING_SISTEMA', 'A_CAMINHO', 'BUSCANDO', jsonb_build_object('motorista_sem_sinal', r.motorista_id));
    perform interno.notificar(r.passageiro_id, 'CANCELAMENTO', 'Buscando outro motorista', 'Perdemos o sinal do motorista. Já estamos buscando outro.', jsonb_build_object('corrida', r.id));
    n := n + 1;
  end loop;
  -- CHEGOU há mais de 30 min sem embarque: cancela sem taxa
  for r in select * from corridas where status = 'CHEGOU' and chegou_em < now() - interval '30 minutes' for update skip locked loop
    update corridas set status = 'CANCELADA', cancelado_por = 'SISTEMA', motivo_cancelamento = 'Embarque não ocorreu', cancelada_em = now(), versao = versao + 1 where id = r.id;
    update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = r.motorista_id;
    perform interno.evento(r.id, 'CANCELAMENTO_SISTEMA', 'CHEGOU', 'CANCELADA', '{}');
    n := n + 1;
  end loop;
  -- EM CURSO muito além do previsto: suporte assume (incidente único por corrida)
  for r in select * from corridas c where status = 'EM_CURSO'
           and iniciada_em < now() - make_interval(mins => (duracao_estimada_min * 3)::int + 30)
           and not exists (select 1 from incidentes i where i.corrida_id = c.id and i.tipo = 'ALERTA_AUTOMATICO' and i.descricao like 'Corrida travada%') loop
    insert into incidentes (corrida_id, tipo, gravidade, descricao)
    values (r.id, 'ALERTA_AUTOMATICO', 'ALTA', 'Corrida travada EM_CURSO muito além do previsto. Suporte deve contatar e finalizar/cancelar.');
    n := n + 1;
  end loop;
  return n;
end $$;

-- suporte encerra corrida travada (com motivo e auditoria)
create or replace function public.suporte_finalizar_corrida(p_corrida uuid, p_cobrar boolean, p_motivo text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{SUPORTE,OPERACOES,ADMIN}'); c corridas;
begin
  if coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  select * into c from corridas where id = p_corrida for update;
  if c.status <> 'EM_CURSO' then perform interno.erro('STATUS_INVALIDO', c.status::text); end if;
  perform interno.sem_conflito(c.passageiro_id); perform interno.sem_conflito(c.motorista_id);
  update motorista_presenca set disponivel = online, disponivel_desde = now() where motorista_id = c.motorista_id;
  if p_cobrar then
    update corridas set status = 'FINALIZADA', finalizada_em = now(), preco_final = preco_estimado,
      distancia_real_km = distancia_estimada_km, duracao_real_min = duracao_estimada_min, versao = versao + 1 where id = p_corrida;
    perform interno.evento(p_corrida, 'FINALIZACAO_SUPORTE', 'EM_CURSO', 'FINALIZADA', jsonb_build_object('motivo', p_motivo));
    return jsonb_build_object('status', 'FINALIZADA', 'pagamento', interno.cobrar_corrida(p_corrida));
  end if;
  update corridas set status = 'CANCELADA', cancelado_por = 'SUPORTE', motivo_cancelamento = p_motivo, cancelada_em = now(), versao = versao + 1 where id = p_corrida;
  perform interno.evento(p_corrida, 'CANCELAMENTO_SUPORTE', 'EM_CURSO', 'CANCELADA', jsonb_build_object('motivo', p_motivo));
  return jsonb_build_object('status', 'CANCELADA');
end $$;

-- job: pergunta sem resposta vira atendimento humano (sem presumir perigo)
create or replace function interno.job_seguranca() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n int := 0;
begin
  for r in update verificacoes_seguranca set status = 'SEM_RESPOSTA'
           where status = 'AGUARDANDO' and criada_em < now() - interval '3 minutes'
           returning * loop
    insert into incidentes (corrida_id, tipo, gravidade, descricao, lat, lng)
    values (r.corrida_id, 'ALERTA_AUTOMATICO', 'ALTA', 'Sem resposta à verificação de ' || r.tipo || '. Suporte deve contatar.',
            (r.dados ->> 'lat')::float8, (r.dados ->> 'lng')::float8);
    n := n + 1;
  end loop;
  return n;
end $$;
