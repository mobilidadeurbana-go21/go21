-- ============================================================
-- 0005 — ANTIFRAUDE, NOTIFICAÇÕES, FINANÇAS DO MOTORISTA,
--        PAINEL ADMIN, PERMISSÕES (RLS), REALTIME, JOBS, STORAGE
-- ============================================================

-- ============================================================
-- ANTIFRAUDE: DETECÇÃO -> ANÁLISE -> VALIDAÇÃO (humana) -> AÇÃO
-- O sistema SINALIZA e SEGURA VALORES suspeitos. Nunca bloqueia
-- conta sozinho: bloqueio é sempre decisão de uma pessoa do Risco.
-- ============================================================
create table if not exists sinais_fraude (
  id uuid primary key default gen_random_uuid(),
  entidade_tipo text not null check (entidade_tipo in ('USUARIO','CORRIDA','PAGAMENTO','INDICACAO','DISPOSITIVO','CUPOM')),
  entidade_id text not null,
  tipo text not null,
  severidade int not null check (severidade between 1 and 5),
  detalhes jsonb not null default '{}',
  ocorrencias int not null default 1,
  status text not null default 'ABERTO' check (status in ('ABERTO','EM_ANALISE','CONFIRMADO','DESCARTADO')),
  analista_id uuid,
  decisao text,
  acao_tomada text,
  criado_em timestamptz not null default now(),
  ultima_ocorrencia timestamptz not null default now(),
  decidido_em timestamptz
);
create unique index if not exists sinal_aberto_unico on sinais_fraude (entidade_tipo, entidade_id, tipo) where status in ('ABERTO','EM_ANALISE');
create index if not exists sinais_fila_idx on sinais_fraude (status, severidade desc, criado_em);
create index if not exists sinais_entidade_idx on sinais_fraude (entidade_tipo, entidade_id);
drop trigger if exists sinais_auditar on sinais_fraude;
create trigger sinais_auditar after update on sinais_fraude for each row execute function interno.trg_auditar();

create or replace function interno.registrar_sinal(p_entidade_tipo text, p_entidade_id text, p_tipo text, p_severidade int, p_detalhes jsonb default '{}')
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_id uuid;
begin
  update sinais_fraude set ocorrencias = ocorrencias + 1, ultima_ocorrencia = now(),
    severidade = greatest(severidade, p_severidade), detalhes = detalhes || coalesce(p_detalhes, '{}')
  where entidade_tipo = p_entidade_tipo and entidade_id = p_entidade_id and tipo = p_tipo and status in ('ABERTO','EM_ANALISE')
  returning id into v_id;
  if v_id is null then
    begin
      insert into sinais_fraude (entidade_tipo, entidade_id, tipo, severidade, detalhes)
      values (p_entidade_tipo, p_entidade_id, p_tipo, p_severidade, coalesce(p_detalhes, '{}')) returning id into v_id;
    exception when unique_violation then
      select id into v_id from sinais_fraude where entidade_tipo = p_entidade_tipo and entidade_id = p_entidade_id
        and tipo = p_tipo and status in ('ABERTO','EM_ANALISE');
    end;
  end if;
  return v_id;
end $$;

-- detectores rodados a cada corrida paga (antes de calcular bônus)
create or replace function interno.detectar_fraude_corrida(p_corrida uuid) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; v_rel jsonb; v_pares int; v_curtas int;
begin
  select * into c from corridas where id = p_corrida;
  if c.motorista_id is null then return; end if;

  -- passageiro e motorista no mesmo aparelho/IP = possível corrida artificial
  v_rel := interno.contas_relacionadas(c.passageiro_id, c.motorista_id);
  if v_rel <> '{}'::jsonb then
    perform interno.registrar_sinal('CORRIDA', c.id::text, 'CONTA_RELACIONADA', 4,
      jsonb_build_object('passageiro', c.passageiro_id, 'motorista', c.motorista_id, 'evidencias', v_rel));
  end if;

  -- mesmo par passageiro-motorista muitas vezes em 24h
  select count(*) into v_pares from corridas
  where passageiro_id = c.passageiro_id and motorista_id = c.motorista_id and status in ('FINALIZADA','PAGA')
    and finalizada_em > now() - interval '24 hours';
  if v_pares >= 3 then
    perform interno.registrar_sinal('USUARIO', c.motorista_id::text, 'MESMO_PAR_REPETIDO', 3,
      jsonb_build_object('passageiro', c.passageiro_id, 'corridas_24h', v_pares));
  end if;

  -- muitas corridas curtíssimas (inflar contagem para bônus)
  select count(*) into v_curtas from corridas
  where motorista_id = c.motorista_id and status in ('FINALIZADA','PAGA') and finalizada_em > now() - interval '24 hours'
    and coalesce(distancia_real_km, 0) < interno.cfg_num('corrida_valida_min_km', 1);
  if v_curtas >= 5 then
    perform interno.registrar_sinal('USUARIO', c.motorista_id::text, 'CORRIDAS_CURTAS_REPETIDAS', 3, jsonb_build_object('qtd_24h', v_curtas));
  end if;

  -- passageiro é da rede de indicação do motorista (acima ou abaixo)
  if exists (select 1 from interno.cadeia_indicacao(c.motorista_id, 3) where beneficiario_id = c.passageiro_id)
     or exists (select 1 from interno.cadeia_indicacao(c.passageiro_id, 3) where beneficiario_id = c.motorista_id) then
    perform interno.registrar_sinal('CORRIDA', c.id::text, 'CORRIDA_NA_PROPRIA_REDE', 3,
      jsonb_build_object('passageiro', c.passageiro_id, 'motorista', c.motorista_id));
  end if;
end $$;

-- job diário de comportamento
create or replace function interno.job_risco() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n int := 0;
begin
  for r in select id, total_corridas, total_cancelamentos from motoristas
           where total_cancelamentos >= 5 and total_cancelamentos::numeric / greatest(total_corridas + total_cancelamentos, 1) > 0.3 loop
    perform interno.registrar_sinal('USUARIO', r.id::text, 'CANCELAMENTO_EXCESSIVO', 2,
      jsonb_build_object('corridas', r.total_corridas, 'cancelamentos', r.total_cancelamentos));
    n := n + 1;
  end loop;
  return n;
end $$;

-- validação + ação: sempre humana, com motivo, auditada
create or replace function public.risco_decidir_sinal(p_sinal uuid, p_confirmar boolean, p_acao text, p_observacao text)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO,ADMIN}'); s sinais_fraude; g record; v_alvo uuid;
begin
  if coalesce(trim(p_observacao), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  if p_acao not in ('NENHUMA','NEGAR_BONUS','SUSPENDER_MOTORISTA','BLOQUEAR_USUARIO') then perform interno.erro('ACAO_INVALIDA'); end if;
  if not p_confirmar and p_acao <> 'NENHUMA' then perform interno.erro('ACAO_EXIGE_CONFIRMACAO'); end if;
  select * into s from sinais_fraude where id = p_sinal for update;
  if s.status not in ('ABERTO','EM_ANALISE') then perform interno.erro('SINAL_JA_DECIDIDO'); end if;
  if s.entidade_tipo in ('USUARIO','INDICACAO') then perform interno.sem_conflito(s.entidade_id::uuid); end if;
  if s.entidade_tipo = 'CORRIDA' then
    perform interno.sem_conflito((select passageiro_id from corridas where id = s.entidade_id::uuid));
    perform interno.sem_conflito((select motorista_id from corridas where id = s.entidade_id::uuid));
  end if;

  update sinais_fraude set status = case when p_confirmar then 'CONFIRMADO' else 'DESCARTADO' end,
    analista_id = v_uid, decisao = p_observacao, acao_tomada = p_acao, decidido_em = now() where id = p_sinal;

  if p_acao = 'NEGAR_BONUS' and s.entidade_tipo = 'CORRIDA' then
    for g in select id from ganhos_indicacao where corrida_id = s.entidade_id::uuid and status = 'BLOQUEADO' loop
      perform public.risco_decidir_ganho_retido(g.id, false, 'Sinal ' || s.tipo || ' confirmado: ' || p_observacao);
    end loop;
  elsif p_acao in ('SUSPENDER_MOTORISTA','BLOQUEAR_USUARIO') then
    v_alvo := case when s.entidade_tipo = 'USUARIO' then s.entidade_id::uuid
                   when s.entidade_tipo = 'CORRIDA' then (select motorista_id from corridas where id = s.entidade_id::uuid) end;
    if v_alvo is null then perform interno.erro('ALVO_NAO_IDENTIFICADO'); end if;
    if p_acao = 'SUSPENDER_MOTORISTA' then
      perform public.ops_alterar_status_motorista(v_alvo, 'SUSPENSO', 'Risco: ' || s.tipo || ' — ' || p_observacao);
    else
      update perfis set status = 'BLOQUEADO' where id = v_alvo;
      update motoristas set status = 'BLOQUEADO', motivo_status = 'Risco: ' || p_observacao where id = v_alvo;
      update motorista_presenca set online = false, disponivel = false where motorista_id = v_alvo;
    end if;
  end if;
  perform interno.auditar_evento('DECISAO_RISCO', 'sinais_fraude', p_sinal::text,
    jsonb_build_object('confirmar', p_confirmar, 'acao', p_acao, 'observacao', p_observacao));
  return jsonb_build_object('status', case when p_confirmar then 'CONFIRMADO' else 'DESCARTADO' end, 'acao', p_acao);
end $$;

-- ============================================================
-- NOTIFICAÇÕES (fila de saída: push, SMS, e-mail, WhatsApp, in-app)
-- ============================================================
create table if not exists notificacoes (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null,
  canal text not null check (canal in ('IN_APP','PUSH','SMS','EMAIL','WHATSAPP')),
  evento text not null,
  titulo text not null,
  mensagem text not null,
  dados jsonb not null default '{}',
  status text not null default 'PENDENTE' check (status in ('PENDENTE','ENVIANDO','ENVIADA','FALHOU','LIDA')),
  tentativas int not null default 0,
  erro text,
  criado_em timestamptz not null default now(),
  enviado_em timestamptz,
  lida_em timestamptz
);
create index if not exists notificacoes_usuario_idx on notificacoes (usuario_id, criado_em desc);
create index if not exists notificacoes_fila_idx on notificacoes (status, canal, criado_em) where status in ('PENDENTE','FALHOU');

create or replace function interno.notificar(p_usuario uuid, p_evento text, p_titulo text, p_mensagem text, p_dados jsonb default '{}', p_canais text[] default '{IN_APP,PUSH}')
returns void language sql security definer set search_path = public, pg_temp as $$
  insert into notificacoes (usuario_id, canal, evento, titulo, mensagem, dados, status)
  select p_usuario, canal, p_evento, p_titulo, p_mensagem, coalesce(p_dados, '{}'),
         case when canal = 'IN_APP' then 'ENVIADA' else 'PENDENTE' end
  from unnest(p_canais) canal
  where p_usuario is not null
$$;

create or replace function public.marcar_notificacoes_lidas(p_ids uuid[] default null) returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); n int;
begin
  update notificacoes set status = 'LIDA', lida_em = now()
  where usuario_id = v_uid and canal = 'IN_APP' and status <> 'LIDA' and (p_ids is null or id = any(p_ids));
  get diagnostics n = row_count;
  return n;
end $$;

-- consumidas pelo servidor (Edge Function) que fala com FCM / SMS / e-mail / WhatsApp
create or replace function public.notificacoes_para_enviar(p_canal text, p_limite int default 100) returns setof notificacoes
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  return query
  update notificacoes set status = 'ENVIANDO', tentativas = tentativas + 1
  where id in (select id from notificacoes where canal = p_canal and status in ('PENDENTE','FALHOU') and tentativas < 5
               order by criado_em limit p_limite for update skip locked)
  returning *;
end $$;

create or replace function public.notificacao_resultado(p_id uuid, p_ok boolean, p_erro text default null) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' then perform interno.erro('SEM_PERMISSAO'); end if;
  update notificacoes set status = case when p_ok then 'ENVIADA' else 'FALHOU' end, erro = p_erro,
    enviado_em = case when p_ok then now() end where id = p_id;
end $$;

-- ============================================================
-- MOTORISTA COMO GERENTE FINANCEIRO
-- ============================================================
create table if not exists custos_motorista (
  motorista_id uuid primary key references motoristas(id) on delete cascade,
  preco_combustivel numeric(6,2) not null default 6.00,   -- R$ por litro (ou kWh)
  consumo_km_l numeric(6,2) not null default 10,          -- km por litro
  manutencao_km numeric(6,3) not null default 0.10,       -- R$ por km
  pneus_km numeric(6,3) not null default 0.03,
  depreciacao_km numeric(6,3) not null default 0.15,
  outros_km numeric(6,3) not null default 0,
  seguro_mes numeric(10,2) not null default 0,
  financiamento_mes numeric(10,2) not null default 0,
  outros_mes numeric(10,2) not null default 0,
  horas_mes numeric(6,1) not null default 200,            -- para ratear custos fixos por hora
  atualizado_em timestamptz not null default now(),
  check (consumo_km_l > 0 and horas_mes > 0)
);

create table if not exists custos_lancados (
  id uuid primary key default gen_random_uuid(),
  motorista_id uuid not null references motoristas(id) on delete cascade,
  data date not null,
  tipo text not null check (tipo in ('COMBUSTIVEL','MANUTENCAO','PNEUS','LAVAGEM','ALIMENTACAO','PEDAGIO','ESTACIONAMENTO','OUTROS')),
  valor numeric(10,2) not null check (valor > 0),
  descricao text,
  criado_em timestamptz not null default now()
);
create index if not exists custos_lancados_idx on custos_lancados (motorista_id, data);

-- o que o motorista vê ANTES de aceitar (a decisão é sempre dele)
create or replace function interno.rentabilidade(p_motorista uuid, p_cidade uuid, p_categoria text, p_valor numeric,
  p_km numeric, p_min numeric, p_km_embarque numeric, p_min_embarque numeric) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare k custos_motorista; r regras_comissao; v_ganho numeric; v_km numeric; v_h numeric; v_comb numeric; v_custos numeric; v_res numeric; v_conf boolean;
begin
  select * into k from custos_motorista where motorista_id = p_motorista;
  v_conf := found;
  if not v_conf then k := row(p_motorista, 6.00, 10, 0.10, 0.03, 0.15, 0, 0, 0, 0, 200, now())::custos_motorista; end if;
  r := interno.resolver_comissao(p_cidade, p_categoria, p_motorista, now());
  v_ganho := p_valor - round(p_valor * coalesce(r.taxa_plataforma_pct, 0) / 100, 2);
  v_km := coalesce(p_km, 0) + coalesce(p_km_embarque, 0);
  v_h := greatest((coalesce(p_min, 0) + coalesce(p_min_embarque, 0)) / 60, 1.0/60);
  v_comb := round(v_km / k.consumo_km_l * k.preco_combustivel, 2);
  v_custos := round(v_km * (k.manutencao_km + k.pneus_km + k.depreciacao_km + k.outros_km)
                    + (k.seguro_mes + k.financiamento_mes + k.outros_mes) / k.horas_mes * v_h, 2);
  v_res := v_ganho - v_comb - v_custos;
  return jsonb_build_object(
    'valor_corrida', p_valor, 'taxa_pct', r.taxa_plataforma_pct, 'seu_ganho', v_ganho,
    'distancia_km', p_km, 'embarque_km', p_km_embarque, 'tempo_min', round(coalesce(p_min, 0) + coalesce(p_min_embarque, 0)),
    'combustivel', v_comb, 'custos', v_custos, 'resultado', round(v_res, 2),
    'resultado_hora', round(v_res / v_h, 2), 'resultado_km', round(v_res / greatest(v_km, 0.1), 2),
    'custos_configurados', v_conf);
end $$;

create or replace function public.salvar_custos(p jsonb) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}');
begin
  insert into custos_motorista (motorista_id) values (v_uid) on conflict do nothing;
  update custos_motorista set
    preco_combustivel = coalesce((p ->> 'preco_combustivel')::numeric, preco_combustivel),
    consumo_km_l = coalesce((p ->> 'consumo_km_l')::numeric, consumo_km_l),
    manutencao_km = coalesce((p ->> 'manutencao_km')::numeric, manutencao_km),
    pneus_km = coalesce((p ->> 'pneus_km')::numeric, pneus_km),
    depreciacao_km = coalesce((p ->> 'depreciacao_km')::numeric, depreciacao_km),
    outros_km = coalesce((p ->> 'outros_km')::numeric, outros_km),
    seguro_mes = coalesce((p ->> 'seguro_mes')::numeric, seguro_mes),
    financiamento_mes = coalesce((p ->> 'financiamento_mes')::numeric, financiamento_mes),
    outros_mes = coalesce((p ->> 'outros_mes')::numeric, outros_mes),
    horas_mes = coalesce((p ->> 'horas_mes')::numeric, horas_mes),
    atualizado_em = now()
  where motorista_id = v_uid;
end $$;

create or replace function public.lancar_custo(p_data date, p_tipo text, p_valor numeric, p_descricao text default null) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_id uuid;
begin
  insert into custos_lancados (motorista_id, data, tipo, valor, descricao) values (v_uid, p_data, p_tipo, p_valor, p_descricao) returning id into v_id;
  return v_id;
end $$;

-- painel HOJE (ou qualquer período): faturamento, custos, resultado, tempos
create or replace function public.painel_motorista(p_inicio date default null, p_fim date default null) returns jsonb
language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_tz text; v_ini timestamptz; v_fim timestamptz; k custos_motorista;
  v_fat numeric; v_gorj numeric; v_km numeric; v_corridas int; v_online numeric; v_corrida_h numeric; v_comb_lanc numeric;
  v_comb numeric; v_outros_lanc numeric; v_outros numeric; v_res numeric; v_conf boolean;
begin
  select coalesce(c.fuso, 'America/Sao_Paulo') into v_tz from motoristas m join cidades c on c.id = m.cidade_id where m.id = v_uid;
  v_ini := (coalesce(p_inicio, (now() at time zone v_tz)::date))::timestamp at time zone v_tz;
  v_fim := ((coalesce(p_fim, p_inicio, (now() at time zone v_tz)::date)) + 1)::timestamp at time zone v_tz;
  select * into k from custos_motorista where motorista_id = v_uid;
  v_conf := found;
  if not v_conf then k := row(v_uid, 6.00, 10, 0.10, 0.03, 0.15, 0, 0, 0, 0, 200, now())::custos_motorista; end if;

  select coalesce(sum((e.dados ->> 'motorista')::numeric), 0), count(*) into v_fat, v_corridas
  from corrida_eventos e join corridas c on c.id = e.corrida_id
  where c.motorista_id = v_uid and e.tipo = 'PAGAMENTO' and e.criado_em >= v_ini and e.criado_em < v_fim;
  select coalesce(sum(valor), 0) into v_gorj from recebiveis
  where motorista_id = v_uid and tipo in ('GORJETA','TAXA_CANCELAMENTO') and criado_em >= v_ini and criado_em < v_fim;

  select coalesce(sum(c.distancia_real_km), 0) + coalesce(sum(o.distancia_embarque_km), 0),
         coalesce(sum(extract(epoch from c.finalizada_em - c.aceita_em)) / 3600, 0)
    into v_km, v_corrida_h
  from corridas c left join ofertas o on o.corrida_id = c.id and o.motorista_id = v_uid and o.status = 'ACEITA'
  where c.motorista_id = v_uid and c.finalizada_em >= v_ini and c.finalizada_em < v_fim;

  select coalesce(sum(extract(epoch from least(coalesce(fim, now()), v_fim) - greatest(inicio, v_ini))) / 3600, 0) into v_online
  from sessoes_online where motorista_id = v_uid and inicio < v_fim and coalesce(fim, now()) > v_ini;

  select coalesce(sum(valor) filter (where tipo = 'COMBUSTIVEL'), 0), coalesce(sum(valor) filter (where tipo <> 'COMBUSTIVEL'), 0)
    into v_comb_lanc, v_outros_lanc
  from custos_lancados where motorista_id = v_uid and data >= v_ini::date and data < v_fim::date;

  v_comb := case when v_comb_lanc > 0 then v_comb_lanc else round(v_km / k.consumo_km_l * k.preco_combustivel, 2) end;
  v_outros := round(v_outros_lanc + v_km * (k.manutencao_km + k.pneus_km + k.depreciacao_km + k.outros_km)
                    + (k.seguro_mes + k.financiamento_mes + k.outros_mes) / k.horas_mes * v_online, 2);
  v_res := v_fat + v_gorj - v_comb - v_outros;
  return jsonb_build_object(
    'periodo', jsonb_build_object('inicio', v_ini, 'fim', v_fim),
    'faturamento', round(v_fat + v_gorj, 2), 'corridas', v_corridas, 'km', round(v_km, 1),
    'combustivel', v_comb, 'combustivel_estimado', v_comb_lanc = 0,
    'outros_custos', v_outros,
    'resultado_operacional', round(v_res, 2),
    'tempo_online_h', round(v_online, 2), 'tempo_em_corrida_h', round(v_corrida_h, 2),
    'tempo_ocioso_h', round(greatest(v_online - v_corrida_h, 0), 2),
    'resultado_hora', case when v_online > 0 then round(v_res / v_online, 2) end,
    'custos_configurados', v_conf);
end $$;

-- ============================================================
-- PAINEL ADMIN
-- ============================================================
create or replace function public.admin_indicadores(p_inicio timestamptz, p_fim timestamptz, p_cidade uuid default null, p_categoria text default null)
returns jsonb language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,OPERACOES,FINANCEIRO,RISCO,SUPORTE}'); v jsonb; v_dur interval := p_fim - p_inicio;
begin
  with c as (
    select * from corridas where solicitada_em >= p_inicio and solicitada_em < p_fim
      and (p_cidade is null or cidade_id = p_cidade) and (p_categoria is null or categoria = p_categoria)
  ), ant as (
    select distinct passageiro_id from corridas where status = 'PAGA' and solicitada_em >= p_inicio - v_dur and solicitada_em < p_inicio
      and (p_cidade is null or cidade_id = p_cidade)
  ), atual as (select distinct passageiro_id from c where status = 'PAGA'),
  liq as (
    select l.valor, ct.tipo from lancamentos_ledger l join contas_ledger ct on ct.id = l.conta_id
    join transacoes_ledger t on t.id = l.transacao_id
    left join corridas cr on t.referencia = cr.id::text
    where l.criado_em >= p_inicio and l.criado_em < p_fim and t.tipo in ('LIQUIDACAO_CORRIDA','ESTORNO','TAXA_CANCELAMENTO')
      and (p_cidade is null or cr.cidade_id = p_cidade) and (p_categoria is null or cr.categoria = p_categoria)
  )
  select jsonb_build_object(
    'passageiros_ativos', (select count(distinct passageiro_id) from c),
    'motoristas_online_agora', (select count(*) from motorista_presenca where online and (p_cidade is null or cidade_id = p_cidade)),
    'corridas', (select count(*) from c),
    'concluidas', (select count(*) from c where status in ('FINALIZADA','PAGA')),
    'canceladas', (select count(*) from c where status = 'CANCELADA'),
    'canceladas_passageiro', (select count(*) from c where status = 'CANCELADA' and cancelado_por = 'PASSAGEIRO'),
    'canceladas_motorista_eventos', (select count(*) from corrida_eventos e join c on c.id = e.corrida_id where e.tipo = 'CANCELAMENTO_MOTORISTA'),
    'sem_motorista', (select count(*) from c where status = 'SEM_MOTORISTA'),
    'taxa_conclusao_pct', (select round(100.0 * count(*) filter (where status in ('FINALIZADA','PAGA')) / nullif(count(*), 0), 1) from c),
    'espera_media_min', (select round((avg(extract(epoch from aceita_em - solicitada_em)) / 60)::numeric, 1) from c where aceita_em is not null),
    'chegada_media_min', (select round((avg(extract(epoch from chegou_em - aceita_em)) / 60)::numeric, 1) from c where chegou_em is not null),
    'ticket_medio', (select round(avg(preco_final), 2) from c where status = 'PAGA'),
    'gmv', (select coalesce(sum(preco_final), 0) from c where status = 'PAGA'),
    'receita_plataforma', (select coalesce(sum(valor), 0) from liq where tipo = 'PLATAFORMA_RECEITA'),
    'repasses_motoristas', (select coalesce(sum(valor), 0) from liq where tipo in ('MOTORISTA_PENDENTE','MOTORISTA_DISPONIVEL')),
    'bonus_indicacao', (select coalesce(sum(valor), 0) from liq where tipo in ('INDICACAO_PENDENTE','INDICACAO_RETIDA')),
    'margem_pct', (select round(100 * (select coalesce(sum(valor), 0) from liq where tipo = 'PLATAFORMA_RECEITA')
                          / nullif((select sum(preco_final) from c where status = 'PAGA'), 0), 2)),
    'incidentes', (select count(*) from incidentes i where i.criado_em >= p_inicio and i.criado_em < p_fim),
    'incidentes_criticos_abertos', (select count(*) from incidentes where gravidade = 'CRITICA' and status in ('ABERTO','EM_ATENDIMENTO')),
    'sinais_fraude', (select count(*) from sinais_fraude where criado_em >= p_inicio and criado_em < p_fim),
    'sinais_fraude_abertos', (select count(*) from sinais_fraude where status in ('ABERTO','EM_ANALISE')),
    'novos_usuarios', (select count(*) from perfis where criado_em >= p_inicio and criado_em < p_fim and (p_cidade is null or cidade_id = p_cidade)),
    'novos_motoristas', (select count(*) from motoristas where criado_em >= p_inicio and criado_em < p_fim and (p_cidade is null or cidade_id = p_cidade)),
    'retencao_passageiros_pct', (select round(100.0 * count(*) / nullif((select count(*) from ant), 0), 1) from ant where passageiro_id in (select passageiro_id from atual)),
    'por_cidade', (select coalesce(jsonb_agg(jsonb_build_object('cidade', ci.nome, 'corridas', x.n, 'concluidas', x.ok, 'gmv', x.gmv) order by x.n desc), '[]')
                   from (select cidade_id, count(*) n, count(*) filter (where status = 'PAGA') ok, coalesce(sum(preco_final) filter (where status = 'PAGA'), 0) gmv
                         from c group by cidade_id) x join cidades ci on ci.id = x.cidade_id),
    'por_categoria', (select coalesce(jsonb_object_agg(categoria, n), '{}') from (select categoria, count(*) n from c group by categoria) y)
  ) into v;
  return v;
end $$;

-- ============================================================
-- PERMISSÕES — RLS em TODAS as tabelas
-- Leitura: cada um vê o que é seu; staff vê tudo.
-- Escrita: NINGUÉM escreve direto. Só pelas funções acima.
-- ============================================================
create or replace function interno.eh_papel(p_papeis papel[]) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from usuario_papeis where usuario_id = auth.uid() and ativo and (papel = any(p_papeis) or papel = 'SUPER_ADMIN'))
$$;

do $$
declare t text;
begin
  foreach t in array array[
    'configuracoes','usuario_papeis','auditoria','limites_uso','cidades','categorias','cidade_categorias','perfis','dispositivos',
    'contatos_confianca','motoristas','veiculos','documentos','motorista_presenca','sessoes_online','corridas','corrida_segredos','corrida_eventos',
    'ofertas','avaliacoes','corrida_trilha','corrida_compartilhamentos','incidentes','verificacoes_seguranca','regras_comissao',
    'contas_ledger','transacoes_ledger','lancamentos_ledger','saldos','pagamentos','webhooks_recebidos','cupons','cupom_usos',
    'recebiveis','indicacoes','ganhos_indicacao','repasses','sinais_fraude','notificacoes','custos_motorista','custos_lancados']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;

-- políticas de leitura
create or replace function interno.criar_politica(p_tabela text, p_nome text, p_expr text) returns void language plpgsql as $$
begin
  execute format('drop policy if exists %I on public.%I', p_nome, p_tabela);
  execute format('create policy %I on public.%I for select to authenticated using (%s)', p_nome, p_tabela, p_expr);
  execute format('grant select on public.%I to authenticated', p_tabela);
end $$;

select interno.criar_politica('configuracoes',     'staff',  'interno.eh_staff()');
select interno.criar_politica('usuario_papeis',    'proprio','usuario_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('auditoria',         'admin',  $p$interno.eh_papel('{ADMIN,RISCO}')$p$);
select interno.criar_politica('cidades',           'todos',  'ativa or interno.eh_staff()');
select interno.criar_politica('categorias',        'todos',  'true');
select interno.criar_politica('cidade_categorias', 'todos',  'true');
select interno.criar_politica('perfis',            'proprio','id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('dispositivos',      'proprio','usuario_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('contatos_confianca','proprio','usuario_id = auth.uid()');
select interno.criar_politica('motoristas',        'proprio','id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('veiculos',          'proprio','motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('documentos',        'proprio','motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('motorista_presenca','proprio','motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('sessoes_online',    'proprio','motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('corridas',          'participante','passageiro_id = auth.uid() or motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('corrida_eventos',   'staff',  'interno.eh_staff()');   -- tem dados internos (score, divisão do dinheiro)
select interno.criar_politica('ofertas',           'proprio','motorista_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('avaliacoes',        'proprio','avaliador_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('corrida_trilha',    'staff',  'interno.eh_staff()');
select interno.criar_politica('incidentes',        'proprio','reportado_por = auth.uid() or interno.eh_staff()');
select interno.criar_politica('verificacoes_seguranca','participante','interno.eh_staff() or exists (select 1 from corridas c where c.id = corrida_id and (c.passageiro_id = auth.uid() or c.motorista_id = auth.uid()))');
select interno.criar_politica('regras_comissao',   'staff',  $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('contas_ledger',     'financeiro', $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('transacoes_ledger', 'financeiro', $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('lancamentos_ledger','financeiro', $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('saldos',            'financeiro', $p$interno.eh_papel('{ADMIN,FINANCEIRO}')$p$);
select interno.criar_politica('pagamentos',        'proprio','pagador_id = auth.uid() or interno.eh_papel(''{ADMIN,FINANCEIRO,SUPORTE}'')');
select interno.criar_politica('cupons',            'staff',  'interno.eh_staff()');
select interno.criar_politica('cupom_usos',        'proprio','usuario_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('recebiveis',        'proprio','motorista_id = auth.uid() or interno.eh_papel(''{ADMIN,FINANCEIRO}'')');
select interno.criar_politica('indicacoes',        'proprio','indicado_id = auth.uid() or indicador_id = auth.uid() or interno.eh_staff()');
select interno.criar_politica('ganhos_indicacao',  'proprio','beneficiario_id = auth.uid() or interno.eh_papel(''{ADMIN,FINANCEIRO,RISCO}'')');
select interno.criar_politica('repasses',          'proprio','motorista_id = auth.uid() or interno.eh_papel(''{ADMIN,FINANCEIRO}'')');
select interno.criar_politica('sinais_fraude',     'risco',  $p$interno.eh_papel('{ADMIN,RISCO}')$p$);
select interno.criar_politica('notificacoes',      'proprio','usuario_id = auth.uid()');
select interno.criar_politica('custos_motorista',  'proprio','motorista_id = auth.uid()');
select interno.criar_politica('custos_lancados',   'proprio','motorista_id = auth.uid()');
-- limites_uso, corrida_segredos (PIN), corrida_compartilhamentos, webhooks_recebidos: sem leitura pelos apps

-- visitante (sem login) só vê cidades e categorias, para a estimativa
drop policy if exists anon_cidades on cidades;
create policy anon_cidades on cidades for select to anon using (ativa);
drop policy if exists anon_categorias on categorias;
create policy anon_categorias on categorias for select to anon using (disponivel_no_sistema);
drop policy if exists anon_cidade_categorias on cidade_categorias;
create policy anon_cidade_categorias on cidade_categorias for select to anon using (habilitada);
grant select on cidades, categorias, cidade_categorias to anon;

-- funções: interno fechado; public só para quem está logado (salvo exceções)
grant usage on schema interno to authenticated;
revoke execute on all functions in schema interno from public, anon, authenticated;
grant execute on function interno.eh_staff(uuid), interno.eh_papel(papel[]) to authenticated;

revoke execute on all functions in schema public from public, anon;
grant execute on all functions in schema public to authenticated;
grant execute on function public.ver_corrida_compartilhada(text), public.estimar_corrida(uuid, float8, float8, float8, float8, numeric, numeric) to anon;
revoke execute on function public.processar_webhook(text, text, text, jsonb) from authenticated;
revoke execute on function public.notificacoes_para_enviar(text, int) from authenticated;
revoke execute on function public.notificacao_resultado(uuid, boolean, text) from authenticated;
grant execute on function public.processar_webhook(text, text, text, jsonb), public.notificacoes_para_enviar(text, int),
  public.notificacao_resultado(uuid, boolean, text), public.fin_concluir_repasse(uuid, boolean, text, text) to service_role;

-- ============================================================
-- REALTIME (apps recebem mudanças na hora, respeitando o RLS)
-- ============================================================
do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin alter publication supabase_realtime add table public.corridas; exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.ofertas; exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.notificacoes; exception when duplicate_object then null; end;
  end if;
end $$;

-- ============================================================
-- JOBS (pg_cron, quando a extensão estiver ligada no Supabase)
-- ============================================================
create or replace function public.executar_jobs(p_qual text default 'rapido') returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_qual = 'rapido' then
    return jsonb_build_object('matching', interno.job_matching(), 'seguranca', interno.job_seguranca(),
                              'travadas', interno.job_corridas_travadas());
  elsif p_qual = 'horario' then
    return jsonb_build_object('liberacao', interno.job_liberar_saldos());
  else
    perform interno.limpar_limites();
    return jsonb_build_object('documentos', interno.job_documentos(), 'risco', interno.job_risco());
  end if;
end $$;
revoke execute on function public.executar_jobs(text) from public, anon, authenticated;

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule(jobid) from cron.job where jobname in ('mob_rapido','mob_horario','mob_diario');
    perform cron.schedule('mob_rapido',  '10 seconds', $c$select public.executar_jobs('rapido')$c$);
    perform cron.schedule('mob_horario', '*/15 * * * *', $c$select public.executar_jobs('horario')$c$);
    perform cron.schedule('mob_diario',  '0 6 * * *', $c$select public.executar_jobs('diario')$c$);
  end if;
exception when others then
  raise notice 'pg_cron não configurado: %', sqlerrm;
end $$;

-- ============================================================
-- STORAGE (só no Supabase): buckets privados com pasta por usuário
-- ============================================================
do $$ begin
  if exists (select 1 from pg_namespace where nspname = 'storage') and exists (select 1 from pg_tables where schemaname = 'storage' and tablename = 'buckets') then
   begin
    insert into storage.buckets (id, name, public) values ('documentos', 'documentos', false) on conflict (id) do nothing;
    insert into storage.buckets (id, name, public) values ('fotos', 'fotos', false) on conflict (id) do nothing;
    drop policy if exists docs_upload_proprio on storage.objects;
    create policy docs_upload_proprio on storage.objects for insert to authenticated
      with check (bucket_id in ('documentos','fotos') and (storage.foldername(name))[1] = auth.uid()::text);
    drop policy if exists docs_ler_proprio_ou_staff on storage.objects;
    create policy docs_ler_proprio_ou_staff on storage.objects for select to authenticated
      using (bucket_id in ('documentos','fotos') and ((storage.foldername(name))[1] = auth.uid()::text or interno.eh_staff()));
   exception when others then
     raise notice 'Storage não configurado por SQL (%). Crie os buckets "documentos" e "fotos" (privados) pelo painel.', sqlerrm;
   end;
  end if;
end $$;
