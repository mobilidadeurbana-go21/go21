-- ============================================================
-- 0002 — CADASTROS: usuários, cidades, categorias, motorista,
--        veículo, documentos, compliance, dispositivos
-- ============================================================

do $$ begin
  create type status_motorista as enum ('PENDENTE','EM_ANALISE','APROVADO','ATIVO','SUSPENSO','BLOQUEADO','INATIVO');
exception when duplicate_object then null; end $$;
do $$ begin
  create type status_documento as enum ('ENVIADO','EM_ANALISE','APROVADO','REPROVADO','VENCIDO');
exception when duplicate_object then null; end $$;
do $$ begin
  create type status_veiculo as enum ('PENDENTE','EM_ANALISE','APROVADO','REPROVADO','INATIVO');
exception when duplicate_object then null; end $$;

-- ---------- CIDADES (multi-cidade desde o dia 1) ----------
create table if not exists cidades (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  uf char(2) not null,
  slug text not null unique,
  fuso text not null default 'America/Sao_Paulo',
  ativa boolean not null default false,
  centro_lat float8,
  centro_lng float8,
  raio_atendimento_km numeric not null default 30,
  -- regras operacionais livres por cidade (sobrepõem as configurações globais)
  regras jsonb not null default '{}'::jsonb,
  -- exigências legais: documentos obrigatórios, idade máx. do veículo, EAR, etc.
  requisitos jsonb not null default '{"documentos_motorista":["CNH","SELFIE","ANTECEDENTES"],"documentos_veiculo":["CRLV","SEGURO"],"exige_ear":false,"idade_max_veiculo_anos":12}'::jsonb,
  tributos jsonb not null default '{}'::jsonb,       -- ISS, retenções, etc. (validar com contador)
  horario_operacao jsonb not null default '{}'::jsonb,
  regulamentacao text,                                -- lei/decreto municipal de referência
  criado_em timestamptz not null default now()
);

-- regra numérica da cidade, caindo na configuração global
create or replace function interno.regra_num(p_cidade uuid, p_chave text, p_padrao numeric)
returns numeric language sql stable as $$
  select coalesce(
    (select (regras ->> p_chave)::numeric from cidades where id = p_cidade),
    interno.cfg_num(p_chave, p_padrao))
$$;

-- ---------- CATEGORIAS (catálogo) e CONFIGURAÇÃO POR CIDADE ----------
create table if not exists categorias (
  codigo text primary key,
  nome text not null,
  descricao text,
  tipo_veiculo text not null default 'CARRO' check (tipo_veiculo in ('CARRO','MOTO','VAN')),
  capacidade_padrao int not null default 4,
  ordem int not null default 100,
  disponivel_no_sistema boolean not null default false   -- liga quando o produto estiver pronto
);

insert into categorias (codigo, nome, descricao, tipo_veiculo, capacidade_padrao, ordem, disponivel_no_sistema) values
  ('ECONOMICO','Econômico','Viagens do dia a dia pelo menor preço','CARRO',4,10,true),
  ('CONFORTO','Conforto','Carros mais novos e espaçosos','CARRO',4,20,true),
  ('PREMIUM','Premium','Carros de alto padrão','CARRO',4,30,true),
  ('SETE_LUGARES','7 lugares','Para grupos e bagagem','CARRO',6,40,false),
  ('MOTO','Moto','Quando permitido pela legislação local','MOTO',1,50,false),
  ('ACESSIVEL','Acessível','Veículo adaptado','CARRO',4,60,false),
  ('FAMILIAR','Familiar','Com cadeirinha infantil','CARRO',4,70,false),
  ('AEROPORTO','Aeroporto','Tarifa e regras de aeroporto','CARRO',4,80,false),
  ('INTERMUNICIPAL','Intermunicipal','Entre cidades','CARRO',4,90,false),
  ('AGENDADA','Agendada','Corrida marcada com antecedência','CARRO',4,100,false),
  ('COMPARTILHADA','Compartilhada','Divide a viagem e o preço','CARRO',4,110,false),
  ('CORPORATIVA','Corporativa','Conta de empresa','CARRO',4,120,false),
  ('EVENTOS','Eventos','Shows, jogos e eventos','CARRO',4,130,false),
  ('TERMINAL','Terminal','Rodoviária / porto','CARRO',4,140,false),
  ('VIAGENS','Viagens','Viagens longas','CARRO',4,150,false)
on conflict (codigo) do nothing;

create table if not exists cidade_categorias (
  cidade_id uuid not null references cidades(id) on delete cascade,
  categoria text not null references categorias(codigo),
  habilitada boolean not null default false,
  tarifa_base numeric(10,2) not null default 0,
  preco_km numeric(10,2) not null default 0,
  preco_minuto numeric(10,2) not null default 0,
  tarifa_minima numeric(10,2) not null default 0,
  taxa_cancelamento numeric(10,2) not null default 0,
  multiplicador_maximo numeric(4,2) not null default 1.0,   -- teto de preço dinâmico
  idade_max_veiculo_anos int,                               -- sobrepõe o da cidade
  requisitos jsonb not null default '{}'::jsonb,
  primary key (cidade_id, categoria),
  check (tarifa_base >= 0 and preco_km >= 0 and preco_minuto >= 0 and tarifa_minima >= 0)
);

-- ---------- PERFIL DO USUÁRIO ----------
create table if not exists perfis (
  id uuid primary key,                         -- = auth.users.id
  nome text not null,
  telefone text unique,
  email text,
  cpf text unique,                             -- só dígitos; acesso restrito (LGPD)
  foto_path text,
  status status_usuario not null default 'ATIVO',
  cidade_id uuid references cidades(id),
  codigo_indicacao text unique,
  criado_em timestamptz not null default now(),
  ultimo_acesso timestamptz,
  aceite_termos_em timestamptz,
  aceite_privacidade_em timestamptz,
  versao_termos text,
  check (cpf is null or cpf ~ '^\d{11}$')
);
create index if not exists perfis_cidade_idx on perfis (cidade_id);

drop trigger if exists perfis_auditar on perfis;
create trigger perfis_auditar after update or delete on perfis
  for each row execute function interno.trg_auditar();

-- ---------- DISPOSITIVOS (antifraude: contas no mesmo aparelho) ----------
create table if not exists dispositivos (
  usuario_id uuid not null references perfis(id) on delete cascade,
  dispositivo_id text not null,
  plataforma text,
  primeiro_acesso timestamptz not null default now(),
  ultimo_acesso timestamptz not null default now(),
  ultimo_ip text,
  push_token text,
  primary key (usuario_id, dispositivo_id)
);
create index if not exists dispositivos_disp_idx on dispositivos (dispositivo_id);

-- ---------- CONTATOS DE CONFIANÇA ----------
create table if not exists contatos_confianca (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references perfis(id) on delete cascade,
  nome text not null,
  telefone text not null,
  criado_em timestamptz not null default now()
);

-- ---------- MOTORISTA ----------
create table if not exists motoristas (
  id uuid primary key references perfis(id) on delete cascade,
  status status_motorista not null default 'PENDENTE',
  cidade_id uuid not null references cidades(id),
  cnh_numero text,
  cnh_categoria text,
  cnh_validade date,
  cnh_ear boolean not null default false,      -- "Exerce Atividade Remunerada"
  data_nascimento date,
  selfie_verificada_em timestamptz,
  veiculo_ativo_id uuid,
  avaliacao_media numeric(3,2) not null default 5.00,
  total_avaliacoes int not null default 0,
  total_corridas int not null default 0,
  total_cancelamentos int not null default 0,
  ofertas_recebidas int not null default 0,
  ofertas_aceitas int not null default 0,
  motivo_status text,
  aprovado_em timestamptz,
  aprovado_por uuid,
  criado_em timestamptz not null default now()
);
create index if not exists motoristas_cidade_status_idx on motoristas (cidade_id, status);

drop trigger if exists motoristas_auditar on motoristas;
create trigger motoristas_auditar after insert or update or delete on motoristas
  for each row execute function interno.trg_auditar();

-- ---------- VEÍCULO ----------
create table if not exists veiculos (
  id uuid primary key default gen_random_uuid(),
  motorista_id uuid not null references motoristas(id) on delete cascade,
  marca text not null,
  modelo text not null,
  ano int not null check (ano between 1980 and 2100),
  placa text not null unique check (placa ~ '^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$'),
  cor text not null,
  capacidade int not null default 4 check (capacidade between 1 and 15),
  acessivel boolean not null default false,
  cidade_id uuid not null references cidades(id),
  categorias_pedidas text[] not null default '{ECONOMICO}',
  categorias_aprovadas text[] not null default '{}',
  status status_veiculo not null default 'PENDENTE',
  motivo_status text,
  criado_em timestamptz not null default now()
);
create index if not exists veiculos_motorista_idx on veiculos (motorista_id);

drop trigger if exists veiculos_auditar on veiculos;
create trigger veiculos_auditar after insert or update or delete on veiculos
  for each row execute function interno.trg_auditar();

-- ---------- DOCUMENTOS (motorista e veículo) ----------
create table if not exists documentos (
  id uuid primary key default gen_random_uuid(),
  dono_tipo text not null check (dono_tipo in ('MOTORISTA','VEICULO')),
  dono_id uuid not null,
  motorista_id uuid not null references motoristas(id) on delete cascade,
  tipo text not null check (tipo in ('CNH','SELFIE','ANTECEDENTES','COMPROVANTE_RESIDENCIA','CRLV','SEGURO','INSPECAO','OUTRO')),
  arquivo_path text not null,                -- caminho no Storage (bucket privado)
  numero text,
  validade date,
  status status_documento not null default 'ENVIADO',
  analisado_por uuid,
  analisado_em timestamptz,
  motivo text,
  criado_em timestamptz not null default now()
);
create index if not exists documentos_dono_idx on documentos (dono_tipo, dono_id, tipo, criado_em desc);
create index if not exists documentos_status_idx on documentos (status, criado_em);

drop trigger if exists documentos_auditar on documentos;
create trigger documentos_auditar after update or delete on documentos
  for each row execute function interno.trg_auditar();

-- ============================================================
-- COMPLIANCE
-- ============================================================

-- último documento de cada tipo do dono
create or replace function interno.doc_vigente(p_dono_tipo text, p_dono uuid, p_tipo text)
returns documentos language sql stable as $$
  select * from documentos
  where dono_tipo = p_dono_tipo and dono_id = p_dono and tipo = p_tipo
  order by criado_em desc limit 1
$$;

-- devolve a lista de pendências. Lista vazia = pode rodar naquela categoria.
create or replace function interno.pendencias_motorista(p_motorista uuid, p_categoria text default null)
returns text[] language plpgsql stable security definer set search_path = public, interno, pg_temp as $$
declare
  m motoristas; v veiculos; c cidades; cc cidade_categorias;
  p perfis; d documentos; t text; pend text[] := '{}';
  v_idade_max int;
begin
  select * into m from motoristas where id = p_motorista;
  if not found then return array['NAO_E_MOTORISTA']; end if;
  select * into p from perfis where id = p_motorista;
  select * into c from cidades where id = m.cidade_id;

  if p.status <> 'ATIVO' then pend := pend || ('CONTA_' || p.status::text); end if;
  if m.status <> 'ATIVO' then pend := pend || ('MOTORISTA_' || m.status::text); end if;
  if not c.ativa then pend := pend || 'CIDADE_INATIVA'::text; end if;
  if m.cnh_validade is null or m.cnh_validade < current_date then pend := pend || 'CNH_VENCIDA'::text; end if;
  if coalesce((c.requisitos ->> 'exige_ear')::boolean, false) and not m.cnh_ear then pend := pend || 'CNH_SEM_EAR'::text; end if;
  if m.selfie_verificada_em is null then pend := pend || 'SELFIE_NAO_VERIFICADA'::text; end if;

  for t in select jsonb_array_elements_text(coalesce(c.requisitos -> 'documentos_motorista', '[]')) loop
    d := interno.doc_vigente('MOTORISTA', m.id, t);
    if d.id is null then pend := pend || ('DOC_FALTANDO_' || t);
    elsif d.status <> 'APROVADO' then pend := pend || ('DOC_' || d.status::text || '_' || t);
    elsif d.validade is not null and d.validade < current_date then pend := pend || ('DOC_VENCIDO_' || t);
    end if;
  end loop;

  select * into v from veiculos where id = m.veiculo_ativo_id;
  if v.id is null then
    pend := pend || 'SEM_VEICULO_ATIVO'::text;
  else
    if v.status <> 'APROVADO' then pend := pend || ('VEICULO_' || v.status::text); end if;
    if v.cidade_id <> m.cidade_id then pend := pend || 'VEICULO_OUTRO_MUNICIPIO'::text; end if;
    for t in select jsonb_array_elements_text(coalesce(c.requisitos -> 'documentos_veiculo', '[]')) loop
      d := interno.doc_vigente('VEICULO', v.id, t);
      if d.id is null then pend := pend || ('DOC_FALTANDO_' || t);
      elsif d.status <> 'APROVADO' then pend := pend || ('DOC_' || d.status::text || '_' || t);
      elsif d.validade is not null and d.validade < current_date then pend := pend || ('DOC_VENCIDO_' || t);
      end if;
    end loop;

    if p_categoria is not null then
      select * into cc from cidade_categorias where cidade_id = m.cidade_id and categoria = p_categoria;
      if cc.cidade_id is null or not cc.habilitada then pend := pend || ('CATEGORIA_INDISPONIVEL_NA_CIDADE_' || p_categoria); end if;
      if not (p_categoria = any(v.categorias_aprovadas)) then pend := pend || ('VEICULO_NAO_APROVADO_PARA_' || p_categoria); end if;
      v_idade_max := coalesce(cc.idade_max_veiculo_anos, (c.requisitos ->> 'idade_max_veiculo_anos')::int);
      if v_idade_max is not null and extract(year from current_date)::int - v.ano > v_idade_max then
        pend := pend || ('VEICULO_ACIMA_DA_IDADE_' || p_categoria);
      end if;
    end if;
  end if;
  return pend;
end $$;

-- categorias em que o motorista pode rodar agora
create or replace function interno.categorias_liberadas(p_motorista uuid)
returns text[] language sql stable security definer set search_path = public, interno, pg_temp as $$
  select coalesce(array_agg(cc.categoria order by cat.ordem), '{}')
  from motoristas m
  join cidade_categorias cc on cc.cidade_id = m.cidade_id and cc.habilitada
  join categorias cat on cat.codigo = cc.categoria and cat.disponivel_no_sistema
  where m.id = p_motorista
    and cardinality(interno.pendencias_motorista(p_motorista, cc.categoria)) = 0
$$;

-- ============================================================
-- RPC — CADASTRO E ACESSO
-- (login, senha, código por SMS, recuperação, sessão e logout
--  ficam com o Supabase Auth; aqui é o perfil da plataforma)
-- ============================================================

create or replace function interno.gerar_codigo_indicacao(p_nome text) returns text
language plpgsql volatile as $$
declare v text; base text;
begin
  base := upper(left(regexp_replace(translate(coalesce(p_nome,'X'),
    'áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ','aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC'), '[^A-Za-z]', '', 'g'), 5));
  loop
    v := base || lpad((floor(random() * 10000))::int::text, 4, '0');
    exit when not exists (select 1 from perfis where codigo_indicacao = v);
  end loop;
  return v;
end $$;

drop function if exists public.completar_cadastro(text, text, text, text, uuid, boolean, text, text, text);
create or replace function public.completar_cadastro(
  p_nome text, p_telefone text, p_cpf text, p_email text, p_cidade uuid,
  p_quer_ser_motorista boolean default false,
  p_codigo_indicacao text default null,
  p_dispositivo text default null,
  p_versao_termos text default 'v1'
) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare
  v_uid uuid := interno.exigir_login();
  v_cpf text := interno.so_digitos(p_cpf);
  v_tel text := interno.so_digitos(p_telefone);
  v_perfil perfis;
  v_aviso text;
begin
  perform interno.limitar('cadastro', 5, 3600);
  -- erros de validação são DEVOLVIDOS (não lançados): assim a tentativa conta no limite
  -- e ninguém usa o cadastro para descobrir em massa quais CPFs/telefones existem.
  if length(trim(coalesce(p_nome,''))) < 3 then return jsonb_build_object('ok', false, 'erro', 'NOME_INVALIDO'); end if;
  if not interno.cpf_valido(v_cpf) then return jsonb_build_object('ok', false, 'erro', 'CPF_INVALIDO'); end if;
  if length(v_tel) not between 10 and 13 then return jsonb_build_object('ok', false, 'erro', 'TELEFONE_INVALIDO'); end if;
  if not exists (select 1 from cidades where id = p_cidade) then return jsonb_build_object('ok', false, 'erro', 'CIDADE_INVALIDA'); end if;
  if exists (select 1 from perfis where (cpf = v_cpf or telefone = v_tel) and id <> v_uid) then
    -- mensagem genérica: não revela se foi o CPF ou o telefone
    return jsonb_build_object('ok', false, 'erro', 'DADOS_JA_CADASTRADOS');
  end if;

  insert into perfis (id, nome, telefone, email, cpf, cidade_id, codigo_indicacao,
                      aceite_termos_em, aceite_privacidade_em, versao_termos)
  values (v_uid, trim(p_nome), v_tel, lower(nullif(trim(p_email),'')), v_cpf, p_cidade,
          interno.gerar_codigo_indicacao(p_nome), now(), now(), p_versao_termos)
  on conflict (id) do update set
    nome = excluded.nome, email = excluded.email, cidade_id = excluded.cidade_id
  returning * into v_perfil;

  insert into usuario_papeis (usuario_id, papel) values (v_uid, 'PASSAGEIRO') on conflict do nothing;

  if p_dispositivo is not null then
    perform public.registrar_acesso(p_dispositivo, null, null);
  end if;

  if p_quer_ser_motorista then
    insert into motoristas (id, cidade_id) values (v_uid, p_cidade) on conflict (id) do nothing;
    insert into usuario_papeis (usuario_id, papel) values (v_uid, 'MOTORISTA') on conflict do nothing;
  end if;

  if p_codigo_indicacao is not null and length(trim(p_codigo_indicacao)) > 0 then
    -- código ruim não impede o cadastro: volta como aviso (e o sinal de risco fica gravado)
    v_aviso := interno.vincular_indicacao(v_uid, upper(trim(p_codigo_indicacao)), p_dispositivo);
  end if;

  perform interno.auditar_evento('CADASTRO', 'perfis', v_uid::text,
    jsonb_build_object('motorista', p_quer_ser_motorista, 'indicacao', p_codigo_indicacao, 'aviso_indicacao', v_aviso));
  return jsonb_build_object('ok', true, 'id', v_perfil.id, 'codigo_indicacao', v_perfil.codigo_indicacao, 'aviso_indicacao', v_aviso);
end $$;

-- chamado pelo app a cada login / abertura: atualiza último acesso,
-- registra o aparelho e grava o login na auditoria
create or replace function public.registrar_acesso(p_dispositivo text, p_plataforma text default null, p_push_token text default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_novo boolean;
begin
  perform interno.limitar('acesso', 30, 60);
  update perfis set ultimo_acesso = now() where id = v_uid;
  if p_dispositivo is not null then
    insert into dispositivos (usuario_id, dispositivo_id, plataforma, ultimo_ip, push_token)
    values (v_uid, p_dispositivo, p_plataforma, interno.ip_requisicao(), p_push_token)
    on conflict (usuario_id, dispositivo_id) do update set
      ultimo_acesso = now(), ultimo_ip = excluded.ultimo_ip,
      plataforma = coalesce(excluded.plataforma, dispositivos.plataforma),
      push_token = coalesce(excluded.push_token, dispositivos.push_token)
    returning (xmax = 0) into v_novo;
    -- mesmo aparelho usado por outras contas -> sinal de risco (nunca bloqueio automático)
    if v_novo and exists (select 1 from dispositivos where dispositivo_id = p_dispositivo and usuario_id <> v_uid) then
      perform interno.registrar_sinal('USUARIO', v_uid::text, 'DISPOSITIVO_COMPARTILHADO', 2,
        jsonb_build_object('dispositivo', p_dispositivo,
          'outras_contas', (select jsonb_agg(usuario_id) from dispositivos where dispositivo_id = p_dispositivo and usuario_id <> v_uid)));
    end if;
  end if;
  perform interno.auditar_evento('LOGIN', 'perfis', v_uid::text, jsonb_build_object('dispositivo', p_dispositivo, 'plataforma', p_plataforma));
end $$;

create or replace function public.meu_perfil() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'perfil', to_jsonb(p) - 'cpf' || jsonb_build_object('cpf_final', right(p.cpf, 3)),
    'papeis', (select coalesce(jsonb_agg(papel), '[]') from usuario_papeis where usuario_id = p.id and ativo),
    'motorista', (select to_jsonb(m) from motoristas m where m.id = p.id),
    'veiculos', (select coalesce(jsonb_agg(to_jsonb(v) order by v.criado_em desc), '[]') from veiculos v where v.motorista_id = p.id),
    'pendencias', case when exists (select 1 from motoristas where id = p.id)
                       then to_jsonb(interno.pendencias_motorista(p.id)) end,
    'categorias_liberadas', case when exists (select 1 from motoristas where id = p.id)
                       then to_jsonb(interno.categorias_liberadas(p.id)) end
  )
  from perfis p where p.id = auth.uid()
$$;

create or replace function public.salvar_contato_confianca(p_nome text, p_telefone text)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); v_id uuid;
begin
  if (select count(*) from contatos_confianca where usuario_id = v_uid) >= 5 then perform interno.erro('LIMITE_CONTATOS'); end if;
  insert into contatos_confianca (usuario_id, nome, telefone) values (v_uid, trim(p_nome), interno.so_digitos(p_telefone))
  returning id into v_id;
  return v_id;
end $$;

-- ============================================================
-- RPC — MOTORISTA: dados, veículo, documentos
-- ============================================================

create or replace function public.motorista_salvar_dados(p_cnh_numero text, p_cnh_categoria text, p_cnh_validade date, p_cnh_ear boolean, p_data_nascimento date)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_status status_motorista;
begin
  select status into v_status from motoristas where id = v_uid;
  if v_status not in ('PENDENTE','EM_ANALISE') then
    -- motorista já analisado não "se autodeclara": manda o documento novo e a operação atualiza
    perform interno.erro('ALTERACAO_VIA_DOCUMENTO', 'envie a nova CNH pelo app; a operação atualiza os dados');
  end if;
  if p_cnh_validade < current_date then perform interno.erro('CNH_VENCIDA'); end if;
  if p_data_nascimento > current_date - interval '18 years' then perform interno.erro('MENOR_DE_IDADE'); end if;
  if upper(p_cnh_categoria) !~ '[BCDE]' then perform interno.erro('CNH_CATEGORIA_INVALIDA'); end if;
  update motoristas set cnh_numero = interno.so_digitos(p_cnh_numero), cnh_categoria = upper(p_cnh_categoria),
    cnh_validade = p_cnh_validade, cnh_ear = p_cnh_ear, data_nascimento = p_data_nascimento,
    status = case when status = 'PENDENTE' then 'EM_ANALISE' else status end
  where id = v_uid;
end $$;

drop function if exists public.motorista_cadastrar_veiculo(text, text, int, text, text, int, boolean, text[]);
create or replace function public.motorista_cadastrar_veiculo(p_marca text, p_modelo text, p_ano int, p_placa text, p_cor text,
  p_capacidade int, p_acessivel boolean, p_categorias text[])
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_id uuid; v_placa text; v_cidade uuid;
begin
  perform interno.limitar('veiculo', 5, 3600);
  v_placa := upper(regexp_replace(coalesce(p_placa,''), '[^A-Za-z0-9]', '', 'g'));
  if v_placa !~ '^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$' then return jsonb_build_object('ok', false, 'erro', 'PLACA_INVALIDA'); end if;
  if exists (select 1 from veiculos where placa = v_placa) then
    perform interno.registrar_sinal('USUARIO', v_uid::text, 'PLACA_DUPLICADA', 3, jsonb_build_object('placa', v_placa));
    return jsonb_build_object('ok', false, 'erro', 'PLACA_JA_CADASTRADA');   -- devolve, não lança: o sinal fica gravado
  end if;
  select cidade_id into v_cidade from motoristas where id = v_uid;
  insert into veiculos (motorista_id, marca, modelo, ano, placa, cor, capacidade, acessivel, cidade_id, categorias_pedidas)
  values (v_uid, trim(p_marca), trim(p_modelo), p_ano, v_placa, trim(p_cor), coalesce(p_capacidade, 4), coalesce(p_acessivel, false),
          v_cidade, coalesce(p_categorias, '{ECONOMICO}'))
  returning id into v_id;
  update motoristas set veiculo_ativo_id = coalesce(veiculo_ativo_id, v_id) where id = v_uid;
  return jsonb_build_object('ok', true, 'veiculo', v_id);
end $$;

-- o arquivo sobe antes para o Storage (bucket privado "documentos"); aqui grava a referência
create or replace function public.motorista_enviar_documento(p_dono_tipo text, p_dono uuid, p_tipo text, p_arquivo_path text, p_numero text, p_validade date)
returns uuid language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_id uuid;
begin
  perform interno.limitar('documento', 30, 3600);
  if p_dono_tipo = 'MOTORISTA' and p_dono <> v_uid then perform interno.erro('SEM_PERMISSAO'); end if;
  if p_dono_tipo = 'VEICULO' and not exists (select 1 from veiculos where id = p_dono and motorista_id = v_uid) then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  if p_validade is not null and p_validade < current_date then perform interno.erro('DOCUMENTO_VENCIDO'); end if;
  -- arquivo precisa estar na pasta do próprio usuário: documentos/<uid>/...
  if p_arquivo_path not like v_uid::text || '/%' then perform interno.erro('CAMINHO_ARQUIVO_INVALIDO'); end if;

  insert into documentos (dono_tipo, dono_id, motorista_id, tipo, arquivo_path, numero, validade)
  values (p_dono_tipo, p_dono, v_uid, p_tipo, p_arquivo_path, p_numero, p_validade)
  returning id into v_id;
  update motoristas set status = 'EM_ANALISE' where id = v_uid and status = 'PENDENTE';
  update veiculos set status = 'EM_ANALISE' where id = p_dono and status = 'PENDENTE';
  return v_id;
end $$;

-- ============================================================
-- RPC — OPERAÇÕES (análise humana)
-- ============================================================

create or replace function public.ops_analisar_documento(p_documento uuid, p_aprovado boolean, p_motivo text default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); d documentos;
begin
  select * into d from documentos where id = p_documento for update;
  if not found then perform interno.erro('DOCUMENTO_NAO_ENCONTRADO'); end if;
  perform interno.sem_conflito(d.motorista_id);
  if not p_aprovado and coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  update documentos set status = case when p_aprovado then 'APROVADO' else 'REPROVADO' end::status_documento,
    analisado_por = v_uid, analisado_em = now(), motivo = p_motivo
  where id = p_documento;
  if p_aprovado and d.tipo = 'SELFIE' then
    update motoristas set selfie_verificada_em = now() where id = d.motorista_id;
  end if;
  perform interno.notificar(d.motorista_id, 'DOCUMENTO',
    case when p_aprovado then 'Documento aprovado' else 'Documento reprovado' end,
    d.tipo || case when p_aprovado then ' aprovado.' else ' reprovado: ' || p_motivo end, jsonb_build_object('documento', d.id));
end $$;

create or replace function public.ops_analisar_veiculo(p_veiculo uuid, p_aprovado boolean, p_categorias text[], p_motivo text default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}'); v veiculos;
begin
  select * into v from veiculos where id = p_veiculo for update;
  if not found then perform interno.erro('VEICULO_NAO_ENCONTRADO'); end if;
  perform interno.sem_conflito(v.motorista_id);
  if not p_aprovado and coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  update veiculos set
    status = case when p_aprovado then 'APROVADO' else 'REPROVADO' end::status_veiculo,
    categorias_aprovadas = case when p_aprovado then coalesce(p_categorias, categorias_pedidas) else '{}' end,
    motivo_status = p_motivo
  where id = p_veiculo;
  perform interno.notificar(v.motorista_id, 'DOCUMENTO',
    case when p_aprovado then 'Veículo aprovado' else 'Veículo reprovado' end,
    v.placa || case when p_aprovado then ' aprovado.' else ': ' || p_motivo end, jsonb_build_object('veiculo', v.id));
end $$;

-- mudança de status do motorista: sempre por humano, com motivo e auditoria
create or replace function public.ops_alterar_status_motorista(p_motorista uuid, p_status status_motorista, p_motivo text)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid; m motoristas; v_pend text[];
begin
  if p_status in ('BLOQUEADO') then
    v_uid := interno.exigir_papel('{RISCO,ADMIN}');
  else
    v_uid := interno.exigir_papel('{OPERACOES,RISCO,ADMIN}');
  end if;
  if coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  perform interno.sem_conflito(p_motorista);
  select * into m from motoristas where id = p_motorista for update;
  if not found then perform interno.erro('MOTORISTA_NAO_ENCONTRADO'); end if;

  if p_status = 'ATIVO' then
    -- para ativar, tudo precisa estar em dia (exceto o próprio status)
    v_pend := array_remove(interno.pendencias_motorista(p_motorista), 'MOTORISTA_' || m.status::text);
    if cardinality(v_pend) > 0 then perform interno.erro('PENDENCIAS_DE_COMPLIANCE', array_to_string(v_pend, ',')); end if;
  end if;

  update motoristas set status = p_status, motivo_status = p_motivo,
    aprovado_em = case when p_status in ('APROVADO','ATIVO') and aprovado_em is null then now() else aprovado_em end,
    aprovado_por = case when p_status in ('APROVADO','ATIVO') then v_uid else aprovado_por end
  where id = p_motorista;

  -- tirou do ar? derruba a presença
  if p_status not in ('ATIVO') then
    update motorista_presenca set online = false, disponivel = false where motorista_id = p_motorista;
  end if;

  perform interno.auditar_evento('STATUS_MOTORISTA', 'motoristas', p_motorista::text,
    jsonb_build_object('de', m.status, 'para', p_status, 'motivo', p_motivo));
  perform interno.notificar(p_motorista, 'DOCUMENTO', 'Status da sua conta', 'Seu cadastro agora está: ' || p_status::text, '{}');
  return jsonb_build_object('status', p_status);
end $$;

create or replace function public.ops_atualizar_cnh(p_motorista uuid, p_cnh_numero text, p_cnh_categoria text, p_cnh_validade date, p_cnh_ear boolean)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{OPERACOES,ADMIN}');
begin
  perform interno.sem_conflito(p_motorista);
  update motoristas set cnh_numero = interno.so_digitos(p_cnh_numero), cnh_categoria = upper(p_cnh_categoria),
    cnh_validade = p_cnh_validade, cnh_ear = p_cnh_ear where id = p_motorista;
  if not found then perform interno.erro('MOTORISTA_NAO_ENCONTRADO'); end if;
end $$;

-- job diário: marca documentos vencidos e avisa antes de vencer
create or replace function interno.job_documentos() returns int
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare n int; r record;
begin
  update documentos set status = 'VENCIDO'
  where status = 'APROVADO' and validade is not null and validade < current_date;
  get diagnostics n = row_count;
  for r in select distinct d.motorista_id, d.tipo, d.validade from documentos d
           where d.status = 'APROVADO' and d.validade = current_date + 15 loop
    perform interno.notificar(r.motorista_id, 'DOCUMENTO', 'Documento vence em 15 dias',
      r.tipo || ' vence em ' || to_char(r.validade, 'DD/MM/YYYY') || '. Envie o novo para não ficar sem rodar.', '{}');
  end loop;
  -- quem ficou irregular sai do ar (não é punição: é exigência legal)
  update motorista_presenca mp set online = false, disponivel = false
  where online and not exists (select 1 from corridas c where c.motorista_id = mp.motorista_id and c.status in ('A_CAMINHO','CHEGOU','EM_CURSO'))
    and cardinality(interno.categorias_liberadas(mp.motorista_id)) = 0;
  return n;
end $$;
