-- ============================================================
-- 0004 — FINANCEIRO: comissões configuráveis, ledger (partidas
--        dobradas, imutável), pagamentos idempotentes, webhooks,
--        carteira, indicação em 3 níveis, repasses, estornos
-- ============================================================

do $$ begin
  create type status_pagamento as enum ('PENDENTE','AUTORIZADO','CONFIRMADO','FALHOU','CANCELADO','ESTORNADO');
exception when duplicate_object then null; end $$;
do $$ begin
  create type status_ganho as enum ('PENDENTE','DISPONIVEL','PAGO','BLOQUEADO','ESTORNADO');
exception when duplicate_object then null; end $$;

-- ============================================================
-- REGRAS DE COMISSÃO (nada fixo no código)
-- ============================================================
-- A regra mais ESPECÍFICA vence (motorista > cidade+categoria > cidade > global),
-- depois a de maior prioridade. Permite regra por cidade, categoria,
-- motorista, dia da semana, horário, campanha e período.
create table if not exists regras_comissao (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  ativa boolean not null default true,
  prioridade int not null default 0,
  cidade_id uuid references cidades(id),
  categoria text references categorias(codigo),
  motorista_id uuid references motoristas(id),
  campanha text,
  dias_semana int[],                  -- 1=seg ... 7=dom
  hora_inicio time, hora_fim time,    -- no fuso da cidade
  vigencia_inicio timestamptz, vigencia_fim timestamptz,
  taxa_plataforma_pct numeric(5,2) not null,
  indicacao_n1_pct numeric(5,2) not null default 0,
  indicacao_n2_pct numeric(5,2) not null default 0,
  indicacao_n3_pct numeric(5,2) not null default 0,
  criado_por uuid,
  criado_em timestamptz not null default now(),
  check (taxa_plataforma_pct between 0 and 60),
  check (indicacao_n1_pct >= 0 and indicacao_n2_pct >= 0 and indicacao_n3_pct >= 0),
  check (indicacao_n1_pct + indicacao_n2_pct + indicacao_n3_pct <= taxa_plataforma_pct)
);
drop trigger if exists regras_comissao_auditar on regras_comissao;
create trigger regras_comissao_auditar after insert or update or delete on regras_comissao
  for each row execute function interno.trg_auditar();

create or replace function interno.resolver_comissao(p_cidade uuid, p_categoria text, p_motorista uuid, p_momento timestamptz default now())
returns regras_comissao language sql stable as $$
  select r.* from regras_comissao r
  left join cidades c on c.id = p_cidade
  where r.ativa
    and (r.vigencia_inicio is null or r.vigencia_inicio <= p_momento)
    and (r.vigencia_fim is null or r.vigencia_fim > p_momento)
    and (r.cidade_id is null or r.cidade_id = p_cidade)
    and (r.categoria is null or r.categoria = p_categoria)
    and (r.motorista_id is null or r.motorista_id = p_motorista)
    and (r.dias_semana is null or extract(isodow from p_momento at time zone coalesce(c.fuso, 'America/Sao_Paulo'))::int = any(r.dias_semana))
    and (r.hora_inicio is null or (
          case when r.hora_fim >= r.hora_inicio
               then (p_momento at time zone coalesce(c.fuso, 'America/Sao_Paulo'))::time between r.hora_inicio and r.hora_fim
               else (p_momento at time zone coalesce(c.fuso, 'America/Sao_Paulo'))::time >= r.hora_inicio
                 or (p_momento at time zone coalesce(c.fuso, 'America/Sao_Paulo'))::time <= r.hora_fim end))
  order by ((r.motorista_id is not null)::int * 8 + (r.cidade_id is not null)::int * 4 + (r.categoria is not null)::int * 2
            + (r.dias_semana is not null or r.hora_inicio is not null or r.campanha is not null)::int) desc,
           r.prioridade desc, r.criado_em desc
  limit 1
$$;

-- ============================================================
-- LEDGER — partidas dobradas, nunca apaga, nunca altera
-- ============================================================
-- Cada transação tem lançamentos que SOMAM ZERO.
-- Saldo de qualquer conta = soma dos lançamentos dela.
-- Correção = nova transação reversora.
create table if not exists contas_ledger (
  id uuid primary key default gen_random_uuid(),
  titular_id uuid,                 -- null = conta da plataforma
  tipo text not null check (tipo in (
    'MOTORISTA_PENDENTE','MOTORISTA_DISPONIVEL',
    'INDICACAO_PENDENTE','INDICACAO_DISPONIVEL',
    'PASSAGEIRO_CARTEIRA',
    'PLATAFORMA_RECEITA','PLATAFORMA_PROMOCOES','INDICACAO_RETIDA',
    'GATEWAY_RECEBIVEIS','REPASSES_EM_PROCESSAMENTO','REPASSES_PAGOS')),
  criado_em timestamptz not null default now()
);
create unique index if not exists contas_ledger_unq on contas_ledger (coalesce(titular_id, '00000000-0000-0000-0000-000000000000'::uuid), tipo);

create table if not exists transacoes_ledger (
  id uuid primary key default gen_random_uuid(),
  tipo text not null,
  referencia text,
  chave_idempotencia text not null unique,
  descricao text,
  reverte_transacao_id uuid unique references transacoes_ledger(id),
  criado_por uuid,
  criado_em timestamptz not null default clock_timestamp()
);

create table if not exists lancamentos_ledger (
  id bigint generated always as identity primary key,
  transacao_id uuid not null references transacoes_ledger(id),
  conta_id uuid not null references contas_ledger(id),
  valor numeric(14,2) not null check (valor <> 0),
  criado_em timestamptz not null default clock_timestamp()
);
create index if not exists lancamentos_conta_idx on lancamentos_ledger (conta_id, id desc);
create index if not exists lancamentos_transacao_idx on lancamentos_ledger (transacao_id);

-- saldo materializado (atualizado no mesmo commit; a linha é travada em saques)
create table if not exists saldos (
  conta_id uuid primary key references contas_ledger(id),
  saldo numeric(14,2) not null default 0,
  atualizado_em timestamptz not null default now()
);

drop trigger if exists transacoes_imutavel on transacoes_ledger;
create trigger transacoes_imutavel before update or delete on transacoes_ledger for each row execute function interno.trg_imutavel();
drop trigger if exists lancamentos_imutavel on lancamentos_ledger;
create trigger lancamentos_imutavel before update or delete on lancamentos_ledger for each row execute function interno.trg_imutavel();

create or replace function interno.trg_saldo() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_saldo numeric;
begin
  insert into saldos (conta_id, saldo) values (new.conta_id, new.valor)
  on conflict (conta_id) do update set saldo = saldos.saldo + excluded.saldo, atualizado_em = now()
  returning saldo into v_saldo;
  -- créditos do passageiro nunca ficam negativos (protege contra gasto duplo)
  if v_saldo < 0 and new.valor < 0 and exists (select 1 from contas_ledger where id = new.conta_id and tipo = 'PASSAGEIRO_CARTEIRA') then
    raise exception using errcode = 'P0001', message = 'SALDO_INSUFICIENTE';
  end if;
  return new;
end $$;
drop trigger if exists lancamentos_saldo on lancamentos_ledger;
create trigger lancamentos_saldo after insert on lancamentos_ledger for each row execute function interno.trg_saldo();

-- conferência no COMMIT: toda transação tem que fechar em zero.
-- SECURITY DEFINER é obrigatório: trigger adiado roda no commit, já fora da
-- função protegida, com o papel do usuário (que não enxerga o ledger pelo RLS).
create or replace function interno.trg_partida_dobrada() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_soma numeric;
begin
  select sum(valor) into v_soma from lancamentos_ledger where transacao_id = new.transacao_id;
  if v_soma <> 0 then
    raise exception using errcode = 'P0001', message = 'LEDGER_DESBALANCEADO', detail = new.transacao_id::text || ' soma ' || v_soma;
  end if;
  return null;
end $$;
drop trigger if exists lancamentos_partida_dobrada on lancamentos_ledger;
create constraint trigger lancamentos_partida_dobrada after insert on lancamentos_ledger
  deferrable initially deferred for each row execute function interno.trg_partida_dobrada();

create or replace function interno.conta(p_titular uuid, p_tipo text) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare v uuid;
begin
  select id into v from contas_ledger where coalesce(titular_id, '00000000-0000-0000-0000-000000000000'::uuid)
    = coalesce(p_titular, '00000000-0000-0000-0000-000000000000'::uuid) and tipo = p_tipo;
  if v is null then
    insert into contas_ledger (titular_id, tipo) values (p_titular, p_tipo) on conflict do nothing returning id into v;
    if v is null then
      select id into v from contas_ledger where coalesce(titular_id, '00000000-0000-0000-0000-000000000000'::uuid)
        = coalesce(p_titular, '00000000-0000-0000-0000-000000000000'::uuid) and tipo = p_tipo;
    end if;
  end if;
  return v;
end $$;

create or replace function interno.saldo(p_titular uuid, p_tipo text) returns numeric
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((select s.saldo from saldos s join contas_ledger c on c.id = s.conta_id
    where coalesce(c.titular_id, '00000000-0000-0000-0000-000000000000'::uuid) = coalesce(p_titular, '00000000-0000-0000-0000-000000000000'::uuid)
      and c.tipo = p_tipo), 0)
$$;

-- trava a linha de saldo (cria se não existir) e devolve o valor atual
create or replace function interno.travar_saldo(p_titular uuid, p_tipo text) returns numeric
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_conta uuid := interno.conta(p_titular, p_tipo); v numeric;
begin
  insert into saldos (conta_id, saldo) values (v_conta, 0) on conflict do nothing;
  select saldo into v from saldos where conta_id = v_conta for update;
  return v;
end $$;

-- grava uma transação. p_linhas = [{"titular": uuid|null, "conta": "TIPO", "valor": 12.34}, ...]
-- Idempotente: a mesma chave nunca lança duas vezes (devolve a transação existente).
create or replace function interno.lancar(p_tipo text, p_referencia text, p_chave text, p_descricao text, p_linhas jsonb,
  p_reverte uuid default null) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_id uuid; l jsonb; v_soma numeric := 0; v_val numeric;
begin
  insert into transacoes_ledger (tipo, referencia, chave_idempotencia, descricao, reverte_transacao_id, criado_por)
  values (p_tipo, p_referencia, p_chave, p_descricao, p_reverte, auth.uid())
  on conflict (chave_idempotencia) do nothing
  returning id into v_id;
  if v_id is null then
    select id into v_id from transacoes_ledger where chave_idempotencia = p_chave;
    return v_id;   -- já lançado antes: não duplica
  end if;
  for l in select * from jsonb_array_elements(p_linhas) loop
    v_val := round((l ->> 'valor')::numeric, 2);
    if v_val <> 0 then
      insert into lancamentos_ledger (transacao_id, conta_id, valor)
      values (v_id, interno.conta(nullif(l ->> 'titular', '')::uuid, l ->> 'conta'), v_val);
      v_soma := v_soma + v_val;
    end if;
  end loop;
  if v_soma <> 0 then perform interno.erro('LEDGER_DESBALANCEADO', p_chave || ' soma ' || v_soma); end if;
  return v_id;
end $$;

-- reverte uma transação inteira (correção). Nunca apaga a original.
create or replace function interno.reverter(p_transacao uuid, p_motivo text) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare t transacoes_ledger; v_linhas jsonb;
begin
  select * into t from transacoes_ledger where id = p_transacao;
  if not found then perform interno.erro('TRANSACAO_NAO_ENCONTRADA'); end if;
  select jsonb_agg(jsonb_build_object('titular', c.titular_id, 'conta', c.tipo, 'valor', -l.valor)) into v_linhas
  from lancamentos_ledger l join contas_ledger c on c.id = l.conta_id where l.transacao_id = p_transacao;
  return interno.lancar('REVERSAO', t.referencia, 'REV:' || p_transacao, 'Reversão: ' || coalesce(p_motivo, ''), v_linhas, p_transacao);
end $$;

-- ============================================================
-- PAGAMENTOS — idempotentes, um identificador único por pagamento
-- ============================================================
create table if not exists pagamentos (
  id uuid primary key default gen_random_uuid(),     -- identificador único enviado ao gateway
  corrida_id uuid references corridas(id),
  pagador_id uuid not null references perfis(id),
  tipo text not null check (tipo in ('CORRIDA','GORJETA','TAXA_CANCELAMENTO','RECARGA')),
  metodo metodo_pagamento not null,
  valor numeric(10,2) not null check (valor > 0),
  status status_pagamento not null default 'PENDENTE',
  chave_idempotencia text not null unique,
  gateway text,
  gateway_ref text,
  motivo_falha text,
  transacao_ledger_id uuid references transacoes_ledger(id),
  criado_em timestamptz not null default now(),
  confirmado_em timestamptz,
  estornado_em timestamptz
);
create unique index if not exists pagamentos_gateway_ref_unq on pagamentos (gateway, gateway_ref) where gateway_ref is not null;
create unique index if not exists um_pagamento_ativo_por_corrida on pagamentos (corrida_id, tipo)
  where status not in ('FALHOU','CANCELADO') and tipo in ('CORRIDA','TAXA_CANCELAMENTO','GORJETA');
create index if not exists pagamentos_status_idx on pagamentos (status, criado_em);
drop trigger if exists pagamentos_auditar on pagamentos;
create trigger pagamentos_auditar after insert or update on pagamentos for each row execute function interno.trg_auditar();

-- webhook repetido não processa duas vezes
create table if not exists webhooks_recebidos (
  gateway text not null,
  evento_id text not null,
  tipo text,
  payload jsonb,
  recebido_em timestamptz not null default now(),
  processado_em timestamptz,
  resultado jsonb,
  primary key (gateway, evento_id)
);

-- cupons (estrutura pronta; aplicação na etapa 2)
create table if not exists cupons (
  codigo text primary key,
  tipo text not null check (tipo in ('PERCENTUAL','VALOR')),
  valor numeric(10,2) not null check (valor > 0),
  desconto_maximo numeric(10,2),
  cidade_id uuid references cidades(id),
  categoria text references categorias(codigo),
  validade_inicio timestamptz, validade_fim timestamptz,
  usos_maximos int, usos_por_usuario int not null default 1,
  somente_primeira_corrida boolean not null default false,
  ativo boolean not null default true,
  criado_por uuid, criado_em timestamptz not null default now()
);
create table if not exists cupom_usos (
  cupom_codigo text not null references cupons(codigo),
  usuario_id uuid not null,
  corrida_id uuid references corridas(id),
  desconto numeric(10,2) not null,
  usado_em timestamptz not null default now(),
  primary key (cupom_codigo, usuario_id, corrida_id)
);

-- ganho do motorista aguardando liberação (D+N)
create table if not exists recebiveis (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid references corridas(id),
  pagamento_id uuid references pagamentos(id),
  motorista_id uuid not null references motoristas(id),
  tipo text not null default 'CORRIDA' check (tipo in ('CORRIDA','GORJETA','TAXA_CANCELAMENTO')),
  valor numeric(10,2) not null,
  status status_ganho not null default 'PENDENTE',
  libera_em timestamptz not null,
  liberado_em timestamptz,
  criado_em timestamptz not null default now(),
  unique (pagamento_id)
);
create index if not exists recebiveis_liberacao_idx on recebiveis (status, libera_em);

-- ============================================================
-- INDICAÇÃO — árvore de até 3 níveis
-- ============================================================
create table if not exists indicacoes (
  indicado_id uuid primary key references perfis(id),      -- cada pessoa tem no máximo 1 indicador
  indicador_id uuid not null references perfis(id),
  codigo_usado text not null,
  status text not null default 'ATIVA' check (status in ('ATIVA','EM_ANALISE','BLOQUEADA')),
  motivo text,
  criado_em timestamptz not null default now(),
  check (indicado_id <> indicador_id)
);
create index if not exists indicacoes_indicador_idx on indicacoes (indicador_id);
drop trigger if exists indicacoes_auditar on indicacoes;
create trigger indicacoes_auditar after insert or update or delete on indicacoes for each row execute function interno.trg_auditar();

create table if not exists ganhos_indicacao (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid not null references corridas(id),
  beneficiario_id uuid not null references perfis(id),
  indicado_id uuid not null references perfis(id),        -- motorista que fez a corrida
  nivel int not null check (nivel between 1 and 3),
  percentual numeric(5,2) not null,
  valor numeric(10,2) not null,
  status status_ganho not null,
  motivo text,
  libera_em timestamptz,
  liberado_em timestamptz,
  pago_em timestamptz,
  criado_em timestamptz not null default now(),
  unique (corrida_id, nivel)
);
create index if not exists ganhos_benef_idx on ganhos_indicacao (beneficiario_id, criado_em desc);
create index if not exists ganhos_liberacao_idx on ganhos_indicacao (status, libera_em);
drop trigger if exists ganhos_indicacao_auditar on ganhos_indicacao;
create trigger ganhos_indicacao_auditar after update on ganhos_indicacao for each row execute function interno.trg_auditar();

-- ancestrais de alguém na árvore (nível 1 = quem indicou diretamente)
create or replace function interno.cadeia_indicacao(p_usuario uuid, p_niveis int default 3)
returns table (nivel int, beneficiario_id uuid, status text)
language sql stable as $$
  with recursive arvore as (
    select 1 as nivel, i.indicador_id, i.status, array[i.indicado_id, i.indicador_id] as caminho
    from indicacoes i where i.indicado_id = p_usuario
    union all
    select a.nivel + 1, i.indicador_id, i.status, a.caminho || i.indicador_id
    from arvore a join indicacoes i on i.indicado_id = a.indicador_id
    where a.nivel < p_niveis and not (i.indicador_id = any(a.caminho))
  )
  select nivel, indicador_id, status from arvore order by nivel
$$;

-- trava de banco contra ciclo (A indica B, B indica A ...), com qualquer profundidade
create or replace function interno.trg_indicacao_sem_ciclo() returns trigger language plpgsql as $$
begin
  if exists (
    with recursive sobe as (
      select new.indicador_id as id, 1 as n
      union all
      select i.indicador_id, s.n + 1 from sobe s join indicacoes i on i.indicado_id = s.id where s.n < 1000
    ) select 1 from sobe where id = new.indicado_id
  ) then
    raise exception using errcode = 'P0001', message = 'CICLO_INDICACAO';
  end if;
  return new;
end $$;
drop trigger if exists indicacoes_sem_ciclo on indicacoes;
create trigger indicacoes_sem_ciclo before insert or update on indicacoes for each row execute function interno.trg_indicacao_sem_ciclo();

-- ============================================================
-- REPASSES (saque)
-- ============================================================
create table if not exists repasses (
  id uuid primary key default gen_random_uuid(),
  motorista_id uuid not null references motoristas(id),
  origem text not null check (origem in ('GANHOS','INDICACAO')),
  valor numeric(10,2) not null check (valor > 0),
  chave_pix text not null,
  status text not null default 'SOLICITADO' check (status in ('SOLICITADO','PROCESSANDO','PAGO','FALHOU')),
  chave_idempotencia text not null unique,
  gateway_ref text,
  motivo_falha text,
  solicitado_em timestamptz not null default now(),
  concluido_em timestamptz
);
create index if not exists repasses_motorista_idx on repasses (motorista_id, solicitado_em desc);
create index if not exists repasses_pix_idx on repasses (chave_pix);
drop trigger if exists repasses_auditar on repasses;
create trigger repasses_auditar after insert or update on repasses for each row execute function interno.trg_auditar();

create or replace function interno.contas_relacionadas(a uuid, b uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_strip_nulls(jsonb_build_object(
    'dispositivo', (select jsonb_agg(distinct d1.dispositivo_id) from dispositivos d1 join dispositivos d2 on d1.dispositivo_id = d2.dispositivo_id
                    where d1.usuario_id = a and d2.usuario_id = b),
    'ip', (select jsonb_agg(distinct d1.ultimo_ip) from dispositivos d1 join dispositivos d2 on d1.ultimo_ip = d2.ultimo_ip
           where d1.usuario_id = a and d2.usuario_id = b and d1.ultimo_ip is not null),
    'chave_pix', (select jsonb_agg(distinct r1.chave_pix) from repasses r1 join repasses r2 on r1.chave_pix = r2.chave_pix
                  where r1.motorista_id = a and r2.motorista_id = b)
  ))
$$;

drop function if exists interno.vincular_indicacao(uuid, text, text);
create or replace function interno.vincular_indicacao(p_indicado uuid, p_codigo text, p_dispositivo text default null)
returns text language plpgsql security definer set search_path = public, interno, pg_temp as $$
-- devolve NULL quando vinculou, ou o código do problema. Não lança erro de propósito:
-- se lançasse, o sinal de risco gravado antes seria desfeito junto (rollback).
declare v_indicador uuid; v_rel jsonb; v_status text := 'ATIVA';
begin
  select id into v_indicador from perfis where codigo_indicacao = upper(p_codigo);
  if v_indicador is null then return 'CODIGO_INDICACAO_INVALIDO'; end if;
  if v_indicador = p_indicado then
    perform interno.registrar_sinal('USUARIO', p_indicado::text, 'AUTOINDICACAO', 3, jsonb_build_object('codigo', p_codigo));
    return 'AUTOINDICACAO';
  end if;
  if exists (select 1 from indicacoes where indicado_id = p_indicado) then return 'JA_POSSUI_INDICADOR'; end if;
  if exists (select 1 from corridas where motorista_id = p_indicado and status in ('FINALIZADA','PAGA')) then
    return 'INDICACAO_FORA_DO_PRAZO';
  end if;
  if exists (select 1 from interno.cadeia_indicacao(v_indicador, 1000) where beneficiario_id = p_indicado) then
    perform interno.registrar_sinal('USUARIO', p_indicado::text, 'CICLO_INDICACAO', 4, jsonb_build_object('indicador', v_indicador));
    return 'CICLO_INDICACAO';
  end if;
  -- contas relacionadas (mesmo aparelho, IP, chave PIX): vincula, mas EM ANÁLISE
  v_rel := interno.contas_relacionadas(p_indicado, v_indicador);
  if v_rel <> '{}'::jsonb then
    v_status := 'EM_ANALISE';
    perform interno.registrar_sinal('INDICACAO', p_indicado::text, 'CONTA_RELACIONADA', 3,
      jsonb_build_object('indicador', v_indicador, 'indicado', p_indicado, 'evidencias', v_rel));
  end if;
  insert into indicacoes (indicado_id, indicador_id, codigo_usado, status, motivo)
  values (p_indicado, v_indicador, upper(p_codigo), v_status, case when v_status <> 'ATIVA' then 'Contas relacionadas: revisão humana' end);
  perform interno.notificar(v_indicador, 'INDICACAO', 'Nova indicação',
    'Alguém se cadastrou com o seu código. O bônus começa quando a pessoa fizer corridas válidas.', '{}');
  return case when v_status = 'ATIVA' then null else 'INDICACAO_EM_ANALISE' end;
end $$;


-- ============================================================
-- COBRANÇA E LIQUIDAÇÃO
-- ============================================================

create or replace function interno.cobrar_corrida(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; p pagamentos; v_valor numeric; v_metodo metodo_pagamento;
begin
  select * into c from corridas where id = p_corrida for update;
  v_valor := c.preco_final - c.desconto;
  v_metodo := c.metodo_pagamento;
  if v_metodo = 'CARTEIRA' and interno.travar_saldo(c.passageiro_id, 'PASSAGEIRO_CARTEIRA') < v_valor then
    v_metodo := 'PIX';   -- saldo insuficiente: cobra por PIX (e avisa)
  end if;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p_corrida, c.passageiro_id, 'CORRIDA', v_metodo, v_valor, 'CORRIDA:' || p_corrida)
  on conflict (chave_idempotencia) do nothing
  returning * into p;
  if p.id is null then
    select * into p from pagamentos where chave_idempotencia = 'CORRIDA:' || p_corrida;
    return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'metodo', p.metodo, 'repetido', true);
  end if;

  if v_metodo in ('DINHEIRO','CARTEIRA') then
    -- dinheiro: o motorista já recebeu na mão | carteira: débito interno imediato
    return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor);
  end if;
  perform interno.notificar(c.passageiro_id, 'PAGAMENTO', 'Pagamento da corrida',
    'Valor: R$ ' || to_char(v_valor, 'FM999990D00') || case when v_metodo = 'PIX' then ' · pague pelo PIX' else '' end,
    jsonb_build_object('pagamento', p.id, 'corrida', p_corrida));
  return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'metodo', p.metodo);
end $$;

create or replace function interno.cobrar_taxa_cancelamento(p_corrida uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare c corridas; p pagamentos; v_metodo metodo_pagamento;
begin
  select * into c from corridas where id = p_corrida;
  if coalesce(c.taxa_cancelamento, 0) <= 0 or c.motorista_id is null and c.cancelado_por = 'PASSAGEIRO' and c.aceita_em is null then return null; end if;
  v_metodo := case when c.metodo_pagamento = 'DINHEIRO' then 'PIX'
                   when c.metodo_pagamento = 'CARTEIRA' and interno.travar_saldo(c.passageiro_id, 'PASSAGEIRO_CARTEIRA') < c.taxa_cancelamento then 'PIX'
                   else c.metodo_pagamento end;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p_corrida, c.passageiro_id, 'TAXA_CANCELAMENTO', v_metodo, c.taxa_cancelamento, 'TAXA_CANC:' || p_corrida)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then return null; end if;
  if v_metodo = 'CARTEIRA' then
    return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor);
  end if;
  return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor);
end $$;

-- coração do pagamento: idempotente, trava a linha, confere valor
create or replace function interno.confirmar_pagamento(p_pagamento uuid, p_gateway text, p_gateway_ref text, p_valor numeric)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare p pagamentos; c corridas; v_tx uuid; r regras_comissao; v_motorista_val numeric; v_origem text;
begin
  select * into p from pagamentos where id = p_pagamento for update;
  if not found then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  if p.status = 'CONFIRMADO' then
    return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'repetido', true);
  end if;
  if p.status in ('ESTORNADO','CANCELADO') then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'CONFIRMACAO_APOS_CANCELAMENTO', 3, jsonb_build_object('gateway_ref', p_gateway_ref));
    return jsonb_build_object('id', p.id, 'status', p.status, 'erro', 'PAGAMENTO_NAO_CONFIRMAVEL');
  end if;
  if round(p_valor, 2) <> p.valor then
    perform interno.registrar_sinal('PAGAMENTO', p.id::text, 'VALOR_DIVERGENTE', 4,
      jsonb_build_object('esperado', p.valor, 'recebido', p_valor, 'gateway_ref', p_gateway_ref));
    return jsonb_build_object('id', p.id, 'status', p.status, 'erro', 'VALOR_DIVERGENTE');
  end if;

  update pagamentos set status = 'CONFIRMADO', gateway = p_gateway, gateway_ref = p_gateway_ref, confirmado_em = now()
  where id = p.id;
  v_origem := case when p.metodo = 'DINHEIRO' then 'DINHEIRO' when p.metodo = 'CARTEIRA' then 'CARTEIRA' else 'GATEWAY' end;

  if p.tipo = 'CORRIDA' then
    v_tx := interno.liquidar_corrida(p.corrida_id, p.id, v_origem);

  elsif p.tipo = 'GORJETA' then
    select * into c from corridas where id = p.corrida_id;
    v_tx := interno.lancar('GORJETA', p.corrida_id::text, 'GORJETA:' || p.id, 'Gorjeta (100% para o motorista)',
      jsonb_build_array(
        case when v_origem = 'CARTEIRA' then jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -p.valor)
             else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor) end,
        jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', p.valor)));
    insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
    values (p.corrida_id, p.id, c.motorista_id, 'GORJETA', p.valor, now() + make_interval(days => interno.cfg_num('motorista_liberacao_dias', 1)::int))
    on conflict (pagamento_id) do nothing;
    perform interno.notificar(c.motorista_id, 'PAGAMENTO', 'Você recebeu uma gorjeta!', 'R$ ' || to_char(p.valor, 'FM999990D00'), jsonb_build_object('corrida', c.id));

  elsif p.tipo = 'TAXA_CANCELAMENTO' then
    select * into c from corridas where id = p.corrida_id;
    r := interno.resolver_comissao(c.cidade_id, c.categoria, c.motorista_id, c.solicitada_em);
    v_motorista_val := case when c.motorista_id is null then 0 else p.valor - round(p.valor * coalesce(r.taxa_plataforma_pct, 0) / 100, 2) end;
    v_tx := interno.lancar('TAXA_CANCELAMENTO', p.corrida_id::text, 'TAXA:' || p.id, 'Taxa de cancelamento',
      jsonb_build_array(
        case when v_origem = 'CARTEIRA' then jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -p.valor)
             else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor) end,
        jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', v_motorista_val),
        jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', p.valor - v_motorista_val)));
    if v_motorista_val > 0 then
      insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
      values (p.corrida_id, p.id, c.motorista_id, 'TAXA_CANCELAMENTO', v_motorista_val,
              now() + make_interval(days => interno.cfg_num('motorista_liberacao_dias', 1)::int))
      on conflict (pagamento_id) do nothing;
    end if;

  elsif p.tipo = 'RECARGA' then
    v_tx := interno.lancar('RECARGA', p.id::text, 'RECARGA:' || p.id, 'Recarga de carteira',
      jsonb_build_array(jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -p.valor),
                        jsonb_build_object('titular', p.pagador_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', p.valor)));
  end if;

  update pagamentos set transacao_ledger_id = v_tx where id = p.id;
  return jsonb_build_object('id', p.id, 'status', 'CONFIRMADO', 'valor', p.valor, 'transacao', v_tx);
end $$;

-- divisão da corrida: motorista / indicação (3 níveis) / plataforma
create or replace function interno.liquidar_corrida(p_corrida uuid, p_pagamento uuid, p_origem text) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare
  c corridas; r regras_comissao; v_bruto numeric; v_pago numeric; v_plat numeric; v_motorista numeric; v_ref_total numeric := 0;
  v_linhas jsonb := '[]'; v_tx uuid; a record; v_pct numeric; v_val numeric; v_status status_ganho; v_motivo text;
  v_min_corr int; v_valida boolean; v_corridas_indicado int; v_suspeita boolean; v_ganhos jsonb := '[]';
begin
  select * into c from corridas where id = p_corrida for update;
  if exists (select 1 from transacoes_ledger where chave_idempotencia = 'LIQ:' || p_corrida) then
    return (select id from transacoes_ledger where chave_idempotencia = 'LIQ:' || p_corrida);
  end if;

  -- antifraude roda ANTES de decidir bônus
  perform interno.detectar_fraude_corrida(p_corrida);

  r := interno.resolver_comissao(c.cidade_id, c.categoria, c.motorista_id, c.solicitada_em);
  if r.id is null then perform interno.erro('SEM_REGRA_DE_COMISSAO'); end if;

  v_bruto := c.preco_final;                         -- base da comissão (sem gorjeta)
  v_pago := c.preco_final - c.desconto;             -- o que o passageiro efetivamente pagou
  v_plat := round(v_bruto * r.taxa_plataforma_pct / 100, 2);
  v_motorista := v_bruto - v_plat;

  -- elegibilidade da corrida para bônus de indicação
  v_valida := coalesce(c.distancia_real_km, 0) >= interno.cfg_num('corrida_valida_min_km', 1)
          and coalesce(c.duracao_real_min, 0) >= interno.cfg_num('corrida_valida_min_minutos', 3);
  v_min_corr := interno.cfg_num('indicacao_min_corridas_indicado', 5)::int;
  select count(*) into v_corridas_indicado from corridas
  where motorista_id = c.motorista_id and status in ('FINALIZADA','PAGA') and id <> c.id
    and coalesce(distancia_real_km, 0) >= interno.cfg_num('corrida_valida_min_km', 1);
  v_suspeita := exists (select 1 from sinais_fraude where status in ('ABERTO','EM_ANALISE') and severidade >= 3
                        and ((entidade_tipo = 'CORRIDA' and entidade_id = c.id::text)
                          or (entidade_tipo = 'USUARIO' and entidade_id = c.motorista_id::text)));

  for a in select * from interno.cadeia_indicacao(c.motorista_id, 3) loop
    v_pct := case a.nivel when 1 then r.indicacao_n1_pct when 2 then r.indicacao_n2_pct else r.indicacao_n3_pct end;
    v_val := least(round(v_bruto * v_pct / 100, 2), v_plat - v_ref_total);   -- arredondamento nunca deixa a plataforma negativa
    continue when v_val <= 0;
    -- regras de atividade válida (não paga só por cadastro): sem bônus, plataforma fica com o valor
    continue when not v_valida or v_corridas_indicado < v_min_corr;
    continue when not exists (select 1 from motoristas m join perfis p on p.id = m.id
                              where m.id = a.beneficiario_id and m.status not in ('BLOQUEADO','INATIVO') and p.status = 'ATIVO');
    -- o beneficiário não pode ser o próprio passageiro (corrida "fabricada")
    if a.beneficiario_id = c.passageiro_id then
      perform interno.registrar_sinal('CORRIDA', c.id::text, 'AUTO_BENEFICIO_INDICACAO', 4,
        jsonb_build_object('beneficiario', a.beneficiario_id, 'nivel', a.nivel));
      v_suspeita := true;
    end if;

    if v_suspeita or a.status <> 'ATIVA' then
      v_status := 'BLOQUEADO';
      v_motivo := case when a.status <> 'ATIVA' then 'Indicação ' || a.status else 'Corrida em análise antifraude' end;
      v_linhas := v_linhas || jsonb_build_object('conta', 'INDICACAO_RETIDA', 'valor', v_val);   -- retido até decisão humana
    else
      v_status := 'PENDENTE'; v_motivo := null;
      v_linhas := v_linhas || jsonb_build_object('titular', a.beneficiario_id, 'conta', 'INDICACAO_PENDENTE', 'valor', v_val);
    end if;
    v_ref_total := v_ref_total + v_val;
    v_ganhos := v_ganhos || jsonb_build_object('nivel', a.nivel, 'beneficiario', a.beneficiario_id, 'pct', v_pct,
                                               'valor', v_val, 'status', v_status, 'motivo', v_motivo);
  end loop;

  -- origem do dinheiro
  if p_origem = 'DINHEIRO' then
    -- motorista já está com o dinheiro: fica devendo a parte da plataforma (descontada nos próximos ganhos)
    v_linhas := v_linhas || jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_DISPONIVEL', 'valor', -(v_plat - c.desconto));
  else
    v_linhas := v_linhas
      || case when p_origem = 'CARTEIRA' then jsonb_build_object('titular', c.passageiro_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', -v_pago)
              else jsonb_build_object('conta', 'GATEWAY_RECEBIVEIS', 'valor', -v_pago) end
      || jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', v_motorista);
  end if;
  v_linhas := v_linhas
    || jsonb_build_object('conta', 'PLATAFORMA_PROMOCOES', 'valor', -c.desconto)
    || jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', v_plat - v_ref_total);

  v_tx := interno.lancar('LIQUIDACAO_CORRIDA', p_corrida::text, 'LIQ:' || p_corrida,
    'Corrida R$ ' || v_bruto || ' · taxa ' || r.taxa_plataforma_pct || '% (' || r.nome || ')', v_linhas);

  insert into ganhos_indicacao (corrida_id, beneficiario_id, indicado_id, nivel, percentual, valor, status, motivo, libera_em)
  select p_corrida, (g ->> 'beneficiario')::uuid, c.motorista_id, (g ->> 'nivel')::int, (g ->> 'pct')::numeric, (g ->> 'valor')::numeric,
         (g ->> 'status')::status_ganho, g ->> 'motivo',
         now() + make_interval(days => interno.cfg_num('indicacao_carencia_dias', 7)::int)
  from jsonb_array_elements(v_ganhos) g;

  if p_origem <> 'DINHEIRO' then
    insert into recebiveis (corrida_id, pagamento_id, motorista_id, tipo, valor, libera_em)
    values (p_corrida, p_pagamento, c.motorista_id, 'CORRIDA', v_motorista,
            now() + make_interval(days => interno.regra_num(c.cidade_id, 'motorista_liberacao_dias', 1)::int));
  end if;

  update corridas set status = 'PAGA', paga_em = now(), versao = versao + 1 where id = p_corrida;
  perform interno.evento(p_corrida, 'PAGAMENTO', 'FINALIZADA', 'PAGA',
    jsonb_build_object('transacao', v_tx, 'bruto', v_bruto, 'motorista', v_motorista, 'plataforma', v_plat - v_ref_total,
                       'indicacao', v_ref_total, 'regra', r.nome, 'origem', p_origem, 'ganhos_indicacao', v_ganhos));
  perform interno.notificar(c.motorista_id, 'PAGAMENTO', 'Corrida paga',
    'Seu ganho: R$ ' || to_char(v_motorista, 'FM999990D00') || case when p_origem = 'DINHEIRO' then ' (recebido em dinheiro)' else '' end,
    jsonb_build_object('corrida', c.id));
  return v_tx;
end $$;

-- ============================================================
-- WEBHOOK DO GATEWAY (chamado só pelo servidor, com service_role)
-- ============================================================
create or replace function public.processar_webhook(p_gateway text, p_evento_id text, p_tipo text, p_payload jsonb)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_ok boolean; v_res jsonb; v_pag uuid;
begin
  -- só o servidor (Edge Function com service_role) chama. Atenção: dentro de SECURITY DEFINER
  -- o current_user é o dono da função, por isso a checagem é pelo papel do JWT.
  if coalesce(auth.role(), '') <> 'service_role' then
    perform interno.erro('SEM_PERMISSAO');
  end if;
  insert into webhooks_recebidos (gateway, evento_id, tipo, payload) values (p_gateway, p_evento_id, p_tipo, p_payload)
  on conflict do nothing returning true into v_ok;
  if v_ok is null then return jsonb_build_object('duplicado', true); end if;   -- webhook repetido

  v_pag := (p_payload ->> 'pagamento_id')::uuid;
  if p_tipo = 'PAGAMENTO_CONFIRMADO' then
    v_res := interno.confirmar_pagamento(v_pag, p_gateway, p_payload ->> 'gateway_ref', (p_payload ->> 'valor')::numeric);
  elsif p_tipo = 'PAGAMENTO_FALHOU' then
    update pagamentos set status = 'FALHOU', motivo_falha = p_payload ->> 'motivo' where id = v_pag and status = 'PENDENTE';
    v_res := jsonb_build_object('status', 'FALHOU');
  else
    v_res := jsonb_build_object('ignorado', p_tipo);
  end if;
  update webhooks_recebidos set processado_em = now(), resultado = v_res where gateway = p_gateway and evento_id = p_evento_id;
  return v_res;
end $$;

-- só em desenvolvimento/homologação: simula o gateway confirmando um PIX/cartão
create or replace function public.dev_simular_pagamento(p_pagamento uuid) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); p pagamentos; v_amb text := coalesce(interno.cfg('ambiente') #>> '{}', 'producao');
begin
  -- fechado por padrão: só abre se o ambiente estiver EXATAMENTE como desenvolvimento/homologação.
  -- Em homologação só a equipe usa; em produção não existe.
  if v_amb not in ('desenvolvimento','homologacao') then perform interno.erro('INDISPONIVEL_EM_PRODUCAO'); end if;
  if v_amb = 'homologacao' and not interno.eh_staff() then perform interno.erro('SEM_PERMISSAO'); end if;
  select * into p from pagamentos where id = p_pagamento;
  if not found or (p.pagador_id <> v_uid and not interno.eh_staff()) then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  return interno.confirmar_pagamento(p.id, 'SIMULADOR', 'SIM:' || p.id, p.valor);
end $$;

-- ============================================================
-- GORJETA
-- ============================================================
create or replace function public.dar_gorjeta(p_corrida uuid, p_valor numeric) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); c corridas; p pagamentos; v_metodo metodo_pagamento;
begin
  select * into c from corridas where id = p_corrida;
  if not found or c.passageiro_id <> v_uid then perform interno.erro('CORRIDA_NAO_ENCONTRADA'); end if;
  if c.status not in ('FINALIZADA','PAGA') then perform interno.erro('STATUS_INVALIDO'); end if;
  if p_valor < 1 or p_valor > greatest(c.preco_final, 50) then perform interno.erro('VALOR_INVALIDO'); end if;
  v_metodo := case when c.metodo_pagamento = 'CARTEIRA' and interno.travar_saldo(v_uid, 'PASSAGEIRO_CARTEIRA') >= p_valor then 'CARTEIRA'
                   when c.metodo_pagamento = 'CARTAO' then 'CARTAO' else 'PIX' end;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p_corrida, v_uid, 'GORJETA', v_metodo, round(p_valor, 2), 'GORJETA:' || p_corrida)
  on conflict (chave_idempotencia) do nothing returning * into p;
  if p.id is null then perform interno.erro('GORJETA_JA_REGISTRADA'); end if;
  if v_metodo = 'CARTEIRA' then return interno.confirmar_pagamento(p.id, 'INTERNO', 'INTERNO:' || p.id, p.valor); end if;
  return jsonb_build_object('id', p.id, 'status', p.status, 'valor', p.valor, 'metodo', p.metodo);
end $$;

-- ============================================================
-- LIBERAÇÃO D+N (job) — pendente -> disponível
-- ============================================================
create or replace function interno.job_liberar_saldos() returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r record; n_mot int := 0; n_ind int := 0;
begin
  for r in select * from recebiveis where status = 'PENDENTE' and libera_em <= now()
           order by libera_em limit 2000 for update skip locked loop
    -- corrida com suspeita em aberto: segura (não bloqueia a conta, só o valor)
    continue when exists (select 1 from sinais_fraude where status in ('ABERTO','EM_ANALISE') and severidade >= 4
                          and entidade_tipo = 'CORRIDA' and entidade_id = r.corrida_id::text);
    perform interno.lancar('LIBERACAO', r.corrida_id::text, 'LIB:' || r.id, 'Ganho liberado para saque',
      jsonb_build_array(jsonb_build_object('titular', r.motorista_id, 'conta', 'MOTORISTA_PENDENTE', 'valor', -r.valor),
                        jsonb_build_object('titular', r.motorista_id, 'conta', 'MOTORISTA_DISPONIVEL', 'valor', r.valor)));
    update recebiveis set status = 'DISPONIVEL', liberado_em = now() where id = r.id;
    if r.tipo = 'CORRIDA' then
      perform interno.evento(r.corrida_id, 'REPASSE', null, null, jsonb_build_object('valor', r.valor, 'disponivel', true));
    end if;
    n_mot := n_mot + 1;
  end loop;

  for r in select * from ganhos_indicacao where status = 'PENDENTE' and libera_em <= now()
           order by libera_em limit 2000 for update skip locked loop
    continue when exists (select 1 from sinais_fraude where status in ('ABERTO','EM_ANALISE') and severidade >= 3
                          and ((entidade_tipo = 'CORRIDA' and entidade_id = r.corrida_id::text)
                            or (entidade_tipo = 'USUARIO' and entidade_id in (r.beneficiario_id::text, r.indicado_id::text))));
    perform interno.lancar('LIBERACAO_INDICACAO', r.corrida_id::text, 'LIBIND:' || r.id, 'Bônus de indicação liberado',
      jsonb_build_array(jsonb_build_object('titular', r.beneficiario_id, 'conta', 'INDICACAO_PENDENTE', 'valor', -r.valor),
                        jsonb_build_object('titular', r.beneficiario_id, 'conta', 'INDICACAO_DISPONIVEL', 'valor', r.valor)));
    update ganhos_indicacao set status = 'DISPONIVEL', liberado_em = now() where id = r.id;
    n_ind := n_ind + 1;
  end loop;
  return jsonb_build_object('motorista', n_mot, 'indicacao', n_ind);
end $$;

-- decisão humana sobre bônus retido (BLOQUEADO)
create or replace function public.risco_decidir_ganho_retido(p_ganho uuid, p_liberar boolean, p_motivo text) returns void
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{RISCO,FINANCEIRO,ADMIN}'); g ganhos_indicacao;
begin
  if coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  select * into g from ganhos_indicacao where id = p_ganho for update;
  if g.status <> 'BLOQUEADO' then perform interno.erro('STATUS_INVALIDO'); end if;
  perform interno.sem_conflito(g.beneficiario_id); perform interno.sem_conflito(g.indicado_id);
  if p_liberar then
    perform interno.lancar('INDICACAO_LIBERADA_REVISAO', g.corrida_id::text, 'RETLIB:' || g.id, 'Bônus liberado após revisão',
      jsonb_build_array(jsonb_build_object('conta', 'INDICACAO_RETIDA', 'valor', -g.valor),
                        jsonb_build_object('titular', g.beneficiario_id, 'conta', 'INDICACAO_PENDENTE', 'valor', g.valor)));
    update ganhos_indicacao set status = 'PENDENTE', motivo = p_motivo, libera_em = now() where id = g.id;
  else
    perform interno.lancar('INDICACAO_NEGADA_REVISAO', g.corrida_id::text, 'RETNEG:' || g.id, 'Bônus negado após revisão',
      jsonb_build_array(jsonb_build_object('conta', 'INDICACAO_RETIDA', 'valor', -g.valor),
                        jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', g.valor)));
    update ganhos_indicacao set status = 'ESTORNADO', motivo = p_motivo where id = g.id;
  end if;
  perform interno.auditar_evento('DECISAO_BONUS_RETIDO', 'ganhos_indicacao', g.id::text, jsonb_build_object('liberar', p_liberar, 'motivo', p_motivo));
end $$;

-- ============================================================
-- ESTORNO (reembolso) — sempre por transação reversora
-- ============================================================
create or replace function public.fin_estornar_corrida(p_corrida uuid, p_motivo text) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{FINANCEIRO,ADMIN}'); c corridas; p pagamentos; t uuid; v_linhas jsonb := '[]';
        l record; rec recebiveis; g record; v_tx uuid; v_conta text;
begin
  if coalesce(trim(p_motivo), '') = '' then perform interno.erro('MOTIVO_OBRIGATORIO'); end if;
  select * into c from corridas where id = p_corrida for update;
  perform interno.sem_conflito(c.passageiro_id); perform interno.sem_conflito(c.motorista_id);
  select * into p from pagamentos where corrida_id = p_corrida and tipo = 'CORRIDA' and status in ('CONFIRMADO','ESTORNADO') for update;
  if p.id is null then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  if p.status = 'ESTORNADO' then return jsonb_build_object('repetido', true); end if;
  select id into t from transacoes_ledger where chave_idempotencia = 'LIQ:' || p_corrida;
  -- trava tudo que o job de liberação poderia mexer ao mesmo tempo
  select * into rec from recebiveis where corrida_id = p_corrida and tipo = 'CORRIDA' for update;
  perform 1 from ganhos_indicacao where corrida_id = p_corrida for update;

  -- 1) linhas que não são de indicação: desfaz, tirando o ganho do motorista de onde ele está agora
  for l in select c2.titular_id, c2.tipo, l2.valor from lancamentos_ledger l2 join contas_ledger c2 on c2.id = l2.conta_id
           where l2.transacao_id = t and c2.tipo not in ('INDICACAO_PENDENTE','INDICACAO_RETIDA') loop
    v_conta := l.tipo;
    if l.tipo = 'MOTORISTA_PENDENTE' and rec.status in ('DISPONIVEL','PAGO') then v_conta := 'MOTORISTA_DISPONIVEL'; end if;
    v_linhas := v_linhas || jsonb_build_object('titular', l.titular_id, 'conta', v_conta, 'valor', -l.valor);
  end loop;
  -- 2) bônus de indicação: cada um sai da conta onde está HOJE
  for g in select * from ganhos_indicacao where corrida_id = p_corrida loop
    v_linhas := v_linhas || case g.status
      when 'BLOQUEADO'  then jsonb_build_object('conta', 'INDICACAO_RETIDA', 'valor', -g.valor)
      when 'PENDENTE'   then jsonb_build_object('titular', g.beneficiario_id, 'conta', 'INDICACAO_PENDENTE', 'valor', -g.valor)
      when 'ESTORNADO'  then jsonb_build_object('conta', 'PLATAFORMA_RECEITA', 'valor', -g.valor)   -- já tinha voltado p/ plataforma
      else                   jsonb_build_object('titular', g.beneficiario_id, 'conta', 'INDICACAO_DISPONIVEL', 'valor', -g.valor)  -- se já sacou, fica negativo
    end;
  end loop;
  v_tx := interno.lancar('ESTORNO', p_corrida::text, 'EST:' || p_corrida, 'Estorno: ' || p_motivo, v_linhas, t);

  -- corrida em dinheiro: o passageiro recebe em crédito, o motorista devolve o que recebeu na mão
  if p.metodo = 'DINHEIRO' then
    perform interno.lancar('ESTORNO_DINHEIRO', p_corrida::text, 'ESTDIN:' || p_corrida, 'Estorno de corrida paga em dinheiro',
      jsonb_build_array(jsonb_build_object('titular', c.motorista_id, 'conta', 'MOTORISTA_DISPONIVEL', 'valor', -p.valor),
                        jsonb_build_object('titular', c.passageiro_id, 'conta', 'PASSAGEIRO_CARTEIRA', 'valor', p.valor)));
  end if;

  update pagamentos set status = 'ESTORNADO', estornado_em = now(), motivo_falha = p_motivo where id = p.id;
  update recebiveis set status = 'ESTORNADO' where corrida_id = p_corrida and tipo = 'CORRIDA';
  update ganhos_indicacao set status = 'ESTORNADO', motivo = 'Corrida estornada: ' || p_motivo where corrida_id = p_corrida;
  perform interno.evento(p_corrida, 'ESTORNO', c.status, c.status, jsonb_build_object('motivo', p_motivo, 'transacao', v_tx));
  perform interno.auditar_evento('ESTORNO', 'pagamentos', p.id::text, jsonb_build_object('motivo', p_motivo, 'valor', p.valor));
  perform interno.notificar(c.passageiro_id, 'PAGAMENTO', 'Estorno realizado', 'R$ ' || to_char(p.valor, 'FM999990D00') || ' estornados.', jsonb_build_object('corrida', c.id));
  return jsonb_build_object('ok', true, 'transacao', v_tx);
end $$;

-- passageiro paga de novo uma cobrança que falhou ou ficou parada (troca de método, nova tentativa)
create or replace function public.pagar_novamente(p_pagamento uuid, p_metodo metodo_pagamento) returns jsonb
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_login(); p pagamentos; n pagamentos; v_tent int;
begin
  perform interno.limitar('pagar_novamente', 10, 3600);
  if p_metodo = 'DINHEIRO' then perform interno.erro('METODO_INVALIDO'); end if;
  select * into p from pagamentos where id = p_pagamento for update;
  if not found or p.pagador_id <> v_uid then perform interno.erro('PAGAMENTO_NAO_ENCONTRADO'); end if;
  if p.status not in ('PENDENTE','FALHOU') then perform interno.erro('STATUS_INVALIDO', p.status::text); end if;
  if p.status = 'PENDENTE' then update pagamentos set status = 'CANCELADO', motivo_falha = 'Substituído por nova tentativa' where id = p.id; end if;
  select count(*) + 1 into v_tent from pagamentos where corrida_id = p.corrida_id and tipo = p.tipo;
  if p_metodo = 'CARTEIRA' and interno.travar_saldo(v_uid, 'PASSAGEIRO_CARTEIRA') < p.valor then perform interno.erro('SALDO_INSUFICIENTE'); end if;
  insert into pagamentos (corrida_id, pagador_id, tipo, metodo, valor, chave_idempotencia)
  values (p.corrida_id, v_uid, p.tipo, p_metodo, p.valor, split_part(p.chave_idempotencia, '#', 1) || '#' || v_tent)
  returning * into n;
  if p_metodo = 'CARTEIRA' then return interno.confirmar_pagamento(n.id, 'INTERNO', 'INTERNO:' || n.id, n.valor); end if;
  return jsonb_build_object('id', n.id, 'status', n.status, 'valor', n.valor, 'metodo', n.metodo);
end $$;

-- ============================================================
-- CARTEIRA, EXTRATO, SAQUE
-- ============================================================
create or replace function public.minha_carteira(p_limite int default 50) returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  select jsonb_build_object(
    'ganhos_disponivel', interno.saldo(auth.uid(), 'MOTORISTA_DISPONIVEL'),
    'ganhos_pendente', interno.saldo(auth.uid(), 'MOTORISTA_PENDENTE'),
    'indicacao_disponivel', interno.saldo(auth.uid(), 'INDICACAO_DISPONIVEL'),
    'indicacao_pendente', interno.saldo(auth.uid(), 'INDICACAO_PENDENTE'),
    'indicacao_em_analise', (select coalesce(sum(valor), 0) from ganhos_indicacao where beneficiario_id = auth.uid() and status = 'BLOQUEADO'),
    'creditos', interno.saldo(auth.uid(), 'PASSAGEIRO_CARTEIRA'),
    'extrato', (select coalesce(jsonb_agg(x order by x.id desc), '[]') from (
        select l.id, l.criado_em as data, ct.tipo as conta, l.valor, t.tipo, t.descricao, t.referencia
        from lancamentos_ledger l
        join contas_ledger ct on ct.id = l.conta_id and ct.titular_id = auth.uid()
        join transacoes_ledger t on t.id = l.transacao_id
        order by l.id desc limit least(p_limite, 200)) x),
    'repasses', (select coalesce(jsonb_agg(to_jsonb(r) - 'chave_idempotencia' order by r.solicitado_em desc), '[]')
                 from (select * from repasses where motorista_id = auth.uid() order by solicitado_em desc limit 20) r)
  )
$$;

create or replace function public.solicitar_repasse(p_valor numeric, p_chave_pix text, p_origem text, p_chave_idempotencia text)
returns jsonb language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{MOTORISTA}'); v_conta text; v_saldo numeric; v_id uuid; r repasses; v_acum numeric := 0; g record;
begin
  perform interno.limitar('repasse', 5, 3600);
  if p_origem not in ('GANHOS','INDICACAO') then perform interno.erro('ORIGEM_INVALIDA'); end if;
  if p_valor < interno.cfg_num('repasse_minimo', 20) then perform interno.erro('VALOR_ABAIXO_DO_MINIMO'); end if;
  if coalesce(length(p_chave_idempotencia), 0) < 8 then perform interno.erro('CHAVE_IDEMPOTENCIA_OBRIGATORIA'); end if;
  select * into r from repasses where chave_idempotencia = p_chave_idempotencia;
  if found then return jsonb_build_object('id', r.id, 'status', r.status, 'repetido', true); end if;

  -- suspeita grave em aberto: saque espera revisão (a conta continua rodando normalmente)
  if exists (select 1 from sinais_fraude where status in ('ABERTO','EM_ANALISE') and severidade >= 4
             and entidade_tipo = 'USUARIO' and entidade_id = v_uid::text) then
    perform interno.erro('REPASSE_AGUARDANDO_REVISAO');
  end if;

  v_conta := case when p_origem = 'GANHOS' then 'MOTORISTA_DISPONIVEL' else 'INDICACAO_DISPONIVEL' end;
  -- trava o saldo: dois saques simultâneos não passam do saldo
  select s.saldo into v_saldo from saldos s where s.conta_id = interno.conta(v_uid, v_conta) for update;
  if coalesce(v_saldo, 0) < p_valor then perform interno.erro('SALDO_INSUFICIENTE', coalesce(v_saldo, 0)::text); end if;

  insert into repasses (motorista_id, origem, valor, chave_pix, chave_idempotencia)
  values (v_uid, p_origem, round(p_valor, 2), trim(p_chave_pix), p_chave_idempotencia) returning id into v_id;
  perform interno.lancar('REPASSE', v_id::text, 'REP:' || v_id, 'Saque via PIX',
    jsonb_build_array(jsonb_build_object('titular', v_uid, 'conta', v_conta, 'valor', -p_valor),
                      jsonb_build_object('conta', 'REPASSES_EM_PROCESSAMENTO', 'valor', p_valor)));

  if p_origem = 'INDICACAO' then
    for g in select id, valor from ganhos_indicacao where beneficiario_id = v_uid and status = 'DISPONIVEL' order by liberado_em, id for update loop
      exit when v_acum + g.valor > p_valor;
      update ganhos_indicacao set status = 'PAGO', pago_em = now() where id = g.id;
      v_acum := v_acum + g.valor;
    end loop;
  end if;

  if exists (select 1 from repasses where chave_pix = trim(p_chave_pix) and motorista_id <> v_uid) then
    perform interno.registrar_sinal('USUARIO', v_uid::text, 'PIX_COMPARTILHADO', 3,
      jsonb_build_object('outros', (select jsonb_agg(distinct motorista_id) from repasses where chave_pix = trim(p_chave_pix) and motorista_id <> v_uid)));
  end if;
  return jsonb_build_object('id', v_id, 'status', 'SOLICITADO');
end $$;

-- confirmação do PIX de saída (servidor/financeiro)
create or replace function public.fin_concluir_repasse(p_repasse uuid, p_sucesso boolean, p_gateway_ref text default null, p_motivo text default null)
returns void language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare r repasses;
begin
  if coalesce(auth.role(), '') <> 'service_role' then
    perform interno.exigir_papel('{FINANCEIRO,ADMIN}');
  end if;
  select * into r from repasses where id = p_repasse for update;
  if r.status in ('PAGO','FALHOU') then return; end if;
  if p_sucesso then
    perform interno.lancar('REPASSE_PAGO', r.id::text, 'REPOK:' || r.id, 'PIX enviado',
      jsonb_build_array(jsonb_build_object('conta', 'REPASSES_EM_PROCESSAMENTO', 'valor', -r.valor),
                        jsonb_build_object('conta', 'REPASSES_PAGOS', 'valor', r.valor)));
    update repasses set status = 'PAGO', gateway_ref = p_gateway_ref, concluido_em = now() where id = r.id;
    perform interno.notificar(r.motorista_id, 'PAGAMENTO', 'Saque enviado', 'R$ ' || to_char(r.valor, 'FM999990D00') || ' enviados para o seu PIX.', '{}');
  else
    perform interno.lancar('REPASSE_FALHOU', r.id::text, 'REPERR:' || r.id, 'Saque não concluído: valor devolvido',
      jsonb_build_array(jsonb_build_object('conta', 'REPASSES_EM_PROCESSAMENTO', 'valor', -r.valor),
                        jsonb_build_object('titular', r.motorista_id,
                          'conta', case when r.origem = 'GANHOS' then 'MOTORISTA_DISPONIVEL' else 'INDICACAO_DISPONIVEL' end, 'valor', r.valor)));
    update repasses set status = 'FALHOU', motivo_falha = p_motivo, concluido_em = now() where id = r.id;
    perform interno.notificar(r.motorista_id, 'PAGAMENTO', 'Saque não concluído', 'O valor voltou para o seu saldo. ' || coalesce(p_motivo, ''), '{}');
  end if;
end $$;

-- ============================================================
-- REDE DE INDICAÇÃO (código, link, árvore, ganhos)
-- ============================================================
create or replace function public.minha_rede() returns jsonb
language sql stable security definer set search_path = public, interno, pg_temp as $$
  with recursive desce as (
    select i.indicado_id as id, 1 as nivel, i.status, i.criado_em from indicacoes i where i.indicador_id = auth.uid()
    union all
    select i.indicado_id, d.nivel + 1, i.status, i.criado_em from desce d join indicacoes i on i.indicador_id = d.id where d.nivel < 3
  )
  select jsonb_build_object(
    'codigo', (select codigo_indicacao from perfis where id = auth.uid()),
    'link', '/c/' || (select codigo_indicacao from perfis where id = auth.uid()),
    'por_nivel', (select coalesce(jsonb_object_agg(nivel, qtd), '{}') from (select nivel, count(*) qtd from desce group by nivel) x),
    'diretos', (select coalesce(jsonb_agg(jsonb_build_object('nome', split_part(p.nome, ' ', 1), 'desde', d.criado_em, 'status', d.status,
                  'corridas', (select count(*) from corridas c where c.motorista_id = d.id and c.status = 'PAGA'))
                  order by d.criado_em desc), '[]')
                from desce d join perfis p on p.id = d.id where d.nivel = 1),
    'ganhos', (select jsonb_build_object(
                  'total', coalesce(sum(valor) filter (where status in ('PENDENTE','DISPONIVEL','PAGO')), 0),
                  'pendente', coalesce(sum(valor) filter (where status = 'PENDENTE'), 0),
                  'disponivel', coalesce(sum(valor) filter (where status = 'DISPONIVEL'), 0),
                  'pago', coalesce(sum(valor) filter (where status = 'PAGO'), 0),
                  'em_analise', coalesce(sum(valor) filter (where status = 'BLOQUEADO'), 0),
                  'por_nivel', (select coalesce(jsonb_object_agg(nivel, v), '{}') from
                     (select nivel, sum(valor) v from ganhos_indicacao where beneficiario_id = auth.uid() and status in ('PENDENTE','DISPONIVEL','PAGO') group by nivel) y))
               from ganhos_indicacao where beneficiario_id = auth.uid()),
    'historico', (select coalesce(jsonb_agg(jsonb_build_object('data', g.criado_em, 'nivel', g.nivel, 'valor', g.valor, 'status', g.status, 'motivo', g.motivo)
                   order by g.criado_em desc), '[]')
                  from (select * from ganhos_indicacao where beneficiario_id = auth.uid() order by criado_em desc limit 50) g)
  )
$$;

-- ============================================================
-- ADMIN: regras de comissão (com auditoria automática)
-- ============================================================
create or replace function public.admin_salvar_regra_comissao(p_regra jsonb) returns uuid
language plpgsql security definer set search_path = public, interno, pg_temp as $$
declare v_uid uuid := interno.exigir_papel('{ADMIN,FINANCEIRO}'); v_id uuid := nullif(p_regra ->> 'id', '')::uuid;
begin
  if v_id is null then
    insert into regras_comissao (nome, ativa, prioridade, cidade_id, categoria, motorista_id, campanha, dias_semana, hora_inicio, hora_fim,
      vigencia_inicio, vigencia_fim, taxa_plataforma_pct, indicacao_n1_pct, indicacao_n2_pct, indicacao_n3_pct, criado_por)
    values (p_regra ->> 'nome', coalesce((p_regra ->> 'ativa')::boolean, true), coalesce((p_regra ->> 'prioridade')::int, 0),
      nullif(p_regra ->> 'cidade_id', '')::uuid, nullif(p_regra ->> 'categoria', ''), nullif(p_regra ->> 'motorista_id', '')::uuid,
      nullif(p_regra ->> 'campanha', ''),
      case when p_regra ? 'dias_semana' and jsonb_typeof(p_regra -> 'dias_semana') = 'array'
           then array(select jsonb_array_elements_text(p_regra -> 'dias_semana')::int) end,
      nullif(p_regra ->> 'hora_inicio', '')::time, nullif(p_regra ->> 'hora_fim', '')::time,
      nullif(p_regra ->> 'vigencia_inicio', '')::timestamptz, nullif(p_regra ->> 'vigencia_fim', '')::timestamptz,
      (p_regra ->> 'taxa_plataforma_pct')::numeric, coalesce((p_regra ->> 'indicacao_n1_pct')::numeric, 0),
      coalesce((p_regra ->> 'indicacao_n2_pct')::numeric, 0), coalesce((p_regra ->> 'indicacao_n3_pct')::numeric, 0), v_uid)
    returning id into v_id;
  else
    -- regra vigente não é editada: é desativada e uma nova é criada (histórico preservado)
    update regras_comissao set ativa = coalesce((p_regra ->> 'ativa')::boolean, ativa),
      vigencia_fim = coalesce(nullif(p_regra ->> 'vigencia_fim', '')::timestamptz, vigencia_fim)
    where id = v_id;
  end if;
  return v_id;
end $$;
