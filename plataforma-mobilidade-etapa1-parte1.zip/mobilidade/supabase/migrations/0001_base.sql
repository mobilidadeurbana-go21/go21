-- ============================================================
-- 0001 — BASE: tipos, configurações, papéis, auditoria, limites
-- ============================================================
-- Convenções:
--  * Schema "public"  -> tabelas + funções RPC chamadas pelos apps
--  * Schema "interno" -> funções internas (NÃO expostas pela API)
--  * Apps NUNCA escrevem direto nas tabelas: toda escrita passa por
--    funções SECURITY DEFINER que validam permissão e regra de negócio.
--  * Erros de regra de negócio usam códigos em MAIÚSCULO
--    (ex.: 'CORRIDA_JA_ACEITA') para o app traduzir para o usuário.
-- ============================================================

create schema if not exists interno;
revoke all on schema interno from public;

-- ---------- TIPOS ----------
do $$ begin
  create type papel as enum ('PASSAGEIRO','MOTORISTA','ADMIN','EMPRESA','SUPORTE','FINANCEIRO','OPERACOES','RISCO','SUPER_ADMIN');
exception when duplicate_object then null; end $$;

do $$ begin
  create type status_usuario as enum ('ATIVO','SUSPENSO','BLOQUEADO','INATIVO');
exception when duplicate_object then null; end $$;

-- ---------- CONFIGURAÇÕES GLOBAIS (sem número fixo no código) ----------
create table if not exists configuracoes (
  chave text primary key,
  valor jsonb not null,
  descricao text,
  atualizado_em timestamptz not null default now(),
  atualizado_por uuid
);

insert into configuracoes (chave, valor, descricao) values
  ('ambiente',                         '"desenvolvimento"', 'desenvolvimento | homologacao | producao'),
  ('oferta_expira_segundos',           '15',   'tempo que o motorista tem para aceitar'),
  ('matching_max_tentativas',          '8',    'ofertas antes de desistir'),
  ('matching_tempo_max_segundos',      '240',  'tempo máximo buscando motorista'),
  ('matching_raios_km',                '[3,5,8,12]', 'raio de busca que cresce a cada tentativa'),
  ('velocidade_media_kmh',             '25',   'para ETA quando não há rota'),
  ('fator_rota',                       '1.3',  'distância em linha reta x fator = rota estimada'),
  ('tolerancia_preco_pct',             '20',   'acima disso o preço final é recalculado'),
  ('carencia_cancelamento_seg',        '120',  'passageiro cancela grátis até X seg após o aceite'),
  ('motorista_liberacao_dias',         '1',    'D+N para ganho do motorista ficar disponível'),
  ('indicacao_carencia_dias',          '7',    'D+N para bônus de indicação ficar disponível'),
  ('indicacao_min_corridas_indicado',  '5',    'indicado precisa ter X corridas válidas antes de gerar bônus'),
  ('corrida_valida_min_km',            '1',    'corrida abaixo disso não gera bônus de indicação'),
  ('corrida_valida_min_minutos',       '3',    'idem, em minutos'),
  ('repasse_minimo',                   '20',   'valor mínimo de saque'),
  ('pin_max_tentativas',               '5',    'tentativas de PIN por corrida'),
  ('seguranca_parada_minutos',         '6',    'parada inesperada durante a corrida'),
  ('seguranca_fator_duracao',          '2',    'duração > estimada x fator = anormal'),
  ('seguranca_desvio_km',              '2',    'desvio mínimo da rota esperada'),
  ('divida_bloqueio_minutos',          '30',   'PIX pendente há mais que isso bloqueia nova corrida'),
  ('chegada_raio_m',                   '300',  'distância máxima do embarque para marcar "cheguei"'),
  ('velocidade_max_kmh',               '150',  'trecho de GPS acima disso é ignorado no cálculo do km'),
  ('teto_km_fator',                    '2',    'km da trilha acima de estimado x fator = cobra o estimado e retém')
on conflict (chave) do nothing;

create or replace function interno.cfg(p_chave text) returns jsonb
language sql stable as $$ select valor from configuracoes where chave = p_chave $$;

create or replace function interno.cfg_num(p_chave text, p_padrao numeric) returns numeric
language sql stable as $$ select coalesce((select (valor #>> '{}')::numeric from configuracoes where chave = p_chave), p_padrao) $$;

-- ---------- ERRO PADRÃO ----------
create or replace function interno.erro(p_codigo text, p_detalhe text default null) returns void
language plpgsql as $$
begin
  raise exception using errcode = 'P0001', message = p_codigo, detail = coalesce(p_detalhe, '');
end $$;

-- ---------- PAPÉIS ----------
create table if not exists usuario_papeis (
  usuario_id uuid not null,
  papel papel not null,
  cidade_id uuid,                      -- papel limitado a uma cidade (null = todas)
  ativo boolean not null default true,
  concedido_por uuid,
  criado_em timestamptz not null default now(),
  primary key (usuario_id, papel)
);

create or replace function public.tem_papel(p papel) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from usuario_papeis where usuario_id = auth.uid() and papel = p and ativo)
$$;

create or replace function interno.eh_staff(p_usuario uuid default null) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (
    select 1 from usuario_papeis
    where usuario_id = coalesce(p_usuario, auth.uid()) and ativo
      and papel in ('ADMIN','SUPER_ADMIN','SUPORTE','FINANCEIRO','OPERACOES','RISCO')
  )
$$;

create or replace function interno.exigir_login() returns uuid
language plpgsql stable as $$
declare v uuid := auth.uid();
begin
  if v is null then perform interno.erro('NAO_AUTENTICADO'); end if;
  return v;
end $$;

create or replace function interno.exigir_papel(p_papeis papel[]) returns uuid
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare v uuid := interno.exigir_login();
begin
  if not exists (
    select 1 from usuario_papeis
    where usuario_id = v and ativo and (papel = any(p_papeis) or papel = 'SUPER_ADMIN')
  ) then
    perform interno.erro('SEM_PERMISSAO', array_to_string(p_papeis, ','));
  end if;
  return v;
end $$;

-- staff não pode decidir sobre o próprio cadastro, bônus, corrida ou sinal
create or replace function interno.sem_conflito(p_alvo uuid) returns void
language plpgsql stable as $$
begin
  if p_alvo is not null and p_alvo = auth.uid() then
    perform interno.erro('CONFLITO_DE_INTERESSE', 'ninguém analisa ou decide sobre o próprio registro');
  end if;
end $$;

-- ---------- AUDITORIA (nunca apagada, nunca alterada) ----------
create table if not exists auditoria (
  id bigint generated always as identity primary key,
  ocorrido_em timestamptz not null default now(),
  ator_id uuid,
  acao text not null,                 -- INSERT / UPDATE / DELETE / LOGIN / BLOQUEIO / ...
  tabela text,
  registro_id text,
  antes jsonb,
  depois jsonb,
  ip text,
  contexto jsonb
);
create index if not exists auditoria_tabela_idx on auditoria (tabela, registro_id);
create index if not exists auditoria_ator_idx on auditoria (ator_id, ocorrido_em desc);
create index if not exists auditoria_data_idx on auditoria (ocorrido_em desc);

-- IP confiável: o cliente controla o começo do X-Forwarded-For, então usamos o
-- cabeçalho do proxy (cf-connecting-ip / x-real-ip) ou o ÚLTIMO item da lista,
-- que é o adicionado pela infraestrutura. Validar no ambiente real do Supabase.
create or replace function interno.ip_requisicao() returns text
language sql stable as $$
  with h as (select nullif(current_setting('request.headers', true), '')::json as j)
  select coalesce(
    nullif(trim(j ->> 'cf-connecting-ip'), ''),
    nullif(trim(j ->> 'x-real-ip'), ''),
    nullif(trim((regexp_split_to_array(coalesce(j ->> 'x-forwarded-for', ''), '\s*,\s*'))[
      cardinality(regexp_split_to_array(coalesce(j ->> 'x-forwarded-for', ''), '\s*,\s*'))]), ''))
  from h
$$;

create or replace function interno.auditar_evento(p_acao text, p_tabela text, p_registro text, p_contexto jsonb default null)
returns void language sql security definer set search_path = public, pg_temp as $$
  insert into auditoria (ator_id, acao, tabela, registro_id, ip, contexto)
  values (auth.uid(), p_acao, p_tabela, p_registro, interno.ip_requisicao(), p_contexto)
$$;

-- trigger genérico: registra antes/depois de qualquer alteração em tabela sensível
create or replace function interno.trg_auditar() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_id text;
begin
  v_id := coalesce(
    case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end ->> 'id',
    case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end ->> 'usuario_id',
    case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end ->> 'chave');
  insert into auditoria (ator_id, acao, tabela, registro_id, antes, depois, ip)
  values (auth.uid(), tg_op, tg_table_name, v_id,
          case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end,
          case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end,
          interno.ip_requisicao());
  return coalesce(new, old);
end $$;

-- trigger que impede alterar/apagar (auditoria, eventos, ledger)
create or replace function interno.trg_imutavel() returns trigger
language plpgsql as $$
begin
  raise exception using errcode = 'P0001', message = 'REGISTRO_IMUTAVEL',
    detail = tg_table_name || ' não pode ser alterado nem apagado. Use um lançamento de correção.';
end $$;

drop trigger if exists auditoria_imutavel on auditoria;
create trigger auditoria_imutavel before update or delete on auditoria
  for each row execute function interno.trg_imutavel();

drop trigger if exists usuario_papeis_auditar on usuario_papeis;
create trigger usuario_papeis_auditar after insert or update or delete on usuario_papeis
  for each row execute function interno.trg_auditar();

drop trigger if exists configuracoes_auditar on configuracoes;
create trigger configuracoes_auditar after insert or update or delete on configuracoes
  for each row execute function interno.trg_auditar();

-- ---------- PROTEÇÃO CONTRA ABUSO (limite de chamadas) ----------
create table if not exists limites_uso (
  chave text not null,
  janela_inicio timestamptz not null,
  contador int not null default 0,
  primary key (chave, janela_inicio)
);

create or replace function interno.limitar(p_acao text, p_max int, p_janela_seg int, p_sujeito text default null)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_chave text := p_acao || ':' || coalesce(p_sujeito, auth.uid()::text, interno.ip_requisicao(), 'anon');
  v_janela timestamptz := to_timestamp(floor(extract(epoch from now()) / p_janela_seg) * p_janela_seg);
  v_cont int;
begin
  insert into limites_uso (chave, janela_inicio, contador) values (v_chave, v_janela, 1)
  on conflict (chave, janela_inicio) do update set contador = limites_uso.contador + 1
  returning contador into v_cont;
  if v_cont > p_max then
    perform interno.erro('LIMITE_EXCEDIDO', p_acao);
  end if;
end $$;

-- limpeza das janelas antigas (job)
create or replace function interno.limpar_limites() returns void language sql as $$
  delete from limites_uso where janela_inicio < now() - interval '1 day'
$$;

-- ---------- UTILITÁRIOS ----------
create or replace function interno.so_digitos(t text) returns text
language sql immutable as $$ select regexp_replace(coalesce(t, ''), '\D', '', 'g') $$;

create or replace function interno.cpf_valido(p text) returns boolean
language plpgsql immutable as $$
declare c text := interno.so_digitos(p); s int; d1 int; d2 int; i int;
begin
  if length(c) <> 11 or c ~ '^(\d)\1{10}$' then return false; end if;
  s := 0; for i in 1..9 loop s := s + substr(c, i, 1)::int * (11 - i); end loop;
  d1 := (s * 10) % 11; if d1 = 10 then d1 := 0; end if;
  s := 0; for i in 1..10 loop s := s + substr(c, i, 1)::int * (12 - i); end loop;
  d2 := (s * 10) % 11; if d2 = 10 then d2 := 0; end if;
  return d1 = substr(c, 10, 1)::int and d2 = substr(c, 11, 1)::int;
end $$;

-- distância em linha reta (haversine), em km
create or replace function interno.distancia_km(lat1 float8, lng1 float8, lat2 float8, lng2 float8)
returns float8 language sql immutable as $$
  select 2 * 6371 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)))
$$;

-- rumo (0..360°) de um ponto a outro
create or replace function interno.rumo(lat1 float8, lng1 float8, lat2 float8, lng2 float8)
returns float8 language sql immutable as $$
  select mod(cast(degrees(atan2(
    sin(radians(lng2 - lng1)) * cos(radians(lat2)),
    cos(radians(lat1)) * sin(radians(lat2)) - sin(radians(lat1)) * cos(radians(lat2)) * cos(radians(lng2 - lng1))
  )) + 360 as numeric), 360)::float8
$$;

create or replace function interno.token() returns text
language sql volatile as $$ select replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '') $$;
