-- ============================================================
-- SEED — dados iniciais de EXEMPLO (ajuste antes de operar)
-- Rodar uma vez, depois das migrations.
-- ============================================================

-- regra de comissão padrão: 20% plataforma, sendo 3/2/1 para indicação (plataforma fica com 14%)
insert into regras_comissao (nome, prioridade, taxa_plataforma_pct, indicacao_n1_pct, indicacao_n2_pct, indicacao_n3_pct)
select 'Padrão nacional', 0, 20, 3, 2, 1
where not exists (select 1 from regras_comissao where nome = 'Padrão nacional');

-- cidade piloto de exemplo (troque nome/coordenadas/tarifas pela sua cidade real)
insert into cidades (nome, uf, slug, ativa, centro_lat, centro_lng, raio_atendimento_km, regras, regulamentacao)
values ('Cidade Piloto (EXEMPLO)', 'RJ', 'piloto', true, -22.9068, -43.1729, 40,
        '{"aceita_dinheiro": false}'::jsonb,
        'PREENCHER: lei/decreto municipal de transporte por aplicativo')
on conflict (slug) do nothing;

insert into cidade_categorias (cidade_id, categoria, habilitada, tarifa_base, preco_km, preco_minuto, tarifa_minima, taxa_cancelamento, multiplicador_maximo)
select c.id, x.categoria, true, x.base, x.km, x.minuto, x.minima, x.canc, 1.0
from cidades c
cross join (values
  ('ECONOMICO', 3.00, 1.60, 0.30,  8.00, 6.00),
  ('CONFORTO',  4.00, 2.10, 0.40, 11.00, 8.00),
  ('PREMIUM',   6.00, 3.00, 0.55, 18.00, 12.00)
) as x(categoria, base, km, minuto, minima, canc)
where c.slug = 'piloto'
on conflict (cidade_id, categoria) do nothing;
