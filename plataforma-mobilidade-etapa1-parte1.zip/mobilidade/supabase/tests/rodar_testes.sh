#!/bin/bash
# Cria um banco limpo, aplica tudo e roda os testes.
set -e
DB=${PGDATABASE:-mob_teste}
dropdb --if-exists "$DB" >/dev/null 2>&1 || true
createdb "$DB"
for f in supabase/tests/shim_supabase.sql supabase/migrations/0*.sql supabase/seed.sql; do
  psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null 2>&1 || { echo "ERRO aplicando $f"; psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f" 2>&1 | grep -i error | head; exit 1; }
done
PGDATABASE="$DB" node supabase/tests/testes.js
