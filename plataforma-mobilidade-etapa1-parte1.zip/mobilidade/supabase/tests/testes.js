// ============================================================
// TESTES DE PONTA A PONTA DO BANCO (PostgreSQL real)
// Cada ator (passageiro, motorista, admin, servidor) usa a SUA conexão,
// com o mesmo papel que teria no Supabase (authenticated / service_role).
// Testes de concorrência usam conexões em paralelo de verdade.
//
// Uso: PGHOST=... PGPORT=... PGUSER=... PGDATABASE=... node supabase/tests/testes.js
// ============================================================
const { Client } = require('pg');

let ok = 0, falhas = 0;
const resultados = [];
function check(cond, nome, extra) {
  if (cond) { ok++; resultados.push(['✔', nome]); }
  else { falhas++; resultados.push(['✘', nome + (extra !== undefined ? '  →  ' + JSON.stringify(extra) : '')]); }
}
async function secao(nome, fn) {
  resultados.push(['', '\n■ ' + nome]);
  try { await fn(); }
  catch (e) { falhas++; resultados.push(['✘', 'ERRO INESPERADO: ' + (e.message || e) + (e.detail ? ' | ' + e.detail : '')]); }
}

// ---------- conexões ----------
const conexoes = [];
async function conectar(uid, papel = 'authenticated') {
  const c = new Client();
  await c.connect();
  conexoes.push(c);
  if (papel === 'postgres') return c;
  await c.query(`select set_config('request.jwt.claim.sub', $1, false), set_config('request.jwt.claim.role', $2, false)`, [uid || '', papel]);
  await c.query(`set role ${papel}`);
  return c;
}
async function rpc(c, fn, args = {}) {
  const ks = Object.keys(args);
  const sql = `select public.${fn}(${ks.map((k, i) => `${k} => $${i + 1}`).join(', ')}) as r`;
  const r = await c.query(sql, ks.map(k => args[k]));
  return r.rows[0].r;
}
async function erroDe(p) {
  try { await p; return null; } catch (e) { return e.message; }
}
function cpf() {
  const n = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10));
  let s = n.reduce((a, d, i) => a + d * (10 - i), 0); let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0; n.push(d1);
  s = n.reduce((a, d, i) => a + d * (11 - i), 0); let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0; n.push(d2);
  return n.join('');
}
let telSeq = 900000000;
const tel = () => '219' + String(telSeq++).slice(-8);
const uuidv4 = () => require('crypto').randomUUID();
const placa = () => 'TST' + Math.floor(Math.random() * 10) + 'A' + String(Math.floor(Math.random() * 100)).padStart(2, '0');

// ponto de origem padrão e destino a ~6 km
const O = { lat: -22.9068, lng: -43.1729 };
const D = { lat: -22.9500, lng: -43.2100 };
function perto(km, angGraus = 0) {   // ponto a "km" da origem
  const r = km / 111;
  return { lat: O.lat + r * Math.cos(angGraus * Math.PI / 180), lng: O.lng + r * Math.sin(angGraus * Math.PI / 180) / Math.cos(O.lat * Math.PI / 180) };
}

(async () => {
  const pg = await conectar(null, 'postgres');
  const q = async (sql, p) => (await pg.query(sql, p)).rows;
  const CID = (await q(`select id from cidades where slug='piloto'`))[0].id;

  // ---------- helpers de cenário ----------
  async function novoUsuario(nome, { motorista = false, codigo = null, dispositivo = null } = {}) {
    const id = uuidv4();
    await q(`insert into auth.users (id, email) values ($1, $2)`, [id, id + '@teste.com']);
    const c = await conectar(id);
    const r = await rpc(c, 'completar_cadastro', {
      p_nome: nome, p_telefone: tel(), p_cpf: cpf(), p_email: id + '@teste.com', p_cidade: CID,
      p_quer_ser_motorista: motorista, p_codigo_indicacao: codigo, p_dispositivo: dispositivo || ('disp-' + id)
    });
    return { id, c, codigo: r.codigo_indicacao, nome };
  }
  let admin;
  async function aprovarMotorista(m, { nota = null, pos = perto(1) } = {}) {
    await rpc(m.c, 'motorista_salvar_dados', { p_cnh_numero: '12345678900', p_cnh_categoria: 'B', p_cnh_validade: '2030-01-01', p_cnh_ear: true, p_data_nascimento: '1985-05-05' });
    const v = (await rpc(m.c, 'motorista_cadastrar_veiculo', { p_marca: 'Fiat', p_modelo: 'Cronos', p_ano: 2022, p_placa: placa(), p_cor: 'Prata', p_capacidade: 4, p_acessivel: false, p_categorias: '{ECONOMICO,CONFORTO}' })).veiculo;
    m.veiculo = v;
    for (const t of ['CNH', 'SELFIE', 'ANTECEDENTES']) {
      const d = await rpc(m.c, 'motorista_enviar_documento', { p_dono_tipo: 'MOTORISTA', p_dono: m.id, p_tipo: t, p_arquivo_path: `${m.id}/${t}.jpg`, p_numero: null, p_validade: t === 'CNH' ? '2030-01-01' : null });
      await rpc(admin.c, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    for (const t of ['CRLV', 'SEGURO']) {
      const d = await rpc(m.c, 'motorista_enviar_documento', { p_dono_tipo: 'VEICULO', p_dono: v, p_tipo: t, p_arquivo_path: `${m.id}/${t}.pdf`, p_numero: null, p_validade: '2030-01-01' });
      await rpc(admin.c, 'ops_analisar_documento', { p_documento: d, p_aprovado: true });
    }
    await rpc(admin.c, 'ops_analisar_veiculo', { p_veiculo: v, p_aprovado: true, p_categorias: '{ECONOMICO,CONFORTO}' });
    await rpc(admin.c, 'ops_alterar_status_motorista', { p_motorista: m.id, p_status: 'ATIVO', p_motivo: 'Documentação aprovada' });
    if (nota !== null) await q(`update motoristas set avaliacao_media=$2 where id=$1`, [m.id, nota]);
    await rpc(m.c, 'ficar_online', { p_lat: pos.lat, p_lng: pos.lng });
    return m;
  }
  async function pedir(p, chave = uuidv4(), extra = {}) {
    return rpc(p.c, 'solicitar_corrida', Object.assign({
      p_chave_idempotencia: chave, p_cidade: CID, p_categoria: 'ECONOMICO',
      p_o_lat: O.lat, p_o_lng: O.lng, p_o_endereco: 'Origem', p_d_lat: D.lat, p_d_lng: D.lng, p_d_endereco: 'Destino',
      p_metodo: 'PIX', p_rota_km: null, p_rota_min: null
    }, extra));
  }
  async function ofertaDe(m) { return rpc(m.c, 'minha_oferta'); }
  async function offline(...ms) { for (const m of ms) await rpc(m.c, 'ficar_offline'); }
  async function online(m, pos = perto(1)) { await rpc(m.c, 'ficar_online', { p_lat: pos.lat, p_lng: pos.lng }); }
  // motorista chega ao embarque (GPS no ponto de origem) e marca "cheguei"
  async function chegar(m, corrida) {
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m.id, O.lat + 0.0005, O.lng]);
    return rpc(m.c, 'cheguei', { p_corrida: corrida });
  }
  const pinDe = async (corrida) => (await q(`select pin from corrida_segredos where corrida_id=$1`, [corrida]))[0].pin;
  // trilha GPS realista: pontos espaçados de minutos (como um celular de verdade mandaria)
  const ROTA = [[O.lat, O.lng], [-22.9165, -43.1800], [-22.9260, -43.1880], [-22.9360, -43.1970], [-22.9440, -43.2050], [D.lat, D.lng]];
  async function trilha(corrida, m, pontos = ROTA, minutosEntre = 3) {
    const n = pontos.length;
    for (let i = 0; i < n; i++) {
      await q(`insert into corrida_trilha (corrida_id, registrado_em, lat, lng, velocidade_kmh) values ($1, now() - make_interval(secs => $2), $3, $4, 30)`,
        [corrida, Math.round((n - 1 - i) * minutosEntre * 60), pontos[i][0], pontos[i][1]]);
    }
    const ult = pontos[n - 1];
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [m.id, ult[0], ult[1]]);
  }
  async function correrAteFinalizar(p, m, corrida, kmPassos = true) {
    const r = await ofertaDe(m);
    await rpc(m.c, 'aceitar_oferta', { p_oferta: r.oferta });
    await chegar(m, corrida);
    await rpc(m.c, 'iniciar_corrida', { p_corrida: corrida, p_pin: await pinDe(corrida) });
    await q(`update corridas set iniciada_em = now() - interval '15 minutes' where id=$1`, [corrida]);
    if (kmPassos) await trilha(corrida, m);
    return rpc(m.c, 'finalizar_corrida', { p_corrida: corrida, p_km_app: null });
  }
  const saldo = async (uid, conta) => Number((await q(`select interno.saldo($1::uuid, $2) s`, [uid, conta]))[0].s);
  const saldoPlat = async (conta) => Number((await q(`select interno.saldo(null, $1) s`, [conta]))[0].s);

  // ---------- admin ----------
  const adminId = uuidv4();
  await q(`insert into auth.users (id) values ($1)`, [adminId]);
  admin = { id: adminId, c: await conectar(adminId) };
  await rpc(admin.c, 'completar_cadastro', { p_nome: 'Admin Teste', p_telefone: tel(), p_cpf: cpf(), p_email: 'admin@teste.com', p_cidade: CID });
  await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'ADMIN'),($1,'OPERACOES'),($1,'FINANCEIRO'),($1,'RISCO'),($1,'SUPORTE') on conflict do nothing`, [adminId]);
  const servidor = await conectar(null, 'service_role');
  // para os testes, indicação vale desde a 1ª corrida e corrida curta conta
  await q(`update configuracoes set valor='0' where chave in ('indicacao_min_corridas_indicado','corrida_valida_min_minutos')`);

  // =====================================================================
  await secao('CADASTRO, LOGIN E VALIDAÇÕES', async () => {
    const id = uuidv4(); await q(`insert into auth.users (id) values ($1)`, [id]);
    const c = await conectar(id);
    check((await rpc(c, 'completar_cadastro', { p_nome: 'Fulano', p_telefone: tel(), p_cpf: '11111111111', p_email: 'a@a.com', p_cidade: CID })).erro === 'CPF_INVALIDO', 'CPF inválido é recusado');
    const meuCpf = cpf();
    await rpc(c, 'completar_cadastro', { p_nome: 'Fulano de Tal', p_telefone: tel(), p_cpf: meuCpf, p_email: 'a@a.com', p_cidade: CID });
    const id2 = uuidv4(); await q(`insert into auth.users (id) values ($1)`, [id2]);
    const c2 = await conectar(id2);
    check((await rpc(c2, 'completar_cadastro', { p_nome: 'Outro', p_telefone: tel(), p_cpf: meuCpf, p_email: 'b@b.com', p_cidade: CID })).erro === 'DADOS_JA_CADASTRADOS', 'CPF duplicado é recusado (mensagem genérica, sem revelar qual dado)');
    let ultimo;
    for (let i = 0; i < 6; i++) ultimo = await erroDe(rpc(c2, 'completar_cadastro', { p_nome: 'Outro', p_telefone: tel(), p_cpf: meuCpf, p_email: 'b@b.com', p_cidade: CID }));
    check(ultimo === 'LIMITE_EXCEDIDO', 'tentativas repetidas de cadastro são barradas (não dá para varrer CPFs)', ultimo);
    const perfil = await rpc(c, 'meu_perfil');
    check(perfil.perfil.nome === 'Fulano de Tal' && perfil.papeis.includes('PASSAGEIRO') && !('cpf' in perfil.perfil), 'perfil criado como PASSAGEIRO, CPF não volta inteiro (LGPD)');
    await rpc(c, 'registrar_acesso', { p_dispositivo: 'aparelho-1', p_plataforma: 'android' });
    const aud = await q(`select count(*)::int n from auditoria where ator_id=$1 and acao='LOGIN'`, [id]);
    check(aud[0].n >= 1, 'login registrado na auditoria');
    const anon = await conectar(null, 'anon');
    check((await erroDe(rpc(anon, 'solicitar_corrida', { p_chave_idempotencia: 'x'.repeat(10), p_cidade: CID, p_categoria: 'ECONOMICO', p_o_lat: 0, p_o_lng: 0, p_o_endereco: '', p_d_lat: 0, p_d_lng: 0, p_d_endereco: '', p_metodo: 'PIX' })) || '').includes('permission denied'), 'visitante sem login não pede corrida');
    const est = await rpc(anon, 'estimar_corrida', { p_cidade: CID, p_o_lat: O.lat, p_o_lng: O.lng, p_d_lat: D.lat, p_d_lng: D.lng });
    check(Array.isArray(est) && est.length === 3, 'visitante vê estimativa das 3 categorias', est && est.length);
  });

  // =====================================================================
  let P1, M1, M2, M3;
  await secao('MOTORISTA: CADASTRO, DOCUMENTOS E COMPLIANCE', async () => {
    M1 = await novoUsuario('Motorista Um', { motorista: true });
    check((await erroDe(rpc(M1.c, 'ficar_online', { p_lat: O.lat, p_lng: O.lng }))) === 'PENDENCIAS_DE_COMPLIANCE', 'sem documentos não fica online');
    const pend = (await rpc(M1.c, 'meu_perfil')).pendencias;
    check(pend.includes('CNH_VENCIDA') && pend.includes('SEM_VEICULO_ATIVO'), 'pendências listadas para o motorista', pend);
    check(await erroDe(rpc(M1.c, 'motorista_enviar_documento', { p_dono_tipo: 'MOTORISTA', p_dono: M1.id, p_tipo: 'CNH', p_arquivo_path: 'outro/cnh.jpg', p_numero: null, p_validade: '2030-01-01' })) === 'CAMINHO_ARQUIVO_INVALIDO', 'não aceita arquivo fora da pasta do próprio usuário');
    check(await erroDe(rpc(M1.c, 'ops_analisar_documento', { p_documento: uuidv4(), p_aprovado: true })) === 'SEM_PERMISSAO', 'motorista não aprova documento');
    await aprovarMotorista(M1, { nota: 3.0, pos: perto(0.5, 0) });
    const pres = (await q(`select online, disponivel, categorias from motorista_presenca where motorista_id=$1`, [M1.id]))[0];
    check(pres.online && pres.disponivel && pres.categorias.includes('ECONOMICO'), 'aprovado: fica online e liberado em ECONOMICO', pres);
    check((await rpc(M1.c, 'motorista_cadastrar_veiculo', { p_marca: 'X', p_modelo: 'Y', p_ano: 2020, p_placa: 'AB-12', p_cor: 'z', p_capacidade: 4, p_acessivel: false, p_categorias: '{ECONOMICO}' })).erro === 'PLACA_INVALIDA', 'placa inválida é recusada');
    const placaM1 = (await q(`select placa from veiculos where motorista_id=$1`, [M1.id]))[0].placa;
    const outroM = await novoUsuario('Clonador', { motorista: true });
    const dupl = await rpc(outroM.c, 'motorista_cadastrar_veiculo', { p_marca: 'X', p_modelo: 'Y', p_ano: 2020, p_placa: placaM1, p_cor: 'z', p_capacidade: 4, p_acessivel: false, p_categorias: '{ECONOMICO}' });
    const sinalPlaca = await q(`select count(*)::int n from sinais_fraude where entidade_id=$1 and tipo='PLACA_DUPLICADA'`, [outroM.id]);
    check(dupl.erro === 'PLACA_JA_CADASTRADA' && sinalPlaca[0].n === 1, 'placa de outro motorista: recusada E o sinal de risco fica gravado');
    check(await erroDe(rpc(M1.c, 'motorista_salvar_dados', { p_cnh_numero: '1', p_cnh_categoria: 'B', p_cnh_validade: '2035-01-01', p_cnh_ear: true, p_data_nascimento: '1985-05-05' })) === 'ALTERACAO_VIA_DOCUMENTO', 'motorista ativo não altera a própria CNH/EAR (só via documento + operação)');
    M2 = await aprovarMotorista(await novoUsuario('Motorista Dois', { motorista: true }), { nota: 5.0, pos: perto(1.0, 90) });
    M3 = await aprovarMotorista(await novoUsuario('Motorista Tres', { motorista: true }), { nota: 4.9, pos: perto(2.0, 180) });
    const aud = await q(`select count(*)::int n from auditoria where tabela='motoristas' and registro_id=$1`, [M1.id]);
    check(aud[0].n >= 2, 'mudanças de status do motorista ficaram na auditoria');
  });

  // =====================================================================
  let corrida1;
  await secao('CORRIDA COMPLETA + MATCHING INTELIGENTE', async () => {
    P1 = await novoUsuario('Passageira Um');
    const est = await rpc(P1.c, 'estimar_corrida', { p_cidade: CID, p_o_lat: O.lat, p_o_lng: O.lng, p_d_lat: D.lat, p_d_lng: D.lng, p_rota_km: 7.5, p_rota_min: 18 });
    const eco = est.find(e => e.categoria === 'ECONOMICO');
    check(Math.abs(eco.preco - (3 + 1.6 * 7.5 + 0.3 * 18)) < 0.01, 'preço = base + km + minuto (rota conferida)', eco.preco);
    check(eco.chegada_min >= 1 && eco.disponivel, 'estimativa de chegada calculada', eco.chegada_min);
    const fake = await rpc(P1.c, 'estimar_corrida', { p_cidade: CID, p_o_lat: O.lat, p_o_lng: O.lng, p_d_lat: D.lat, p_d_lng: D.lng, p_rota_km: 0.5, p_rota_min: 1 });
    check(fake[0].distancia_km > 5, 'rota falsa (menor que a linha reta) é ignorada pelo servidor', fake[0].distancia_km);

    const chave = uuidv4();
    const r1 = await pedir(P1, chave, { p_rota_km: 7.5, p_rota_min: 18 });
    corrida1 = r1.corrida;
    const r1b = await pedir(P1, chave, { p_rota_km: 7.5, p_rota_min: 18 });
    check(r1b.corrida === corrida1 && r1b.repetido, 'mesmo pedido repetido devolve a MESMA corrida (idempotência)');
    check(await erroDe(pedir(P1)) === 'JA_EXISTE_CORRIDA_ATIVA', 'passageiro não abre 2 corridas ao mesmo tempo');

    // M1 está mais perto (0,5 km) mas nota 3,0 → M2 (1 km, nota 5,0) deve vencer
    const of = await q(`select motorista_id, score, componentes from ofertas where corrida_id=$1 and status='PENDENTE'`, [corrida1]);
    check(of.length === 1 && of[0].motorista_id === M2.id, 'matching NÃO pegou só o mais perto: escolheu o de melhor score', of[0] && of[0].componentes);
    check(of[0] && ['eta_min', 'direcao', 'ocioso', 'qualidade', 'cancelamentos', 'aceite', 'risco', 'demanda_regiao'].every(k => k in of[0].componentes), 'score registra todos os componentes');

    const vis = await ofertaDe(M2);
    check(vis && vis.rentabilidade && 'resultado' in vis.rentabilidade && 'combustivel' in vis.rentabilidade && 'resultado_hora' in vis.rentabilidade,
      'motorista vê valor, distância, tempo, combustível, custos e resultado ANTES de aceitar', vis && vis.rentabilidade);
    const rt = vis.rentabilidade;
    check(Math.abs(rt.resultado - (rt.seu_ganho - rt.combustivel - rt.custos)) < 0.02, 'resultado = ganho − combustível − custos');
    check(!(await ofertaDe(M1)), 'outros motoristas não veem a oferta');
    const vistaM1 = await M1.c.query(`select count(*)::int n from corridas where id=$1`, [corrida1]);
    check(await erroDe(M2.c.query(`select pin from corrida_segredos where corrida_id=$1`, [corrida1])) !== null, 'motorista NÃO consegue ler o PIN no banco');
    check(!(await q(`select column_name from information_schema.columns where table_name='corridas' and column_name='pin'`)).length, 'PIN não fica na tabela de corridas (nem no realtime)');
    check(vistaM1.rows[0].n === 0, 'RLS: motorista de fora não enxerga a corrida');

    const ac = await rpc(M2.c, 'aceitar_oferta', { p_oferta: vis.oferta });
    check(ac.ok && ac.status === 'A_CAMINHO', 'aceite: corrida A_CAMINHO');
    const ac2 = await rpc(M2.c, 'aceitar_oferta', { p_oferta: vis.oferta });
    check(ac2.ok && ac2.repetido, 'clique duplo no aceitar não quebra');
    const acomp = await rpc(P1.c, 'acompanhar_corrida', { p_corrida: corrida1 });
    check(acomp.motorista && acomp.motorista.veiculo && acomp.motorista.veiculo.placa && acomp.pin, 'passageiro vê motorista, placa e PIN');

    await chegar(M2, corrida1);
    const errado = await rpc(M2.c, 'iniciar_corrida', { p_corrida: corrida1, p_pin: '0000' === acomp.pin ? '1111' : '0000' });
    check(errado.ok === false && errado.erro === 'PIN_INCORRETO', 'PIN errado não inicia a corrida');
    const tent = (await q(`select pin_tentativas from corrida_segredos where corrida_id=$1`, [corrida1]))[0].pin_tentativas;
    check(tent === 1, 'tentativa de PIN errado fica registrada');
    const certo = await rpc(M2.c, 'iniciar_corrida', { p_corrida: corrida1, p_pin: acomp.pin });
    check(certo.ok && certo.status === 'EM_CURSO', 'PIN certo: embarque');
    await q(`update corridas set iniciada_em = now() - interval '18 minutes' where id=$1`, [corrida1]);
    await trilha(corrida1, M2);
    const fin = await rpc(M2.c, 'finalizar_corrida', { p_corrida: corrida1, p_km_app: 50 });
    const c1 = (await q(`select * from corridas where id=$1`, [corrida1]))[0];
    const evFin = (await q(`select dados from corrida_eventos where corrida_id=$1 and tipo='FINALIZACAO'`, [corrida1]))[0].dados;
    check(fin.status === 'FINALIZADA' && evFin.fonte_km === 'TRILHA' && Number(c1.distancia_real_km) > 5 && Number(c1.distancia_real_km) < 9, 'km final veio da trilha GPS do servidor, não do app (app mandou 50 km)', [c1.distancia_real_km, evFin.fonte_km]);
    check(Number(c1.preco_final) === Number(c1.preco_estimado), 'preço previsível: dentro da tolerância, paga o estimado', [c1.preco_final, c1.preco_estimado]);
    check(fin.pagamento.status === 'PENDENTE' && fin.pagamento.metodo === 'PIX', 'pagamento PIX criado e pendente');
    const pres = (await q(`select disponivel from motorista_presenca where motorista_id=$1`, [M2.id]))[0];
    check(pres.disponivel, 'motorista volta a ficar disponível');

    const pag = await rpc(P1.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id });
    check(pag.status === 'CONFIRMADO', 'pagamento confirmado (simulador)');
    const st = (await q(`select status from corridas where id=$1`, [corrida1]))[0].status;
    check(st === 'PAGA', 'corrida PAGA');
    const pf = Number(c1.preco_final);
    check(Math.abs(await saldo(M2.id, 'MOTORISTA_PENDENTE') - (pf - Math.round(pf * 20) / 100)) < 0.01, 'motorista recebeu 80% em saldo PENDENTE');
    await rpc(P1.c, 'avaliar_corrida', { p_corrida: corrida1, p_nota: 5, p_comentario: 'Ótimo' });
    check(await erroDe(rpc(P1.c, 'avaliar_corrida', { p_corrida: corrida1, p_nota: 1 })) === 'JA_AVALIADA', 'avaliação só uma vez');
    const ev = (await q(`select tipo from corrida_eventos where corrida_id=$1 order by id`, [corrida1])).map(r => r.tipo);
    const fluxo = ['SOLICITACAO', 'OFERTA_ENVIADA', 'ACEITE', 'DESLOCAMENTO', 'CHEGADA', 'PIN_INCORRETO', 'EMBARQUE', 'FINALIZACAO', 'PAGAMENTO', 'AVALIACAO'];
    check(fluxo.every((t, i) => ev.indexOf(t) >= 0 && (i === 0 || ev.indexOf(t) > ev.indexOf(fluxo[i - 1]))), 'todos os eventos registrados, em ordem', ev);
    check(await erroDe(q(`update corrida_eventos set tipo='X' where corrida_id=$1`, [corrida1])) === 'REGISTRO_IMUTAVEL', 'histórico da corrida não pode ser alterado');
  });

  // =====================================================================
  await secao('RECUSA, EXPIRAÇÃO E REMATCHING', async () => {
    const P2 = await novoUsuario('Passageiro Dois');
    const r = await pedir(P2);
    let o = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r.corrida]))[0];
    const primeiro = [M1, M2, M3].find(m => m.id === o.motorista_id);
    await rpc(primeiro.c, 'recusar_oferta', { p_oferta: (await ofertaDe(primeiro)).oferta });
    o = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r.corrida]))[0];
    check(o && o.motorista_id !== primeiro.id, 'recusou → oferta vai na hora para outro motorista');
    const segundo = [M1, M2, M3].find(m => m.id === o.motorista_id);
    await q(`update ofertas set expira_em = now() - interval '1 second' where corrida_id=$1 and status='PENDENTE'`, [r.corrida]);
    await q(`select interno.job_matching()`);
    o = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r.corrida]))[0];
    check(o && o.motorista_id !== primeiro.id && o.motorista_id !== segundo.id, 'não respondeu a tempo → expira e vai para o terceiro');
    const terceiro = [M1, M2, M3].find(m => m.id === o.motorista_id);
    await rpc(terceiro.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(terceiro)).oferta });

    // motorista cancela depois de aceitar → rematching automático
    const can = await rpc(terceiro.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'Pneu furou' });
    check(can.status === 'BUSCANDO' && can.rematching, 'motorista cancelou → corrida volta para BUSCANDO automaticamente');
    const c = (await q(`select status, motorista_id, motoristas_excluidos from corridas where id=$1`, [r.corrida]))[0];
    check(c.motorista_id === null && c.motoristas_excluidos.includes(terceiro.id), 'motorista que cancelou não recebe a mesma corrida de novo');
    const notif = await q(`select count(*)::int n from notificacoes where usuario_id=$1 and titulo='Buscando outro motorista'`, [P2.id]);
    check(notif[0].n >= 1, 'passageiro avisado: "buscando outro motorista"');
    const canc = (await q(`select total_cancelamentos from motoristas where id=$1`, [terceiro.id]))[0].total_cancelamentos;
    check(canc === 1, 'cancelamento conta no histórico do motorista');
    // todos já foram excluídos → sem candidatos; passageiro cancela grátis
    const pc = await rpc(P2.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'Desisti' });
    check(pc.status === 'CANCELADA' && Number(pc.taxa) === 0, 'passageiro cancela sem taxa enquanto busca');
  });

  // =====================================================================
  await secao('CANCELAMENTO COM TAXA E PASSAGEIRO QUE NÃO APARECE', async () => {
    const P3 = await novoUsuario('Passageiro Tres');
    const r = await pedir(P3);
    const o = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r.corrida]))[0];
    const mot = [M1, M2, M3].find(x => x.id === o.motorista_id);
    await rpc(mot.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(mot)).oferta });
    await q(`update corridas set aceita_em = now() - interval '5 minutes' where id=$1`, [r.corrida]);
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [mot.id, O.lat + 0.002, O.lng]);  // veio vindo
    const pc = await rpc(P3.c, 'cancelar_corrida', { p_corrida: r.corrida, p_motivo: 'Mudei de ideia' });
    check(pc.status === 'CANCELADA' && Number(pc.taxa) === 6, 'cancelou depois da carência → taxa de cancelamento', pc);
    const tp = (await q(`select * from pagamentos where corrida_id=$1 and tipo='TAXA_CANCELAMENTO'`, [r.corrida]))[0];
    check(tp && Number(tp.valor) === 6, 'cobrança da taxa criada');
    const antes = await saldo(mot.id, 'MOTORISTA_PENDENTE');
    await rpc(P3.c, 'dev_simular_pagamento', { p_pagamento: tp.id });
    check(Math.abs(await saldo(mot.id, 'MOTORISTA_PENDENTE') - antes - 4.8) < 0.01, 'motorista recebe a taxa (menos a comissão)');

    const P4 = await novoUsuario('Passageiro Quatro');
    const r2 = await pedir(P4);
    const o2 = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r2.corrida]))[0];
    const mot2 = [M1, M2, M3].find(x => x.id === o2.motorista_id);
    await rpc(mot2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(mot2)).oferta });
    await chegar(mot2, r2.corrida);
    const cedo = await rpc(mot2.c, 'cancelar_corrida', { p_corrida: r2.corrida, p_motivo: 'PASSAGEIRO_NAO_APARECEU' });
    check(cedo.status === 'BUSCANDO', 'antes do tempo de espera, "não apareceu" vira cancelamento do motorista (rematching)');
    await rpc(P4.c, 'cancelar_corrida', { p_corrida: r2.corrida });
    const P5 = await novoUsuario('Passageiro Cinco');
    const r3 = await pedir(P5);
    const o3 = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r3.corrida]))[0];
    const mot3 = [M1, M2, M3].find(x => x.id === o3.motorista_id);
    await rpc(mot3.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(mot3)).oferta });
    await chegar(mot3, r3.corrida);
    await q(`update corridas set chegou_em = now() - interval '6 minutes' where id=$1`, [r3.corrida]);
    const ns = await rpc(mot3.c, 'cancelar_corrida', { p_corrida: r3.corrida, p_motivo: 'PASSAGEIRO_NAO_APARECEU' });
    const c3 = (await q(`select status, cancelado_por from corridas where id=$1`, [r3.corrida]))[0];
    check(ns.status === 'CANCELADA' && c3.cancelado_por === 'PASSAGEIRO' && Number(ns.taxa) === 6, 'esperou 5+ min → cancelamento por culpa do passageiro, com taxa');
  });

  // =====================================================================
  await secao('CONCORRÊNCIA (conexões em paralelo de verdade)', async () => {
    // 1) mesmo passageiro, 2 pedidos diferentes ao mesmo tempo → só 1 corrida
    const P6 = await novoUsuario('Passageiro Seis');
    const c6b = await conectar(P6.id);
    await offline(M1, M2, M3);
    const [a, b] = await Promise.allSettled([pedir(P6), pedir({ c: c6b })]);
    const n6 = (await q(`select count(*)::int n from corridas where passageiro_id=$1`, [P6.id]))[0].n;
    check(n6 === 1 && [a, b].filter(x => x.status === 'rejected').length === 1, '2 pedidos simultâneos → 1 corrida só', [a.status, b.status, n6]);
    const ativa = (await q(`select id from corridas where passageiro_id=$1`, [P6.id]))[0].id;
    await rpc(P6.c, 'cancelar_corrida', { p_corrida: ativa });

    // 2) mesma chave de idempotência em paralelo → 1 corrida
    const P7 = await novoUsuario('Passageiro Sete');
    const c7b = await conectar(P7.id), c7c = await conectar(P7.id);
    const k = uuidv4();
    const rs = await Promise.allSettled([pedir(P7, k), pedir({ c: c7b }, k), pedir({ c: c7c }, k)]);
    const n7 = (await q(`select count(*)::int n from corridas where passageiro_id=$1`, [P7.id]))[0].n;
    const ids7 = new Set(rs.filter(x => x.status === 'fulfilled').map(x => x.value.corrida));
    check(n7 === 1 && ids7.size === 1, '3 envios simultâneos com a mesma chave → 1 corrida', rs.map(x => x.status));
    const c7 = [...ids7][0];

    // 3) aceite x cancelamento ao mesmo tempo → estado final coerente
    await online(M1, perto(0.3));
    await q(`select interno.buscar_motorista($1)`, [c7]);
    const of7 = await ofertaDe(M1);
    const m1b = await conectar(M1.id);
    const [ra, rc] = await Promise.allSettled([rpc(m1b, 'aceitar_oferta', { p_oferta: of7.oferta }), rpc(c7b, 'cancelar_corrida', { p_corrida: c7 })]);
    const f7 = (await q(`select status, motorista_id from corridas where id=$1`, [c7]))[0];
    const pr = (await q(`select disponivel from motorista_presenca where motorista_id=$1`, [M1.id]))[0];
    check(f7.status === 'CANCELADA' && pr.disponivel === true, 'aceite e cancelamento simultâneos: corrida CANCELADA e motorista liberado', { f7, pr, ra: ra.status, rc: rc.status });

    // 4) dois motoristas: oferta é de um só; o outro não consegue aceitar
    const P8 = await novoUsuario('Passageiro Oito');
    await online(M2, perto(0.4));
    const r8 = await pedir(P8);
    const o8 = (await q(`select id, motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [r8.corrida]))[0];
    const dono = [M1, M2].find(m => m.id === o8.motorista_id), outro = [M1, M2].find(m => m.id !== o8.motorista_id);
    const [x1, x2, x3] = await Promise.allSettled([
      rpc(dono.c, 'aceitar_oferta', { p_oferta: o8.id }),
      rpc(await conectar(dono.id), 'aceitar_oferta', { p_oferta: o8.id }),
      rpc(outro.c, 'aceitar_oferta', { p_oferta: o8.id })]);
    const f8 = (await q(`select status, motorista_id from corridas where id=$1`, [r8.corrida]))[0];
    check(f8.motorista_id === dono.id && x3.status === 'rejected', 'outro motorista não rouba a oferta; duplo aceite do dono não duplica', [x1.status, x2.status, x3.status, x3.reason && x3.reason.message]);

    // 5) webhook repetido em paralelo → liquida 1 vez
    const mot8 = dono;
    await chegar(mot8, r8.corrida);
    const pin = await pinDe(r8.corrida);
    await rpc(mot8.c, 'iniciar_corrida', { p_corrida: r8.corrida, p_pin: pin });
    await q(`update corridas set iniciada_em = now() - interval '10 minutes' where id=$1`, [r8.corrida]);
    const fin = await rpc(mot8.c, 'finalizar_corrida', { p_corrida: r8.corrida });
    const antes = await saldo(mot8.id, 'MOTORISTA_PENDENTE');
    const svs = [servidor, await conectar(null, 'service_role'), await conectar(null, 'service_role'), await conectar(null, 'service_role')];
    const payload = { pagamento_id: fin.pagamento.id, gateway_ref: 'gw-123', valor: fin.pagamento.valor };
    const wh = await Promise.allSettled(svs.map((s, i) =>
      rpc(s, 'processar_webhook', { p_gateway: 'GW', p_evento_id: i < 2 ? 'evt-1' : 'evt-' + i, p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify(payload) })));
    const liq = (await q(`select count(*)::int n from transacoes_ledger where chave_idempotencia=$1`, ['LIQ:' + r8.corrida]))[0].n;
    const ganho = await saldo(mot8.id, 'MOTORISTA_PENDENTE') - antes;
    const esperado = Number(fin.preco_final) - Math.round(Number(fin.preco_final) * 20) / 100;
    check(liq === 1 && Math.abs(ganho - esperado) < 0.01, '4 webhooks simultâneos (2 iguais + 2 diferentes p/ o mesmo pagamento) → 1 liquidação só', { liq, ganho, esperado, st: wh.map(x => x.status) });
    const dup = await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'evt-1', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify(payload) });
    check(dup.duplicado === true, 'webhook repetido depois é reconhecido como duplicado');
    check((await erroDe(rpc(P8.c, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'hack', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify(payload) })) || '').includes('permission denied'), 'usuário comum não chama o webhook');

    // 6) saques simultâneos não passam do saldo
    await q(`update recebiveis set libera_em = now() - interval '1 minute' where motorista_id=$1`, [mot8.id]);
    await q(`select interno.job_liberar_saldos()`);
    const disp = await saldo(mot8.id, 'MOTORISTA_DISPONIVEL');
    const val = Math.max(20, Math.floor(disp * 0.6 * 100) / 100);
    const conns = [mot8.c, await conectar(mot8.id), await conectar(mot8.id)];
    const sq = await Promise.allSettled(conns.map(c => rpc(c, 'solicitar_repasse', { p_valor: val, p_chave_pix: 'pix@motorista.com', p_origem: 'GANHOS', p_chave_idempotencia: uuidv4() })));
    const okSaques = sq.filter(x => x.status === 'fulfilled').length;
    const depois = await saldo(mot8.id, 'MOTORISTA_DISPONIVEL');
    check(depois >= 0 && okSaques === Math.floor(disp / val), '3 saques simultâneos: só passam os que cabem no saldo', { disp, val, okSaques, depois });
  });

  // =====================================================================
  let A, B, C, Dm, corridaSuspeita;
  await secao('INDICAÇÃO 3 NÍVEIS + DIVISÃO DE R$ 100', async () => {
    await offline(M1, M2, M3);
    A = await aprovarMotorista(await novoUsuario('Ana Indicadora', { motorista: true }), { pos: perto(5) });
    B = await aprovarMotorista(await novoUsuario('Bruno', { motorista: true, codigo: A.codigo }), { pos: perto(5.2) });
    C = await aprovarMotorista(await novoUsuario('Carla', { motorista: true, codigo: B.codigo }), { pos: perto(5.4) });
    Dm = await aprovarMotorista(await novoUsuario('Diego', { motorista: true, codigo: C.codigo }), { pos: perto(0.2) });
    await offline(A, B, C);
    const cadeia = await q(`select nivel, beneficiario_id from interno.cadeia_indicacao($1)`, [Dm.id]);
    check(cadeia.length === 3 && cadeia[0].beneficiario_id === C.id && cadeia[1].beneficiario_id === B.id && cadeia[2].beneficiario_id === A.id, 'árvore: D → C (nível 1) → B (2) → A (3)');

    const P = await novoUsuario('Passageiro Indicação');
    const r = await pedir(P);
    const fin = await correrAteFinalizar(P, Dm, r.corrida);
    await q(`update corridas set preco_final = 100 where id=$1`, [r.corrida]);
    await q(`update pagamentos set valor = 100 where id=$1`, [fin.pagamento.id]);
    const ant = { gw: await saldoPlat('GATEWAY_RECEBIVEIS'), plat: await saldoPlat('PLATAFORMA_RECEITA') };
    await rpc(P.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id });
    const s = {
      D: await saldo(Dm.id, 'MOTORISTA_PENDENTE'), C: await saldo(C.id, 'INDICACAO_PENDENTE'),
      B: await saldo(B.id, 'INDICACAO_PENDENTE'), A: await saldo(A.id, 'INDICACAO_PENDENTE'),
      plat: await saldoPlat('PLATAFORMA_RECEITA') - ant.plat, gw: await saldoPlat('GATEWAY_RECEBIVEIS') - ant.gw
    };
    check(s.D === 80 && s.C === 3 && s.B === 2 && s.A === 1 && s.plat === 14 && s.gw === -100,
      'R$100: motorista 80 · C 3 · B 2 · A 1 · plataforma 14 · total 100', s);
    const g = await q(`select nivel, status, valor from ganhos_indicacao where corrida_id=$1 order by nivel`, [r.corrida]);
    check(g.length === 3 && g.every(x => x.status === 'PENDENTE'), 'bônus nascem PENDENTE (carência antes de liberar)');
    const rede = await rpc(A.c, 'minha_rede');
    check(rede.codigo === A.codigo && rede.por_nivel['1'] === 1 && rede.por_nivel['3'] === 1 && Number(rede.ganhos.pendente) === 1, 'A vê código, rede por nível e ganhos', rede.por_nivel);

    // muda a regra só para PREMIUM nesta cidade: resolver pega a mais específica
    await rpc(admin.c, 'admin_salvar_regra_comissao', { p_regra: JSON.stringify({ nome: 'Premium piloto', cidade_id: CID, categoria: 'PREMIUM', taxa_plataforma_pct: 15, indicacao_n1_pct: 2, indicacao_n2_pct: 1, indicacao_n3_pct: 0.5 }) });
    const reg = (await q(`select (interno.resolver_comissao($1,'PREMIUM',null)).taxa_plataforma_pct t, (interno.resolver_comissao($1,'ECONOMICO',null)).taxa_plataforma_pct e`, [CID]))[0];
    check(Number(reg.t) === 15 && Number(reg.e) === 20, 'comissão configurável por cidade/categoria (PREMIUM 15%, ECONÔMICO 20%)', reg);
    const audR = await q(`select count(*)::int n from auditoria where tabela='regras_comissao' and acao='INSERT'`);
    check(audR[0].n >= 1, 'mudança de comissão registrada na auditoria');
    check(await erroDe(rpc(Dm.c, 'admin_salvar_regra_comissao', { p_regra: JSON.stringify({ nome: 'hack', taxa_plataforma_pct: 0 }) })) === 'SEM_PERMISSAO', 'motorista não mexe em comissão');
    check(await erroDe(q(`insert into regras_comissao (nome, taxa_plataforma_pct, indicacao_n1_pct, indicacao_n2_pct, indicacao_n3_pct) values ('x',5,3,2,1)`)) !== null, 'banco não aceita indicação maior que a taxa da plataforma');
  });

  // =====================================================================
  await secao('ANTIFRAUDE NA INDICAÇÃO', async () => {
    const X = await novoUsuario('Xavier', { motorista: true });
    const vi = async (a, b) => (await q(`select interno.vincular_indicacao($1, $2) r`, [a, b]))[0].r;
    check(await vi(X.id, X.codigo) === 'AUTOINDICACAO', 'autoindicação bloqueada');
    check((await q(`select count(*)::int n from sinais_fraude where entidade_id=$1 and tipo='AUTOINDICACAO'`, [X.id]))[0].n === 1, 'tentativa de autoindicação fica registrada como sinal');
    check(await vi(A.id, Dm.codigo) === 'CICLO_INDICACAO', 'ciclo bloqueado (A não pode ser indicado por D, que está abaixo dele)');
    check(await erroDe(q(`insert into indicacoes (indicado_id, indicador_id, codigo_usado) values ($1,$2,'X')`, [B.id, C.id])) !== null, 'trava do banco impede ciclo/duplicidade mesmo por fora da função');
    check(await vi(Dm.id, A.codigo) === 'JA_POSSUI_INDICADOR', 'quem já tem indicador não troca');
    // conta relacionada: E usa o MESMO aparelho de B e o código de B
    const dispB = (await q(`select dispositivo_id from dispositivos where usuario_id=$1 limit 1`, [B.id]))[0].dispositivo_id;
    const E = await novoUsuario('Eduardo', { motorista: true, codigo: B.codigo, dispositivo: dispB });
    const ind = (await q(`select status from indicacoes where indicado_id=$1`, [E.id]))[0];
    const sinal = await q(`select tipo from sinais_fraude where entidade_id=$1`, [E.id]);
    check(ind.status === 'EM_ANALISE' && sinal.some(s => s.tipo === 'CONTA_RELACIONADA'), 'mesmo aparelho do indicador → indicação EM ANÁLISE + sinal de risco');
    const pE = (await q(`select status from perfis where id=$1`, [E.id]))[0];
    check(pE.status === 'ATIVO', 'NÃO bloqueou a conta automaticamente');

    // corrida "fabricada": passageiro no mesmo aparelho do motorista D → bônus RETIDO
    const dispD = (await q(`select dispositivo_id from dispositivos where usuario_id=$1 limit 1`, [Dm.id]))[0].dispositivo_id;
    const Pf = await novoUsuario('Passageiro Suspeito', { dispositivo: dispD });
    await online(Dm, perto(0.2));
    const r = await pedir(Pf);
    corridaSuspeita = r.corrida;
    const fin = await correrAteFinalizar(Pf, Dm, r.corrida);
    await rpc(Pf.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id });
    const g = await q(`select id, nivel, status, motivo from ganhos_indicacao where corrida_id=$1 order by nivel`, [r.corrida]);
    check(g.length === 3 && g.every(x => x.status === 'BLOQUEADO'), 'corrida com conta relacionada → bônus de indicação RETIDO (BLOQUEADO)', g);
    const retido = await saldoPlat('INDICACAO_RETIDA');
    check(retido > 0, 'valor retido fica em conta separada até decisão humana', retido);
    // risco libera um e nega outro
    await rpc(admin.c, 'risco_decidir_ganho_retido', { p_ganho: g[0].id, p_liberar: true, p_motivo: 'Família no mesmo celular, verificado' });
    await rpc(admin.c, 'risco_decidir_ganho_retido', { p_ganho: g[1].id, p_liberar: false, p_motivo: 'Não comprovado' });
    const g2 = await q(`select nivel, status from ganhos_indicacao where corrida_id=$1 order by nivel`, [r.corrida]);
    check(g2[0].status === 'PENDENTE' && g2[1].status === 'ESTORNADO', 'decisão humana: libera (PENDENTE) ou nega (ESTORNADO)');
    check(await erroDe(rpc(Dm.c, 'risco_decidir_ganho_retido', { p_ganho: g[2].id, p_liberar: true, p_motivo: 'eu mesmo' })) === 'SEM_PERMISSAO', 'motorista não decide o próprio bônus');
    // sinal: análise humana com ação
    const s1 = (await q(`select id from sinais_fraude where entidade_tipo='CORRIDA' and entidade_id=$1 and tipo='CONTA_RELACIONADA'`, [r.corrida]))[0];
    const dec = await rpc(admin.c, 'risco_decidir_sinal', { p_sinal: s1.id, p_confirmar: true, p_acao: 'NEGAR_BONUS', p_observacao: 'Corrida artificial confirmada' });
    check(dec.status === 'CONFIRMADO', 'Risco confirma o sinal e nega o bônus restante');
    const g3 = (await q(`select status from ganhos_indicacao where corrida_id=$1 and nivel=3`, [r.corrida]))[0];
    check(g3.status === 'ESTORNADO', 'bônus restante estornado pela decisão');
  });

  // =====================================================================
  await secao('CARTEIRA, LIBERAÇÃO D+N, SAQUE E ESTORNO', async () => {
    await q(`update recebiveis set libera_em = now() - interval '1 minute' where motorista_id=$1`, [Dm.id]);
    await q(`update ganhos_indicacao set libera_em = now() - interval '1 minute' where beneficiario_id in ($1,$2,$3)`, [A.id, B.id, C.id]);
    const lib = (await q(`select interno.job_liberar_saldos() r`))[0].r;
    check(lib.motorista >= 1 && lib.indicacao >= 3, 'job libera pendente → disponível', lib);
    const cartC = await rpc(C.c, 'minha_carteira');
    check(Number(cartC.indicacao_disponivel) >= 3 && Array.isArray(cartC.extrato) && cartC.extrato.length > 0, 'carteira mostra saldo e extrato', cartC.indicacao_disponivel);
    check(await erroDe(rpc(C.c, 'solicitar_repasse', { p_valor: 5, p_chave_pix: 'c@pix', p_origem: 'INDICACAO', p_chave_idempotencia: uuidv4() })) === 'VALOR_ABAIXO_DO_MINIMO', 'saque abaixo do mínimo recusado');

    const dispD = await saldo(Dm.id, 'MOTORISTA_DISPONIVEL');
    const k = uuidv4();
    const sq = await rpc(Dm.c, 'solicitar_repasse', { p_valor: 20, p_chave_pix: 'diego@pix', p_origem: 'GANHOS', p_chave_idempotencia: k });
    const sq2 = await rpc(Dm.c, 'solicitar_repasse', { p_valor: 20, p_chave_pix: 'diego@pix', p_origem: 'GANHOS', p_chave_idempotencia: k });
    check(sq2.repetido && sq2.id === sq.id && Math.abs(await saldo(Dm.id, 'MOTORISTA_DISPONIVEL') - (dispD - 20)) < 0.01, 'saque idempotente: repetir não saca 2 vezes');
    await rpc(servidor, 'fin_concluir_repasse', { p_repasse: sq.id, p_sucesso: false, p_gateway_ref: null, p_motivo: 'Chave PIX inválida' });
    check(Math.abs(await saldo(Dm.id, 'MOTORISTA_DISPONIVEL') - dispD) < 0.01, 'PIX de saída falhou → valor volta para o saldo');

    // estorno da corrida 1 (já liberada? não) → reverte tudo
    const pag = (await q(`select corrida_id from pagamentos where corrida_id=$1 and status='CONFIRMADO' and tipo='CORRIDA'`, [corrida1]))[0];
    const antesM2 = await saldo(M2.id, 'MOTORISTA_PENDENTE') + await saldo(M2.id, 'MOTORISTA_DISPONIVEL');
    const pf = Number((await q(`select preco_final from corridas where id=$1`, [corrida1]))[0].preco_final);
    check(await erroDe(rpc(M2.c, 'fin_estornar_corrida', { p_corrida: corrida1, p_motivo: 'x' })) === 'SEM_PERMISSAO', 'motorista não estorna');
    const est = await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: pag.corrida_id, p_motivo: 'Cobrança indevida' });
    const est2 = await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: pag.corrida_id, p_motivo: 'de novo' });
    const depoisM2 = await saldo(M2.id, 'MOTORISTA_PENDENTE') + await saldo(M2.id, 'MOTORISTA_DISPONIVEL');
    check(est.ok && est2.repetido && Math.abs((antesM2 - depoisM2) - (pf - Math.round(pf * 20) / 100)) < 0.01, 'estorno por transação reversora (e não duplica)', { antesM2, depoisM2 });
    const orig = (await q(`select count(*)::int n from lancamentos_ledger l join transacoes_ledger t on t.id=l.transacao_id where t.chave_idempotencia=$1`, ['LIQ:' + corrida1]))[0].n;
    check(orig > 0, 'lançamento original continua lá (nada apagado)');
    check(await erroDe(q(`delete from lancamentos_ledger where id = (select min(id) from lancamentos_ledger)`)) === 'REGISTRO_IMUTAVEL', 'ledger não deixa apagar');
    check(await erroDe(q(`update transacoes_ledger set descricao='x' where chave_idempotencia=$1`, ['LIQ:' + corrida1])) === 'REGISTRO_IMUTAVEL', 'ledger não deixa alterar');
    check(await erroDe(q(`delete from auditoria`)) === 'REGISTRO_IMUTAVEL', 'auditoria não deixa apagar');
  });

  // =====================================================================
  await secao('PAGAMENTO: VALOR DIVERGENTE E DINHEIRO', async () => {
    await offline(Dm);
    await online(M3, perto(0.3));
    const P = await novoUsuario('Passageiro Divergente');
    const r = await pedir(P);
    const fin = await correrAteFinalizar(P, M3, r.corrida);
    const res = await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'evt-div', p_tipo: 'PAGAMENTO_CONFIRMADO', p_payload: JSON.stringify({ pagamento_id: fin.pagamento.id, gateway_ref: 'x', valor: 1.00 }) });
    const st = (await q(`select status from pagamentos where id=$1`, [fin.pagamento.id]))[0].status;
    const s = await q(`select tipo from sinais_fraude where entidade_id=$1`, [fin.pagamento.id]);
    check(res.erro === 'VALOR_DIVERGENTE' && st === 'PENDENTE' && s.some(x => x.tipo === 'VALOR_DIVERGENTE'), 'gateway com valor diferente → não confirma e abre sinal');

    // cidade não aceita dinheiro → recusa; liga e testa
    const P2 = await novoUsuario('Passageiro Dinheiro');
    check(await erroDe(pedir(P2, uuidv4(), { p_metodo: 'DINHEIRO' })) === 'DINHEIRO_NAO_PERMITIDO_NA_CIDADE', 'dinheiro só onde a cidade permite');
    await q(`update cidades set regras = regras || '{"aceita_dinheiro": true}' where id=$1`, [CID]);
    const r2 = await pedir(P2, uuidv4(), { p_metodo: 'DINHEIRO' });
    const of2 = (await q(`select motorista_id, distancia_embarque_km from ofertas where corrida_id=$1 and status='PENDENTE'`, [r2.corrida]))[0];
    check(of2 && of2.motorista_id === M3.id && Number(of2.distancia_embarque_km) > 3, 'ninguém a 3 km → raio amplia na hora e acha motorista mais longe', of2);
    const antes = await saldo(M3.id, 'MOTORISTA_DISPONIVEL');
    const f2 = await correrAteFinalizar(P2, M3, r2.corrida);
    const pf = Number(f2.preco_final);
    const dif = await saldo(M3.id, 'MOTORISTA_DISPONIVEL') - antes;
    check(f2.pagamento.status === 'CONFIRMADO' && Math.abs(dif + Math.round(pf * 20) / 100) < 0.01, 'dinheiro: motorista fica devendo só a comissão (descontada dos próximos ganhos)', { dif, pf });
  });

  // =====================================================================
  await secao('SEGURANÇA DA VIAGEM', async () => {
    await online(M3, perto(0.3));
    const P = await novoUsuario('Passageira Segura');
    await rpc(P.c, 'salvar_contato_confianca', { p_nome: 'Mãe', p_telefone: '21999990000' });
    const r = await pedir(P);
    await rpc(M3.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M3)).oferta });
    const tok = await rpc(P.c, 'compartilhar_corrida', { p_corrida: r.corrida });
    const anon = await conectar(null, 'anon');
    const pub = await rpc(anon, 'ver_corrida_compartilhada', { p_token: tok });
    check(pub && pub.status === 'A_CAMINHO' && pub.veiculo && pub.veiculo.placa && !('pin' in pub), 'link de compartilhamento funciona sem login (sem expor PIN/CPF)');
    await chegar(M3, r.corrida);
    const pin = await pinDe(r.corrida);
    await rpc(M3.c, 'iniciar_corrida', { p_corrida: r.corrida, p_pin: pin });
    // duração anormal
    await q(`update corridas set iniciada_em = now() - interval '3 hours' where id=$1`, [r.corrida]);
    await rpc(M3.c, 'atualizar_localizacao', { p_lat: O.lat, p_lng: O.lng, p_rumo: 0, p_velocidade_kmh: 20 });
    const v = (await q(`select id, tipo, mensagem from verificacoes_seguranca where corrida_id=$1`, [r.corrida]))[0];
    check(v && v.tipo === 'DURACAO' && v.mensagem === 'Detectamos uma alteração inesperada. Está tudo bem?', 'duração anormal → pergunta "Está tudo bem?" (não presume perigo)', v);
    const ac = await rpc(P.c, 'acompanhar_corrida', { p_corrida: r.corrida });
    check(ac.verificacao && ac.verificacao.id === v.id, 'passageira vê a pergunta no app');
    await rpc(P.c, 'responder_verificacao', { p_verificacao: v.id, p_tudo_bem: true });
    check((await q(`select status from verificacoes_seguranca where id=$1`, [v.id]))[0].status === 'TUDO_BEM', 'respondeu "tudo bem" → encerra sem alarde');
    // desvio
    await q(`update corridas set iniciada_em = now() - interval '5 minutes' where id=$1`, [r.corrida]);
    await rpc(M3.c, 'atualizar_localizacao', { p_lat: -22.80, p_lng: -43.05, p_rumo: 0, p_velocidade_kmh: 40 });
    const vd = (await q(`select tipo from verificacoes_seguranca where corrida_id=$1 and tipo='DESVIO'`, [r.corrida]))[0];
    check(vd, 'desvio grande da rota → nova verificação');
    // emergência
    const inc = await rpc(P.c, 'acionar_emergencia', { p_corrida: r.corrida, p_lat: -22.8, p_lng: -43.05, p_descricao: 'Teste' });
    const i = (await q(`select gravidade from incidentes where id=$1`, [inc]))[0];
    const sms = await q(`select count(*)::int n from notificacoes where usuario_id=$1 and canal='SMS'`, [P.id]);
    const sup = await q(`select count(*)::int n from notificacoes where usuario_id=$1 and titulo='EMERGÊNCIA EM CORRIDA'`, [admin.id]);
    check(i.gravidade === 'CRITICA' && sms[0].n >= 1 && sup[0].n >= 1, 'emergência: incidente CRÍTICO + SMS ao contato de confiança + alerta ao suporte');
    // sem resposta vira atendimento humano
    await q(`update verificacoes_seguranca set criada_em = now() - interval '10 minutes' where corrida_id=$1 and status='AGUARDANDO'`, [r.corrida]);
    const n = (await q(`select interno.job_seguranca() n`))[0].n;
    check(n >= 1, 'pergunta sem resposta → incidente para o suporte ligar');
    await rpc(M3.c, 'finalizar_corrida', { p_corrida: r.corrida });
    // GPS impossível
    await rpc(M3.c, 'atualizar_localizacao', { p_lat: -22.9, p_lng: -43.17 });
    await rpc(M3.c, 'atualizar_localizacao', { p_lat: -23.5, p_lng: -46.6 });
    const gps = await q(`select count(*)::int n from sinais_fraude where entidade_id=$1 and tipo='GPS_INCONSISTENTE'`, [M3.id]);
    check(gps[0].n === 1, 'GPS "teletransportando" gera sinal de risco');
  });

  // =====================================================================
  await secao('PAINÉIS: MOTORISTA GERENTE FINANCEIRO E ADMIN', async () => {
    await rpc(Dm.c, 'salvar_custos', { p: JSON.stringify({ preco_combustivel: 6.2, consumo_km_l: 11, seguro_mes: 200, financiamento_mes: 900 }) });
    await rpc(Dm.c, 'lancar_custo', { p_data: new Date().toISOString().slice(0, 10), p_tipo: 'LAVAGEM', p_valor: 30 });
    const pnl = await rpc(Dm.c, 'painel_motorista');
    const campos = ['faturamento', 'combustivel', 'outros_custos', 'resultado_operacional', 'tempo_online_h', 'tempo_em_corrida_h', 'tempo_ocioso_h', 'resultado_hora'];
    check(campos.every(k => k in pnl) && pnl.faturamento > 0 && pnl.custos_configurados, 'painel HOJE com faturamento, custos, resultado e tempos', pnl);
    check(Math.abs(pnl.resultado_operacional - (pnl.faturamento - pnl.combustivel - pnl.outros_custos)) < 0.02, 'resultado = faturamento − combustível − outros custos');
    check(pnl.tempo_online_h >= pnl.tempo_em_corrida_h * 0 && pnl.tempo_ocioso_h >= 0, 'tempo ocioso calculado');
    const kpi = await rpc(admin.c, 'admin_indicadores', { p_inicio: new Date(Date.now() - 86400000).toISOString(), p_fim: new Date(Date.now() + 60000).toISOString(), p_cidade: CID });
    const k = ['passageiros_ativos', 'motoristas_online_agora', 'corridas', 'concluidas', 'canceladas', 'espera_media_min', 'chegada_media_min', 'ticket_medio', 'receita_plataforma', 'repasses_motoristas', 'margem_pct', 'incidentes', 'sinais_fraude', 'novos_usuarios', 'retencao_passageiros_pct', 'por_cidade'];
    check(k.every(x => x in kpi) && kpi.corridas > 5 && Number(kpi.receita_plataforma) > 0, 'painel admin com todos os indicadores', { corridas: kpi.corridas, receita: kpi.receita_plataforma, margem: kpi.margem_pct });
    check(await erroDe(rpc(P1.c, 'admin_indicadores', { p_inicio: '2020-01-01', p_fim: '2030-01-01' })) === 'SEM_PERMISSAO', 'passageiro não vê painel admin');
    const vis = await P1.c.query(`select count(*)::int n from auditoria`);
    check(vis.rows[0].n === 0, 'RLS: passageiro não lê auditoria');
    check((await erroDe(P1.c.query(`insert into corridas (chave_idempotencia) values ('x')`)) || '').includes('permission denied'), 'ninguém escreve direto nas tabelas (só pelas funções)');
    const minhas = await P1.c.query(`select count(*)::int n from notificacoes`);
    const todas = await q(`select count(*)::int n from notificacoes where usuario_id=$1`, [P1.id]);
    check(minhas.rows[0].n === todas[0].n && minhas.rows[0].n > 0, 'cada um só lê as próprias notificações');
  });

  // =====================================================================
  await secao('CORREÇÕES DA REVISÃO INDEPENDENTE (1 teste por achado)', async () => {
    await offline(M1, M2, M3, Dm);
    const so = async (m, pos = perto(0.3)) => { await offline(M1, M2, M3, Dm); await online(m, pos); };

    // 1) simulador de pagamento fechado por padrão
    await so(M2);
    const P = await novoUsuario('Passageiro Simulador');
    const r = await pedir(P);
    const fin = await correrAteFinalizar(P, M2, r.corrida);
    await q(`update configuracoes set valor='"produção"' where chave='ambiente'`);
    check(await erroDe(rpc(P.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id })) === 'INDISPONIVEL_EM_PRODUCAO', '#1 simulador fecha com qualquer valor diferente de desenvolvimento/homologação (ex.: "produção" com acento)');
    await q(`delete from configuracoes where chave='ambiente'`);
    check(await erroDe(rpc(P.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id })) === 'INDISPONIVEL_EM_PRODUCAO', '#1 simulador fecha se a configuração sumir');
    await q(`insert into configuracoes (chave, valor) values ('ambiente', '"homologacao"')`);
    check(await erroDe(rpc(P.c, 'dev_simular_pagamento', { p_pagamento: fin.pagamento.id })) === 'SEM_PERMISSAO', '#1 em homologação, passageiro não simula (só a equipe)');
    await q(`update configuracoes set valor='"desenvolvimento"' where chave='ambiente'`);

    // 5) pagamento em aberto bloqueia nova corrida; pagar de novo destrava
    await q(`update pagamentos set criado_em = now() - interval '1 hour' where id=$1`, [fin.pagamento.id]);
    check(await erroDe(pedir(P)) === 'PAGAMENTO_EM_ABERTO', '#5 PIX pendente antigo bloqueia pedir outra corrida');
    const novo = await rpc(P.c, 'pagar_novamente', { p_pagamento: fin.pagamento.id, p_metodo: 'PIX' });
    const velho = (await q(`select status from pagamentos where id=$1`, [fin.pagamento.id]))[0].status;
    check(novo.id !== fin.pagamento.id && velho === 'CANCELADO', '#5 nova cobrança criada, a antiga cancelada');
    await rpc(P.c, 'dev_simular_pagamento', { p_pagamento: novo.id });
    check((await q(`select status from corridas where id=$1`, [r.corrida]))[0].status === 'PAGA', '#5 pagou a nova cobrança → corrida PAGA');
    const r2 = await pedir(P);
    check(r2.corrida, '#5 depois de pagar, consegue pedir outra corrida');
    await rpc(P.c, 'cancelar_corrida', { p_corrida: r2.corrida });
    // falhou no gateway → bloqueia na hora → paga de novo
    const r3 = await pedir(P);
    await q(`select interno.buscar_motorista($1)`, [r3.corrida]);
    const f3 = await correrAteFinalizar(P, M2, r3.corrida);
    await rpc(servidor, 'processar_webhook', { p_gateway: 'GW', p_evento_id: 'falha-' + f3.pagamento.id, p_tipo: 'PAGAMENTO_FALHOU', p_payload: JSON.stringify({ pagamento_id: f3.pagamento.id, motivo: 'cartão recusado' }) });
    check(await erroDe(pedir(P)) === 'PAGAMENTO_EM_ABERTO', '#5 cobrança que FALHOU bloqueia nova corrida');
    const n3 = await rpc(P.c, 'pagar_novamente', { p_pagamento: f3.pagamento.id, p_metodo: 'PIX' });
    await rpc(P.c, 'dev_simular_pagamento', { p_pagamento: n3.id });
    check((await q(`select status from corridas where id=$1`, [r3.corrida]))[0].status === 'PAGA', '#5 cobrança que falhou tem caminho para ser paga');

    // 3) GPS falso não infla o preço
    const Pg = await novoUsuario('Passageiro GPS');
    const rg = await pedir(Pg);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await chegar(M2, rg.corrida);
    await rpc(M2.c, 'iniciar_corrida', { p_corrida: rg.corrida, p_pin: await pinDe(rg.corrida) });
    await q(`update corridas set iniciada_em = now() - interval '25 minutes' where id=$1`, [rg.corrida]);
    const zig = []; for (let i = 0; i < 48; i++) zig.push(i % 2 ? [O.lat + 0.009, O.lng] : [O.lat, O.lng]);   // 1 km pra lá e pra cá a cada 30s
    await trilha(rg.corrida, M2, zig.concat([[D.lat, D.lng]]), 0.5);
    const fg = await rpc(M2.c, 'finalizar_corrida', { p_corrida: rg.corrida, p_km_app: 80 });
    const cg = (await q(`select preco_final, preco_estimado, distancia_real_km from corridas where id=$1`, [rg.corrida]))[0];
    const sg = await q(`select severidade from sinais_fraude where entidade_id=$1 and tipo='DISTANCIA_ACIMA_DO_TETO'`, [rg.corrida]);
    check(Number(cg.preco_final) === Number(cg.preco_estimado) && sg.length === 1 && sg[0].severidade === 4, '#3 trilha GPS inflada (zigue-zague) → cobra o estimado e abre sinal grave', cg);
    await rpc(Pg.c, 'dev_simular_pagamento', { p_pagamento: fg.pagamento.id });
    await q(`update recebiveis set libera_em = now() - interval '1 minute' where corrida_id=$1`, [rg.corrida]);
    await q(`select interno.job_liberar_saldos()`);
    check((await q(`select status from recebiveis where corrida_id=$1`, [rg.corrida]))[0].status === 'PENDENTE', '#3 ganho dessa corrida fica RETIDO até análise');
    const Pt = await novoUsuario('Passageiro Teleporte');
    const rt = await pedir(Pt);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await chegar(M2, rt.corrida);
    await rpc(M2.c, 'iniciar_corrida', { p_corrida: rt.corrida, p_pin: await pinDe(rt.corrida) });
    await q(`update corridas set iniciada_em = now() - interval '15 minutes' where id=$1`, [rt.corrida]);
    await trilha(rt.corrida, M2, ROTA.slice(0, 3).concat([[-23.5, -46.6], [-22.9360, -43.1970]]).concat(ROTA.slice(4)), 0.05);  // salto para SP em 3 segundos
    await rpc(M2.c, 'finalizar_corrida', { p_corrida: rt.corrida });
    const kt = Number((await q(`select distancia_real_km from corridas where id=$1`, [rt.corrida]))[0].distancia_real_km);
    check(kt < 20, '#3 trechos com velocidade impossível são descartados do km', kt);
    await q(`update pagamentos set status='CANCELADO' where corrida_id=$1`, [rt.corrida]);   // limpa para não travar o passageiro

    // 4) só o passageiro responde "Está tudo bem?" e a pergunta não some ao finalizar
    const Ps = await novoUsuario('Passageira Verificação');
    const rs = await pedir(Ps);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await chegar(M2, rs.corrida);
    await rpc(M2.c, 'iniciar_corrida', { p_corrida: rs.corrida, p_pin: await pinDe(rs.corrida) });
    await q(`update corridas set iniciada_em = now() - interval '3 hours' where id=$1`, [rs.corrida]);
    await rpc(M2.c, 'atualizar_localizacao', { p_lat: O.lat + 0.001, p_lng: O.lng, p_rumo: 0, p_velocidade_kmh: 10 });
    const vs = (await q(`select id from verificacoes_seguranca where corrida_id=$1 and status='AGUARDANDO'`, [rs.corrida]))[0];
    check(vs && await erroDe(rpc(M2.c, 'responder_verificacao', { p_verificacao: vs.id, p_tudo_bem: true })) === 'NAO_ENCONTRADO', '#4 motorista NÃO responde "tudo bem" pela passageira');
    await q(`update corridas set iniciada_em = now() - interval '20 minutes' where id=$1`, [rs.corrida]);
    await rpc(M2.c, 'finalizar_corrida', { p_corrida: rs.corrida });
    check((await q(`select status from verificacoes_seguranca where id=$1`, [vs.id]))[0].status === 'AGUARDANDO', '#4 finalizar a corrida não apaga a pergunta aberta');
    await q(`update verificacoes_seguranca set criada_em = now() - interval '10 minutes' where id=$1`, [vs.id]);
    await q(`select interno.job_seguranca()`);
    check((await q(`select count(*)::int n from incidentes where corrida_id=$1 and tipo='ALERTA_AUTOMATICO'`, [rs.corrida]))[0].n >= 1, '#4 sem resposta → vira atendimento do suporte');
    await q(`update pagamentos set status='CANCELADO' where corrida_id=$1`, [rs.corrida]);

    // 6) estorno de corrida com bônus retido já decidido não vaza dinheiro
    const benef = await q(`select beneficiario_id, valor, status from ganhos_indicacao where corrida_id=$1`, [corridaSuspeita]);
    const totB = async (u) => await saldo(u, 'INDICACAO_PENDENTE') + await saldo(u, 'INDICACAO_DISPONIVEL');
    const antesB = {}; for (const b of benef) antesB[b.beneficiario_id] = await totB(b.beneficiario_id);
    const retAntes = await saldoPlat('INDICACAO_RETIDA');
    await rpc(admin.c, 'fin_estornar_corrida', { p_corrida: corridaSuspeita, p_motivo: 'Corrida artificial' });
    let vaz = false;
    for (const b of benef) {
      const dif = antesB[b.beneficiario_id] - await totB(b.beneficiario_id);
      if (['PENDENTE', 'DISPONIVEL', 'PAGO'].includes(b.status) && Math.abs(dif - Number(b.valor)) > 0.001) vaz = true;
      if (['BLOQUEADO', 'ESTORNADO'].includes(b.status) && Math.abs(dif) > 0.001) vaz = true;
    }
    const retDepois = await saldoPlat('INDICACAO_RETIDA');
    check(!vaz && retDepois >= 0 && retDepois <= retAntes, '#6 estorno tira cada bônus de onde ele está (nada sobra com o indicador, conta retida não fica negativa)', { benef, retAntes, retDepois });

    // 7) sinais não se perdem quando a operação dá erro → coberto em PLACA_DUPLICADA e AUTOINDICACAO acima
    // 8) varredura de CPF → coberto no teste de limite de cadastro acima

    // 9) "cheguei" só perto do embarque
    const Pc = await novoUsuario('Passageiro Cheguei');
    const rc = await pedir(Pc);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [M2.id, perto(5).lat, perto(5).lng]);
    check(await erroDe(rpc(M2.c, 'cheguei', { p_corrida: rc.corrida })) === 'LONGE_DO_EMBARQUE', '#9 "cheguei" a 5 km do embarque é recusado');
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() - interval '10 minutes' where motorista_id=$1`, [M2.id, O.lat, O.lng]);
    check(await erroDe(rpc(M2.c, 'cheguei', { p_corrida: rc.corrida })) === 'GPS_DESATUALIZADO', '#9 "cheguei" com GPS velho é recusado');
    // passageiro cancela e o motorista nem se mexeu → sem taxa
    await q(`update motorista_presenca set lat=$2, lng=$3, atualizado_em=now() where motorista_id=$1`, [M2.id, perto(0.3).lat, perto(0.3).lng]);
    await q(`update corridas set aceita_em = now() - interval '5 minutes' where id=$1`, [rc.corrida]);
    const cc = await rpc(Pc.c, 'cancelar_corrida', { p_corrida: rc.corrida, p_motivo: 'Demorou' });
    check(Number(cc.taxa) === 0, '#9 motorista parado → passageiro não paga taxa de cancelamento', cc);

    // 10) rematching zera o relógio da busca
    await online(M1, perto(0.6));
    const Pr = await novoUsuario('Passageiro Rematch');
    const rr = await pedir(Pr);
    const orr = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [rr.corrida]))[0];
    const mr = [M1, M2].find(m => m.id === orr.motorista_id), outro = [M1, M2].find(m => m.id !== orr.motorista_id);
    await rpc(mr.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(mr)).oferta });
    await q(`update corridas set solicitada_em = now() - interval '10 minutes', busca_iniciada_em = now() - interval '10 minutes' where id=$1`, [rr.corrida]);
    const cr = await rpc(mr.c, 'cancelar_corrida', { p_corrida: rr.corrida, p_motivo: 'Imprevisto' });
    const orr2 = (await q(`select motorista_id from ofertas where corrida_id=$1 and status='PENDENTE'`, [rr.corrida]))[0];
    check(cr.status === 'BUSCANDO' && orr2 && orr2.motorista_id === outro.id, '#10 motorista cancelou depois de 4+ min → busca recomeça (não vira "sem motorista")', cr);
    await rpc(Pr.c, 'cancelar_corrida', { p_corrida: rr.corrida });

    // 12) carteira não é gasta duas vezes
    await so(M2);
    const Pw = await novoUsuario('Passageiro Carteira');
    await q(`select interno.lancar('RECARGA', 'teste', $2, 'crédito de teste', jsonb_build_array(jsonb_build_object('conta','GATEWAY_RECEBIVEIS','valor',-100), jsonb_build_object('titular',$1::text,'conta','PASSAGEIRO_CARTEIRA','valor',100)))`, [Pw.id, 'rec-' + Pw.id]);
    const rw1 = await pedir(Pw, uuidv4(), { p_metodo: 'CARTEIRA' });
    await correrAteFinalizar(Pw, M2, rw1.corrida);
    const rw2 = await pedir(Pw, uuidv4(), { p_metodo: 'CARTEIRA' });
    await correrAteFinalizar(Pw, M2, rw2.corrida);
    const sobra = await saldo(Pw.id, 'PASSAGEIRO_CARTEIRA');
    const gorj = Math.floor(sobra * 0.7);
    const pw2 = await conectar(Pw.id);
    const gs = await Promise.allSettled([rpc(Pw.c, 'dar_gorjeta', { p_corrida: rw1.corrida, p_valor: gorj }), rpc(pw2, 'dar_gorjeta', { p_corrida: rw2.corrida, p_valor: gorj })]);
    const metodos = gs.filter(x => x.status === 'fulfilled').map(x => x.value.metodo || 'CARTEIRA');
    const sw = await saldo(Pw.id, 'PASSAGEIRO_CARTEIRA');
    check(sw >= 0 && Math.abs(sw - (sobra - gorj)) < 0.01, '#12 duas gorjetas simultâneas: só uma sai da carteira, a outra vai para PIX', { sobra, gorj, sw, metodos });
    check(await erroDe(q(`select interno.lancar('X','x',$2,'x', jsonb_build_array(jsonb_build_object('titular',$1::text,'conta','PASSAGEIRO_CARTEIRA','valor',-1000), jsonb_build_object('conta','PLATAFORMA_RECEITA','valor',1000)))`, [Pw.id, 'neg-' + Pw.id])) === 'SALDO_INSUFICIENTE', '#12 banco não deixa carteira do passageiro ficar negativa');

    // 13) ninguém aprova o próprio cadastro
    const S = await novoUsuario('Operador Motorista', { motorista: true });
    await q(`insert into usuario_papeis (usuario_id, papel) values ($1,'OPERACOES')`, [S.id]);
    const ds = await rpc(S.c, 'motorista_enviar_documento', { p_dono_tipo: 'MOTORISTA', p_dono: S.id, p_tipo: 'CNH', p_arquivo_path: `${S.id}/cnh.jpg`, p_numero: null, p_validade: '2030-01-01' });
    check(await erroDe(rpc(S.c, 'ops_analisar_documento', { p_documento: ds, p_aprovado: true })) === 'CONFLITO_DE_INTERESSE', '#13 operador não aprova o próprio documento');
    check(await erroDe(rpc(S.c, 'ops_alterar_status_motorista', { p_motorista: S.id, p_status: 'ATIVO', p_motivo: 'eu mesmo' })) === 'CONFLITO_DE_INTERESSE', '#13 operador não ativa a si mesmo');

    // 14) IP confiável
    await q(`select set_config('request.headers', $1, false)`, [JSON.stringify({ 'x-forwarded-for': '1.1.1.1, 9.9.9.9' })]);
    const ip1 = (await q(`select interno.ip_requisicao() ip`))[0].ip;
    await q(`select set_config('request.headers', $1, false)`, [JSON.stringify({ 'x-forwarded-for': '1.1.1.1, 9.9.9.9', 'cf-connecting-ip': '8.8.4.4' })]);
    const ip2 = (await q(`select interno.ip_requisicao() ip`))[0].ip;
    await q(`select set_config('request.headers', '', false)`);
    check(ip1 === '9.9.9.9' && ip2 === '8.8.4.4', '#14 IP vem do proxy confiável, não do que o cliente escreveu primeiro', [ip1, ip2]);

    // 15) jobs não são chamáveis pelos apps
    check((await erroDe(rpc(P.c, 'executar_jobs', { p_qual: 'rapido' })) || '').includes('permission denied'), '#15 usuário logado não dispara jobs');
    check((await erroDe(rpc(await conectar(null, 'anon'), 'executar_jobs', { p_qual: 'rapido' })) || '').includes('permission denied'), '#15 visitante não dispara jobs');

    // 16) passageiro não vê dados internos dos eventos
    check((await P.c.query(`select count(*)::int n from corrida_eventos`)).rows[0].n === 0, '#16 passageiro não lê eventos internos (score, divisão do dinheiro)');

    // 17) corridas travadas
    const Pk = await novoUsuario('Passageiro Travado');
    const rk = await pedir(Pk);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await q(`update corridas set aceita_em = now() - interval '10 minutes' where id=$1`, [rk.corrida]);
    await q(`update motorista_presenca set atualizado_em = now() - interval '10 minutes' where motorista_id=$1`, [M2.id]);
    await q(`select interno.job_corridas_travadas()`);
    const ck = (await q(`select status, motorista_id from corridas where id=$1`, [rk.corrida]))[0];
    const pk = (await q(`select online from motorista_presenca where motorista_id=$1`, [M2.id]))[0];
    check(ck.status === 'BUSCANDO' && ck.motorista_id === null && !pk.online, '#17 motorista sumiu (sem GPS) → corrida volta para busca e ele sai do ar', { ck, pk });
    await rpc(Pk.c, 'cancelar_corrida', { p_corrida: rk.corrida });
    await so(M2);
    const Pk2 = await novoUsuario('Passageiro Travado 2');
    const rk2 = await pedir(Pk2);
    await rpc(M2.c, 'aceitar_oferta', { p_oferta: (await ofertaDe(M2)).oferta });
    await chegar(M2, rk2.corrida);
    await rpc(M2.c, 'iniciar_corrida', { p_corrida: rk2.corrida, p_pin: await pinDe(rk2.corrida) });
    await q(`update corridas set iniciada_em = now() - interval '6 hours' where id=$1`, [rk2.corrida]);
    await q(`select interno.job_corridas_travadas()`);
    check((await q(`select count(*)::int n from incidentes where corrida_id=$1 and descricao like 'Corrida travada%'`, [rk2.corrida]))[0].n === 1, '#17 corrida EM CURSO muito além do previsto → incidente para o suporte');
    const sf = await rpc(admin.c, 'suporte_finalizar_corrida', { p_corrida: rk2.corrida, p_cobrar: true, p_motivo: 'App do motorista travou; viagem confirmada por telefone' });
    check(sf.status === 'FINALIZADA' && sf.pagamento && sf.pagamento.id, '#17 suporte encerra a corrida travada (com cobrança do estimado)');
    await q(`update pagamentos set status='CANCELADO' where corrida_id=$1`, [rk2.corrida]);

    // 18) arredondamento nunca deixa a receita da plataforma negativa
    await rpc(admin.c, 'admin_salvar_regra_comissao', { p_regra: JSON.stringify({ nome: 'Teste arredondamento', motorista_id: Dm.id, taxa_plataforma_pct: 6, indicacao_n1_pct: 2, indicacao_n2_pct: 2, indicacao_n3_pct: 2 }) });
    await so(Dm);
    const Pa = await novoUsuario('Passageiro Arredonda');
    const ra = await pedir(Pa);
    const fa = await correrAteFinalizar(Pa, Dm, ra.corrida);
    await q(`update corridas set preco_final = 10.25 where id=$1`, [ra.corrida]);
    await q(`update pagamentos set valor = 10.25 where id=$1`, [fa.pagamento.id]);
    await rpc(Pa.c, 'dev_simular_pagamento', { p_pagamento: fa.pagamento.id });
    const linhaPlat = await q(`select l.valor from lancamentos_ledger l join contas_ledger c on c.id=l.conta_id join transacoes_ledger t on t.id=l.transacao_id
                               where t.chave_idempotencia=$1 and c.tipo='PLATAFORMA_RECEITA'`, ['LIQ:' + ra.corrida]);
    const somaInd = (await q(`select coalesce(sum(valor),0) s from ganhos_indicacao where corrida_id=$1`, [ra.corrida]))[0].s;
    check(Number(somaInd) <= 0.62 && (!linhaPlat.length || Number(linhaPlat[0].valor) >= 0), '#18 indicação 2+2+2% de R$10,25 não passa dos 6% (R$0,62) da plataforma', { somaInd, plat: linhaPlat });
    await q(`update regras_comissao set ativa=false where nome='Teste arredondamento'`);

    // 19) promoção que atravessa a meia-noite
    await q(`insert into regras_comissao (nome, cidade_id, categoria, hora_inicio, hora_fim, taxa_plataforma_pct) values ('Madrugada', $1, 'CONFORTO', '22:00', '02:00', 12)`, [CID]);
    const em = async (ts) => Number((await q(`select (interno.resolver_comissao($1,'CONFORTO',null,$2::timestamptz)).taxa_plataforma_pct t`, [CID, ts]))[0].t);
    const [h1, h2, h3] = [await em('2026-10-03 23:30:00-03'), await em('2026-10-04 01:00:00-03'), await em('2026-10-03 12:00:00-03')];
    check(h1 === 12 && h2 === 12 && h3 === 20, '#19 regra das 22h às 2h vale às 23h30 e à 1h, e não ao meio-dia', [h1, h2, h3]);
  });

  // =====================================================================
  await secao('LIMITE DE ABUSO E INTEGRIDADE GERAL DO LEDGER', async () => {
    await online(M3, perto(0.3));
    let erro = null;
    for (let i = 0; i < 130 && !erro; i++) {
      erro = await erroDe(rpc(M3.c, 'atualizar_localizacao', { p_lat: -23.5 + i * 0.00001, p_lng: -46.6 }));
    }
    check(erro === 'LIMITE_EXCEDIDO', 'GPS acima de 120/min é barrado (proteção contra abuso)', erro);
    const tot = (await q(`select coalesce(sum(valor),0)::numeric s from lancamentos_ledger`))[0].s;
    check(Number(tot) === 0, 'soma de TODO o ledger = 0,00 (partidas dobradas)', tot);
    const desb = await q(`select transacao_id from lancamentos_ledger group by transacao_id having sum(valor) <> 0`);
    check(desb.length === 0, 'nenhuma transação desbalanceada');
    const sal = await q(`select c.id from contas_ledger c left join saldos s on s.conta_id=c.id
                         where coalesce(s.saldo,0) <> coalesce((select sum(valor) from lancamentos_ledger l where l.conta_id=c.id),0)`);
    check(sal.length === 0, 'saldos materializados batem com o ledger');
    check(await erroDe(q(`select interno.lancar('X','x','teste-desb','x','[{"conta":"PLATAFORMA_RECEITA","valor":10}]')`)) === 'LEDGER_DESBALANCEADO', 'banco recusa transação que não fecha em zero');
    // mesmo inserindo "por fora" das funções, o COMMIT é barrado
    const errCommit = await erroDe((async () => {
      await pg.query('begin');
      try {
        const t = (await pg.query(`insert into transacoes_ledger (tipo, chave_idempotencia) values ('X', 'por-fora-1') returning id`)).rows[0].id;
        await pg.query(`insert into lancamentos_ledger (transacao_id, conta_id, valor) values ($1, interno.conta(null,'PLATAFORMA_RECEITA'), 10)`, [t]);
        await pg.query('commit');
      } catch (e) { await pg.query('rollback').catch(() => {}); throw e; }
    })());
    check(errCommit === 'LEDGER_DESBALANCEADO', 'conferência de partidas dobradas barra o commit mesmo fora das funções', errCommit);
  });

  // ---------- relatório ----------
  for (const [s, n] of resultados) console.log(s ? `  ${s} ${n}` : n);
  console.log(`\n=========================================\n  ${ok} OK   ·   ${falhas} FALHA(S)\n=========================================`);
  for (const c of conexoes) await c.end().catch(() => {});
  process.exit(falhas ? 1 : 0);
})().catch(async e => { console.error('FALHA GERAL:', e); process.exit(2); });
